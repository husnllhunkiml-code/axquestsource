package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.dvs.versioning;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.block.implementation.Section;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.dvs.Pattern;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.dvs.Version;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/dvs/versioning/ManualVersioning.class */
public class ManualVersioning implements Versioning {
    private final Version documentVersion;
    private final Version defaultsVersion;
    private static transient /* synthetic */ String hmoamfJDfx = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public ManualVersioning(@NotNull Pattern pattern, @Nullable String str, @NotNull String str2) {
        this.documentVersion = str == null ? null : pattern.getVersion(str);
        this.defaultsVersion = pattern.getVersion(str2);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.dvs.versioning.Versioning
    @Nullable
    public Version getDocumentVersion(@NotNull Section section, boolean z) {
        return z ? this.defaultsVersion : this.documentVersion;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.dvs.versioning.Versioning
    @NotNull
    public Version getFirstVersion() {
        return this.defaultsVersion.getPattern().getFirstVersion();
    }

    public String toString() {
        return "ManualVersioning{documentVersion=" + this.documentVersion + ", defaultsVersion=" + this.defaultsVersion + '}';
    }
}
