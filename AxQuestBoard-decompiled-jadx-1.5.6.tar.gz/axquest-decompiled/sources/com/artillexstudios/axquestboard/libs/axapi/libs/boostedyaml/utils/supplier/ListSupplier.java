package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.utils.supplier;

import java.util.List;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/utils/supplier/ListSupplier.class */
public interface ListSupplier {
    @NotNull
    <T> List<T> supply(int i);
}
