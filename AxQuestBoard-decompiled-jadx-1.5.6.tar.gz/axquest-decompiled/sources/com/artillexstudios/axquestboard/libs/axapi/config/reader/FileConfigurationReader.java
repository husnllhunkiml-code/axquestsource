package com.artillexstudios.axquestboard.libs.axapi.config.reader;

import com.artillexstudios.axquestboard.libs.axapi.config.YamlConstructor;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapterHolder;
import com.artillexstudios.axquestboard.libs.axapi.config.annotation.Comment;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.DumperOptions;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.Yaml;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.comments.CommentLine;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.comments.CommentType;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.nodes.AnchorNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.nodes.MappingNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.nodes.Node;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.nodes.NodeTuple;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.nodes.Tag;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.reader.UnicodeReader;
import com.artillexstudios.axquestboard.libs.axapi.utils.UncheckedUtils;
import it.unimi.dsi.fastutil.Pair;
import java.io.InputStream;
import java.io.StringWriter;
import java.lang.annotation.Annotation;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/reader/FileConfigurationReader.class */
public final class FileConfigurationReader implements Handler {
    private final TypeAdapterHolder holder;
    private final YamlConstructor constructor;
    private final Yaml yaml;
    private static transient /* synthetic */ String iiMXVtuvpG = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public FileConfigurationReader(Yaml yaml, YamlConstructor constructor, TypeAdapterHolder holder) {
        this.holder = holder;
        this.constructor = constructor;
        this.yaml = yaml;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.config.reader.Handler
    public Pair<Map<String, Object>, Map<String, Comment>> read(InputStream stream, Object instance) {
        LinkedHashMap<String, Object> linkedHashMap = new LinkedHashMap<>();
        HashMap map = new HashMap();
        load("", (MappingNode) this.yaml.compose(new UnicodeReader(stream)), linkedHashMap, map);
        return Pair.of(linkedHashMap, map);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.config.reader.Handler
    public String write(Map<String, Object> contents, Map<String, Comment> comments) {
        StringWriter stringWriter = new StringWriter();
        this.yaml.serialize(map(contents, comments, ""), stringWriter);
        return stringWriter.toString();
    }

    private MappingNode map(Map<String, Object> map, Map<String, Comment> comments, String path) {
        Node nodeRepresent;
        ArrayList arrayList = new ArrayList();
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            Node nodeRepresent2 = this.yaml.represent(entry.getKey());
            Object value = entry.getValue();
            if (value instanceof Map) {
                nodeRepresent = map((Map) UncheckedUtils.unsafeCast((Map) value), comments, path.isEmpty() ? entry.getKey() : path + "." + entry.getKey());
            } else {
                nodeRepresent = this.yaml.represent(entry.getValue());
            }
            Comment comment = comments.get(path.isEmpty() ? entry.getKey() : path + "." + entry.getKey());
            if (comment != null) {
                ArrayList arrayList2 = new ArrayList();
                for (String str : comment.value().split("\n")) {
                    arrayList2.add(new CommentLine(null, null, str, comment.type() == Comment.CommentType.BLOCK ? CommentType.BLOCK : CommentType.IN_LINE));
                }
                if (comment.type() == Comment.CommentType.BLOCK) {
                    nodeRepresent2.setBlockComments(arrayList2);
                } else {
                    nodeRepresent2.setInLineComments(arrayList2);
                }
            }
            arrayList.add(new NodeTuple(nodeRepresent2, nodeRepresent));
        }
        return new MappingNode(Tag.MAP, arrayList, DumperOptions.FlowStyle.BLOCK);
    }

    private void load(String path, MappingNode node, LinkedHashMap<String, Object> map, Map<String, Comment> comments) {
        Node node2;
        if (node == null) {
            return;
        }
        this.constructor.flatten(node);
        for (NodeTuple nodeTuple : node.getValue()) {
            Node keyNode = nodeTuple.getKeyNode();
            String strValueOf = String.valueOf(this.constructor.construct(keyNode));
            Node valueNode = nodeTuple.getValueNode();
            while (true) {
                node2 = valueNode;
                if (!(node2 instanceof AnchorNode)) {
                    break;
                } else {
                    valueNode = ((AnchorNode) node2).getRealNode();
                }
            }
            String str = path.isEmpty() ? strValueOf : path + "." + strValueOf;
            if (node2 instanceof MappingNode) {
                LinkedHashMap<String, Object> linkedHashMap = new LinkedHashMap<>();
                map.put(strValueOf, linkedHashMap);
                load(strValueOf, (MappingNode) node2, linkedHashMap, comments);
            } else {
                map.put(strValueOf, this.constructor.construct(node2));
            }
            List<CommentLine> blockComments = keyNode.getBlockComments();
            if (blockComments != null) {
                final StringBuilder sb = new StringBuilder();
                for (int i = 0; i < blockComments.size(); i++) {
                    sb.append(blockComments.get(i).getValue());
                    if (i + 1 < blockComments.size()) {
                        sb.append('\n');
                    }
                }
                if (!sb.isEmpty()) {
                    comments.put(str, new Comment(this) { // from class: com.artillexstudios.axquestboard.libs.axapi.config.reader.FileConfigurationReader.1
                        private static transient /* synthetic */ String QeguZdqmPC = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

                        @Override // java.lang.annotation.Annotation
                        public Class<? extends Annotation> annotationType() {
                            return Comment.class;
                        }

                        @Override // com.artillexstudios.axquestboard.libs.axapi.config.annotation.Comment
                        public String value() {
                            return sb.toString();
                        }

                        @Override // com.artillexstudios.axquestboard.libs.axapi.config.annotation.Comment
                        public Comment.CommentType type() {
                            return Comment.CommentType.BLOCK;
                        }
                    });
                }
            }
            List<CommentLine> inLineComments = keyNode.getInLineComments();
            if (inLineComments != null) {
                final StringBuilder sb2 = new StringBuilder();
                for (int i2 = 0; i2 < inLineComments.size(); i2++) {
                    sb2.append(inLineComments.get(i2).getValue());
                    if (i2 + 1 < inLineComments.size()) {
                        sb2.append('\n');
                    }
                }
                if (!sb2.isEmpty()) {
                    comments.put(str, new Comment(this) { // from class: com.artillexstudios.axquestboard.libs.axapi.config.reader.FileConfigurationReader.2
                        private static transient /* synthetic */ String SOzqAqNygU = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

                        @Override // java.lang.annotation.Annotation
                        public Class<? extends Annotation> annotationType() {
                            return Comment.class;
                        }

                        @Override // com.artillexstudios.axquestboard.libs.axapi.config.annotation.Comment
                        public String value() {
                            return sb2.toString();
                        }

                        @Override // com.artillexstudios.axquestboard.libs.axapi.config.annotation.Comment
                        public Comment.CommentType type() {
                            return Comment.CommentType.INLINE;
                        }
                    });
                }
            }
        }
    }
}
