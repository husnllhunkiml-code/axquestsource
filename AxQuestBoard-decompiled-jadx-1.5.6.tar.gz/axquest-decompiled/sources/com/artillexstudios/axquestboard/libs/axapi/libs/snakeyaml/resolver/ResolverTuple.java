package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.resolver;

import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.nodes.Tag;
import java.util.regex.Pattern;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/resolver/ResolverTuple.class */
final class ResolverTuple {
    private final Tag tag;
    private final Pattern regexp;
    private final int limit;
    private static transient /* synthetic */ String tFoWnurgLT = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public ResolverTuple(Tag tag, Pattern pattern, int i) {
        this.tag = tag;
        this.regexp = pattern;
        this.limit = i;
    }

    public Tag getTag() {
        return this.tag;
    }

    public Pattern getRegexp() {
        return this.regexp;
    }

    public int getLimit() {
        return this.limit;
    }

    public String toString() {
        return "Tuple tag=" + this.tag + " regexp=" + this.regexp + " limit=" + this.limit;
    }
}
