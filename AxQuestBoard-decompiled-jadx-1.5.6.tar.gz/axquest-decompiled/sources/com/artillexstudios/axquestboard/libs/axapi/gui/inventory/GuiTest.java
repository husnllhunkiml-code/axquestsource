package com.artillexstudios.axquestboard.libs.axapi.gui.inventory;

import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.provider.implementation.AsyncGuiItemProvider;
import com.artillexstudios.axquestboard.libs.axapi.items.WrappedItemStack;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/gui/inventory/GuiTest.class */
public class GuiTest {
    private static transient /* synthetic */ String rjLUgEdrpQ = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public static void test() {
        GuiBuilder.createDynamic().title(hashMapContext -> {
            return Component.text("oreo");
        }).rows(6).build((Player) null).setItem(0, new AsyncGuiItemProvider(new GuiItem(hashMapContext2 -> {
            return WrappedItemStack.wrap(new ItemStack(Material.STONE));
        }, (hashMapContext3, inventoryClickEvent) -> {
        })));
    }
}
