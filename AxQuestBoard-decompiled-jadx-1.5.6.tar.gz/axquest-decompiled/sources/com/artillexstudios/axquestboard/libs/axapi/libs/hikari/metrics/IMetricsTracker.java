package com.artillexstudios.axquestboard.libs.axapi.libs.hikari.metrics;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/hikari/metrics/IMetricsTracker.class */
public interface IMetricsTracker extends AutoCloseable {
    default void recordConnectionCreatedMillis(long connectionCreatedMillis) {
    }

    default void recordConnectionAcquiredNanos(long elapsedAcquiredNanos) {
    }

    default void recordConnectionUsageMillis(long elapsedBorrowedMillis) {
    }

    default void recordConnectionTimeout() {
    }

    @Override // java.lang.AutoCloseable
    default void close() {
    }
}
