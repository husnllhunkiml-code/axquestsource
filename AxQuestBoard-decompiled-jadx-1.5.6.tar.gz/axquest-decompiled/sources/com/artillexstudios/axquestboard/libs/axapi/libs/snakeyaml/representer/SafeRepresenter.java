package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.representer;

import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.DumperOptions;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.error.YAMLException;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.external.biz.base64Coder.Base64Coder;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.nodes.Node;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.nodes.Tag;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.reader.StreamReader;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.UUID;
import java.util.regex.Pattern;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/representer/SafeRepresenter.class */
class SafeRepresenter extends BaseRepresenter {
    protected Map<Class<? extends Object>, Tag> classTags;
    protected TimeZone timeZone = null;
    protected DumperOptions.NonPrintableStyle nonPrintableStyle;
    private static final Pattern MULTILINE_PATTERN = Pattern.compile("\n|\u0085|\u2028|\u2029");
    private static transient /* synthetic */ String YylJXbfEiP = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public SafeRepresenter(DumperOptions dumperOptions) {
        if (dumperOptions == null) {
            throw new NullPointerException("DumperOptions must be provided.");
        }
        this.nullRepresenter = new RepresentNull();
        this.representers.put(String.class, new RepresentString());
        this.representers.put(Boolean.class, new RepresentBoolean());
        this.representers.put(Character.class, new RepresentString());
        this.representers.put(UUID.class, new RepresentUuid());
        this.representers.put(byte[].class, new RepresentByteArray());
        RepresentPrimitiveArray representPrimitiveArray = new RepresentPrimitiveArray();
        this.representers.put(short[].class, representPrimitiveArray);
        this.representers.put(int[].class, representPrimitiveArray);
        this.representers.put(long[].class, representPrimitiveArray);
        this.representers.put(float[].class, representPrimitiveArray);
        this.representers.put(double[].class, representPrimitiveArray);
        this.representers.put(char[].class, representPrimitiveArray);
        this.representers.put(boolean[].class, representPrimitiveArray);
        this.multiRepresenters.put(Number.class, new RepresentNumber());
        this.multiRepresenters.put(List.class, new RepresentList());
        this.multiRepresenters.put(Map.class, new RepresentMap());
        this.multiRepresenters.put(Set.class, new RepresentSet());
        this.multiRepresenters.put(Iterator.class, new RepresentIterator());
        this.multiRepresenters.put(new Object[0].getClass(), new RepresentArray());
        this.multiRepresenters.put(Date.class, new RepresentDate());
        this.multiRepresenters.put(Enum.class, new RepresentEnum());
        this.multiRepresenters.put(Calendar.class, new RepresentDate());
        this.classTags = new HashMap();
        this.nonPrintableStyle = dumperOptions.getNonPrintableStyle();
        setDefaultScalarStyle(dumperOptions.getDefaultScalarStyle());
        setDefaultFlowStyle(dumperOptions.getDefaultFlowStyle());
    }

    protected Tag getTag(Class<?> cls, Tag tag) {
        if (this.classTags.containsKey(cls)) {
            return this.classTags.get(cls);
        }
        return tag;
    }

    public Tag addClassTag(Class<? extends Object> cls, Tag tag) {
        if (tag == null) {
            throw new NullPointerException("Tag must be provided.");
        }
        return this.classTags.put(cls, tag);
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/representer/SafeRepresenter$RepresentNull.class */
    protected class RepresentNull implements Represent {
        private static transient /* synthetic */ String CUvikuFLkz = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        protected RepresentNull() {
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.representer.Represent
        public Node representData(Object obj) {
            return SafeRepresenter.this.representScalar(Tag.NULL, "null");
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/representer/SafeRepresenter$RepresentString.class */
    protected class RepresentString implements Represent {
        private static transient /* synthetic */ String fBaBXUDosW = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        protected RepresentString() {
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.representer.Represent
        public Node representData(Object obj) {
            Tag tag = Tag.STR;
            DumperOptions.ScalarStyle scalarStyle = SafeRepresenter.this.defaultScalarStyle;
            String string = obj.toString();
            if (SafeRepresenter.this.nonPrintableStyle == DumperOptions.NonPrintableStyle.BINARY && !StreamReader.isPrintable(string)) {
                tag = Tag.BINARY;
                byte[] bytes = string.getBytes(StandardCharsets.UTF_8);
                if (!new String(bytes, StandardCharsets.UTF_8).equals(string)) {
                    throw new YAMLException("invalid string value has occurred");
                }
                string = String.valueOf(Base64Coder.encode(bytes));
                scalarStyle = DumperOptions.ScalarStyle.LITERAL;
            }
            if (SafeRepresenter.this.defaultScalarStyle == DumperOptions.ScalarStyle.PLAIN && SafeRepresenter.MULTILINE_PATTERN.matcher(string).find()) {
                scalarStyle = DumperOptions.ScalarStyle.LITERAL;
            }
            return SafeRepresenter.this.representScalar(tag, string, scalarStyle);
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/representer/SafeRepresenter$RepresentBoolean.class */
    protected class RepresentBoolean implements Represent {
        private static transient /* synthetic */ String LFvySjBFaY = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        protected RepresentBoolean() {
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.representer.Represent
        public Node representData(Object obj) {
            String str;
            if (Boolean.TRUE.equals(obj)) {
                str = "true";
            } else {
                str = "false";
            }
            return SafeRepresenter.this.representScalar(Tag.BOOL, str);
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/representer/SafeRepresenter$RepresentNumber.class */
    protected class RepresentNumber implements Represent {
        private static transient /* synthetic */ String BOTfFXMDOn = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        protected RepresentNumber() {
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.representer.Represent
        public Node representData(Object obj) {
            Tag tag;
            String string;
            if ((obj instanceof Byte) || (obj instanceof Short) || (obj instanceof Integer) || (obj instanceof Long) || (obj instanceof BigInteger)) {
                tag = Tag.INT;
                string = obj.toString();
            } else {
                Number number = (Number) obj;
                tag = Tag.FLOAT;
                if (number.equals(Double.valueOf(Double.NaN))) {
                    string = ".NaN";
                } else if (number.equals(Double.valueOf(Double.POSITIVE_INFINITY))) {
                    string = ".inf";
                } else if (number.equals(Double.valueOf(Double.NEGATIVE_INFINITY))) {
                    string = "-.inf";
                } else {
                    string = number.toString();
                }
            }
            return SafeRepresenter.this.representScalar(SafeRepresenter.this.getTag(obj.getClass(), tag), string);
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/representer/SafeRepresenter$RepresentList.class */
    protected class RepresentList implements Represent {
        private static transient /* synthetic */ String rSSiCWstMQ = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        protected RepresentList() {
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.representer.Represent
        public Node representData(Object obj) {
            return SafeRepresenter.this.representSequence(SafeRepresenter.this.getTag(obj.getClass(), Tag.SEQ), (List) obj, DumperOptions.FlowStyle.AUTO);
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/representer/SafeRepresenter$RepresentIterator.class */
    protected class RepresentIterator implements Represent {
        private static transient /* synthetic */ String PkvqMHYlSe = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        protected RepresentIterator() {
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.representer.Represent
        public Node representData(Object obj) {
            return SafeRepresenter.this.representSequence(SafeRepresenter.this.getTag(obj.getClass(), Tag.SEQ), new IteratorWrapper((Iterator) obj), DumperOptions.FlowStyle.AUTO);
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/representer/SafeRepresenter$IteratorWrapper.class */
    private static class IteratorWrapper implements Iterable<Object> {
        private final Iterator<Object> iter;
        private static transient /* synthetic */ String JWRLmDFHfU = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        public IteratorWrapper(Iterator<Object> it) {
            this.iter = it;
        }

        @Override // java.lang.Iterable
        public Iterator<Object> iterator() {
            return this.iter;
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/representer/SafeRepresenter$RepresentArray.class */
    protected class RepresentArray implements Represent {
        private static transient /* synthetic */ String wECxdcRTvY = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        protected RepresentArray() {
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.representer.Represent
        public Node representData(Object obj) {
            return SafeRepresenter.this.representSequence(Tag.SEQ, Arrays.asList((Object[]) obj), DumperOptions.FlowStyle.AUTO);
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/representer/SafeRepresenter$RepresentPrimitiveArray.class */
    protected class RepresentPrimitiveArray implements Represent {
        private static transient /* synthetic */ String TGHjedkizu = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        protected RepresentPrimitiveArray() {
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.representer.Represent
        public Node representData(Object obj) {
            Class<?> componentType = obj.getClass().getComponentType();
            if (Byte.TYPE == componentType) {
                return SafeRepresenter.this.representSequence(Tag.SEQ, asByteList(obj), DumperOptions.FlowStyle.AUTO);
            }
            if (Short.TYPE == componentType) {
                return SafeRepresenter.this.representSequence(Tag.SEQ, asShortList(obj), DumperOptions.FlowStyle.AUTO);
            }
            if (Integer.TYPE == componentType) {
                return SafeRepresenter.this.representSequence(Tag.SEQ, asIntList(obj), DumperOptions.FlowStyle.AUTO);
            }
            if (Long.TYPE == componentType) {
                return SafeRepresenter.this.representSequence(Tag.SEQ, asLongList(obj), DumperOptions.FlowStyle.AUTO);
            }
            if (Float.TYPE == componentType) {
                return SafeRepresenter.this.representSequence(Tag.SEQ, asFloatList(obj), DumperOptions.FlowStyle.AUTO);
            }
            if (Double.TYPE == componentType) {
                return SafeRepresenter.this.representSequence(Tag.SEQ, asDoubleList(obj), DumperOptions.FlowStyle.AUTO);
            }
            if (Character.TYPE == componentType) {
                return SafeRepresenter.this.representSequence(Tag.SEQ, asCharList(obj), DumperOptions.FlowStyle.AUTO);
            }
            if (Boolean.TYPE == componentType) {
                return SafeRepresenter.this.representSequence(Tag.SEQ, asBooleanList(obj), DumperOptions.FlowStyle.AUTO);
            }
            throw new YAMLException("Unexpected primitive '" + componentType.getCanonicalName() + "'");
        }

        private List<Byte> asByteList(Object obj) {
            byte[] bArr = (byte[]) obj;
            ArrayList arrayList = new ArrayList(bArr.length);
            for (byte b : bArr) {
                arrayList.add(Byte.valueOf(b));
            }
            return arrayList;
        }

        private List<Short> asShortList(Object obj) {
            short[] sArr = (short[]) obj;
            ArrayList arrayList = new ArrayList(sArr.length);
            for (short s : sArr) {
                arrayList.add(Short.valueOf(s));
            }
            return arrayList;
        }

        private List<Integer> asIntList(Object obj) {
            int[] iArr = (int[]) obj;
            ArrayList arrayList = new ArrayList(iArr.length);
            for (int i : iArr) {
                arrayList.add(Integer.valueOf(i));
            }
            return arrayList;
        }

        private List<Long> asLongList(Object obj) {
            long[] jArr = (long[]) obj;
            ArrayList arrayList = new ArrayList(jArr.length);
            for (long j : jArr) {
                arrayList.add(Long.valueOf(j));
            }
            return arrayList;
        }

        private List<Float> asFloatList(Object obj) {
            float[] fArr = (float[]) obj;
            ArrayList arrayList = new ArrayList(fArr.length);
            for (float f : fArr) {
                arrayList.add(Float.valueOf(f));
            }
            return arrayList;
        }

        private List<Double> asDoubleList(Object obj) {
            double[] dArr = (double[]) obj;
            ArrayList arrayList = new ArrayList(dArr.length);
            for (double d : dArr) {
                arrayList.add(Double.valueOf(d));
            }
            return arrayList;
        }

        private List<Character> asCharList(Object obj) {
            char[] cArr = (char[]) obj;
            ArrayList arrayList = new ArrayList(cArr.length);
            for (char c : cArr) {
                arrayList.add(Character.valueOf(c));
            }
            return arrayList;
        }

        private List<Boolean> asBooleanList(Object obj) {
            boolean[] zArr = (boolean[]) obj;
            ArrayList arrayList = new ArrayList(zArr.length);
            for (boolean z : zArr) {
                arrayList.add(Boolean.valueOf(z));
            }
            return arrayList;
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/representer/SafeRepresenter$RepresentMap.class */
    protected class RepresentMap implements Represent {
        private static transient /* synthetic */ String jGcaBMuXyt = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        protected RepresentMap() {
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.representer.Represent
        public Node representData(Object obj) {
            return SafeRepresenter.this.representMapping(SafeRepresenter.this.getTag(obj.getClass(), Tag.MAP), (Map) obj, DumperOptions.FlowStyle.AUTO);
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/representer/SafeRepresenter$RepresentSet.class */
    protected class RepresentSet implements Represent {
        private static transient /* synthetic */ String nTXWUzCcYg = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        protected RepresentSet() {
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.representer.Represent
        public Node representData(Object obj) {
            LinkedHashMap linkedHashMap = new LinkedHashMap();
            Iterator it = ((Set) obj).iterator();
            while (it.hasNext()) {
                linkedHashMap.put(it.next(), null);
            }
            return SafeRepresenter.this.representMapping(SafeRepresenter.this.getTag(obj.getClass(), Tag.SET), linkedHashMap, DumperOptions.FlowStyle.AUTO);
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/representer/SafeRepresenter$RepresentDate.class */
    protected class RepresentDate implements Represent {
        private static transient /* synthetic */ String sBYkUADJPH = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        protected RepresentDate() {
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.representer.Represent
        public Node representData(Object obj) {
            Calendar calendar;
            if (obj instanceof Calendar) {
                calendar = (Calendar) obj;
            } else {
                calendar = Calendar.getInstance(SafeRepresenter.this.getTimeZone() == null ? TimeZone.getTimeZone("UTC") : SafeRepresenter.this.timeZone);
                calendar.setTime((Date) obj);
            }
            int i = calendar.get(1);
            int i2 = calendar.get(2) + 1;
            int i3 = calendar.get(5);
            int i4 = calendar.get(11);
            int i5 = calendar.get(12);
            int i6 = calendar.get(13);
            int i7 = calendar.get(14);
            StringBuilder sb = new StringBuilder(String.valueOf(i));
            while (sb.length() < 4) {
                sb.insert(0, "0");
            }
            sb.append("-");
            if (i2 < 10) {
                sb.append("0");
            }
            sb.append(i2);
            sb.append("-");
            if (i3 < 10) {
                sb.append("0");
            }
            sb.append(i3);
            sb.append("T");
            if (i4 < 10) {
                sb.append("0");
            }
            sb.append(i4);
            sb.append(":");
            if (i5 < 10) {
                sb.append("0");
            }
            sb.append(i5);
            sb.append(":");
            if (i6 < 10) {
                sb.append("0");
            }
            sb.append(i6);
            if (i7 > 0) {
                if (i7 < 10) {
                    sb.append(".00");
                } else if (i7 < 100) {
                    sb.append(".0");
                } else {
                    sb.append(".");
                }
                sb.append(i7);
            }
            int offset = calendar.getTimeZone().getOffset(calendar.getTime().getTime());
            if (offset == 0) {
                sb.append('Z');
            } else {
                if (offset < 0) {
                    sb.append('-');
                    offset *= -1;
                } else {
                    sb.append('+');
                }
                int i8 = offset / 60000;
                int i9 = i8 / 60;
                int i10 = i8 % 60;
                if (i9 < 10) {
                    sb.append('0');
                }
                sb.append(i9);
                sb.append(':');
                if (i10 < 10) {
                    sb.append('0');
                }
                sb.append(i10);
            }
            return SafeRepresenter.this.representScalar(SafeRepresenter.this.getTag(obj.getClass(), Tag.TIMESTAMP), sb.toString(), DumperOptions.ScalarStyle.PLAIN);
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/representer/SafeRepresenter$RepresentEnum.class */
    protected class RepresentEnum implements Represent {
        private static transient /* synthetic */ String xmMCOfrBtt = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        protected RepresentEnum() {
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.representer.Represent
        public Node representData(Object obj) {
            return SafeRepresenter.this.representScalar(SafeRepresenter.this.getTag(obj.getClass(), new Tag((Class<? extends Object>) obj.getClass())), ((Enum) obj).name());
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/representer/SafeRepresenter$RepresentByteArray.class */
    protected class RepresentByteArray implements Represent {
        private static transient /* synthetic */ String xzhsuKFfGR = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        protected RepresentByteArray() {
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.representer.Represent
        public Node representData(Object obj) {
            return SafeRepresenter.this.representScalar(Tag.BINARY, String.valueOf(Base64Coder.encode((byte[]) obj)), DumperOptions.ScalarStyle.LITERAL);
        }
    }

    public TimeZone getTimeZone() {
        return this.timeZone;
    }

    public void setTimeZone(TimeZone timeZone) {
        this.timeZone = timeZone;
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/representer/SafeRepresenter$RepresentUuid.class */
    protected class RepresentUuid implements Represent {
        private static transient /* synthetic */ String EsxfharUxx = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        protected RepresentUuid() {
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.representer.Represent
        public Node representData(Object obj) {
            return SafeRepresenter.this.representScalar(SafeRepresenter.this.getTag(obj.getClass(), new Tag((Class<? extends Object>) UUID.class)), obj.toString());
        }
    }
}
