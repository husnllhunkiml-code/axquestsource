package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.Mark;
import java.util.Optional;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/events/MappingEndEvent.class */
public final class MappingEndEvent extends CollectionEndEvent {
    private static transient /* synthetic */ String gmAEKwXuwf = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public MappingEndEvent(Optional<Mark> optional, Optional<Mark> optional2) {
        super(optional, optional2);
    }

    public MappingEndEvent() {
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.Event
    public Event.ID getEventId() {
        return Event.ID.MappingEnd;
    }

    public String toString() {
        return "-MAP";
    }
}
