package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.serialization.standard;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.serialization.YamlSerializer;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.utils.supplier.MapSupplier;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/serialization/standard/StandardSerializer.class */
public class StandardSerializer implements YamlSerializer {
    public static final String DEFAULT_SERIALIZED_TYPE_KEY = "==";
    private static final StandardSerializer defaultSerializer = new StandardSerializer(DEFAULT_SERIALIZED_TYPE_KEY);
    private final Map<Class<?>, TypeAdapter<?>> adapters = new HashMap();
    private final Map<String, Class<?>> aliases = new HashMap();
    private final Object serializedTypeKey;
    private static transient /* synthetic */ String LJEXRRmdsS = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public StandardSerializer(@NotNull Object obj) {
        this.serializedTypeKey = obj;
    }

    public <T> void register(@NotNull Class<T> cls, @NotNull TypeAdapter<T> typeAdapter) {
        this.adapters.put(cls, typeAdapter);
        this.aliases.put(cls.getCanonicalName(), cls);
    }

    public <T> void register(@NotNull String str, @NotNull Class<T> cls) {
        if (!this.adapters.containsKey(cls)) {
            throw new IllegalStateException("Cannot register an alias for yet unregistered type!");
        }
        this.aliases.put(str, cls);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.serialization.YamlSerializer
    @Nullable
    public Object deserialize(@NotNull Map<Object, Object> map) {
        Class<?> cls;
        if (!map.containsKey(this.serializedTypeKey) || (cls = this.aliases.get(map.get(this.serializedTypeKey).toString())) == null) {
            return null;
        }
        return this.adapters.get(cls).deserialize(map);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.serialization.YamlSerializer
    @Nullable
    public <T> Map<Object, Object> serialize(@NotNull T t, @NotNull MapSupplier mapSupplier) {
        if (!this.adapters.containsKey(t.getClass())) {
            return null;
        }
        Map<Object, Object> mapSupply = mapSupplier.supply(1);
        mapSupply.putAll(this.adapters.get(t.getClass()).serialize(t));
        mapSupply.computeIfAbsent(this.serializedTypeKey, obj -> {
            return t.getClass().getCanonicalName();
        });
        return mapSupply;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.serialization.YamlSerializer
    @NotNull
    public Set<Class<?>> getSupportedClasses() {
        return this.adapters.keySet();
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.serialization.YamlSerializer
    @NotNull
    public Set<Class<?>> getSupportedParentClasses() {
        return Collections.emptySet();
    }

    public static StandardSerializer getDefault() {
        return defaultSerializer;
    }
}
