package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.nodes;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/nodes/NodeId.class */
public enum NodeId {
    scalar,
    sequence,
    mapping,
    anchor
}
