package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.error;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/error/YAMLException.class */
public class YAMLException extends RuntimeException {
    private static final long serialVersionUID = -4738336175050337570L;
    private static transient /* synthetic */ String hjIvOYOEbi = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public YAMLException(String str) {
        super(str);
    }

    public YAMLException(Throwable th) {
        super(th);
    }

    public YAMLException(String str, Throwable th) {
        super(str, th);
    }
}
