package com.artillexstudios.axquestboard.libs.axapi.collections;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.function.Consumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/collections/ThreadSafeList.class */
public class ThreadSafeList<E> extends ArrayList<E> {
    private static final Logger log = LoggerFactory.getLogger(ThreadSafeList.class);
    private final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
    private final ReentrantReadWriteLock.ReadLock read = this.lock.readLock();
    private final ReentrantReadWriteLock.WriteLock write = this.lock.writeLock();
    private static transient /* synthetic */ String pQPgzNkKdp = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    @Override // java.util.ArrayList, java.util.AbstractList, java.util.List
    public int indexOf(Object o) {
        this.read.lock();
        try {
            return super.indexOf(o);
        } finally {
            this.read.unlock();
        }
    }

    @Override // java.util.ArrayList, java.util.AbstractList, java.util.List
    public int lastIndexOf(Object o) {
        this.read.lock();
        try {
            return super.lastIndexOf(o);
        } finally {
            this.read.unlock();
        }
    }

    @Override // java.util.ArrayList, java.util.AbstractList, java.util.List
    public void add(int index, E element) {
        this.write.lock();
        try {
            super.add(index, element);
        } finally {
            this.write.unlock();
        }
    }

    @Override // java.util.ArrayList, java.util.AbstractList, java.util.List
    public E get(int i) {
        this.read.lock();
        try {
            return (E) super.get(i);
        } finally {
            this.read.unlock();
        }
    }

    @Override // java.util.ArrayList, java.util.AbstractList, java.util.List
    public E set(int i, E e) {
        this.write.lock();
        try {
            return (E) super.set(i, e);
        } finally {
            this.write.unlock();
        }
    }

    @Override // java.util.ArrayList, java.util.AbstractList, java.util.List
    public E remove(int i) {
        this.write.lock();
        try {
            return (E) super.remove(i);
        } finally {
            this.write.unlock();
        }
    }

    @Override // java.util.ArrayList, java.util.AbstractCollection, java.util.Collection, java.util.List
    public boolean remove(Object o) {
        this.write.lock();
        try {
            return super.remove(o);
        } finally {
            this.write.unlock();
        }
    }

    @Override // java.util.ArrayList, java.util.AbstractCollection, java.util.Collection, java.util.List
    public boolean removeAll(Collection<?> c) {
        this.write.lock();
        try {
            return super.removeAll(c);
        } finally {
            this.write.unlock();
        }
    }

    @Override // java.util.ArrayList, java.lang.Iterable
    public void forEach(Consumer<? super E> action) {
        this.read.lock();
        try {
            super.forEach(action);
        } finally {
            this.read.unlock();
        }
    }

    @Override // java.util.ArrayList, java.util.AbstractList, java.util.AbstractCollection, java.util.Collection, java.util.List
    public boolean add(E e) {
        this.write.lock();
        try {
            return super.add(e);
        } finally {
            this.write.unlock();
        }
    }

    @Override // java.util.ArrayList, java.util.List
    public void sort(Comparator<? super E> c) {
        this.write.lock();
        try {
            super.sort(c);
        } finally {
            this.write.unlock();
        }
    }

    @Override // java.util.ArrayList, java.util.AbstractList, java.util.List
    @Deprecated
    public ListIterator<E> listIterator() {
        log.warn("Unsupported operation! You should not be using any iterator from the ThreadSafeList! Advanced for loops use the iterator!", new UnsupportedOperationException("The iterator should not be used!"));
        return super.listIterator();
    }

    @Override // java.util.ArrayList, java.util.AbstractList, java.util.List
    @Deprecated
    public ListIterator<E> listIterator(int index) {
        log.warn("Unsupported operation! You should not be using any iterator from the ThreadSafeList! Advanced for loops use the iterator!", new UnsupportedOperationException("The iterator should not be used!"));
        return super.listIterator(index);
    }

    @Override // java.util.ArrayList, java.util.AbstractList, java.util.AbstractCollection, java.util.Collection, java.lang.Iterable, java.util.List
    @Deprecated
    public Iterator<E> iterator() {
        log.warn("Unsupported operation! You should not be using any iterator from the ThreadSafeList! Advanced for loops use the iterator!", new UnsupportedOperationException("The iterator should not be used!"));
        return super.iterator();
    }
}
