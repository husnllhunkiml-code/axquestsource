package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.scanner;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.Token;
import java.util.Iterator;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/scanner/Scanner.class */
public interface Scanner extends Iterator<Token> {
    boolean checkToken(Token.ID... idArr);

    Token peekToken();

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // java.util.Iterator
    Token next();

    void resetDocumentIndex();
}
