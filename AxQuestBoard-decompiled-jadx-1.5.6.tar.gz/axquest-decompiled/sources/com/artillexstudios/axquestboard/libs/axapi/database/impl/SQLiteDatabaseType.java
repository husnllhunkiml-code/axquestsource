package com.artillexstudios.axquestboard.libs.axapi.database.impl;

import com.artillexstudios.axquestboard.libs.axapi.AxPlugin;
import com.artillexstudios.axquestboard.libs.axapi.database.DatabaseConfig;
import com.artillexstudios.axquestboard.libs.axapi.database.DatabaseType;
import com.artillexstudios.axquestboard.libs.axapi.libs.hikari.HikariConfig;
import java.util.List;
import java.util.UUID;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/database/impl/SQLiteDatabaseType.class */
public class SQLiteDatabaseType extends DatabaseType {
    private final String relocated;
    private static transient /* synthetic */ String cJYmaXFCgy = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public SQLiteDatabaseType() {
        this("org.sqlite");
    }

    public SQLiteDatabaseType(String relocated) {
        this.relocated = relocated;
        registerTransformer(UUID.class, uuid -> {
            return List.of(uuid.toString());
        });
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.database.DatabaseType
    public HikariConfig config(DatabaseConfig databaseConfig) {
        HikariConfig hikariConfig = new HikariConfig();
        hikariConfig.setDriverClassName(this.relocated + ".JDBC");
        hikariConfig.setJdbcUrl(databaseConfig.url == null ? "jdbc:sqlite:" + String.valueOf(((AxPlugin) AxPlugin.getPlugin(AxPlugin.class)).getDataFolder()) + "/data" : databaseConfig.url);
        hikariConfig.setMaximumPoolSize(databaseConfig.pool.maximumPoolSize);
        hikariConfig.setMinimumIdle(databaseConfig.pool.minimumIdle);
        return hikariConfig;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.database.DatabaseType
    public String name() {
        return "sqlite";
    }
}
