package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.util;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/util/PlatformFeatureDetector.class */
public class PlatformFeatureDetector {
    private Boolean isRunningOnAndroid = null;
    private static transient /* synthetic */ String KlpXdQFGZI = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public boolean isRunningOnAndroid() {
        if (this.isRunningOnAndroid == null) {
            String property = System.getProperty("java.runtime.name");
            this.isRunningOnAndroid = Boolean.valueOf(property != null && property.startsWith("Android Runtime"));
        }
        return this.isRunningOnAndroid.booleanValue();
    }
}
