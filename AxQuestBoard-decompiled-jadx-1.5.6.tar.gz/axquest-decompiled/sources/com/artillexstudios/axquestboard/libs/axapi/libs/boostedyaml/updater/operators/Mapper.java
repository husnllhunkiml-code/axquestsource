package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.updater.operators;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.block.implementation.Section;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.route.Route;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.updater.ValueMapper;
import java.util.Map;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/updater/operators/Mapper.class */
public class Mapper {
    private static transient /* synthetic */ String CehikXvItU = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public static void apply(@NotNull Section section, @NotNull Map<Route, ValueMapper> map) {
        map.forEach((route, valueMapper) -> {
            section.getParent(route).ifPresent(section2 -> {
                Route routeFromSingleKey = Route.fromSingleKey(route.get(route.length() - 1));
                if (!section2.getStoredValue().containsKey(routeFromSingleKey.get(0))) {
                    return;
                }
                section2.set(routeFromSingleKey, valueMapper.map(section2, routeFromSingleKey));
            });
        });
    }
}
