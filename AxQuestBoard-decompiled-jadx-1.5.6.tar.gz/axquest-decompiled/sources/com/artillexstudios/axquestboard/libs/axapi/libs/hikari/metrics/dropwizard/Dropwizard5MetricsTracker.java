package com.artillexstudios.axquestboard.libs.axapi.libs.hikari.metrics.dropwizard;

import com.artillexstudios.axquestboard.libs.axapi.libs.hikari.metrics.IMetricsTracker;
import com.artillexstudios.axquestboard.libs.axapi.libs.hikari.metrics.PoolStats;
import io.dropwizard.metrics5.Histogram;
import io.dropwizard.metrics5.Meter;
import io.dropwizard.metrics5.MetricName;
import io.dropwizard.metrics5.MetricRegistry;
import io.dropwizard.metrics5.Timer;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/hikari/metrics/dropwizard/Dropwizard5MetricsTracker.class */
public class Dropwizard5MetricsTracker implements IMetricsTracker {
    private final String poolName;
    private final Timer connectionObtainTimer;
    private final Histogram connectionUsage;
    private final Histogram connectionCreation;
    private final Meter connectionTimeoutMeter;
    private final MetricRegistry registry;
    private static transient /* synthetic */ String QeoxOcWbCB = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    Dropwizard5MetricsTracker(String str, PoolStats poolStats, MetricRegistry metricRegistry) {
        this.poolName = str;
        this.registry = metricRegistry;
        this.connectionObtainTimer = metricRegistry.timer(MetricRegistry.name(str, new String[]{"pool", "Wait"}));
        this.connectionUsage = metricRegistry.histogram(MetricRegistry.name(str, new String[]{"pool", "Usage"}));
        this.connectionCreation = metricRegistry.histogram(MetricRegistry.name(str, new String[]{"pool", "ConnectionCreation"}));
        this.connectionTimeoutMeter = metricRegistry.meter(MetricRegistry.name(str, new String[]{"pool", "ConnectionTimeoutRate"}));
        MetricName metricNameName = MetricRegistry.name(str, new String[]{"pool", "TotalConnections"});
        Objects.requireNonNull(poolStats);
        metricRegistry.register(metricNameName, poolStats::getTotalConnections);
        MetricName metricNameName2 = MetricRegistry.name(str, new String[]{"pool", "IdleConnections"});
        Objects.requireNonNull(poolStats);
        metricRegistry.register(metricNameName2, poolStats::getIdleConnections);
        MetricName metricNameName3 = MetricRegistry.name(str, new String[]{"pool", "ActiveConnections"});
        Objects.requireNonNull(poolStats);
        metricRegistry.register(metricNameName3, poolStats::getActiveConnections);
        MetricName metricNameName4 = MetricRegistry.name(str, new String[]{"pool", "PendingConnections"});
        Objects.requireNonNull(poolStats);
        metricRegistry.register(metricNameName4, poolStats::getPendingThreads);
        MetricName metricNameName5 = MetricRegistry.name(str, new String[]{"pool", "MaxConnections"});
        Objects.requireNonNull(poolStats);
        metricRegistry.register(metricNameName5, poolStats::getMaxConnections);
        MetricName metricNameName6 = MetricRegistry.name(str, new String[]{"pool", "MinConnections"});
        Objects.requireNonNull(poolStats);
        metricRegistry.register(metricNameName6, poolStats::getMinConnections);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.hikari.metrics.IMetricsTracker, java.lang.AutoCloseable
    public void close() {
        this.registry.remove(MetricRegistry.name(this.poolName, new String[]{"pool", "Wait"}));
        this.registry.remove(MetricRegistry.name(this.poolName, new String[]{"pool", "Usage"}));
        this.registry.remove(MetricRegistry.name(this.poolName, new String[]{"pool", "ConnectionCreation"}));
        this.registry.remove(MetricRegistry.name(this.poolName, new String[]{"pool", "ConnectionTimeoutRate"}));
        this.registry.remove(MetricRegistry.name(this.poolName, new String[]{"pool", "TotalConnections"}));
        this.registry.remove(MetricRegistry.name(this.poolName, new String[]{"pool", "IdleConnections"}));
        this.registry.remove(MetricRegistry.name(this.poolName, new String[]{"pool", "ActiveConnections"}));
        this.registry.remove(MetricRegistry.name(this.poolName, new String[]{"pool", "PendingConnections"}));
        this.registry.remove(MetricRegistry.name(this.poolName, new String[]{"pool", "MaxConnections"}));
        this.registry.remove(MetricRegistry.name(this.poolName, new String[]{"pool", "MinConnections"}));
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.hikari.metrics.IMetricsTracker
    public void recordConnectionAcquiredNanos(long j) {
        this.connectionObtainTimer.update(j, TimeUnit.NANOSECONDS);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.hikari.metrics.IMetricsTracker
    public void recordConnectionUsageMillis(long j) {
        this.connectionUsage.update(j);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.hikari.metrics.IMetricsTracker
    public void recordConnectionTimeout() {
        this.connectionTimeoutMeter.mark();
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.hikari.metrics.IMetricsTracker
    public void recordConnectionCreatedMillis(long j) {
        this.connectionCreation.update(j);
    }

    public Timer getConnectionAcquisitionTimer() {
        return this.connectionObtainTimer;
    }

    public Histogram getConnectionDurationHistogram() {
        return this.connectionUsage;
    }

    public Histogram getConnectionCreationHistogram() {
        return this.connectionCreation;
    }
}
