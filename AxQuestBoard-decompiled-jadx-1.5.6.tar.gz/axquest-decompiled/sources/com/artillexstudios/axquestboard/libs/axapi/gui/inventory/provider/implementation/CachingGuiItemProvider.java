package com.artillexstudios.axquestboard.libs.axapi.gui.inventory.provider.implementation;

import com.artillexstudios.axquestboard.libs.axapi.context.HashMapContext;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.BakedGuiItem;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.GuiItem;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.modifier.WrappedItemStackModifier;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.provider.GuiItemProvider;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/gui/inventory/provider/implementation/CachingGuiItemProvider.class */
public class CachingGuiItemProvider implements GuiItemProvider {
    private final GuiItem guiItem;
    private BakedGuiItem bakedGuiItem;
    private CompletableFuture<BakedGuiItem> future;
    private static transient /* synthetic */ String XMOScAafNs = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public CachingGuiItemProvider(GuiItem guiItem) {
        this.guiItem = guiItem;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.gui.inventory.provider.GuiItemProvider
    public CompletableFuture<BakedGuiItem> provide(HashMapContext context, List<WrappedItemStackModifier> modifiers) {
        if (this.future == null) {
            this.bakedGuiItem = new BakedGuiItem(handleModifiers(this.guiItem.stack().apply(context), modifiers).toBukkit(), inventoryClickEvent -> {
                this.guiItem.eventConsumer().accept(context, inventoryClickEvent);
            });
            this.future = CompletableFuture.completedFuture(this.bakedGuiItem);
        }
        return this.future;
    }
}
