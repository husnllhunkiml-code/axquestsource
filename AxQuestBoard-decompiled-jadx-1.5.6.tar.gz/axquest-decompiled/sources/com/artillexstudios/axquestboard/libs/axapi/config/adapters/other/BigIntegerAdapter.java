package com.artillexstudios.axquestboard.libs.axapi.config.adapters.other;

import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapterHolder;
import java.lang.reflect.Type;
import java.math.BigInteger;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/adapters/other/BigIntegerAdapter.class */
public final class BigIntegerAdapter implements TypeAdapter<BigInteger, String> {
    private static transient /* synthetic */ String ZtOgPKspmf = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public BigInteger deserialize(TypeAdapterHolder holder, Object input, Type type) {
        if (input instanceof String) {
            return new BigInteger((String) input);
        }
        if (input instanceof Number) {
            return BigInteger.valueOf(((Number) input).longValue());
        }
        throw new IllegalArgumentException("Can't convert %s into a BigInteger!".formatted(input.getClass()));
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public String serialize(TypeAdapterHolder holder, BigInteger value, Type type) {
        return value.toString();
    }
}
