package com.artillexstudios.axquestboard.libs.axapi.config.adapters.other;

import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapterHolder;
import com.artillexstudios.axquestboard.libs.axapi.database.DatabaseType;
import com.artillexstudios.axquestboard.libs.axapi.database.DatabaseTypes;
import java.lang.reflect.Type;
import java.util.List;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/adapters/other/DatabaseTypeAdapter.class */
public final class DatabaseTypeAdapter implements TypeAdapter<DatabaseType, String> {
    private static transient /* synthetic */ String NHIXEgPtzz = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public DatabaseType deserialize(TypeAdapterHolder holder, Object input, Type type) {
        if (input instanceof DatabaseType) {
            return (DatabaseType) input;
        }
        if (input instanceof String) {
            return DatabaseTypes.fetch((String) input);
        }
        throw new IllegalArgumentException();
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public String serialize(TypeAdapterHolder holder, DatabaseType value, Type type) {
        return value.name();
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public List<String> values(Type type) {
        return DatabaseTypes.keys();
    }
}
