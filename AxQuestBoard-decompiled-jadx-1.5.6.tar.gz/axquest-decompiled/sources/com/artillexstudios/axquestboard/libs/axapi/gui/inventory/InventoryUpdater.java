package com.artillexstudios.axquestboard.libs.axapi.gui.inventory;

import com.artillexstudios.axquestboard.libs.axapi.AxPlugin;
import com.artillexstudios.axquestboard.libs.axapi.executor.ExceptionReportingScheduledThreadPool;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.renderer.InventoryRenderer;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.renderer.InventoryRenderers;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/gui/inventory/InventoryUpdater.class */
public enum InventoryUpdater {
    INSTANCE;

    private ScheduledExecutorService service;

    public void start(AxPlugin plugin) {
        this.service = new ExceptionReportingScheduledThreadPool(1, Thread.ofPlatform().name(plugin.getName() + "-AxAPI-inventory-updater").factory());
        this.service.scheduleWithFixedDelay(() -> {
            for (InventoryRenderer inventoryRenderer : InventoryRenderers.getCurrentRenderers()) {
                Gui currentGui = inventoryRenderer.getCurrentGui();
                if (currentGui != null && !inventoryRenderer.isClosed()) {
                    currentGui.tick();
                }
            }
        }, 0L, 50L, TimeUnit.MILLISECONDS);
    }

    public void shutdown() {
        if (this.service == null || this.service.isShutdown()) {
            return;
        }
        this.service.shutdown();
    }
}
