package com.artillexstudios.axquestboard.libs.axapi.items.component.type;

import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.runtime.ObjectMethods;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/items/component/type/Unbreakable.class */
public final class Unbreakable extends Record {
    private final boolean showInTooltip;
    private static transient /* synthetic */ String RleAkgxEPx = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public Unbreakable(boolean showInTooltip) {
        this.showInTooltip = showInTooltip;
    }

    @Override // java.lang.Record
    public final String toString() {
        return (String) ObjectMethods.bootstrap(MethodHandles.lookup(), "toString", MethodType.methodType(String.class, Unbreakable.class), Unbreakable.class, "showInTooltip", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/items/component/type/Unbreakable;->showInTooltip:Z").dynamicInvoker().invoke(this) /* invoke-custom */;
    }

    @Override // java.lang.Record
    public final int hashCode() {
        return (int) ObjectMethods.bootstrap(MethodHandles.lookup(), "hashCode", MethodType.methodType(Integer.TYPE, Unbreakable.class), Unbreakable.class, "showInTooltip", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/items/component/type/Unbreakable;->showInTooltip:Z").dynamicInvoker().invoke(this) /* invoke-custom */;
    }

    @Override // java.lang.Record
    public final boolean equals(Object o) {
        return (boolean) ObjectMethods.bootstrap(MethodHandles.lookup(), "equals", MethodType.methodType(Boolean.TYPE, Unbreakable.class, Object.class), Unbreakable.class, "showInTooltip", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/items/component/type/Unbreakable;->showInTooltip:Z").dynamicInvoker().invoke(this, o) /* invoke-custom */;
    }

    public boolean showInTooltip() {
        return this.showInTooltip;
    }
}
