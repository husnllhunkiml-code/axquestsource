package com.artillexstudios.axquestboard.libs.axapi.config.service;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/service/Formatter.class */
public interface Formatter {
    String format(String input);
}
