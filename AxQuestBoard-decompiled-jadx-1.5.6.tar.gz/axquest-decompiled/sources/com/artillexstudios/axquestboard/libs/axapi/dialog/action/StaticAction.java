package com.artillexstudios.axquestboard.libs.axapi.dialog.action;

import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.runtime.ObjectMethods;
import net.kyori.adventure.text.event.ClickEvent;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/dialog/action/StaticAction.class */
public final class StaticAction extends Record implements Action {
    private final ClickEvent clickEvent;
    private static transient /* synthetic */ String QRtTmNxOvW = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public StaticAction(ClickEvent clickEvent) {
        this.clickEvent = clickEvent;
    }

    @Override // java.lang.Record
    public final String toString() {
        return (String) ObjectMethods.bootstrap(MethodHandles.lookup(), "toString", MethodType.methodType(String.class, StaticAction.class), StaticAction.class, "clickEvent", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/dialog/action/StaticAction;->clickEvent:Lnet/kyori/adventure/text/event/ClickEvent;").dynamicInvoker().invoke(this) /* invoke-custom */;
    }

    @Override // java.lang.Record
    public final int hashCode() {
        return (int) ObjectMethods.bootstrap(MethodHandles.lookup(), "hashCode", MethodType.methodType(Integer.TYPE, StaticAction.class), StaticAction.class, "clickEvent", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/dialog/action/StaticAction;->clickEvent:Lnet/kyori/adventure/text/event/ClickEvent;").dynamicInvoker().invoke(this) /* invoke-custom */;
    }

    @Override // java.lang.Record
    public final boolean equals(Object o) {
        return (boolean) ObjectMethods.bootstrap(MethodHandles.lookup(), "equals", MethodType.methodType(Boolean.TYPE, StaticAction.class, Object.class), StaticAction.class, "clickEvent", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/dialog/action/StaticAction;->clickEvent:Lnet/kyori/adventure/text/event/ClickEvent;").dynamicInvoker().invoke(this, o) /* invoke-custom */;
    }

    public ClickEvent clickEvent() {
        return this.clickEvent;
    }
}
