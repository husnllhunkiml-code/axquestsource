package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.dvs.versioning;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.block.implementation.Section;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.dvs.Pattern;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.dvs.Version;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.route.Route;
import java.util.Optional;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/dvs/versioning/AutomaticVersioning.class */
public class AutomaticVersioning implements Versioning {
    private final Pattern pattern;
    private final Route route;
    private final String strRoute;
    private static transient /* synthetic */ String dniHlrWEtv = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public AutomaticVersioning(@NotNull Pattern pattern, @NotNull Route route) {
        this.pattern = pattern;
        this.route = route;
        this.strRoute = null;
    }

    public AutomaticVersioning(@NotNull Pattern pattern, @NotNull String str) {
        this.pattern = pattern;
        this.route = null;
        this.strRoute = str;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.dvs.versioning.Versioning
    @Nullable
    public Version getDocumentVersion(@NotNull Section section, boolean z) {
        Optional<String> optionalString = this.route != null ? section.getOptionalString(this.route) : section.getOptionalString(this.strRoute);
        Pattern pattern = this.pattern;
        pattern.getClass();
        return (Version) optionalString.map(pattern::getVersion).orElse(null);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.dvs.versioning.Versioning
    @NotNull
    public Version getFirstVersion() {
        return this.pattern.getFirstVersion();
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.dvs.versioning.Versioning
    public void updateVersionID(@NotNull Section section, @NotNull Section section2) {
        if (this.route != null) {
            section.set(this.route, section2.getString(this.route));
        } else {
            section.set(this.strRoute, section2.getString(this.strRoute));
        }
    }

    public String toString() {
        return "AutomaticVersioning{pattern=" + this.pattern + ", route='" + (this.route == null ? this.strRoute : this.route) + "'}";
    }
}
