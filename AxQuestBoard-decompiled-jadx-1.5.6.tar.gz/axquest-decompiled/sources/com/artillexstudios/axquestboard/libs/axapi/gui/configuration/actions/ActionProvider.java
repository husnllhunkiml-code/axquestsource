package com.artillexstudios.axquestboard.libs.axapi.gui.configuration.actions;

import com.artillexstudios.axquestboard.libs.axapi.gui.configuration.actions.Action;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/gui/configuration/actions/ActionProvider.class */
public interface ActionProvider<T extends Action<?>> {
    T provide(String data);
}
