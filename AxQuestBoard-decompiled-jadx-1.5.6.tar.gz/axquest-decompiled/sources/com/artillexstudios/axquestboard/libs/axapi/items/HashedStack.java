package com.artillexstudios.axquestboard.libs.axapi.items;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/items/HashedStack.class */
public interface HashedStack {
    boolean matches(WrappedItemStack stack, HashGenerator generator);
}
