package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions;

import java.util.Optional;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/exceptions/DuplicateKeyException.class */
public class DuplicateKeyException extends ConstructorException {
    private static transient /* synthetic */ String NdFsNPBAtj = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public DuplicateKeyException(Optional<Mark> optional, Object obj, Optional<Mark> optional2) {
        super("while constructing a mapping", optional, "found duplicate key " + obj.toString(), optional2);
    }
}
