package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.emitter;

import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.events.Event;
import java.io.IOException;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/emitter/Emitable.class */
public interface Emitable {
    void emit(Event event) throws IOException;
}
