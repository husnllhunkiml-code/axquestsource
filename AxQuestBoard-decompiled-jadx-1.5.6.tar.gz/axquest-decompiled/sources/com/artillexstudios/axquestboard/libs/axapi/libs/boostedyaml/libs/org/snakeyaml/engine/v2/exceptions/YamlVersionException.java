package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.SpecVersion;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/exceptions/YamlVersionException.class */
public class YamlVersionException extends YamlEngineException {
    private final SpecVersion specVersion;
    private static transient /* synthetic */ String OBxOnAMFvJ = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public YamlVersionException(SpecVersion specVersion) {
        super(specVersion.toString());
        this.specVersion = specVersion;
    }

    public SpecVersion getSpecVersion() {
        return this.specVersion;
    }
}
