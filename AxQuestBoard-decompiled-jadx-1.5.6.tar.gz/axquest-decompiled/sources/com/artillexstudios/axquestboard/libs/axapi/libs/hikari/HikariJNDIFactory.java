package com.artillexstudios.axquestboard.libs.axapi.libs.hikari;

import com.artillexstudios.axquestboard.libs.axapi.libs.hikari.util.PropertyElf;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Set;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.Name;
import javax.naming.RefAddr;
import javax.naming.Reference;
import javax.naming.spi.ObjectFactory;
import javax.sql.DataSource;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/hikari/HikariJNDIFactory.class */
public class HikariJNDIFactory implements ObjectFactory {
    private static transient /* synthetic */ String KyGdqEyTpK = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public synchronized Object getObjectInstance(Object obj, Name name, Context context, Hashtable<?, ?> hashtable) {
        if ((obj instanceof Reference) && "javax.sql.DataSource".equals(((Reference) obj).getClassName())) {
            Set<String> propertyNames = PropertyElf.getPropertyNames(HikariConfig.class);
            Properties properties = new Properties();
            Enumeration all = ((Reference) obj).getAll();
            while (all.hasMoreElements()) {
                RefAddr refAddr = (RefAddr) all.nextElement();
                String type = refAddr.getType();
                if (type.startsWith("dataSource.") || propertyNames.contains(type)) {
                    properties.setProperty(type, refAddr.getContent().toString());
                }
            }
            return createDataSource(properties, context);
        }
        return null;
    }

    private DataSource createDataSource(Properties properties, Context context) {
        String property = properties.getProperty("dataSourceJNDI");
        if (property != null) {
            return lookupJndiDataSource(properties, context, property);
        }
        return new HikariDataSource(new HikariConfig(properties));
    }

    private DataSource lookupJndiDataSource(Properties properties, Context context, String str) {
        if (context == null) {
            throw new RuntimeException("JNDI context does not found for dataSourceJNDI : " + str);
        }
        DataSource dataSource = (DataSource) context.lookup(str);
        if (dataSource == null) {
            InitialContext initialContext = new InitialContext();
            dataSource = (DataSource) initialContext.lookup(str);
            initialContext.close();
        }
        if (dataSource != null) {
            HikariConfig hikariConfig = new HikariConfig(properties);
            hikariConfig.setDataSource(dataSource);
            return new HikariDataSource(hikariConfig);
        }
        return null;
    }
}
