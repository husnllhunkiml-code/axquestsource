package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.util;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/util/EnumUtils.class */
public class EnumUtils {
    private static transient /* synthetic */ String URFaKiibVz = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public static <T extends Enum<T>> T findEnumInsensitiveCase(Class<T> cls, String str) {
        for (T t : cls.getEnumConstants()) {
            if (t.name().compareToIgnoreCase(str) == 0) {
                return t;
            }
        }
        throw new IllegalArgumentException("No enum constant " + cls.getCanonicalName() + "." + str);
    }
}
