package com.artillexstudios.axquestboard.libs.axapi.config.adapters.other;

import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapterHolder;
import java.lang.reflect.Type;
import java.util.regex.Pattern;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/adapters/other/PatternAdapter.class */
public final class PatternAdapter implements TypeAdapter<Pattern, String> {
    private static transient /* synthetic */ String ABTwKFnuNX = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public Pattern deserialize(TypeAdapterHolder holder, Object input, Type type) {
        if (input instanceof String) {
            return Pattern.compile((String) input);
        }
        throw new IllegalArgumentException();
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public String serialize(TypeAdapterHolder holder, Pattern value, Type type) {
        return value.pattern();
    }
}
