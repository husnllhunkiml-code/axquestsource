package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.engine;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.YamlDocument;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.block.Block;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.block.Comments;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.block.implementation.Section;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.DumpSettings;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.RepresentToNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.comments.CommentLine;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.comments.CommentType;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.FlowStyle;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.ScalarStyle;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.MappingNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Node;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.NodeTuple;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.ScalarNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.SequenceNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Tag;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.representer.StandardRepresenter;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.dumper.DumperSettings;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.general.GeneralSettings;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.utils.format.NodeRole;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/engine/ExtendedRepresenter.class */
public class ExtendedRepresenter extends StandardRepresenter {
    private final GeneralSettings generalSettings;
    private final DumperSettings dumperSettings;
    private NodeRole nodeRole;
    private static transient /* synthetic */ String WzNMCWIBoR = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    /* JADX INFO: renamed from: com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.engine.ExtendedRepresenter$1 */
    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/engine/ExtendedRepresenter$1.class */
    static /* synthetic */ class C00121 {
        private static transient /* synthetic */ String iCbcIIDyTY = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";
    }

    public ExtendedRepresenter(Class<?> cls, @NotNull GeneralSettings generalSettings, @NotNull DumperSettings dumperSettings, @NotNull DumpSettings dumpSettings) {
        super(dumpSettings);
        this.nodeRole = NodeRole.KEY;
        this.generalSettings = generalSettings;
        this.dumperSettings = dumperSettings;
        RepresentSerializable representSerializable = new RepresentSerializable(this, null);
        this.representers.put(cls, new RepresentDocument(this, null));
        this.representers.put(Section.class, new RepresentSection(this, null));
        this.representers.put(Enum.class, new RepresentEnum(this, null));
        this.representers.put(String.class, new RepresentString(this, this.representers.get(String.class), null));
        Iterator<Class<?>> it = generalSettings.getSerializer().getSupportedClasses().iterator();
        while (it.hasNext()) {
            this.representers.put(it.next(), representSerializable);
        }
        Iterator<Class<?>> it2 = generalSettings.getSerializer().getSupportedParentClasses().iterator();
        while (it2.hasNext()) {
            this.parentClassRepresenters.put(it2.next(), representSerializable);
        }
    }

    public ExtendedRepresenter(@NotNull GeneralSettings generalSettings, @NotNull DumperSettings dumperSettings) {
        this(YamlDocument.class, generalSettings, dumperSettings, dumperSettings.buildEngineSettings());
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.representer.BaseRepresenter
    protected Node representScalar(Tag tag, String str, ScalarStyle scalarStyle) {
        return super.representScalar(tag, str, this.dumperSettings.getScalarFormatter().format(tag, str, this.nodeRole, scalarStyle));
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.representer.BaseRepresenter
    protected Node representSequence(Tag tag, Iterable<?> iterable, FlowStyle flowStyle) {
        return super.representSequence(tag, iterable, this.dumperSettings.getSequenceFormatter().format(tag, iterable, this.nodeRole, flowStyle));
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.representer.BaseRepresenter
    protected Node representMapping(Tag tag, Map<?, ?> map, FlowStyle flowStyle) {
        return super.representMapping(tag, map, this.dumperSettings.getMappingFormatter().format(tag, map, this.nodeRole, flowStyle));
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/engine/ExtendedRepresenter$RepresentSerializable.class */
    private class RepresentSerializable implements RepresentToNode {
        private static transient /* synthetic */ String iLVoZSlAGO = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        private RepresentSerializable() {
        }

        /* synthetic */ RepresentSerializable(ExtendedRepresenter extendedRepresenter, C00121 c00121) {
            this();
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.RepresentToNode
        public Node representData(Object obj) {
            Map<Object, Object> mapSerialize = ExtendedRepresenter.this.generalSettings.getSerializer().serialize(obj, ExtendedRepresenter.this.generalSettings.getDefaultMapSupplier());
            return ExtendedRepresenter.this.representData(mapSerialize == null ? obj : mapSerialize);
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/engine/ExtendedRepresenter$RepresentDocument.class */
    private class RepresentDocument implements RepresentToNode {
        private static transient /* synthetic */ String tahwkIWMYS = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        private RepresentDocument() {
        }

        /* synthetic */ RepresentDocument(ExtendedRepresenter extendedRepresenter, C00121 c00121) {
            this();
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.RepresentToNode
        public Node representData(Object obj) {
            Section section = (Section) obj;
            return ExtendedRepresenter.this.applyComments(section, NodeRole.VALUE, ExtendedRepresenter.this.representData(section.getStoredValue()), section.isRoot());
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/engine/ExtendedRepresenter$RepresentSection.class */
    private class RepresentSection implements RepresentToNode {
        private static transient /* synthetic */ String TvcqGmcMjM = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        private RepresentSection() {
        }

        /* synthetic */ RepresentSection(ExtendedRepresenter extendedRepresenter, C00121 c00121) {
            this();
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.RepresentToNode
        public Node representData(Object obj) {
            Section section = (Section) obj;
            return ExtendedRepresenter.this.applyComments(section, NodeRole.KEY, ExtendedRepresenter.this.representData(section.getStoredValue()), section.isRoot());
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/engine/ExtendedRepresenter$RepresentEnum.class */
    private class RepresentEnum implements RepresentToNode {
        private static transient /* synthetic */ String pmoqIXHxVD = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        private RepresentEnum() {
        }

        /* synthetic */ RepresentEnum(ExtendedRepresenter extendedRepresenter, C00121 c00121) {
            this();
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.RepresentToNode
        public Node representData(Object obj) {
            return ExtendedRepresenter.this.representData(((Enum) obj).name());
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/engine/ExtendedRepresenter$RepresentString.class */
    private class RepresentString implements RepresentToNode {
        private final RepresentToNode previous;
        private static transient /* synthetic */ String LAqxVbgmFr = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        /* synthetic */ RepresentString(ExtendedRepresenter extendedRepresenter, RepresentToNode representToNode, C00121 c00121) {
            this(representToNode);
        }

        private RepresentString(RepresentToNode representToNode) {
            this.previous = representToNode;
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.RepresentToNode
        public Node representData(Object obj) {
            ScalarStyle scalarStyle = ExtendedRepresenter.this.defaultScalarStyle;
            ExtendedRepresenter.this.defaultScalarStyle = ExtendedRepresenter.this.dumperSettings.getStringStyle();
            Node nodeRepresentData = this.previous.representData(obj);
            ExtendedRepresenter.this.defaultScalarStyle = scalarStyle;
            return nodeRepresentData;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public Node applyComments(@Nullable Block<?> block, @NotNull NodeRole nodeRole, @NotNull Node node, boolean z) {
        if (block == null) {
            return node;
        }
        if (allowBlockComments(z)) {
            node.setBlockComments(Comments.get(block, nodeRole, Comments.Position.BEFORE));
            node.setEndComments(Comments.get(block, nodeRole, Comments.Position.AFTER));
        }
        List<CommentLine> list = Comments.get(block, nodeRole, Comments.Position.INLINE);
        if (list != null && !list.isEmpty()) {
            if (allowInlineComments(node)) {
                node.setInLineComments(list);
            } else if (allowBlockComments(z)) {
                ArrayList arrayList = node.getBlockComments() == null ? new ArrayList(list.size()) : new ArrayList(node.getBlockComments());
                for (CommentLine commentLine : list) {
                    arrayList.add(new CommentLine(commentLine.getStartMark(), commentLine.getEndMark(), commentLine.getValue(), commentLine.getCommentType() == CommentType.IN_LINE ? CommentType.BLOCK : commentLine.getCommentType()));
                }
                node.setBlockComments(arrayList);
            }
        }
        return node;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.representer.BaseRepresenter
    protected NodeTuple representMappingEntry(Map.Entry<?, ?> entry) {
        Block<?> block = entry.getValue() instanceof Block ? (Block) entry.getValue() : null;
        NodeRole nodeRole = NodeRole.KEY;
        this.nodeRole = nodeRole;
        Node nodeApplyComments = applyComments(block, nodeRole, representData(entry.getKey()), false);
        NodeRole nodeRole2 = NodeRole.VALUE;
        this.nodeRole = nodeRole2;
        return new NodeTuple(nodeApplyComments, applyComments(block, nodeRole2, representData(block == null ? entry.getValue() : block.getStoredValue()), false));
    }

    private boolean allowBlockComments(boolean z) {
        return z || this.settings.getDefaultFlowStyle() == FlowStyle.BLOCK;
    }

    private boolean allowInlineComments(@NotNull Node node) {
        return (this.settings.getDefaultFlowStyle() == FlowStyle.BLOCK && (node instanceof ScalarNode)) || (this.settings.getDefaultFlowStyle() == FlowStyle.FLOW && ((node instanceof SequenceNode) || (node instanceof MappingNode)));
    }
}
