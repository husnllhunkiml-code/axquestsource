package com.artillexstudios.axquestboard.libs.axapi.config.service;

import java.nio.file.Path;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/service/Writer.class */
public interface Writer {
    boolean write(Path path, String toWrite);
}
