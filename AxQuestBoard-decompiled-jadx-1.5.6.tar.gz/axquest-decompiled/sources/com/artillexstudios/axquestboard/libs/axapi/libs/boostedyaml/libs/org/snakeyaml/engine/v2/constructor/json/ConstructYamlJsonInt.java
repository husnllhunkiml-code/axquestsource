package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.constructor.json;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.constructor.ConstructScalar;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Node;
import java.math.BigInteger;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/constructor/json/ConstructYamlJsonInt.class */
public class ConstructYamlJsonInt extends ConstructScalar {
    private static transient /* synthetic */ String RHjLXQyJHY = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.ConstructNode
    public Object construct(Node node) {
        return createIntNumber(constructScalar(node));
    }

    protected Number createIntNumber(String str) {
        Number bigInteger;
        try {
            bigInteger = Integer.valueOf(str);
        } catch (NumberFormatException e) {
            try {
                bigInteger = Long.valueOf(str);
            } catch (NumberFormatException e2) {
                bigInteger = new BigInteger(str);
            }
        }
        return bigInteger;
    }
}
