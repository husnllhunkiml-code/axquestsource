package com.artillexstudios.axquestboard.libs.axapi.libs.hikari.metrics.micrometer;

import com.artillexstudios.axquestboard.libs.axapi.libs.hikari.metrics.IMetricsTracker;
import com.artillexstudios.axquestboard.libs.axapi.libs.hikari.metrics.MetricsTrackerFactory;
import com.artillexstudios.axquestboard.libs.axapi.libs.hikari.metrics.PoolStats;
import io.micrometer.core.instrument.MeterRegistry;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/hikari/metrics/micrometer/MicrometerMetricsTrackerFactory.class */
public class MicrometerMetricsTrackerFactory implements MetricsTrackerFactory {
    private final MeterRegistry registry;
    private static transient /* synthetic */ String xokgctjCyM = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public MicrometerMetricsTrackerFactory(MeterRegistry meterRegistry) {
        this.registry = meterRegistry;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.hikari.metrics.MetricsTrackerFactory
    public IMetricsTracker create(String str, PoolStats poolStats) {
        return new MicrometerMetricsTracker(str, poolStats, this.registry);
    }
}
