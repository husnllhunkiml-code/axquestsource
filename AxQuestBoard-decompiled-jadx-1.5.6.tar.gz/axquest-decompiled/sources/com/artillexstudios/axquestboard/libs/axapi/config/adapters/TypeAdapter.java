package com.artillexstudios.axquestboard.libs.axapi.config.adapters;

import java.lang.reflect.Type;
import java.util.List;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/adapters/TypeAdapter.class */
public interface TypeAdapter<T, Z> {
    T deserialize(TypeAdapterHolder holder, Object input, Type type);

    Z serialize(TypeAdapterHolder holder, T value, Type type);

    default List<String> values(Type type) {
        return List.of();
    }
}
