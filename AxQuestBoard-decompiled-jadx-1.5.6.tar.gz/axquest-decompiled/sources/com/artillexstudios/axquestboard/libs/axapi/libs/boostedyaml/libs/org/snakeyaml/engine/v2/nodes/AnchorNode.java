package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/nodes/AnchorNode.class */
public class AnchorNode extends Node {
    private final Node realNode;
    private static transient /* synthetic */ String CIzRbyGLuA = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public AnchorNode(Node node) {
        super(node.getTag(), node.getStartMark(), node.getEndMark());
        this.realNode = node;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Node
    public NodeType getNodeType() {
        return NodeType.ANCHOR;
    }

    public Node getRealNode() {
        return this.realNode;
    }
}
