package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.dvs;

import java.util.Arrays;
import java.util.Objects;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/dvs/Version.class */
public class Version implements Comparable<Version> {
    private final Pattern pattern;
    private final int[] cursors;
    private String id;
    private static transient /* synthetic */ String pPtcWFnaqV = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    Version(@Nullable String str, @NotNull Pattern pattern, int[] iArr) {
        this.id = str;
        this.pattern = pattern;
        this.cursors = iArr;
        if (str == null) {
            buildID();
        }
    }

    @Override // java.lang.Comparable
    public int compareTo(Version version) {
        if (!this.pattern.equals(version.pattern)) {
            throw new ClassCastException("Compared versions are not defined by the same pattern!");
        }
        for (int i = 0; i < this.cursors.length; i++) {
            int iCompare = Integer.compare(this.cursors[i], version.cursors[i]);
            if (iCompare != 0) {
                return iCompare;
            }
        }
        return 0;
    }

    public int getCursor(int i) {
        return this.cursors[i];
    }

    public void next() {
        for (int length = this.cursors.length - 1; length >= 0; length--) {
            int i = this.cursors[length];
            if (i + 1 >= this.pattern.getSegment(length).length()) {
                this.cursors[length] = 0;
            } else {
                this.cursors[length] = i + 1;
                break;
            }
        }
        buildID();
    }

    private void buildID() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < this.cursors.length; i++) {
            sb.append(this.pattern.getSegment(i).getElement(this.cursors[i]));
        }
        this.id = sb.toString();
    }

    public String asID() {
        return this.id;
    }

    public Version copy() {
        return new Version(this.id, this.pattern, Arrays.copyOf(this.cursors, this.cursors.length));
    }

    public Pattern getPattern() {
        return this.pattern;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Version)) {
            return false;
        }
        Version version = (Version) obj;
        return this.pattern.equals(version.pattern) && Arrays.equals(this.cursors, version.cursors);
    }

    public int hashCode() {
        return (31 * Objects.hash(this.pattern)) + Arrays.hashCode(this.cursors);
    }

    public String toString() {
        return "Version{pattern=" + this.pattern + ", cursors=" + Arrays.toString(this.cursors) + ", id='" + this.id + "'}";
    }
}
