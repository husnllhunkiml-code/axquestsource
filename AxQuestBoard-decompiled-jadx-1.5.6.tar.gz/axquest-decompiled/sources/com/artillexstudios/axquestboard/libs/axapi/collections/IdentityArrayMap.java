package com.artillexstudios.axquestboard.libs.axapi.collections;

import com.artillexstudios.axquestboard.libs.axapi.utils.UncheckedUtils;
import java.util.AbstractCollection;
import java.util.AbstractSet;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/collections/IdentityArrayMap.class */
public class IdentityArrayMap<K, V> implements Map<K, V> {
    private static final Object[] EMPTY_ARRAY = new Object[0];
    private Object[] keys;
    private Object[] values;
    private int size;
    private static transient /* synthetic */ String kRzDKopTSU = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public IdentityArrayMap() {
        this.keys = EMPTY_ARRAY;
        this.values = EMPTY_ARRAY;
    }

    public IdentityArrayMap(int size) {
        this.keys = new Object[size];
        this.values = new Object[size];
    }

    @Override // java.util.Map
    public int size() {
        return this.size;
    }

    @Override // java.util.Map
    public boolean isEmpty() {
        return this.size == 0;
    }

    @Override // java.util.Map
    public boolean containsKey(Object key) {
        return findKey(key) != -1;
    }

    @Override // java.util.Map
    public boolean containsValue(Object value) {
        Object[] objArr = this.values;
        int i = this.size;
        while (objArr[i] != value) {
            int i2 = i;
            i--;
            if (i2 == 0) {
                return false;
            }
        }
        return true;
    }

    @Override // java.util.Map
    public V get(Object obj) {
        int iFindKey = findKey(obj);
        if (iFindKey == -1) {
            return null;
        }
        return (V) UncheckedUtils.unsafeCast(this.values[iFindKey]);
    }

    @Override // java.util.Map
    public V put(K k, V v) {
        int iFindKey = findKey(k);
        if (iFindKey != -1) {
            V v2 = (V) UncheckedUtils.unsafeCast(this.values[iFindKey]);
            this.values[iFindKey] = v;
            return v2;
        }
        if (this.size == this.keys.length) {
            Object[] objArr = new Object[this.size == 0 ? 2 : this.size * 2];
            Object[] objArr2 = new Object[this.size == 0 ? 2 : this.size * 2];
            System.arraycopy(this.keys, 0, objArr, 0, this.size);
            System.arraycopy(this.values, 0, objArr2, 0, this.size);
            this.keys = objArr;
            this.values = objArr2;
        }
        this.keys[this.size] = k;
        this.values[this.size] = v;
        this.size++;
        return null;
    }

    @Override // java.util.Map
    public V remove(Object obj) {
        int iFindKey = findKey(obj);
        if (iFindKey == -1) {
            return null;
        }
        V v = (V) UncheckedUtils.unsafeCast(this.values[iFindKey]);
        int i = (this.size - iFindKey) - 1;
        System.arraycopy(this.keys, iFindKey + 1, this.keys, iFindKey, i);
        System.arraycopy(this.values, iFindKey + 1, this.values, iFindKey, i);
        this.size--;
        this.keys[this.size] = null;
        this.values[this.size] = null;
        return v;
    }

    @Override // java.util.Map
    public void putAll(Map<? extends K, ? extends V> m) {
        m.forEach(this::put);
    }

    @Override // java.util.Map
    public void clear() {
        for (int i = 0; i < this.size; i++) {
            this.keys[i] = null;
            this.values[i] = null;
        }
        this.size = 0;
    }

    @Override // java.util.Map
    @NotNull
    public Set<K> keySet() {
        return new AbstractSet<K>() { // from class: com.artillexstudios.axquestboard.libs.axapi.collections.IdentityArrayMap.1
            private static transient /* synthetic */ String rnDUkQJFDc = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

            @Override // java.util.AbstractCollection, java.util.Collection, java.lang.Iterable, java.util.Set
            @NotNull
            public Iterator<K> iterator() {
                return new Iterator<K>() { // from class: com.artillexstudios.axquestboard.libs.axapi.collections.IdentityArrayMap.1.1
                    private int index = 0;
                    private static transient /* synthetic */ String NxjWTqGzzW = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

                    @Override // java.util.Iterator
                    public boolean hasNext() {
                        return this.index < IdentityArrayMap.this.size;
                    }

                    @Override // java.util.Iterator
                    public K next() {
                        if (!hasNext()) {
                            throw new NoSuchElementException();
                        }
                        int i = this.index;
                        this.index++;
                        return (K) UncheckedUtils.unsafeCast(IdentityArrayMap.this.keys[i]);
                    }
                };
            }

            @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
            public int size() {
                return IdentityArrayMap.this.size;
            }
        };
    }

    @Override // java.util.Map
    @NotNull
    public Collection<V> values() {
        return new AbstractCollection<V>() { // from class: com.artillexstudios.axquestboard.libs.axapi.collections.IdentityArrayMap.2
            private static transient /* synthetic */ String RfRVKKbhsy = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

            @Override // java.util.AbstractCollection, java.util.Collection, java.lang.Iterable
            @NotNull
            public Iterator<V> iterator() {
                return new Iterator<V>() { // from class: com.artillexstudios.axquestboard.libs.axapi.collections.IdentityArrayMap.2.1
                    private int index = 0;
                    private static transient /* synthetic */ String rDcBNMFEBN = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

                    @Override // java.util.Iterator
                    public boolean hasNext() {
                        return this.index < IdentityArrayMap.this.size;
                    }

                    @Override // java.util.Iterator
                    public V next() {
                        if (!hasNext()) {
                            throw new NoSuchElementException();
                        }
                        int i = this.index;
                        this.index++;
                        return (V) UncheckedUtils.unsafeCast(IdentityArrayMap.this.values[i]);
                    }
                };
            }

            @Override // java.util.AbstractCollection, java.util.Collection
            public int size() {
                return IdentityArrayMap.this.size;
            }
        };
    }

    /* JADX INFO: renamed from: com.artillexstudios.axquestboard.libs.axapi.collections.IdentityArrayMap$3 */
    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/collections/IdentityArrayMap$3.class */
    class C00033 extends AbstractSet<Map.Entry<K, V>> {
        private static transient /* synthetic */ String FHAKpDKBcL = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        C00033() {
        }

        /* JADX INFO: renamed from: com.artillexstudios.axquestboard.libs.axapi.collections.IdentityArrayMap$3$1, reason: invalid class name */
        /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/collections/IdentityArrayMap$3$1.class */
        class AnonymousClass1 implements Iterator<Map.Entry<K, V>> {
            private int index = 0;
            private static transient /* synthetic */ String tWLvlFcNly = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

            AnonymousClass1() {
            }

            @Override // java.util.Iterator
            public boolean hasNext() {
                return this.index < IdentityArrayMap.this.size;
            }

            @Override // java.util.Iterator
            public Map.Entry<K, V> next() {
                if (!hasNext()) {
                    throw new NoSuchElementException();
                }
                return new Map.Entry<K, V>() { // from class: com.artillexstudios.axquestboard.libs.axapi.collections.IdentityArrayMap.3.1.1
                    private final int currentIndex;
                    private static transient /* synthetic */ String cTORuFxRQJ = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

                    {
                        AnonymousClass1 anonymousClass1 = AnonymousClass1.this;
                        int i = anonymousClass1.index;
                        anonymousClass1.index = i + 1;
                        this.currentIndex = i;
                    }

                    @Override // java.util.Map.Entry
                    public K getKey() {
                        return (K) UncheckedUtils.unsafeCast(IdentityArrayMap.this.keys[this.currentIndex]);
                    }

                    @Override // java.util.Map.Entry
                    public V getValue() {
                        return (V) UncheckedUtils.unsafeCast(IdentityArrayMap.this.values[this.currentIndex]);
                    }

                    @Override // java.util.Map.Entry
                    public V setValue(V v) {
                        V v2 = (V) UncheckedUtils.unsafeCast(IdentityArrayMap.this.values[this.currentIndex]);
                        IdentityArrayMap.this.values[this.currentIndex] = v;
                        return v2;
                    }
                };
            }

            @Override // java.util.Iterator
            public void remove() {
                if (this.index < 0) {
                    throw new IllegalStateException();
                }
                IdentityArrayMap.this.remove(IdentityArrayMap.this.keys[this.index - 1]);
                this.index--;
            }
        }

        @Override // java.util.AbstractCollection, java.util.Collection, java.lang.Iterable, java.util.Set
        @NotNull
        public Iterator<Map.Entry<K, V>> iterator() {
            return new AnonymousClass1();
        }

        @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
        public int size() {
            return IdentityArrayMap.this.size;
        }
    }

    @Override // java.util.Map
    @NotNull
    public Set<Map.Entry<K, V>> entrySet() {
        return new C00033();
    }

    private int findKey(Object key) {
        Object[] objArr = this.keys;
        int i = this.size;
        if (i == objArr.length) {
            return -1;
        }
        while (objArr[i] != key) {
            int i2 = i;
            i--;
            if (i2 == 0) {
                return -1;
            }
        }
        return i;
    }
}
