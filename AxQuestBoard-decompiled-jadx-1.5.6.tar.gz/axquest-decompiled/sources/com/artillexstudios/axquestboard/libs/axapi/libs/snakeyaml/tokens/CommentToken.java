package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.tokens;

import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.comments.CommentType;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.error.Mark;
import java.util.Objects;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/tokens/CommentToken.class */
public final class CommentToken extends Token {
    private final CommentType type;
    private final String value;
    private static transient /* synthetic */ String BYyPkCZdsj = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public CommentToken(CommentType commentType, String str, Mark mark, Mark mark2) {
        super(mark, mark2);
        Objects.requireNonNull(commentType);
        this.type = commentType;
        Objects.requireNonNull(str);
        this.value = str;
    }

    public CommentType getCommentType() {
        return this.type;
    }

    public String getValue() {
        return this.value;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.tokens.Token
    public Token.ID getTokenId() {
        return Token.ID.Comment;
    }
}
