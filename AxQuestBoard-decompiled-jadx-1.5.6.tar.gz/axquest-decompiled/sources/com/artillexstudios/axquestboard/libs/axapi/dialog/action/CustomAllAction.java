package com.artillexstudios.axquestboard.libs.axapi.dialog.action;

import com.artillexstudios.axquestboard.libs.axapi.items.nbt.CompoundTag;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.runtime.ObjectMethods;
import net.kyori.adventure.key.Key;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/dialog/action/CustomAllAction.class */
public final class CustomAllAction extends Record implements Action {
    private final Key key;
    private final CompoundTag tag;
    private static transient /* synthetic */ String GeqXEgrthH = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public CustomAllAction(Key key, CompoundTag tag) {
        this.key = key;
        this.tag = tag;
    }

    @Override // java.lang.Record
    public final String toString() {
        return (String) ObjectMethods.bootstrap(MethodHandles.lookup(), "toString", MethodType.methodType(String.class, CustomAllAction.class), CustomAllAction.class, "key;tag", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/dialog/action/CustomAllAction;->key:Lnet/kyori/adventure/key/Key;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/dialog/action/CustomAllAction;->tag:Lcom/artillexstudios/axquestboard/libs/axapi/items/nbt/CompoundTag;").dynamicInvoker().invoke(this) /* invoke-custom */;
    }

    @Override // java.lang.Record
    public final int hashCode() {
        return (int) ObjectMethods.bootstrap(MethodHandles.lookup(), "hashCode", MethodType.methodType(Integer.TYPE, CustomAllAction.class), CustomAllAction.class, "key;tag", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/dialog/action/CustomAllAction;->key:Lnet/kyori/adventure/key/Key;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/dialog/action/CustomAllAction;->tag:Lcom/artillexstudios/axquestboard/libs/axapi/items/nbt/CompoundTag;").dynamicInvoker().invoke(this) /* invoke-custom */;
    }

    @Override // java.lang.Record
    public final boolean equals(Object o) {
        return (boolean) ObjectMethods.bootstrap(MethodHandles.lookup(), "equals", MethodType.methodType(Boolean.TYPE, CustomAllAction.class, Object.class), CustomAllAction.class, "key;tag", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/dialog/action/CustomAllAction;->key:Lnet/kyori/adventure/key/Key;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/dialog/action/CustomAllAction;->tag:Lcom/artillexstudios/axquestboard/libs/axapi/items/nbt/CompoundTag;").dynamicInvoker().invoke(this, o) /* invoke-custom */;
    }

    public Key key() {
        return this.key;
    }

    public CompoundTag tag() {
        return this.tag;
    }
}
