package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.utils.format;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Tag;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/utils/format/Formatter.class */
public interface Formatter<S, V> {
    @NotNull
    S format(@NotNull Tag tag, @NotNull V v, @NotNull NodeRole nodeRole, @NotNull S s);

    @NotNull
    static <S, V> Formatter<S, V> identity() {
        return (tag, value, role, def) -> {
            return def;
        };
    }
}
