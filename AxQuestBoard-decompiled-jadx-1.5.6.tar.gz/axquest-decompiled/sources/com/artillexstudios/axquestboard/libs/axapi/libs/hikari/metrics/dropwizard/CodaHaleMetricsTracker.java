package com.artillexstudios.axquestboard.libs.axapi.libs.hikari.metrics.dropwizard;

import com.artillexstudios.axquestboard.libs.axapi.libs.hikari.metrics.IMetricsTracker;
import com.artillexstudios.axquestboard.libs.axapi.libs.hikari.metrics.PoolStats;
import com.codahale.metrics.Histogram;
import com.codahale.metrics.Meter;
import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.Timer;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/hikari/metrics/dropwizard/CodaHaleMetricsTracker.class */
public final class CodaHaleMetricsTracker implements IMetricsTracker {
    private final String poolName;
    private final Timer connectionObtainTimer;
    private final Histogram connectionUsage;
    private final Histogram connectionCreation;
    private final Meter connectionTimeoutMeter;
    private final MetricRegistry registry;
    private static transient /* synthetic */ String PqCvMkWiCi = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    CodaHaleMetricsTracker(String str, PoolStats poolStats, MetricRegistry metricRegistry) {
        this.poolName = str;
        this.registry = metricRegistry;
        this.connectionObtainTimer = metricRegistry.timer(MetricRegistry.name(str, new String[]{"pool", "Wait"}));
        this.connectionUsage = metricRegistry.histogram(MetricRegistry.name(str, new String[]{"pool", "Usage"}));
        this.connectionCreation = metricRegistry.histogram(MetricRegistry.name(str, new String[]{"pool", "ConnectionCreation"}));
        this.connectionTimeoutMeter = metricRegistry.meter(MetricRegistry.name(str, new String[]{"pool", "ConnectionTimeoutRate"}));
        String strName = MetricRegistry.name(str, new String[]{"pool", "TotalConnections"});
        Objects.requireNonNull(poolStats);
        metricRegistry.register(strName, poolStats::getTotalConnections);
        String strName2 = MetricRegistry.name(str, new String[]{"pool", "IdleConnections"});
        Objects.requireNonNull(poolStats);
        metricRegistry.register(strName2, poolStats::getIdleConnections);
        String strName3 = MetricRegistry.name(str, new String[]{"pool", "ActiveConnections"});
        Objects.requireNonNull(poolStats);
        metricRegistry.register(strName3, poolStats::getActiveConnections);
        String strName4 = MetricRegistry.name(str, new String[]{"pool", "PendingConnections"});
        Objects.requireNonNull(poolStats);
        metricRegistry.register(strName4, poolStats::getPendingThreads);
        String strName5 = MetricRegistry.name(str, new String[]{"pool", "MaxConnections"});
        Objects.requireNonNull(poolStats);
        metricRegistry.register(strName5, poolStats::getMaxConnections);
        String strName6 = MetricRegistry.name(str, new String[]{"pool", "MinConnections"});
        Objects.requireNonNull(poolStats);
        metricRegistry.register(strName6, poolStats::getMinConnections);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.hikari.metrics.IMetricsTracker, java.lang.AutoCloseable
    public void close() {
        this.registry.remove(MetricRegistry.name(this.poolName, new String[]{"pool", "Wait"}));
        this.registry.remove(MetricRegistry.name(this.poolName, new String[]{"pool", "Usage"}));
        this.registry.remove(MetricRegistry.name(this.poolName, new String[]{"pool", "ConnectionCreation"}));
        this.registry.remove(MetricRegistry.name(this.poolName, new String[]{"pool", "ConnectionTimeoutRate"}));
        this.registry.remove(MetricRegistry.name(this.poolName, new String[]{"pool", "TotalConnections"}));
        this.registry.remove(MetricRegistry.name(this.poolName, new String[]{"pool", "IdleConnections"}));
        this.registry.remove(MetricRegistry.name(this.poolName, new String[]{"pool", "ActiveConnections"}));
        this.registry.remove(MetricRegistry.name(this.poolName, new String[]{"pool", "PendingConnections"}));
        this.registry.remove(MetricRegistry.name(this.poolName, new String[]{"pool", "MaxConnections"}));
        this.registry.remove(MetricRegistry.name(this.poolName, new String[]{"pool", "MinConnections"}));
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.hikari.metrics.IMetricsTracker
    public void recordConnectionAcquiredNanos(long j) {
        this.connectionObtainTimer.update(j, TimeUnit.NANOSECONDS);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.hikari.metrics.IMetricsTracker
    public void recordConnectionUsageMillis(long j) {
        this.connectionUsage.update(j);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.hikari.metrics.IMetricsTracker
    public void recordConnectionTimeout() {
        this.connectionTimeoutMeter.mark();
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.hikari.metrics.IMetricsTracker
    public void recordConnectionCreatedMillis(long j) {
        this.connectionCreation.update(j);
    }

    public Timer getConnectionAcquisitionTimer() {
        return this.connectionObtainTimer;
    }

    public Histogram getConnectionDurationHistogram() {
        return this.connectionUsage;
    }

    public Histogram getConnectionCreationHistogram() {
        return this.connectionCreation;
    }
}
