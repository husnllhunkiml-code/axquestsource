package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.emitter;

import java.io.IOException;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/emitter/EmitterState.class */
interface EmitterState {
    void expect() throws IOException;
}
