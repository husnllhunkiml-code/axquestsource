package com.artillexstudios.axquestboard.libs.axapi.config;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.YamlDocument;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.block.implementation.Section;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.dumper.DumperSettings;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.general.GeneralSettings;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.loader.LoaderSettings;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.updater.UpdaterSettings;
import com.artillexstudios.axquestboard.libs.axapi.utils.YamlUtils;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/Config.class */
public class Config {
    private YamlDocument configuration;
    private static transient /* synthetic */ String nMvYyKItwE = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public Config(File file) {
        this(file, null);
    }

    public Config(File file, InputStream defaults) {
        this(file, defaults, GeneralSettings.DEFAULT, LoaderSettings.DEFAULT, DumperSettings.DEFAULT, UpdaterSettings.DEFAULT);
    }

    public Config(File file, InputStream defaults, GeneralSettings generalSettings, LoaderSettings loaderSettings, DumperSettings dumperSettings, UpdaterSettings updaterSettings) {
        try {
            this.configuration = YamlDocument.create(file, defaults, generalSettings, loaderSettings, dumperSettings, updaterSettings);
        } catch (Exception e) {
            YamlUtils.suggest(file);
        }
    }

    public <T> T get(String str) {
        return (T) this.configuration.get(str);
    }

    public <T> T get(String str, T t) {
        return (T) this.configuration.get(str, t);
    }

    public void set(String key, Object value) {
        this.configuration.set(key, value);
    }

    public void remove(String key) {
        this.configuration.remove(key);
    }

    public boolean getBoolean(String key) {
        return this.configuration.getBoolean(key).booleanValue();
    }

    public String getString(String key) {
        return this.configuration.getString(key);
    }

    public int getInt(String key) {
        return this.configuration.getInt(key).intValue();
    }

    public int getInt(String key, int def) {
        return this.configuration.getInt(key, Integer.valueOf(def)).intValue();
    }

    public long getLong(String key) {
        return this.configuration.getLong(key).longValue();
    }

    public long getLong(String key, long def) {
        return this.configuration.getLong(key, Long.valueOf(def)).longValue();
    }

    public List<String> getStringList(String key) {
        return getList(key);
    }

    public List<String> getStringList(String key, List<String> def) {
        return getList(key, def);
    }

    public <T> List<T> getList(String str) {
        return (List<T>) this.configuration.getList(str);
    }

    public <T> List<T> getList(String str, List<T> list) {
        return (List<T>) this.configuration.getList(str, (List<?>) list);
    }

    public double getDouble(String key) {
        return this.configuration.getDouble(key).doubleValue();
    }

    public double getDouble(String key, double def) {
        return this.configuration.getDouble(key, Double.valueOf(def)).doubleValue();
    }

    public float getDouble(String key, float def) {
        return this.configuration.getFloat(key, Float.valueOf(def)).floatValue();
    }

    public String getString(String key, String def) {
        return this.configuration.getString(key, def);
    }

    public boolean getBoolean(String key, boolean def) {
        return this.configuration.getBoolean(key, Boolean.valueOf(def)).booleanValue();
    }

    public float getFloat(String key) {
        return this.configuration.getFloat(key).floatValue();
    }

    public float getFloat(String key, float def) {
        return this.configuration.getFloat(key, Float.valueOf(def)).floatValue();
    }

    public <T, U> List<Map<T, U>> getMapList(String key) {
        ArrayList arrayList = new ArrayList();
        for (Map<?, ?> map : this.configuration.getMapList(key)) {
            HashMap map2 = new HashMap();
            map.forEach((obj, obj2) -> {
                map2.put(obj, obj2);
            });
            arrayList.add(map2);
        }
        return arrayList;
    }

    public Section getSection(String key) {
        return this.configuration.getSection(key);
    }

    public <T> Optional<T> getOptional(String str) {
        return (Optional<T>) this.configuration.getOptional(str);
    }

    public Set<String> getKeys(boolean deep) {
        return this.configuration.getRoutesAsStrings(deep);
    }

    public boolean reload() {
        try {
            return this.configuration.reload();
        } catch (Exception e) {
            YamlUtils.suggest(this.configuration.getFile());
            return false;
        }
    }

    public void save() {
        try {
            this.configuration.save();
        } catch (IOException e) {
            YamlUtils.suggest(this.configuration.getFile());
        }
    }

    public YamlDocument getBackingDocument() {
        return this.configuration;
    }
}
