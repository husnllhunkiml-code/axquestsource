package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.scanner;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.LoadSettings;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.comments.CommentType;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.Anchor;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.ArrayStack;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.CharConstants;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.ScalarStyle;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.UriEncoder;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.Mark;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.ScannerException;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.YamlEngineException;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.AliasToken;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.AnchorToken;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.BlockEndToken;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.BlockEntryToken;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.BlockMappingStartToken;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.BlockSequenceStartToken;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.CommentToken;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.DirectiveToken;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.DocumentEndToken;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.DocumentStartToken;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.FlowEntryToken;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.FlowMappingEndToken;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.FlowMappingStartToken;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.FlowSequenceEndToken;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.FlowSequenceStartToken;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.KeyToken;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.ScalarToken;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.StreamEndToken;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.StreamStartToken;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.TagToken;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.TagTuple;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.Token;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.ValueToken;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.general.GeneralSettings;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.regex.Pattern;
import net.kyori.adventure.text.minimessage.internal.parser.TokenParser;
import net.kyori.adventure.text.minimessage.tag.standard.DecorationTag;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/scanner/ScannerImpl.class */
public final class ScannerImpl implements Scanner {
    private static final String DIRECTIVE_PREFIX = "while scanning a directive";
    private static final String EXPECTED_ALPHA_ERROR_PREFIX = "expected alphabetic or numeric character, but found ";
    private static final String SCANNING_SCALAR = "while scanning a block scalar";
    private static final String SCANNING_PREFIX = "while scanning a ";
    private static final Pattern NOT_HEXA = Pattern.compile("[^0-9A-Fa-f]");
    private final StreamReader reader;
    private final List<Token> tokens;
    private final ArrayStack<Integer> indents;
    private final Map<Integer, SimpleKey> possibleSimpleKeys;
    private final LoadSettings settings;
    private boolean done;
    private int flowLevel;
    private Token lastToken;
    private int tokensTaken;
    private int indent;
    private boolean allowSimpleKey;
    private static transient /* synthetic */ String jDAkzPOixl = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    @Deprecated
    public ScannerImpl(StreamReader streamReader, LoadSettings loadSettings) {
        this(loadSettings, streamReader);
    }

    public ScannerImpl(LoadSettings loadSettings, StreamReader streamReader) {
        this.done = false;
        this.flowLevel = 0;
        this.tokensTaken = 0;
        this.indent = -1;
        this.allowSimpleKey = true;
        this.reader = streamReader;
        this.settings = loadSettings;
        this.tokens = new ArrayList(100);
        this.indents = new ArrayStack<>(10);
        this.possibleSimpleKeys = new LinkedHashMap();
        fetchStreamStart();
    }

    @Deprecated
    public ScannerImpl(StreamReader streamReader) {
        this(LoadSettings.builder().build(), streamReader);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.scanner.Scanner
    public boolean checkToken(Token.ID... idArr) {
        while (needMoreTokens()) {
            fetchMoreTokens();
        }
        if (!this.tokens.isEmpty()) {
            if (idArr.length == 0) {
                return true;
            }
            Token.ID tokenId = this.tokens.get(0).getTokenId();
            for (Token.ID id : idArr) {
                if (tokenId == id) {
                    return true;
                }
            }
            return false;
        }
        return false;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.scanner.Scanner
    public Token peekToken() {
        while (needMoreTokens()) {
            fetchMoreTokens();
        }
        return this.tokens.get(0);
    }

    @Override // java.util.Iterator
    public boolean hasNext() {
        return checkToken(new Token.ID[0]);
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.scanner.Scanner, java.util.Iterator
    public Token next() {
        this.tokensTaken++;
        if (this.tokens.isEmpty()) {
            throw new NoSuchElementException("No more Tokens found.");
        }
        return this.tokens.remove(0);
    }

    private void addToken(Token token) {
        this.lastToken = token;
        this.tokens.add(token);
    }

    private void addToken(int i, Token token) {
        if (i == this.tokens.size()) {
            this.lastToken = token;
        }
        this.tokens.add(i, token);
    }

    private void addAllTokens(List<Token> list) {
        this.lastToken = list.get(list.size() - 1);
        this.tokens.addAll(list);
    }

    private boolean isBlockContext() {
        return this.flowLevel == 0;
    }

    private boolean isFlowContext() {
        return !isBlockContext();
    }

    private boolean needMoreTokens() {
        if (this.done) {
            return false;
        }
        if (this.tokens.isEmpty()) {
            return true;
        }
        stalePossibleSimpleKeys();
        return nextPossibleSimpleKey() == this.tokensTaken;
    }

    private void fetchMoreTokens() {
        if (this.reader.getDocumentIndex() > this.settings.getCodePointLimit()) {
            throw new YamlEngineException("The incoming YAML document exceeds the limit: " + this.settings.getCodePointLimit() + " code points.");
        }
        scanToNextToken();
        stalePossibleSimpleKeys();
        unwindIndent(this.reader.getColumn());
        int iPeek = this.reader.peek();
        switch (iPeek) {
            case 0:
                fetchStreamEnd();
                return;
            case 33:
                fetchTag();
                return;
            case 34:
                fetchDouble();
                return;
            case 37:
                if (checkDirective()) {
                    fetchDirective();
                    return;
                }
                break;
            case LegacyComponentSerializer.AMPERSAND_CHAR /* 38 */:
                fetchAnchor();
                return;
            case 39:
                fetchSingle();
                return;
            case 42:
                fetchAlias();
                return;
            case 44:
                fetchFlowEntry();
                return;
            case 45:
                if (checkDocumentStart()) {
                    fetchDocumentStart();
                    return;
                } else if (checkBlockEntry()) {
                    fetchBlockEntry();
                    return;
                }
            case GeneralSettings.DEFAULT_ROUTE_SEPARATOR /* 46 */:
                if (checkDocumentEnd()) {
                    fetchDocumentEnd();
                    return;
                }
                break;
            case TokenParser.SEPARATOR /* 58 */:
                if (checkValue()) {
                    fetchValue();
                    return;
                }
                break;
            case TokenParser.TAG_END /* 62 */:
                if (isBlockContext()) {
                    fetchFolded();
                    return;
                }
                break;
            case 63:
                if (checkKey()) {
                    fetchKey();
                    return;
                }
                break;
            case 91:
                fetchFlowSequenceStart();
                return;
            case 93:
                fetchFlowSequenceEnd();
                return;
            case 123:
                fetchFlowMappingStart();
                return;
            case 124:
                if (isBlockContext()) {
                    fetchLiteral();
                    return;
                }
                break;
            case 125:
                fetchFlowMappingEnd();
                return;
        }
        if (checkPlain()) {
            fetchPlain();
            return;
        }
        String strEscapeChar = CharConstants.escapeChar(String.valueOf(Character.toChars(iPeek)));
        if (iPeek == 9) {
            strEscapeChar = strEscapeChar + "(TAB)";
        }
        throw new ScannerException("while scanning for the next token", Optional.empty(), String.format("found character '%s' that cannot start any token. (Do not use %s for indentation)", strEscapeChar, strEscapeChar), this.reader.getMark());
    }

    private int nextPossibleSimpleKey() {
        if (!this.possibleSimpleKeys.isEmpty()) {
            return this.possibleSimpleKeys.values().iterator().next().getTokenNumber();
        }
        return -1;
    }

    private void stalePossibleSimpleKeys() {
        if (!this.possibleSimpleKeys.isEmpty()) {
            Iterator<SimpleKey> it = this.possibleSimpleKeys.values().iterator();
            while (it.hasNext()) {
                SimpleKey next = it.next();
                if (next.getLine() != this.reader.getLine() || this.reader.getIndex() - next.getIndex() > 1024) {
                    if (next.isRequired()) {
                        throw new ScannerException("while scanning a simple key", next.getMark(), "could not find expected ':'", this.reader.getMark());
                    }
                    it.remove();
                }
            }
        }
    }

    private void savePossibleSimpleKey() {
        boolean z = isBlockContext() && this.indent == this.reader.getColumn();
        if (!this.allowSimpleKey && z) {
            throw new YamlEngineException("A simple key is required only if it is the first token in the current line");
        }
        if (this.allowSimpleKey) {
            removePossibleSimpleKey();
            this.possibleSimpleKeys.put(Integer.valueOf(this.flowLevel), new SimpleKey(this.tokensTaken + this.tokens.size(), z, this.reader.getIndex(), this.reader.getLine(), this.reader.getColumn(), this.reader.getMark()));
        }
    }

    private void removePossibleSimpleKey() {
        SimpleKey simpleKeyRemove = this.possibleSimpleKeys.remove(Integer.valueOf(this.flowLevel));
        if (simpleKeyRemove != null && simpleKeyRemove.isRequired()) {
            throw new ScannerException("while scanning a simple key", simpleKeyRemove.getMark(), "could not find expected ':'", this.reader.getMark());
        }
    }

    private void unwindIndent(int i) {
        if (isFlowContext()) {
            return;
        }
        while (this.indent > i) {
            Optional<Mark> mark = this.reader.getMark();
            this.indent = this.indents.pop().intValue();
            addToken(new BlockEndToken(mark, mark));
        }
    }

    private boolean addIndent(int i) {
        if (this.indent < i) {
            this.indents.push(Integer.valueOf(this.indent));
            this.indent = i;
            return true;
        }
        return false;
    }

    private void fetchStreamStart() {
        Optional<Mark> mark = this.reader.getMark();
        addToken(new StreamStartToken(mark, mark));
    }

    private void fetchStreamEnd() {
        unwindIndent(-1);
        removePossibleSimpleKey();
        this.allowSimpleKey = false;
        this.possibleSimpleKeys.clear();
        Optional<Mark> mark = this.reader.getMark();
        addToken(new StreamEndToken(mark, mark));
        this.done = true;
    }

    private void fetchDirective() {
        unwindIndent(-1);
        removePossibleSimpleKey();
        this.allowSimpleKey = false;
        addAllTokens(scanDirective());
    }

    private void fetchDocumentStart() {
        fetchDocumentIndicator(true);
    }

    private void fetchDocumentEnd() {
        fetchDocumentIndicator(false);
    }

    private void fetchDocumentIndicator(boolean z) {
        Token documentEndToken;
        unwindIndent(-1);
        removePossibleSimpleKey();
        this.allowSimpleKey = false;
        Optional<Mark> mark = this.reader.getMark();
        this.reader.forward(3);
        Optional<Mark> mark2 = this.reader.getMark();
        if (z) {
            documentEndToken = new DocumentStartToken(mark, mark2);
        } else {
            documentEndToken = new DocumentEndToken(mark, mark2);
        }
        addToken(documentEndToken);
    }

    private void fetchFlowSequenceStart() {
        fetchFlowCollectionStart(false);
    }

    private void fetchFlowMappingStart() {
        fetchFlowCollectionStart(true);
    }

    private void fetchFlowCollectionStart(boolean z) {
        Token flowSequenceStartToken;
        savePossibleSimpleKey();
        this.flowLevel++;
        this.allowSimpleKey = true;
        Optional<Mark> mark = this.reader.getMark();
        this.reader.forward(1);
        Optional<Mark> mark2 = this.reader.getMark();
        if (z) {
            flowSequenceStartToken = new FlowMappingStartToken(mark, mark2);
        } else {
            flowSequenceStartToken = new FlowSequenceStartToken(mark, mark2);
        }
        addToken(flowSequenceStartToken);
    }

    private void fetchFlowSequenceEnd() {
        fetchFlowCollectionEnd(false);
    }

    private void fetchFlowMappingEnd() {
        fetchFlowCollectionEnd(true);
    }

    private void fetchFlowCollectionEnd(boolean z) {
        Token flowSequenceEndToken;
        removePossibleSimpleKey();
        this.flowLevel--;
        this.allowSimpleKey = false;
        Optional<Mark> mark = this.reader.getMark();
        this.reader.forward();
        Optional<Mark> mark2 = this.reader.getMark();
        if (z) {
            flowSequenceEndToken = new FlowMappingEndToken(mark, mark2);
        } else {
            flowSequenceEndToken = new FlowSequenceEndToken(mark, mark2);
        }
        addToken(flowSequenceEndToken);
    }

    private void fetchFlowEntry() {
        this.allowSimpleKey = true;
        removePossibleSimpleKey();
        Optional<Mark> mark = this.reader.getMark();
        this.reader.forward();
        addToken(new FlowEntryToken(mark, this.reader.getMark()));
    }

    private void fetchBlockEntry() {
        if (isBlockContext()) {
            if (!this.allowSimpleKey) {
                throw new ScannerException("", Optional.empty(), "sequence entries are not allowed here", this.reader.getMark());
            }
            if (addIndent(this.reader.getColumn())) {
                Optional<Mark> mark = this.reader.getMark();
                addToken(new BlockSequenceStartToken(mark, mark));
            }
        }
        this.allowSimpleKey = true;
        removePossibleSimpleKey();
        Optional<Mark> mark2 = this.reader.getMark();
        this.reader.forward();
        addToken(new BlockEntryToken(mark2, this.reader.getMark()));
    }

    private void fetchKey() {
        if (isBlockContext()) {
            if (!this.allowSimpleKey) {
                throw new ScannerException("mapping keys are not allowed here", this.reader.getMark());
            }
            if (addIndent(this.reader.getColumn())) {
                Optional<Mark> mark = this.reader.getMark();
                addToken(new BlockMappingStartToken(mark, mark));
            }
        }
        this.allowSimpleKey = isBlockContext();
        removePossibleSimpleKey();
        Optional<Mark> mark2 = this.reader.getMark();
        this.reader.forward();
        addToken(new KeyToken(mark2, this.reader.getMark()));
    }

    private void fetchValue() {
        SimpleKey simpleKeyRemove = this.possibleSimpleKeys.remove(Integer.valueOf(this.flowLevel));
        if (simpleKeyRemove != null) {
            addToken(simpleKeyRemove.getTokenNumber() - this.tokensTaken, new KeyToken(simpleKeyRemove.getMark(), simpleKeyRemove.getMark()));
            if (isBlockContext() && addIndent(simpleKeyRemove.getColumn())) {
                addToken(simpleKeyRemove.getTokenNumber() - this.tokensTaken, new BlockMappingStartToken(simpleKeyRemove.getMark(), simpleKeyRemove.getMark()));
            }
            this.allowSimpleKey = false;
        } else {
            if (isBlockContext() && !this.allowSimpleKey) {
                throw new ScannerException("mapping values are not allowed here", this.reader.getMark());
            }
            if (isBlockContext() && addIndent(this.reader.getColumn())) {
                Optional<Mark> mark = this.reader.getMark();
                addToken(new BlockMappingStartToken(mark, mark));
            }
            this.allowSimpleKey = isBlockContext();
            removePossibleSimpleKey();
        }
        Optional<Mark> mark2 = this.reader.getMark();
        this.reader.forward();
        addToken(new ValueToken(mark2, this.reader.getMark()));
    }

    private void fetchAlias() {
        savePossibleSimpleKey();
        this.allowSimpleKey = false;
        addToken(scanAnchor(false));
    }

    private void fetchAnchor() {
        savePossibleSimpleKey();
        this.allowSimpleKey = false;
        addToken(scanAnchor(true));
    }

    private void fetchTag() {
        savePossibleSimpleKey();
        this.allowSimpleKey = false;
        addToken(scanTag());
    }

    private void fetchLiteral() {
        fetchBlockScalar(ScalarStyle.LITERAL);
    }

    private void fetchFolded() {
        fetchBlockScalar(ScalarStyle.FOLDED);
    }

    private void fetchBlockScalar(ScalarStyle scalarStyle) {
        this.allowSimpleKey = true;
        removePossibleSimpleKey();
        addAllTokens(scanBlockScalar(scalarStyle));
    }

    private void fetchSingle() {
        fetchFlowScalar(ScalarStyle.SINGLE_QUOTED);
    }

    private void fetchDouble() {
        fetchFlowScalar(ScalarStyle.DOUBLE_QUOTED);
    }

    private void fetchFlowScalar(ScalarStyle scalarStyle) {
        savePossibleSimpleKey();
        this.allowSimpleKey = false;
        addToken(scanFlowScalar(scalarStyle));
    }

    private void fetchPlain() {
        savePossibleSimpleKey();
        this.allowSimpleKey = false;
        addToken(scanPlain());
    }

    private boolean checkDirective() {
        return this.reader.getColumn() == 0;
    }

    private boolean checkDocumentStart() {
        return this.reader.getColumn() == 0 && "---".equals(this.reader.prefix(3)) && CharConstants.NULL_BL_T_LINEBR.has(this.reader.peek(3));
    }

    private boolean checkDocumentEnd() {
        return this.reader.getColumn() == 0 && "...".equals(this.reader.prefix(3)) && CharConstants.NULL_BL_T_LINEBR.has(this.reader.peek(3));
    }

    private boolean checkBlockEntry() {
        return CharConstants.NULL_BL_T_LINEBR.has(this.reader.peek(1));
    }

    private boolean checkKey() {
        return CharConstants.NULL_BL_T_LINEBR.has(this.reader.peek(1));
    }

    private boolean checkValue() {
        if (isFlowContext()) {
            return true;
        }
        return CharConstants.NULL_BL_T_LINEBR.has(this.reader.peek(1));
    }

    private boolean checkPlain() {
        int iPeek = this.reader.peek();
        if (CharConstants.NULL_BL_T_LINEBR.hasNo(iPeek, "-?:,[]{}#&*!|>'\"%@`")) {
            return true;
        }
        if (isBlockContext()) {
            return CharConstants.NULL_BL_T_LINEBR.hasNo(this.reader.peek(1)) && "-?:".indexOf(iPeek) != -1;
        }
        return CharConstants.NULL_BL_T_LINEBR.hasNo(this.reader.peek(1), ",]") && "-?".indexOf(iPeek) != -1;
    }

    private void scanToNextToken() {
        CommentType commentType;
        if (this.reader.getIndex() == 0 && this.reader.peek() == 65279) {
            this.reader.forward();
        }
        boolean z = false;
        int column = -1;
        while (!z) {
            Optional<Mark> mark = this.reader.getMark();
            int column2 = this.reader.getColumn();
            boolean z2 = false;
            int i = 0;
            while (this.reader.peek(i) == 32) {
                i++;
            }
            if (i > 0) {
                this.reader.forward(i);
            }
            if (this.reader.peek() == 35) {
                z2 = true;
                if (column2 != 0 && (this.lastToken == null || this.lastToken.getTokenId() != Token.ID.BlockEntry)) {
                    commentType = CommentType.IN_LINE;
                    column = this.reader.getColumn();
                } else if (column == this.reader.getColumn()) {
                    commentType = CommentType.IN_LINE;
                } else {
                    column = -1;
                    commentType = CommentType.BLOCK;
                }
                CommentToken commentTokenScanComment = scanComment(commentType);
                if (this.settings.getParseComments()) {
                    addToken(commentTokenScanComment);
                }
            }
            Optional<String> optionalScanLineBreak = scanLineBreak();
            if (optionalScanLineBreak.isPresent()) {
                if (this.settings.getParseComments() && !z2 && column2 == 0) {
                    addToken(new CommentToken(CommentType.BLANK_LINE, optionalScanLineBreak.get(), mark, this.reader.getMark()));
                }
                if (isBlockContext()) {
                    this.allowSimpleKey = true;
                }
            } else {
                z = true;
            }
        }
    }

    private CommentToken scanComment(CommentType commentType) {
        Optional<Mark> mark = this.reader.getMark();
        this.reader.forward();
        int i = 0;
        while (CharConstants.NULL_OR_LINEBR.hasNo(this.reader.peek(i))) {
            i++;
        }
        return new CommentToken(commentType, this.reader.prefixForward(i), mark, this.reader.getMark());
    }

    private List<Token> scanDirective() {
        Optional<Mark> mark;
        Optional optionalEmpty;
        Optional<Mark> mark2 = this.reader.getMark();
        this.reader.forward();
        String strScanDirectiveName = scanDirectiveName(mark2);
        if (DirectiveToken.YAML_DIRECTIVE.equals(strScanDirectiveName)) {
            optionalEmpty = Optional.of(scanYamlDirectiveValue(mark2));
            mark = this.reader.getMark();
        } else if (DirectiveToken.TAG_DIRECTIVE.equals(strScanDirectiveName)) {
            optionalEmpty = Optional.of(scanTagDirectiveValue(mark2));
            mark = this.reader.getMark();
        } else {
            mark = this.reader.getMark();
            int i = 0;
            while (CharConstants.NULL_OR_LINEBR.hasNo(this.reader.peek(i))) {
                i++;
            }
            if (i > 0) {
                this.reader.forward(i);
            }
            optionalEmpty = Optional.empty();
        }
        return makeTokenList(new DirectiveToken(strScanDirectiveName, optionalEmpty, mark2, mark), scanDirectiveIgnoredLine(mark2));
    }

    private String scanDirectiveName(Optional<Mark> optional) {
        int i;
        int i2 = 0;
        int iPeek = this.reader.peek(0);
        while (true) {
            i = iPeek;
            if (!CharConstants.ALPHA.has(i)) {
                break;
            }
            i2++;
            iPeek = this.reader.peek(i2);
        }
        if (i2 == 0) {
            throw new ScannerException(DIRECTIVE_PREFIX, optional, EXPECTED_ALPHA_ERROR_PREFIX + String.valueOf(Character.toChars(i)) + "(" + i + ")", this.reader.getMark());
        }
        String strPrefixForward = this.reader.prefixForward(i2);
        int iPeek2 = this.reader.peek();
        if (CharConstants.NULL_BL_LINEBR.hasNo(iPeek2)) {
            throw new ScannerException(DIRECTIVE_PREFIX, optional, EXPECTED_ALPHA_ERROR_PREFIX + String.valueOf(Character.toChars(iPeek2)) + "(" + iPeek2 + ")", this.reader.getMark());
        }
        return strPrefixForward;
    }

    private List<Integer> scanYamlDirectiveValue(Optional<Mark> optional) {
        while (this.reader.peek() == 32) {
            this.reader.forward();
        }
        Integer numScanYamlDirectiveNumber = scanYamlDirectiveNumber(optional);
        int iPeek = this.reader.peek();
        if (iPeek != 46) {
            throw new ScannerException(DIRECTIVE_PREFIX, optional, "expected a digit or '.', but found " + String.valueOf(Character.toChars(iPeek)) + "(" + iPeek + ")", this.reader.getMark());
        }
        this.reader.forward();
        Integer numScanYamlDirectiveNumber2 = scanYamlDirectiveNumber(optional);
        int iPeek2 = this.reader.peek();
        if (CharConstants.NULL_BL_LINEBR.hasNo(iPeek2)) {
            throw new ScannerException(DIRECTIVE_PREFIX, optional, "expected a digit or ' ', but found " + String.valueOf(Character.toChars(iPeek2)) + "(" + iPeek2 + ")", this.reader.getMark());
        }
        ArrayList arrayList = new ArrayList(2);
        arrayList.add(numScanYamlDirectiveNumber);
        arrayList.add(numScanYamlDirectiveNumber2);
        return arrayList;
    }

    private Integer scanYamlDirectiveNumber(Optional<Mark> optional) {
        int iPeek = this.reader.peek();
        if (!Character.isDigit(iPeek)) {
            throw new ScannerException(DIRECTIVE_PREFIX, optional, "expected a digit, but found " + String.valueOf(Character.toChars(iPeek)) + "(" + iPeek + ")", this.reader.getMark());
        }
        int i = 0;
        while (Character.isDigit(this.reader.peek(i))) {
            i++;
        }
        String strPrefixForward = this.reader.prefixForward(i);
        if (i > 3) {
            throw new ScannerException("while scanning a YAML directive", optional, "found a number which cannot represent a valid version: " + strPrefixForward, this.reader.getMark());
        }
        return Integer.valueOf(Integer.parseInt(strPrefixForward));
    }

    private List<String> scanTagDirectiveValue(Optional<Mark> optional) {
        while (this.reader.peek() == 32) {
            this.reader.forward();
        }
        String strScanTagDirectiveHandle = scanTagDirectiveHandle(optional);
        while (this.reader.peek() == 32) {
            this.reader.forward();
        }
        String strScanTagDirectivePrefix = scanTagDirectivePrefix(optional);
        ArrayList arrayList = new ArrayList(2);
        arrayList.add(strScanTagDirectiveHandle);
        arrayList.add(strScanTagDirectivePrefix);
        return arrayList;
    }

    private String scanTagDirectiveHandle(Optional<Mark> optional) {
        String strScanTagHandle = scanTagHandle("directive", optional);
        int iPeek = this.reader.peek();
        if (iPeek != 32) {
            throw new ScannerException(DIRECTIVE_PREFIX, optional, "expected ' ', but found " + String.valueOf(Character.toChars(iPeek)) + "(" + iPeek + ")", this.reader.getMark());
        }
        return strScanTagHandle;
    }

    private String scanTagDirectivePrefix(Optional<Mark> optional) {
        String strScanTagUri = scanTagUri("directive", CharConstants.URI_CHARS_FOR_TAG_PREFIX, optional);
        int iPeek = this.reader.peek();
        if (CharConstants.NULL_BL_LINEBR.hasNo(iPeek)) {
            throw new ScannerException(DIRECTIVE_PREFIX, optional, "expected ' ', but found " + String.valueOf(Character.toChars(iPeek)) + "(" + iPeek + ")", this.reader.getMark());
        }
        return strScanTagUri;
    }

    private CommentToken scanDirectiveIgnoredLine(Optional<Mark> optional) {
        while (this.reader.peek() == 32) {
            this.reader.forward();
        }
        CommentToken commentToken = null;
        if (this.reader.peek() == 35) {
            CommentToken commentTokenScanComment = scanComment(CommentType.IN_LINE);
            if (this.settings.getParseComments()) {
                commentToken = commentTokenScanComment;
            }
        }
        int iPeek = this.reader.peek();
        if (!scanLineBreak().isPresent() && iPeek != 0) {
            throw new ScannerException(DIRECTIVE_PREFIX, optional, "expected a comment or a line break, but found " + String.valueOf(Character.toChars(iPeek)) + "(" + iPeek + ")", this.reader.getMark());
        }
        return commentToken;
    }

    private Token scanAnchor(boolean z) {
        int i;
        Token aliasToken;
        Optional<Mark> mark = this.reader.getMark();
        String str = this.reader.peek() == 42 ? "alias" : "anchor";
        this.reader.forward();
        int i2 = 0;
        int iPeek = this.reader.peek(0);
        while (true) {
            i = iPeek;
            if (!CharConstants.NULL_BL_T_LINEBR.hasNo(i, ",[]{}/.*&")) {
                break;
            }
            i2++;
            iPeek = this.reader.peek(i2);
        }
        if (i2 == 0) {
            throw new ScannerException("while scanning an " + str, mark, "unexpected character found " + String.valueOf(Character.toChars(i)) + "(" + i + ")", this.reader.getMark());
        }
        String strPrefixForward = this.reader.prefixForward(i2);
        int iPeek2 = this.reader.peek();
        if (CharConstants.NULL_BL_T_LINEBR.hasNo(iPeek2, "?:,]}%@`")) {
            throw new ScannerException("while scanning an " + str, mark, "unexpected character found " + String.valueOf(Character.toChars(iPeek2)) + "(" + iPeek2 + ")", this.reader.getMark());
        }
        Optional<Mark> mark2 = this.reader.getMark();
        if (z) {
            aliasToken = new AnchorToken(new Anchor(strPrefixForward), mark, mark2);
        } else {
            aliasToken = new AliasToken(new Anchor(strPrefixForward), mark, mark2);
        }
        return aliasToken;
    }

    private Token scanTag() {
        String strScanTagUri;
        Optional<Mark> mark = this.reader.getMark();
        int iPeek = this.reader.peek(1);
        String strScanTagHandle = null;
        if (iPeek == 60) {
            this.reader.forward(2);
            strScanTagUri = scanTagUri("tag", CharConstants.URI_CHARS_FOR_TAG_PREFIX, mark);
            int iPeek2 = this.reader.peek();
            if (iPeek2 != 62) {
                throw new ScannerException("while scanning a tag", mark, "expected '>', but found '" + String.valueOf(Character.toChars(iPeek2)) + "' (" + iPeek2 + ")", this.reader.getMark());
            }
            this.reader.forward();
        } else if (CharConstants.NULL_BL_T_LINEBR.has(iPeek)) {
            strScanTagUri = DecorationTag.REVERT;
            this.reader.forward();
        } else {
            int i = 1;
            boolean z = false;
            while (CharConstants.NULL_BL_LINEBR.hasNo(iPeek)) {
                if (iPeek == 33) {
                    z = true;
                    break;
                }
                i++;
                iPeek = this.reader.peek(i);
            }
            if (z) {
                strScanTagHandle = scanTagHandle("tag", mark);
            } else {
                strScanTagHandle = DecorationTag.REVERT;
                this.reader.forward();
            }
            strScanTagUri = scanTagUri("tag", CharConstants.URI_CHARS_FOR_TAG_SUFFIX, mark);
        }
        int iPeek3 = this.reader.peek();
        if (CharConstants.NULL_BL_LINEBR.hasNo(iPeek3)) {
            throw new ScannerException("while scanning a tag", mark, "expected ' ', but found '" + String.valueOf(Character.toChars(iPeek3)) + "' (" + iPeek3 + ")", this.reader.getMark());
        }
        return new TagToken(new TagTuple(Optional.ofNullable(strScanTagHandle), strScanTagUri), mark, this.reader.getMark());
    }

    private List<Token> scanBlockScalar(ScalarStyle scalarStyle) {
        String str;
        Optional optional;
        int iMax;
        StringBuilder sb = new StringBuilder();
        Optional<Mark> mark = this.reader.getMark();
        this.reader.forward();
        Chomping chompingScanBlockScalarIndicators = scanBlockScalarIndicators(mark);
        CommentToken commentTokenScanBlockScalarIgnoredLine = scanBlockScalarIgnoredLine(mark);
        int i = this.indent + 1;
        if (i < 1) {
            i = 1;
        }
        if (!chompingScanBlockScalarIndicators.increment.isPresent()) {
            BreakIntentHolder breakIntentHolderScanBlockScalarIndentation = scanBlockScalarIndentation();
            str = breakIntentHolderScanBlockScalarIndentation.breaks;
            int i2 = breakIntentHolderScanBlockScalarIndentation.maxIndent;
            optional = breakIntentHolderScanBlockScalarIndentation.endMark;
            iMax = Math.max(i, i2);
        } else {
            iMax = (i + ((Integer) chompingScanBlockScalarIndicators.increment.get()).intValue()) - 1;
            BreakIntentHolder breakIntentHolderScanBlockScalarBreaks = scanBlockScalarBreaks(iMax);
            str = breakIntentHolderScanBlockScalarBreaks.breaks;
            optional = breakIntentHolderScanBlockScalarBreaks.endMark;
        }
        Optional<String> optionalEmpty = Optional.empty();
        if (this.reader.getColumn() < iMax && this.indent != this.reader.getColumn()) {
            throw new ScannerException(SCANNING_SCALAR, mark, " the leading empty lines contain more spaces (" + iMax + ") than the first non-empty line.", this.reader.getMark());
        }
        while (this.reader.getColumn() == iMax && this.reader.peek() != 0) {
            sb.append(str);
            boolean z = " \t".indexOf(this.reader.peek()) == -1;
            int i3 = 0;
            while (CharConstants.NULL_OR_LINEBR.hasNo(this.reader.peek(i3))) {
                i3++;
            }
            sb.append(this.reader.prefixForward(i3));
            optionalEmpty = scanLineBreak();
            BreakIntentHolder breakIntentHolderScanBlockScalarBreaks2 = scanBlockScalarBreaks(iMax);
            str = breakIntentHolderScanBlockScalarBreaks2.breaks;
            optional = breakIntentHolderScanBlockScalarBreaks2.endMark;
            if (this.reader.getColumn() != iMax || this.reader.peek() == 0) {
                break;
            }
            if (scalarStyle == ScalarStyle.FOLDED && "\n".equals(optionalEmpty.orElse("")) && z && " \t".indexOf(this.reader.peek()) == -1) {
                if (str.isEmpty()) {
                    sb.append(" ");
                }
            } else {
                sb.append(optionalEmpty.orElse(""));
            }
        }
        if (chompingScanBlockScalarIndicators.value == Chomping.Indicator.CLIP || chompingScanBlockScalarIndicators.value == Chomping.Indicator.KEEP) {
            sb.append(optionalEmpty.orElse(""));
        }
        if (chompingScanBlockScalarIndicators.value == Chomping.Indicator.KEEP) {
            sb.append(str);
        }
        return makeTokenList(commentTokenScanBlockScalarIgnoredLine, new ScalarToken(sb.toString(), false, scalarStyle, mark, optional));
    }

    private Chomping scanBlockScalarIndicators(Optional<Mark> optional) {
        int i = Integer.MIN_VALUE;
        Optional optionalEmpty = Optional.empty();
        int iPeek = this.reader.peek();
        if (iPeek == 45 || iPeek == 43) {
            i = iPeek;
            this.reader.forward();
            int iPeek2 = this.reader.peek();
            if (Character.isDigit(iPeek2)) {
                int i2 = Integer.parseInt(String.valueOf(Character.toChars(iPeek2)));
                if (i2 == 0) {
                    throw new ScannerException(SCANNING_SCALAR, optional, "expected indentation indicator in the range 1-9, but found 0", this.reader.getMark());
                }
                optionalEmpty = Optional.of(Integer.valueOf(i2));
                this.reader.forward();
            }
        } else if (Character.isDigit(iPeek)) {
            int i3 = Integer.parseInt(String.valueOf(Character.toChars(iPeek)));
            if (i3 == 0) {
                throw new ScannerException(SCANNING_SCALAR, optional, "expected indentation indicator in the range 1-9, but found 0", this.reader.getMark());
            }
            optionalEmpty = Optional.of(Integer.valueOf(i3));
            this.reader.forward();
            int iPeek3 = this.reader.peek();
            if (iPeek3 == 45 || iPeek3 == 43) {
                i = iPeek3;
                this.reader.forward();
            }
        }
        int iPeek4 = this.reader.peek();
        if (CharConstants.NULL_BL_LINEBR.hasNo(iPeek4)) {
            throw new ScannerException(SCANNING_SCALAR, optional, "expected chomping or indentation indicators, but found " + String.valueOf(Character.toChars(iPeek4)) + "(" + iPeek4 + ")", this.reader.getMark());
        }
        return new Chomping(i, (Optional<Integer>) optionalEmpty);
    }

    private CommentToken scanBlockScalarIgnoredLine(Optional<Mark> optional) {
        while (this.reader.peek() == 32) {
            this.reader.forward();
        }
        CommentToken commentTokenScanComment = null;
        if (this.reader.peek() == 35) {
            commentTokenScanComment = scanComment(CommentType.IN_LINE);
        }
        int iPeek = this.reader.peek();
        if (!scanLineBreak().isPresent() && iPeek != 0) {
            throw new ScannerException(SCANNING_SCALAR, optional, "expected a comment or a line break, but found " + String.valueOf(Character.toChars(iPeek)) + "(" + iPeek + ")", this.reader.getMark());
        }
        return commentTokenScanComment;
    }

    private BreakIntentHolder scanBlockScalarIndentation() {
        StringBuilder sb = new StringBuilder();
        int column = 0;
        Optional<Mark> mark = this.reader.getMark();
        while (CharConstants.LINEBR.has(this.reader.peek(), " \r")) {
            if (this.reader.peek() != 32) {
                sb.append(scanLineBreak().orElse(""));
                mark = this.reader.getMark();
            } else {
                this.reader.forward();
                if (this.reader.getColumn() > column) {
                    column = this.reader.getColumn();
                }
            }
        }
        return new BreakIntentHolder(sb.toString(), column, mark);
    }

    private BreakIntentHolder scanBlockScalarBreaks(int i) {
        StringBuilder sb = new StringBuilder();
        Optional<Mark> mark = this.reader.getMark();
        for (int column = this.reader.getColumn(); column < i && this.reader.peek() == 32; column++) {
            this.reader.forward();
        }
        while (true) {
            Optional<String> optionalScanLineBreak = scanLineBreak();
            if (optionalScanLineBreak.isPresent()) {
                sb.append(optionalScanLineBreak.get());
                mark = this.reader.getMark();
                for (int column2 = this.reader.getColumn(); column2 < i && this.reader.peek() == 32; column2++) {
                    this.reader.forward();
                }
            } else {
                return new BreakIntentHolder(sb.toString(), -1, mark);
            }
        }
    }

    private Token scanFlowScalar(ScalarStyle scalarStyle) {
        boolean z = scalarStyle == ScalarStyle.DOUBLE_QUOTED;
        StringBuilder sb = new StringBuilder();
        Optional<Mark> mark = this.reader.getMark();
        int iPeek = this.reader.peek();
        this.reader.forward();
        sb.append(scanFlowScalarNonSpaces(z, mark));
        while (this.reader.peek() != iPeek) {
            sb.append(scanFlowScalarSpaces(mark));
            sb.append(scanFlowScalarNonSpaces(z, mark));
        }
        this.reader.forward();
        return new ScalarToken(sb.toString(), false, scalarStyle, mark, this.reader.getMark());
    }

    private String scanFlowScalarNonSpaces(boolean z, Optional<Mark> optional) {
        StringBuilder sb = new StringBuilder();
        while (true) {
            int i = 0;
            while (CharConstants.NULL_BL_T_LINEBR.hasNo(this.reader.peek(i), "'\"\\")) {
                i++;
            }
            if (i != 0) {
                sb.append(this.reader.prefixForward(i));
            }
            int iPeek = this.reader.peek();
            if (!z && iPeek == 39 && this.reader.peek(1) == 39) {
                sb.append("'");
                this.reader.forward(2);
            } else if ((z && iPeek == 39) || (!z && "\"\\".indexOf(iPeek) != -1)) {
                sb.appendCodePoint(iPeek);
                this.reader.forward();
            } else {
                if (!z || iPeek != 92) {
                    break;
                }
                this.reader.forward();
                int iPeek2 = this.reader.peek();
                if (!Character.isSupplementaryCodePoint(iPeek2) && CharConstants.ESCAPE_REPLACEMENTS.containsKey(Character.valueOf((char) iPeek2))) {
                    sb.append(CharConstants.ESCAPE_REPLACEMENTS.get(Character.valueOf((char) iPeek2)));
                    this.reader.forward();
                } else if (!Character.isSupplementaryCodePoint(iPeek2) && CharConstants.ESCAPE_CODES.containsKey(Character.valueOf((char) iPeek2))) {
                    int iIntValue = CharConstants.ESCAPE_CODES.get(Character.valueOf((char) iPeek2)).intValue();
                    this.reader.forward();
                    String strPrefix = this.reader.prefix(iIntValue);
                    if (NOT_HEXA.matcher(strPrefix).find()) {
                        throw new ScannerException("while scanning a double-quoted scalar", optional, "expected escape sequence of " + iIntValue + " hexadecimal numbers, but found: " + strPrefix, this.reader.getMark());
                    }
                    try {
                        sb.append(new String(Character.toChars(Integer.parseInt(strPrefix, 16))));
                        this.reader.forward(iIntValue);
                    } catch (IllegalArgumentException e) {
                        throw new ScannerException("while scanning a double-quoted scalar", optional, "found unknown escape character " + strPrefix, this.reader.getMark());
                    }
                } else if (scanLineBreak().isPresent()) {
                    sb.append(scanFlowScalarBreaks(optional));
                } else {
                    throw new ScannerException("while scanning a double-quoted scalar", optional, "found unknown escape character " + String.valueOf(Character.toChars(iPeek2)) + "(" + iPeek2 + ")", this.reader.getMark());
                }
            }
        }
        return sb.toString();
    }

    private String scanFlowScalarSpaces(Optional<Mark> optional) {
        StringBuilder sb = new StringBuilder();
        int i = 0;
        while (" \t".indexOf(this.reader.peek(i)) != -1) {
            i++;
        }
        String strPrefixForward = this.reader.prefixForward(i);
        if (this.reader.peek() == 0) {
            throw new ScannerException("while scanning a quoted scalar", optional, "found unexpected end of stream", this.reader.getMark());
        }
        Optional<String> optionalScanLineBreak = scanLineBreak();
        if (optionalScanLineBreak.isPresent()) {
            String strScanFlowScalarBreaks = scanFlowScalarBreaks(optional);
            if (!"\n".equals(optionalScanLineBreak.get())) {
                sb.append(optionalScanLineBreak.get());
            } else if (strScanFlowScalarBreaks.isEmpty()) {
                sb.append(" ");
            }
            sb.append(strScanFlowScalarBreaks);
        } else {
            sb.append(strPrefixForward);
        }
        return sb.toString();
    }

    private String scanFlowScalarBreaks(Optional<Mark> optional) {
        StringBuilder sb = new StringBuilder();
        while (true) {
            String strPrefix = this.reader.prefix(3);
            if (("---".equals(strPrefix) || "...".equals(strPrefix)) && CharConstants.NULL_BL_T_LINEBR.has(this.reader.peek(3))) {
                throw new ScannerException("while scanning a quoted scalar", optional, "found unexpected document separator", this.reader.getMark());
            }
            while (" \t".indexOf(this.reader.peek()) != -1) {
                this.reader.forward();
            }
            Optional<String> optionalScanLineBreak = scanLineBreak();
            if (optionalScanLineBreak.isPresent()) {
                sb.append(optionalScanLineBreak.get());
            } else {
                return sb.toString();
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:16:0x0072  */
    private Token scanPlain() {
        StringBuilder sb = new StringBuilder();
        Optional<Mark> mark = this.reader.getMark();
        Optional<Mark> mark2 = mark;
        int i = this.indent + 1;
        String strScanPlainSpaces = "";
        while (true) {
            int i2 = 0;
            if (this.reader.peek() == 35) {
                break;
            }
            while (true) {
                int iPeek = this.reader.peek(i2);
                if (CharConstants.NULL_BL_T_LINEBR.has(iPeek)) {
                    break;
                }
                if (iPeek == 58) {
                    if (!CharConstants.NULL_BL_T_LINEBR.has(this.reader.peek(i2 + 1), isFlowContext() ? ",[]{}" : "")) {
                        if (!isFlowContext() && ",[]{}".indexOf(iPeek) != -1) {
                            break;
                        }
                        i2++;
                    } else {
                        break;
                    }
                } else {
                    if (!isFlowContext()) {
                    }
                    i2++;
                }
            }
            if (i2 == 0) {
                break;
            }
            this.allowSimpleKey = false;
            sb.append(strScanPlainSpaces);
            sb.append(this.reader.prefixForward(i2));
            mark2 = this.reader.getMark();
            strScanPlainSpaces = scanPlainSpaces();
            if (strScanPlainSpaces.isEmpty() || this.reader.peek() == 35 || (isBlockContext() && this.reader.getColumn() < i)) {
                break;
            }
        }
        return new ScalarToken(sb.toString(), true, mark, mark2);
    }

    private boolean atEndOfPlain() {
        int i = 0;
        int column = this.reader.getColumn();
        while (true) {
            int iPeek = this.reader.peek(i);
            if (iPeek == 0 || !CharConstants.NULL_BL_T_LINEBR.has(iPeek)) {
                break;
            }
            i++;
            if (!CharConstants.LINEBR.has(iPeek) && ((iPeek != 13 || this.reader.peek(i + 1) != 10) && iPeek != 65279)) {
                column++;
            } else {
                column = 0;
            }
        }
        if (this.reader.peek(i) != 35 && this.reader.peek(i + 1) != 0) {
            if (isBlockContext() && column < this.indent) {
                return true;
            }
            if (isBlockContext()) {
                int i2 = 1;
                while (true) {
                    int iPeek2 = this.reader.peek(i + i2);
                    if (iPeek2 != 0 && !CharConstants.NULL_BL_T_LINEBR.has(iPeek2)) {
                        if (iPeek2 != 58 || !CharConstants.NULL_BL_T_LINEBR.has(this.reader.peek(i + i2 + 1))) {
                            i2++;
                        } else {
                            return true;
                        }
                    } else {
                        return false;
                    }
                }
            } else {
                return false;
            }
        } else {
            return true;
        }
    }

    private String scanPlainSpaces() {
        int i = 0;
        while (true) {
            if (this.reader.peek(i) != 32 && this.reader.peek(i) != 9) {
                break;
            }
            i++;
        }
        String strPrefixForward = this.reader.prefixForward(i);
        Optional<String> optionalScanLineBreak = scanLineBreak();
        if (optionalScanLineBreak.isPresent()) {
            this.allowSimpleKey = true;
            String strPrefix = this.reader.prefix(3);
            if (!"---".equals(strPrefix)) {
                if ("...".equals(strPrefix) && CharConstants.NULL_BL_T_LINEBR.has(this.reader.peek(3))) {
                    return "";
                }
                if (this.settings.getParseComments() && atEndOfPlain()) {
                    return "";
                }
                StringBuilder sb = new StringBuilder();
                while (true) {
                    if (this.reader.peek() == 32) {
                        this.reader.forward();
                    } else {
                        Optional<String> optionalScanLineBreak2 = scanLineBreak();
                        if (optionalScanLineBreak2.isPresent()) {
                            sb.append(optionalScanLineBreak2.get());
                            String strPrefix2 = this.reader.prefix(3);
                            if (!"---".equals(strPrefix2)) {
                                if ("...".equals(strPrefix2) && CharConstants.NULL_BL_T_LINEBR.has(this.reader.peek(3))) {
                                    return "";
                                }
                            } else {
                                return "";
                            }
                        } else {
                            if (!"\n".equals(optionalScanLineBreak.orElse(""))) {
                                return optionalScanLineBreak.orElse("") + ((Object) sb);
                            }
                            if (sb.length() == 0) {
                                return " ";
                            }
                            return sb.toString();
                        }
                    }
                }
            } else {
                return "";
            }
        } else {
            return strPrefixForward;
        }
    }

    private String scanTagHandle(String str, Optional<Mark> optional) {
        int iPeek = this.reader.peek();
        if (iPeek != 33) {
            throw new ScannerException(SCANNING_PREFIX + str, optional, "expected '!', but found " + String.valueOf(Character.toChars(iPeek)) + "(" + iPeek + ")", this.reader.getMark());
        }
        int i = 1;
        int iPeek2 = this.reader.peek(1);
        if (iPeek2 != 32) {
            while (CharConstants.ALPHA.has(iPeek2)) {
                i++;
                iPeek2 = this.reader.peek(i);
            }
            if (iPeek2 != 33) {
                this.reader.forward(i);
                throw new ScannerException(SCANNING_PREFIX + str, optional, "expected '!', but found " + String.valueOf(Character.toChars(iPeek2)) + "(" + iPeek2 + ")", this.reader.getMark());
            }
            i++;
        }
        return this.reader.prefixForward(i);
    }

    private String scanTagUri(String str, CharConstants charConstants, Optional<Mark> optional) {
        int i;
        StringBuilder sb = new StringBuilder();
        int i2 = 0;
        int iPeek = this.reader.peek(0);
        while (true) {
            i = iPeek;
            if (!charConstants.has(i)) {
                break;
            }
            if (i == 37) {
                sb.append(this.reader.prefixForward(i2));
                i2 = 0;
                sb.append(scanUriEscapes(str, optional));
            } else {
                i2++;
            }
            iPeek = this.reader.peek(i2);
        }
        if (i2 != 0) {
            sb.append(this.reader.prefixForward(i2));
        }
        if (sb.length() == 0) {
            throw new ScannerException(SCANNING_PREFIX + str, optional, "expected URI, but found " + String.valueOf(Character.toChars(i)) + "(" + i + ")", this.reader.getMark());
        }
        return sb.toString();
    }

    private String scanUriEscapes(String str, Optional<Mark> optional) {
        int i = 1;
        while (this.reader.peek(i * 3) == 37) {
            i++;
        }
        Optional<Mark> mark = this.reader.getMark();
        ByteBuffer byteBufferAllocate = ByteBuffer.allocate(i);
        while (this.reader.peek() == 37) {
            this.reader.forward();
            try {
                byteBufferAllocate.put((byte) Integer.parseInt(this.reader.prefix(2), 16));
                this.reader.forward(2);
            } catch (NumberFormatException e) {
                int iPeek = this.reader.peek();
                String strValueOf = String.valueOf(Character.toChars(iPeek));
                int iPeek2 = this.reader.peek(1);
                throw new ScannerException(SCANNING_PREFIX + str, optional, "expected URI escape sequence of 2 hexadecimal numbers, but found " + strValueOf + "(" + iPeek + ") and " + String.valueOf(Character.toChars(iPeek2)) + "(" + iPeek2 + ")", this.reader.getMark());
            }
        }
        byteBufferAllocate.flip();
        try {
            return UriEncoder.decode(byteBufferAllocate);
        } catch (CharacterCodingException e2) {
            throw new ScannerException(SCANNING_PREFIX + str, optional, "expected URI in UTF-8: " + e2.getMessage(), mark);
        }
    }

    private Optional<String> scanLineBreak() {
        int iPeek = this.reader.peek();
        if (iPeek == 13 || iPeek == 10 || iPeek == 133) {
            if (iPeek == 13 && 10 == this.reader.peek(1)) {
                this.reader.forward(2);
            } else {
                this.reader.forward();
            }
            return Optional.of("\n");
        }
        return Optional.empty();
    }

    private List<Token> makeTokenList(Token... tokenArr) {
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < tokenArr.length; i++) {
            if (tokenArr[i] != null && (this.settings.getParseComments() || !(tokenArr[i] instanceof CommentToken))) {
                arrayList.add(tokenArr[i]);
            }
        }
        return arrayList;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.scanner.Scanner
    public void resetDocumentIndex() {
        this.reader.resetDocumentIndex();
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/scanner/ScannerImpl$Chomping.class */
    static class Chomping {
        private final Indicator value;
        private final Optional<Integer> increment;
        private static transient /* synthetic */ String UQWUaxgNcU = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/scanner/ScannerImpl$Chomping$Indicator.class */
        enum Indicator {
            STRIP,
            CLIP,
            KEEP
        }

        public Chomping(Indicator indicator, Optional<Integer> optional) {
            this.value = indicator;
            this.increment = optional;
        }

        public Chomping(int i, Optional<Integer> optional) {
            this(parse(i), optional);
        }

        private static Indicator parse(int i) {
            if (i == 43) {
                return Indicator.KEEP;
            }
            if (i == 45) {
                return Indicator.STRIP;
            }
            if (i == Integer.MIN_VALUE) {
                return Indicator.CLIP;
            }
            throw new IllegalArgumentException("Unexpected block chomping indicator: " + i);
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/scanner/ScannerImpl$BreakIntentHolder.class */
    static class BreakIntentHolder {
        private final String breaks;
        private final int maxIndent;
        private final Optional<Mark> endMark;
        private static transient /* synthetic */ String phPwUTSrui = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        public BreakIntentHolder(String str, int i, Optional<Mark> optional) {
            this.breaks = str;
            this.maxIndent = i;
            this.endMark = optional;
        }
    }
}
