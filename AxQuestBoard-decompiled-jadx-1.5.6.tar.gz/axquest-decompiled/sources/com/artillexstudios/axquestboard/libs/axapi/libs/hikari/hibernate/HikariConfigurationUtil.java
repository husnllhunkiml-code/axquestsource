package com.artillexstudios.axquestboard.libs.axapi.libs.hikari.hibernate;

import com.artillexstudios.axquestboard.libs.axapi.libs.hikari.HikariConfig;
import java.util.Map;
import java.util.Properties;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/hikari/hibernate/HikariConfigurationUtil.class */
public class HikariConfigurationUtil {
    public static final String CONFIG_PREFIX = "hibernate.hikari.";
    public static final String CONFIG_PREFIX_DATASOURCE = "hibernate.hikari.dataSource.";
    private static transient /* synthetic */ String OkhiaDBBYD = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public static HikariConfig loadConfiguration(Map map) {
        Properties properties = new Properties();
        copyProperty("hibernate.connection.isolation", map, "transactionIsolation", properties);
        copyProperty("hibernate.connection.autocommit", map, "autoCommit", properties);
        copyProperty("hibernate.connection.driver_class", map, "driverClassName", properties);
        copyProperty("hibernate.connection.url", map, "jdbcUrl", properties);
        copyProperty("hibernate.connection.username", map, "username", properties);
        copyProperty("hibernate.connection.password", map, "password", properties);
        for (String str : map.keySet()) {
            if (str.startsWith(CONFIG_PREFIX)) {
                properties.setProperty(str.substring(CONFIG_PREFIX.length()), (String) map.get(str));
            }
        }
        return new HikariConfig(properties);
    }

    private static void copyProperty(String str, Map map, String str2, Properties properties) {
        if (map.containsKey(str)) {
            properties.setProperty(str2, (String) map.get(str));
        }
    }
}
