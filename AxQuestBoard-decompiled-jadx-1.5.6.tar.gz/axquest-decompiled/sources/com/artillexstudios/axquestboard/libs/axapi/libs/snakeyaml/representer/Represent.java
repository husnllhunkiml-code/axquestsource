package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.representer;

import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.nodes.Node;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/representer/Represent.class */
public interface Represent {
    Node representData(Object obj);
}
