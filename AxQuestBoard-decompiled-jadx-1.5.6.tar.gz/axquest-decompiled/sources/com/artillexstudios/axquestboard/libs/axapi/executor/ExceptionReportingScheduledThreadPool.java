package com.artillexstudios.axquestboard.libs.axapi.executor;

import com.artillexstudios.axquestboard.libs.axapi.utils.logging.LogUtils;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadFactory;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/executor/ExceptionReportingScheduledThreadPool.class */
public class ExceptionReportingScheduledThreadPool extends ScheduledThreadPoolExecutor {
    private static transient /* synthetic */ String jrujYTyada = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public ExceptionReportingScheduledThreadPool(int corePoolSize) {
        super(corePoolSize);
    }

    public ExceptionReportingScheduledThreadPool(int corePoolSize, ThreadFactory factory) {
        super(corePoolSize, factory);
    }

    @Override // java.util.concurrent.ThreadPoolExecutor
    protected void afterExecute(Runnable r, Throwable t) {
        super.afterExecute(r, t);
        if (r instanceof Future) {
            Future future = (Future) r;
            if (future.isDone()) {
                try {
                    future.get();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                } catch (CancellationException e2) {
                } catch (ExecutionException e3) {
                    LogUtils.error("An uncaught exception occurred on thread {}!", Thread.currentThread().getName(), e3.getCause());
                }
            }
        }
    }
}
