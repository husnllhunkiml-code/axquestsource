package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.nodes;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/nodes/AnchorNode.class */
public class AnchorNode extends Node {
    private final Node realNode;
    private static transient /* synthetic */ String hNmJfSBVCt = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public AnchorNode(Node node) {
        super(node.getTag(), node.getStartMark(), node.getEndMark());
        this.realNode = node;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.nodes.Node
    public NodeId getNodeId() {
        return NodeId.anchor;
    }

    public Node getRealNode() {
        return this.realNode;
    }
}
