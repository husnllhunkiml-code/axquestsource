package com.artillexstudios.axquestboard.libs.axapi.context;

import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.runtime.ObjectMethods;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/context/ContextKey.class */
public final class ContextKey<T> extends Record {
    private final String name;
    private final Class<T> type;
    private static transient /* synthetic */ String hBaWPOeYIf = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public ContextKey(String name, Class<T> type) {
        this.name = name;
        this.type = type;
    }

    @Override // java.lang.Record
    public final String toString() {
        return (String) ObjectMethods.bootstrap(MethodHandles.lookup(), "toString", MethodType.methodType(String.class, ContextKey.class), ContextKey.class, "name;type", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/context/ContextKey;->name:Ljava/lang/String;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/context/ContextKey;->type:Ljava/lang/Class;").dynamicInvoker().invoke(this) /* invoke-custom */;
    }

    @Override // java.lang.Record
    public final int hashCode() {
        return (int) ObjectMethods.bootstrap(MethodHandles.lookup(), "hashCode", MethodType.methodType(Integer.TYPE, ContextKey.class), ContextKey.class, "name;type", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/context/ContextKey;->name:Ljava/lang/String;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/context/ContextKey;->type:Ljava/lang/Class;").dynamicInvoker().invoke(this) /* invoke-custom */;
    }

    @Override // java.lang.Record
    public final boolean equals(Object o) {
        return (boolean) ObjectMethods.bootstrap(MethodHandles.lookup(), "equals", MethodType.methodType(Boolean.TYPE, ContextKey.class, Object.class), ContextKey.class, "name;type", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/context/ContextKey;->name:Ljava/lang/String;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/context/ContextKey;->type:Ljava/lang/Class;").dynamicInvoker().invoke(this, o) /* invoke-custom */;
    }

    public String name() {
        return this.name;
    }

    public Class<T> type() {
        return this.type;
    }

    public static <Z> ContextKey<Z> of(String name, Class<Z> type) {
        return new ContextKey<>(name, type);
    }
}
