package com.artillexstudios.axquestboard.libs.axapi.gui.inventory.provider;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/gui/inventory/provider/GuiItemProviderProvider.class */
public interface GuiItemProviderProvider<T> {
    GuiItemProvider provide(T data);
}
