package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.events;

import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.DumperOptions;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.error.Mark;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/events/MappingStartEvent.class */
public final class MappingStartEvent extends CollectionStartEvent {
    private static transient /* synthetic */ String ULmUGFWUnB = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public MappingStartEvent(String str, String str2, boolean z, Mark mark, Mark mark2, DumperOptions.FlowStyle flowStyle) {
        super(str, str2, z, mark, mark2, flowStyle);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.events.Event
    public Event.ID getEventId() {
        return Event.ID.MappingStart;
    }
}
