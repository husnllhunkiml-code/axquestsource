package com.artillexstudios.axquestboard.libs.axapi.libs.hikari.pool;

import com.artillexstudios.axquestboard.libs.axapi.libs.hikari.SQLExceptionOverride;
import com.artillexstudios.axquestboard.libs.axapi.libs.hikari.util.FastList;
import java.lang.reflect.Proxy;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Savepoint;
import java.sql.Statement;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.Executor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/hikari/pool/ProxyConnection.class */
public abstract class ProxyConnection implements Connection {
    static final int DIRTY_BIT_READONLY = 1;
    static final int DIRTY_BIT_AUTOCOMMIT = 2;
    static final int DIRTY_BIT_ISOLATION = 4;
    static final int DIRTY_BIT_CATALOG = 8;
    static final int DIRTY_BIT_NETTIMEOUT = 16;
    static final int DIRTY_BIT_SCHEMA = 32;
    private static final Logger LOGGER = LoggerFactory.getLogger(ProxyConnection.class);
    private static final Set<String> ERROR_STATES = new HashSet();
    private static final Set<Integer> ERROR_CODES;
    protected Connection delegate;
    private final PoolEntry poolEntry;
    private final ProxyLeakTask leakTask;
    private final FastList<Statement> openStatements;
    private int dirtyBits;
    private boolean isCommitStateDirty;
    private boolean isReadOnly;
    private boolean isAutoCommit;
    private int networkTimeout;
    private int transactionIsolation;
    private String dbcatalog;
    private String dbschema;

    static {
        ERROR_STATES.add("0A000");
        ERROR_STATES.add("57P01");
        ERROR_STATES.add("57P02");
        ERROR_STATES.add("57P03");
        ERROR_STATES.add("01002");
        ERROR_STATES.add("JZ0C0");
        ERROR_STATES.add("JZ0C1");
        ERROR_CODES = new HashSet();
        ERROR_CODES.add(500150);
        ERROR_CODES.add(2399);
        ERROR_CODES.add(1105);
    }

    protected ProxyConnection(PoolEntry poolEntry, Connection connection, FastList<Statement> fastList, ProxyLeakTask proxyLeakTask, boolean z, boolean z2) {
        this.poolEntry = poolEntry;
        this.delegate = connection;
        this.openStatements = fastList;
        this.leakTask = proxyLeakTask;
        this.isReadOnly = z;
        this.isAutoCommit = z2;
    }

    public final String toString() {
        return getClass().getSimpleName() + "@" + System.identityHashCode(this) + " wrapping " + this.delegate;
    }

    final boolean getAutoCommitState() {
        return this.isAutoCommit;
    }

    final String getCatalogState() {
        return this.dbcatalog;
    }

    final String getSchemaState() {
        return this.dbschema;
    }

    final int getTransactionIsolationState() {
        return this.transactionIsolation;
    }

    final boolean getReadOnlyState() {
        return this.isReadOnly;
    }

    final int getNetworkTimeoutState() {
        return this.networkTimeout;
    }

    final PoolEntry getPoolEntry() {
        return this.poolEntry;
    }

    final SQLException checkException(SQLException sQLException) {
        boolean z = false;
        SQLException nextException = sQLException;
        SQLExceptionOverride sQLExceptionOverride = this.poolEntry.getPoolBase().exceptionOverride;
        for (int i = 0; this.delegate != ClosedConnection.CLOSED_CONNECTION && nextException != null && i < 10; i++) {
            String sQLState = nextException.getSQLState();
            SQLExceptionOverride.Override overrideAdjudicate = sQLExceptionOverride != null ? sQLExceptionOverride.adjudicate(nextException) : SQLExceptionOverride.Override.CONTINUE_EVICT;
            if (overrideAdjudicate == SQLExceptionOverride.Override.DO_NOT_EVICT) {
                break;
            }
            if ((sQLState != null && sQLState.startsWith("08")) || ERROR_STATES.contains(sQLState) || ERROR_CODES.contains(Integer.valueOf(nextException.getErrorCode())) || overrideAdjudicate == SQLExceptionOverride.Override.MUST_EVICT) {
                z = true;
                break;
            }
            nextException = nextException.getNextException();
        }
        if (z) {
            SQLException sQLException2 = nextException != null ? nextException : sQLException;
            LOGGER.warn("{} - Connection {} marked as broken because of SQLSTATE({}), ErrorCode({})", new Object[]{this.poolEntry.getPoolName(), this.delegate, sQLException2.getSQLState(), Integer.valueOf(sQLException2.getErrorCode()), sQLException2});
            this.leakTask.cancel();
            this.poolEntry.evict("(connection is broken)");
            this.delegate = ClosedConnection.CLOSED_CONNECTION;
        }
        return sQLException;
    }

    final synchronized void untrackStatement(Statement statement) {
        this.openStatements.remove(statement);
    }

    final void markCommitStateDirty() {
        if (!this.isAutoCommit) {
            this.isCommitStateDirty = true;
        }
    }

    void cancelLeakTask() {
        this.leakTask.cancel();
    }

    private synchronized <T extends Statement> T trackStatement(T t) {
        this.openStatements.add(t);
        return t;
    }

    private synchronized void closeStatements() {
        int size = this.openStatements.size();
        if (size > 0) {
            for (int i = 0; i < size && this.delegate != ClosedConnection.CLOSED_CONNECTION; i++) {
                try {
                    Statement statement = this.openStatements.get(i);
                    if (statement != null) {
                        statement.close();
                    }
                } catch (SQLException e) {
                    LOGGER.warn("{} - Connection {} marked as broken because of an exception closing open statements during Connection.close()", this.poolEntry.getPoolName(), this.delegate);
                    this.leakTask.cancel();
                    this.poolEntry.evict("(exception closing Statements during Connection.close())");
                    this.delegate = ClosedConnection.CLOSED_CONNECTION;
                }
            }
            this.openStatements.clear();
        }
    }

    @Override // java.sql.Connection, java.lang.AutoCloseable
    public final void close() {
        closeStatements();
        if (this.delegate != ClosedConnection.CLOSED_CONNECTION) {
            this.leakTask.cancel();
            try {
                try {
                    if (this.isCommitStateDirty && !this.isAutoCommit) {
                        this.delegate.rollback();
                        LOGGER.debug("{} - Executed rollback on connection {} due to dirty commit state on close().", this.poolEntry.getPoolName(), this.delegate);
                    }
                    if (this.dirtyBits != 0) {
                        this.poolEntry.resetConnectionState(this, this.dirtyBits);
                    }
                    this.delegate.clearWarnings();
                    this.delegate = ClosedConnection.CLOSED_CONNECTION;
                    this.poolEntry.recycle();
                } catch (SQLException e) {
                    if (!this.poolEntry.isMarkedEvicted()) {
                        throw checkException(e);
                    }
                    this.delegate = ClosedConnection.CLOSED_CONNECTION;
                    this.poolEntry.recycle();
                }
            } catch (Throwable th) {
                this.delegate = ClosedConnection.CLOSED_CONNECTION;
                this.poolEntry.recycle();
                throw th;
            }
        }
    }

    @Override // java.sql.Connection
    public boolean isClosed() {
        return this.delegate == ClosedConnection.CLOSED_CONNECTION;
    }

    @Override // java.sql.Connection
    public Statement createStatement() {
        return ProxyFactory.getProxyStatement(this, trackStatement(this.delegate.createStatement()));
    }

    @Override // java.sql.Connection
    public Statement createStatement(int i, int i2) {
        return ProxyFactory.getProxyStatement(this, trackStatement(this.delegate.createStatement(i, i2)));
    }

    @Override // java.sql.Connection
    public Statement createStatement(int i, int i2, int i3) {
        return ProxyFactory.getProxyStatement(this, trackStatement(this.delegate.createStatement(i, i2, i3)));
    }

    @Override // java.sql.Connection
    public CallableStatement prepareCall(String str) {
        return ProxyFactory.getProxyCallableStatement(this, (CallableStatement) trackStatement(this.delegate.prepareCall(str)));
    }

    @Override // java.sql.Connection
    public CallableStatement prepareCall(String str, int i, int i2) {
        return ProxyFactory.getProxyCallableStatement(this, (CallableStatement) trackStatement(this.delegate.prepareCall(str, i, i2)));
    }

    @Override // java.sql.Connection
    public CallableStatement prepareCall(String str, int i, int i2, int i3) {
        return ProxyFactory.getProxyCallableStatement(this, (CallableStatement) trackStatement(this.delegate.prepareCall(str, i, i2, i3)));
    }

    @Override // java.sql.Connection
    public PreparedStatement prepareStatement(String str) {
        return ProxyFactory.getProxyPreparedStatement(this, (PreparedStatement) trackStatement(this.delegate.prepareStatement(str)));
    }

    @Override // java.sql.Connection
    public PreparedStatement prepareStatement(String str, int i) {
        return ProxyFactory.getProxyPreparedStatement(this, (PreparedStatement) trackStatement(this.delegate.prepareStatement(str, i)));
    }

    @Override // java.sql.Connection
    public PreparedStatement prepareStatement(String str, int i, int i2) {
        return ProxyFactory.getProxyPreparedStatement(this, (PreparedStatement) trackStatement(this.delegate.prepareStatement(str, i, i2)));
    }

    @Override // java.sql.Connection
    public PreparedStatement prepareStatement(String str, int i, int i2, int i3) {
        return ProxyFactory.getProxyPreparedStatement(this, (PreparedStatement) trackStatement(this.delegate.prepareStatement(str, i, i2, i3)));
    }

    @Override // java.sql.Connection
    public PreparedStatement prepareStatement(String str, int[] iArr) {
        return ProxyFactory.getProxyPreparedStatement(this, (PreparedStatement) trackStatement(this.delegate.prepareStatement(str, iArr)));
    }

    @Override // java.sql.Connection
    public PreparedStatement prepareStatement(String str, String[] strArr) {
        return ProxyFactory.getProxyPreparedStatement(this, (PreparedStatement) trackStatement(this.delegate.prepareStatement(str, strArr)));
    }

    @Override // java.sql.Connection
    public DatabaseMetaData getMetaData() {
        markCommitStateDirty();
        return ProxyFactory.getProxyDatabaseMetaData(this, this.delegate.getMetaData());
    }

    @Override // java.sql.Connection
    public void commit() throws SQLException {
        this.delegate.commit();
        this.isCommitStateDirty = false;
    }

    @Override // java.sql.Connection
    public void rollback() throws SQLException {
        this.delegate.rollback();
        this.isCommitStateDirty = false;
    }

    @Override // java.sql.Connection
    public void rollback(Savepoint savepoint) throws SQLException {
        this.delegate.rollback(savepoint);
        this.isCommitStateDirty = true;
    }

    @Override // java.sql.Connection
    public boolean getAutoCommit() {
        if ((this.dirtyBits & 2) != 0) {
            return this.isAutoCommit;
        }
        return this.delegate.getAutoCommit();
    }

    @Override // java.sql.Connection
    public void setAutoCommit(boolean z) throws SQLException {
        this.delegate.setAutoCommit(z);
        this.isAutoCommit = z;
        this.dirtyBits |= 2;
    }

    @Override // java.sql.Connection
    public boolean isReadOnly() {
        if ((this.dirtyBits & 1) != 0) {
            return this.isReadOnly;
        }
        return this.delegate.isReadOnly();
    }

    @Override // java.sql.Connection
    public void setReadOnly(boolean z) throws SQLException {
        this.delegate.setReadOnly(z);
        this.isReadOnly = z;
        this.dirtyBits |= 1;
    }

    @Override // java.sql.Connection
    public int getTransactionIsolation() {
        if ((this.dirtyBits & DIRTY_BIT_ISOLATION) != 0) {
            return this.transactionIsolation;
        }
        return this.delegate.getTransactionIsolation();
    }

    @Override // java.sql.Connection
    public void setTransactionIsolation(int i) throws SQLException {
        this.delegate.setTransactionIsolation(i);
        this.transactionIsolation = i;
        this.dirtyBits |= DIRTY_BIT_ISOLATION;
    }

    @Override // java.sql.Connection
    public String getCatalog() {
        if ((this.dirtyBits & DIRTY_BIT_CATALOG) != 0) {
            return this.dbcatalog;
        }
        return this.delegate.getCatalog();
    }

    @Override // java.sql.Connection
    public void setCatalog(String str) throws SQLException {
        this.delegate.setCatalog(str);
        this.dbcatalog = str;
        this.dirtyBits |= DIRTY_BIT_CATALOG;
    }

    public int getNetworkTimeout() {
        if ((this.dirtyBits & DIRTY_BIT_NETTIMEOUT) != 0) {
            return this.networkTimeout;
        }
        return this.delegate.getNetworkTimeout();
    }

    public void setNetworkTimeout(Executor executor, int i) {
        this.delegate.setNetworkTimeout(executor, i);
        this.networkTimeout = i;
        this.dirtyBits |= DIRTY_BIT_NETTIMEOUT;
    }

    public String getSchema() {
        if ((this.dirtyBits & DIRTY_BIT_SCHEMA) != 0) {
            return this.dbschema;
        }
        return this.delegate.getSchema();
    }

    public void setSchema(String str) {
        this.delegate.setSchema(str);
        this.dbschema = str;
        this.dirtyBits |= DIRTY_BIT_SCHEMA;
    }

    @Override // java.sql.Wrapper
    public final boolean isWrapperFor(Class<?> cls) {
        return cls.isInstance(this.delegate) || (this.delegate != null && this.delegate.isWrapperFor(cls));
    }

    @Override // java.sql.Wrapper
    public final <T> T unwrap(Class<T> cls) throws SQLException {
        if (cls.isInstance(this.delegate)) {
            return (T) this.delegate;
        }
        if (this.delegate != null) {
            return (T) this.delegate.unwrap(cls);
        }
        throw new SQLException("Wrapped connection is not an instance of " + cls);
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/hikari/pool/ProxyConnection$ClosedConnection.class */
    private static final class ClosedConnection {
        static final Connection CLOSED_CONNECTION = getClosedConnection();
        private static transient /* synthetic */ String SYJnVIlMtb = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        private ClosedConnection() {
        }

        private static Connection getClosedConnection() {
            return (Connection) Proxy.newProxyInstance(Connection.class.getClassLoader(), new Class[]{Connection.class}, (obj, method, objArr) -> {
                String name = method.getName();
                byte b = -1;
                switch (name.hashCode()) {
                    case -1776922004:
                        if (name.equals("toString")) {
                            b = ProxyConnection.DIRTY_BIT_ISOLATION;
                        }
                        break;
                    case -683486410:
                        if (name.equals("isClosed")) {
                            b = 0;
                        }
                        break;
                    case 92611376:
                        if (name.equals("abort")) {
                            b = 2;
                        }
                        break;
                    case 94756344:
                        if (name.equals("close")) {
                            b = 3;
                        }
                        break;
                    case 2073378034:
                        if (name.equals("isValid")) {
                            b = 1;
                        }
                        break;
                }
                switch (b) {
                    case 0:
                        return Boolean.TRUE;
                    case 1:
                        return Boolean.FALSE;
                    case 2:
                        return Void.TYPE;
                    case 3:
                        return Void.TYPE;
                    case ProxyConnection.DIRTY_BIT_ISOLATION /* 4 */:
                        return ClosedConnection.class.getCanonicalName();
                    default:
                        throw new SQLException("Connection is closed");
                }
            });
        }
    }
}
