package com.artillexstudios.axquestboard.libs.axapi.config.annotation;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/annotation/ConfigurationPart.class */
public interface ConfigurationPart {
}
