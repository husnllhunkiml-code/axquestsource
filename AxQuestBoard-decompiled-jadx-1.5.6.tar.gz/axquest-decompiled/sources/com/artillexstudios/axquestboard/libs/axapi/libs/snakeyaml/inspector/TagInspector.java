package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.inspector;

import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.nodes.Tag;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/inspector/TagInspector.class */
public interface TagInspector {
    boolean isGlobalTagAllowed(Tag tag);
}
