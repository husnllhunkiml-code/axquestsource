package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.comments;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/comments/CommentType.class */
public enum CommentType {
    BLANK_LINE,
    BLOCK,
    IN_LINE
}
