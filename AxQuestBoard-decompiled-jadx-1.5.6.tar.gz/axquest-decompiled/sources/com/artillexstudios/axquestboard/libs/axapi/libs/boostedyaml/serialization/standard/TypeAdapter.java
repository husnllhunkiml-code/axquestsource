package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.serialization.standard;

import java.util.HashMap;
import java.util.Map;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/serialization/standard/TypeAdapter.class */
public interface TypeAdapter<T> {
    @NotNull
    Map<Object, Object> serialize(@NotNull T t);

    @NotNull
    T deserialize(@NotNull Map<Object, Object> map);

    @NotNull
    default Map<String, Object> toStringKeyedMap(@NotNull Map<?, ?> map) {
        Map<String, Object> newMap = new HashMap<>();
        for (Map.Entry<?, ?> entry : map.entrySet()) {
            if (entry.getValue() instanceof Map) {
                newMap.put(entry.getKey().toString(), toStringKeyedMap((Map) entry.getValue()));
            } else {
                newMap.put(entry.getKey().toString(), entry.getValue());
            }
        }
        return newMap;
    }
}
