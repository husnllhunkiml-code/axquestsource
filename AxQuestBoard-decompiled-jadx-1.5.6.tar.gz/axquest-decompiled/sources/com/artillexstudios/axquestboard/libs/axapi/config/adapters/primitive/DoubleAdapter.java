package com.artillexstudios.axquestboard.libs.axapi.config.adapters.primitive;

import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapterHolder;
import java.lang.reflect.Type;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/adapters/primitive/DoubleAdapter.class */
public final class DoubleAdapter implements TypeAdapter<Double, Double> {
    private static transient /* synthetic */ String dFshrilcFG = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public Double deserialize(TypeAdapterHolder registry, Object input, Type type) {
        if (input instanceof Number) {
            return Double.valueOf(((Number) input).doubleValue());
        }
        if (input instanceof String) {
            return Double.valueOf(Double.parseDouble((String) input));
        }
        throw new IllegalArgumentException("Can't make a short from a " + String.valueOf(input.getClass()));
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public Double serialize(TypeAdapterHolder registry, Double value, Type type) {
        return value;
    }
}
