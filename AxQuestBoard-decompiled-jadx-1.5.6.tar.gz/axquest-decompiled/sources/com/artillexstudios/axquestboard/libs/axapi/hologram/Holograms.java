package com.artillexstudios.axquestboard.libs.axapi.hologram;

import com.artillexstudios.axquestboard.libs.axapi.AxPlugin;
import com.artillexstudios.axquestboard.libs.axapi.executor.ExceptionReportingScheduledThreadPool;
import com.artillexstudios.axquestboard.libs.axapi.hologram.page.HologramPage;
import com.artillexstudios.axquestboard.libs.axapi.utils.featureflags.FeatureFlags;
import com.artillexstudios.axquestboard.libs.axapi.utils.logging.LogUtils;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import java.util.Collections;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/hologram/Holograms.class */
public final class Holograms {
    private static final AxPlugin plugin = (AxPlugin) AxPlugin.getPlugin(AxPlugin.class);
    private static final ConcurrentHashMap<Integer, HologramPage<?, ?>> pagesMap = new ConcurrentHashMap<>();
    private static ScheduledExecutorService hologramUpdater;
    private static transient /* synthetic */ String ovENoDTYxP = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public static void startTicking() {
        shutdown();
        hologramUpdater = new ExceptionReportingScheduledThreadPool(1, new ThreadFactoryBuilder().setNameFormat(plugin.getName() + "-Hologram-Update-Thread").build());
        hologramUpdater.scheduleAtFixedRate(() -> {
            getView().forEach((num, hologramPage) -> {
                if (!hologramPage.containsPlaceholders()) {
                    return;
                }
                hologramPage.update();
            });
        }, 0L, FeatureFlags.HOLOGRAM_UPDATE_TICKS.get().longValue() * 50, TimeUnit.MILLISECONDS);
    }

    public static void shutdown() {
        if (hologramUpdater != null) {
            hologramUpdater.shutdown();
            try {
                hologramUpdater.awaitTermination(30L, TimeUnit.SECONDS);
            } catch (InterruptedException e) {
                LogUtils.error("An unexpected error occurred while disabling hologram ticker!", e);
            }
        }
    }

    public static void put(int entityId, HologramPage<?, ?> page) {
        pagesMap.put(Integer.valueOf(entityId), page);
    }

    public static void remove(int entityId) {
        pagesMap.remove(Integer.valueOf(entityId));
    }

    public static HologramPage<?, ?> byId(int entityId) {
        return pagesMap.get(Integer.valueOf(entityId));
    }

    public static Map<Integer, HologramPage<?, ?>> getView() {
        return Collections.unmodifiableMap(pagesMap);
    }
}
