package com.artillexstudios.axquestboard.libs.axapi.config.adapters.primitive;

import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapterHolder;
import java.lang.reflect.Type;
import java.math.BigInteger;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/adapters/primitive/IntegerAdapter.class */
public final class IntegerAdapter implements TypeAdapter<Integer, Integer> {
    private static transient /* synthetic */ String hzvPYLCkHy = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public Integer deserialize(TypeAdapterHolder registry, Object input, Type type) {
        if (input instanceof Number) {
            return validate((Number) input);
        }
        if (input instanceof String) {
            return validate(Double.valueOf(Double.parseDouble((String) input)));
        }
        throw new IllegalArgumentException("Can't make an int from a " + String.valueOf(input.getClass()));
    }

    private Integer validate(Number number) {
        long jLongValueExact = number instanceof BigInteger ? ((BigInteger) number).longValueExact() : number.longValue();
        if (jLongValueExact > 2147483647L || jLongValueExact < -2147483648L) {
            throw new IllegalArgumentException("Int value is not actually an int! Should be between %s and %s, but was %s".formatted(Integer.MIN_VALUE, Integer.MAX_VALUE, Long.valueOf(jLongValueExact)));
        }
        return Integer.valueOf((int) jLongValueExact);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public Integer serialize(TypeAdapterHolder registry, Integer value, Type type) {
        return value;
    }
}
