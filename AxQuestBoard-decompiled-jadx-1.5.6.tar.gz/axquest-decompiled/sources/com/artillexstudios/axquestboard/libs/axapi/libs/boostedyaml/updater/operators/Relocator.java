package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.updater.operators;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.block.Block;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.block.implementation.Section;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.route.Route;
import java.util.Map;
import java.util.Optional;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/updater/operators/Relocator.class */
public class Relocator {
    private static final Relocator INSTANCE = new Relocator();
    private static transient /* synthetic */ String NnBDMRSSTF = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public static void apply(@NotNull Section section, @NotNull Map<Route, Route> map) {
        while (map.size() > 0) {
            INSTANCE.apply(section, map, map.keySet().iterator().next());
        }
    }

    private void apply(@NotNull Section section, @NotNull Map<Route, Route> map, @Nullable Route route) {
        if (route == null || !map.containsKey(route)) {
            return;
        }
        Optional<Section> parent = section.getParent(route);
        if (!parent.isPresent()) {
            map.remove(route);
            return;
        }
        Object obj = route.get(route.length() - 1);
        Block<?> block = parent.get().getStoredValue().get(obj);
        if (block == null) {
            map.remove(route);
            return;
        }
        Route route2 = map.get(route);
        map.remove(route);
        parent.get().getStoredValue().remove(obj);
        removeParents(parent.get());
        apply(section, map, route2);
        section.set(route2, block);
    }

    private void removeParents(@NotNull Section section) {
        if (section.isEmpty(false) && !section.isRoot()) {
            section.getParent().getStoredValue().remove(section.getName());
            removeParents(section.getParent());
        }
    }
}
