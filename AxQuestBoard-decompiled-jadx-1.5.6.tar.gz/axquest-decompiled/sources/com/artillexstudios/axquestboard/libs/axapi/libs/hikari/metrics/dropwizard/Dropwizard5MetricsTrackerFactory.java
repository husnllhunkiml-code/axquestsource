package com.artillexstudios.axquestboard.libs.axapi.libs.hikari.metrics.dropwizard;

import com.artillexstudios.axquestboard.libs.axapi.libs.hikari.metrics.IMetricsTracker;
import com.artillexstudios.axquestboard.libs.axapi.libs.hikari.metrics.MetricsTrackerFactory;
import com.artillexstudios.axquestboard.libs.axapi.libs.hikari.metrics.PoolStats;
import io.dropwizard.metrics5.MetricRegistry;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/hikari/metrics/dropwizard/Dropwizard5MetricsTrackerFactory.class */
public class Dropwizard5MetricsTrackerFactory implements MetricsTrackerFactory {
    private final MetricRegistry registry;
    private static transient /* synthetic */ String xZhcRSHyls = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public Dropwizard5MetricsTrackerFactory(MetricRegistry metricRegistry) {
        this.registry = metricRegistry;
    }

    public MetricRegistry getRegistry() {
        return this.registry;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.hikari.metrics.MetricsTrackerFactory
    public IMetricsTracker create(String str, PoolStats poolStats) {
        return new Dropwizard5MetricsTracker(str, poolStats, this.registry);
    }
}
