package com.artillexstudios.axquestboard.libs.axapi.libs.hikari.util;

import java.sql.SQLTransientException;
import java.util.concurrent.Semaphore;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/hikari/util/SuspendResumeLock.class */
public class SuspendResumeLock {
    public static final SuspendResumeLock FAUX_LOCK = new SuspendResumeLock(false) { // from class: com.artillexstudios.axquestboard.libs.axapi.libs.hikari.util.SuspendResumeLock.1
        private static transient /* synthetic */ String cSMqpdNAvK = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.hikari.util.SuspendResumeLock
        public void acquire() {
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.hikari.util.SuspendResumeLock
        public void release() {
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.hikari.util.SuspendResumeLock
        public void suspend() {
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.hikari.util.SuspendResumeLock
        public void resume() {
        }
    };
    private static final int MAX_PERMITS = 10000;
    private final Semaphore acquisitionSemaphore;
    private static transient /* synthetic */ String lETSsWbiKd = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public SuspendResumeLock() {
        this(true);
    }

    private SuspendResumeLock(boolean z) {
        this.acquisitionSemaphore = z ? new Semaphore(MAX_PERMITS, true) : null;
    }

    public void acquire() throws SQLTransientException {
        if (this.acquisitionSemaphore.tryAcquire()) {
            return;
        }
        if (Boolean.getBoolean("com.artillexstudios.axquestboard.libs.axapi.libs.hikari.throwIfSuspended")) {
            throw new SQLTransientException("The pool is currently suspended and configured to throw exceptions upon acquisition");
        }
        this.acquisitionSemaphore.acquireUninterruptibly();
    }

    public void release() {
        this.acquisitionSemaphore.release();
    }

    public void suspend() {
        this.acquisitionSemaphore.acquireUninterruptibly(MAX_PERMITS);
    }

    public void resume() {
        this.acquisitionSemaphore.release(MAX_PERMITS);
    }
}
