package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.serializer;

import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.DumperOptions;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.comments.CommentLine;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.emitter.Emitable;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.events.AliasEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.events.CommentEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.events.DocumentEndEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.events.DocumentStartEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.events.ImplicitTuple;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.events.MappingEndEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.events.MappingStartEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.events.ScalarEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.events.SequenceEndEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.events.SequenceStartEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.events.StreamEndEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.events.StreamStartEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.nodes.AnchorNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.nodes.MappingNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.nodes.Node;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.nodes.NodeId;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.nodes.NodeTuple;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.nodes.ScalarNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.nodes.SequenceNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.nodes.Tag;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.resolver.Resolver;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/serializer/Serializer.class */
public final class Serializer {
    private final Emitable emitter;
    private final Resolver resolver;
    private final boolean explicitStart;
    private final boolean explicitEnd;
    private DumperOptions.Version useVersion;
    private final Map<String, String> useTags;
    private final Set<Node> serializedNodes;
    private final Map<Node, String> anchors;
    private final AnchorGenerator anchorGenerator;
    private Boolean closed;
    private final Tag explicitRoot;
    private static transient /* synthetic */ String KGyrfVOFZT = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public Serializer(Emitable emitable, Resolver resolver, DumperOptions dumperOptions, Tag tag) {
        if (emitable == null) {
            throw new NullPointerException("Emitter must  be provided");
        }
        if (resolver == null) {
            throw new NullPointerException("Resolver must  be provided");
        }
        if (dumperOptions == null) {
            throw new NullPointerException("DumperOptions must  be provided");
        }
        this.emitter = emitable;
        this.resolver = resolver;
        this.explicitStart = dumperOptions.isExplicitStart();
        this.explicitEnd = dumperOptions.isExplicitEnd();
        if (dumperOptions.getVersion() != null) {
            this.useVersion = dumperOptions.getVersion();
        }
        this.useTags = dumperOptions.getTags();
        this.serializedNodes = new HashSet();
        this.anchors = new HashMap();
        this.anchorGenerator = dumperOptions.getAnchorGenerator();
        this.closed = null;
        this.explicitRoot = tag;
    }

    public void open() {
        if (this.closed == null) {
            this.emitter.emit(new StreamStartEvent(null, null));
            this.closed = Boolean.FALSE;
        } else {
            if (Boolean.TRUE.equals(this.closed)) {
                throw new SerializerException("serializer is closed");
            }
            throw new SerializerException("serializer is already opened");
        }
    }

    public void close() {
        if (this.closed == null) {
            throw new SerializerException("serializer is not opened");
        }
        if (!Boolean.TRUE.equals(this.closed)) {
            this.emitter.emit(new StreamEndEvent(null, null));
            this.closed = Boolean.TRUE;
            this.serializedNodes.clear();
            this.anchors.clear();
        }
    }

    public void serialize(Node node) {
        if (this.closed == null) {
            throw new SerializerException("serializer is not opened");
        }
        if (this.closed.booleanValue()) {
            throw new SerializerException("serializer is closed");
        }
        this.emitter.emit(new DocumentStartEvent(null, null, this.explicitStart, this.useVersion, this.useTags));
        anchorNode(node);
        if (this.explicitRoot != null) {
            node.setTag(this.explicitRoot);
        }
        serializeNode(node, null);
        this.emitter.emit(new DocumentEndEvent(null, null, this.explicitEnd));
        this.serializedNodes.clear();
        this.anchors.clear();
    }

    private void anchorNode(Node node) {
        if (node.getNodeId() == NodeId.anchor) {
            node = ((AnchorNode) node).getRealNode();
        }
        if (this.anchors.containsKey(node)) {
            if (null == this.anchors.get(node)) {
                this.anchors.put(node, this.anchorGenerator.nextAnchor(node));
                return;
            }
            return;
        }
        this.anchors.put(node, node.getAnchor() != null ? this.anchorGenerator.nextAnchor(node) : null);
        switch (node.getNodeId()) {
            case sequence:
                Iterator<Node> it = ((SequenceNode) node).getValue().iterator();
                while (it.hasNext()) {
                    anchorNode(it.next());
                }
                break;
            case mapping:
                for (NodeTuple nodeTuple : ((MappingNode) node).getValue()) {
                    Node keyNode = nodeTuple.getKeyNode();
                    Node valueNode = nodeTuple.getValueNode();
                    anchorNode(keyNode);
                    anchorNode(valueNode);
                }
                break;
        }
    }

    private void serializeNode(Node node, Node node2) throws IOException {
        if (node.getNodeId() == NodeId.anchor) {
            node = ((AnchorNode) node).getRealNode();
        }
        String str = this.anchors.get(node);
        if (this.serializedNodes.contains(node)) {
            this.emitter.emit(new AliasEvent(str, null, null));
            return;
        }
        this.serializedNodes.add(node);
        switch (node.getNodeId()) {
            case sequence:
                SequenceNode sequenceNode = (SequenceNode) node;
                serializeComments(node.getBlockComments());
                this.emitter.emit(new SequenceStartEvent(str, node.getTag().getValue(), node.getTag().equals(this.resolver.resolve(NodeId.sequence, null, true)), null, null, sequenceNode.getFlowStyle()));
                Iterator<Node> it = sequenceNode.getValue().iterator();
                while (it.hasNext()) {
                    serializeNode(it.next(), node);
                }
                this.emitter.emit(new SequenceEndEvent(null, null));
                serializeComments(node.getInLineComments());
                serializeComments(node.getEndComments());
                break;
            case scalar:
                ScalarNode scalarNode = (ScalarNode) node;
                serializeComments(node.getBlockComments());
                this.emitter.emit(new ScalarEvent(str, node.getTag().getValue(), new ImplicitTuple(node.getTag().equals(this.resolver.resolve(NodeId.scalar, scalarNode.getValue(), true)), node.getTag().equals(this.resolver.resolve(NodeId.scalar, scalarNode.getValue(), false))), scalarNode.getValue(), null, null, scalarNode.getScalarStyle()));
                serializeComments(node.getInLineComments());
                serializeComments(node.getEndComments());
                break;
            default:
                serializeComments(node.getBlockComments());
                boolean zEquals = node.getTag().equals(this.resolver.resolve(NodeId.mapping, null, true));
                MappingNode mappingNode = (MappingNode) node;
                List<NodeTuple> value = mappingNode.getValue();
                if (mappingNode.getTag() != Tag.COMMENT) {
                    this.emitter.emit(new MappingStartEvent(str, mappingNode.getTag().getValue(), zEquals, null, null, mappingNode.getFlowStyle()));
                    for (NodeTuple nodeTuple : value) {
                        Node keyNode = nodeTuple.getKeyNode();
                        Node valueNode = nodeTuple.getValueNode();
                        serializeNode(keyNode, mappingNode);
                        serializeNode(valueNode, mappingNode);
                    }
                    this.emitter.emit(new MappingEndEvent(null, null));
                    serializeComments(node.getInLineComments());
                    serializeComments(node.getEndComments());
                }
                break;
        }
    }

    private void serializeComments(List<CommentLine> list) throws IOException {
        if (list == null) {
            return;
        }
        for (CommentLine commentLine : list) {
            this.emitter.emit(new CommentEvent(commentLine.getCommentType(), commentLine.getValue(), commentLine.getStartMark(), commentLine.getEndMark()));
        }
    }
}
