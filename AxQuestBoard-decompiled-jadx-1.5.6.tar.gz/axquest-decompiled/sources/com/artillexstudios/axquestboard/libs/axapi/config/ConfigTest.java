package com.artillexstudios.axquestboard.libs.axapi.config;

import com.artillexstudios.axquestboard.libs.axapi.config.annotation.Comment;
import com.artillexstudios.axquestboard.libs.axapi.config.annotation.ConfigurationPart;
import com.artillexstudios.axquestboard.libs.axapi.config.annotation.Header;
import com.artillexstudios.axquestboard.libs.axapi.config.annotation.Hidden;
import com.artillexstudios.axquestboard.libs.axapi.config.annotation.Named;
import com.artillexstudios.axquestboard.libs.axapi.config.annotation.Serializable;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.DumperOptions;
import java.nio.file.Path;
import java.util.Map;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/ConfigTest.class */
@Header({"This is a configuration file!"})
public class ConfigTest implements ConfigurationPart {

    @Named("setting")
    @Comment("oreo")
    public static double value = 0.0d;
    public static CustomClass bigOreo = new CustomClass(69420, 10);
    public static Map<String, CustomClass> oreos = Map.of("world", new CustomClass(2, 4), "world_the_end", new CustomClass(), "spawn", new CustomClass(10, 30));
    private static transient /* synthetic */ String KEbKhBVZRp = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public static void main(String[] args) {
        YamlConfiguration yamlConfigurationBuild = YamlConfiguration.of(Path.of("D:\\EcoSkills\\rivals\\AxConfig\\asd\\bruh.yml", new String[0]), ConfigTest.class).withDumperOptions(dumperOptions -> {
            dumperOptions.setDefaultFlowStyle(DumperOptions.FlowStyle.BLOCK);
        }).withLoaderOptions(loaderOptions -> {
            loaderOptions.setAllowDuplicateKeys(false);
        }).build();
        yamlConfigurationBuild.load();
        yamlConfigurationBuild.save();
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/ConfigTest$CustomClass.class */
    @Serializable
    public static class CustomClass {

        @Comment("This is the max")
        public int max;

        @Comment("this is the min")
        public int min;

        @Hidden
        public String secret;
        private static transient /* synthetic */ String vPYRQOWNaK = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        public CustomClass() {
            this(1, 2);
        }

        public CustomClass(int min, int max) {
            this.secret = null;
            this.min = min;
            this.max = max;
        }

        public String toString() {
            return "CustomClass{max=" + this.max + ", min=" + this.min + "}";
        }
    }
}
