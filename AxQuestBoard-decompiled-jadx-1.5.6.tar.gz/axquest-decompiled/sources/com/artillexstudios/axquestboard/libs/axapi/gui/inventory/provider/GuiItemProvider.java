package com.artillexstudios.axquestboard.libs.axapi.gui.inventory.provider;

import com.artillexstudios.axquestboard.libs.axapi.context.HashMapContext;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.BakedGuiItem;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.GuiItem;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.modifier.WrappedItemStackModifier;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.provider.implementation.AsyncGuiItemProvider;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.provider.implementation.CachingGuiItemProvider;
import com.artillexstudios.axquestboard.libs.axapi.items.WrappedItemStack;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/gui/inventory/provider/GuiItemProvider.class */
public interface GuiItemProvider {
    CompletableFuture<BakedGuiItem> provide(HashMapContext context, List<WrappedItemStackModifier> modifiers);

    static GuiItemProvider async(GuiItem item) {
        return new AsyncGuiItemProvider(item);
    }

    static GuiItemProvider caching(GuiItem item) {
        return new CachingGuiItemProvider(item);
    }

    default WrappedItemStack handleModifiers(WrappedItemStack stack, List<WrappedItemStackModifier> modifiers) {
        for (WrappedItemStackModifier modifier : modifiers) {
            stack = modifier.modify(stack);
        }
        return stack;
    }
}
