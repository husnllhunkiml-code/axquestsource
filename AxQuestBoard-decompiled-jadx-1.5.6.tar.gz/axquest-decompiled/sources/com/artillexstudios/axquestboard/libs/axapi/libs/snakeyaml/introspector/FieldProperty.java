package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.introspector;

import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.error.YAMLException;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.util.ArrayUtils;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.List;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/introspector/FieldProperty.class */
public class FieldProperty extends GenericProperty {
    private final Field field;
    private static transient /* synthetic */ String zBPhnXuKrC = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public FieldProperty(Field field) {
        super(field.getName(), field.getType(), field.getGenericType());
        this.field = field;
        field.setAccessible(true);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.introspector.Property
    public void set(Object obj, Object obj2) throws IllegalAccessException {
        this.field.set(obj, obj2);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.introspector.Property
    public Object get(Object obj) {
        try {
            return this.field.get(obj);
        } catch (Exception e) {
            throw new YAMLException("Unable to access field " + this.field.getName() + " on object " + obj + " : " + e);
        }
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.introspector.Property
    public List<Annotation> getAnnotations() {
        return ArrayUtils.toUnmodifiableList(this.field.getAnnotations());
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.introspector.Property
    public <A extends Annotation> A getAnnotation(Class<A> cls) {
        return (A) this.field.getAnnotation(cls);
    }
}
