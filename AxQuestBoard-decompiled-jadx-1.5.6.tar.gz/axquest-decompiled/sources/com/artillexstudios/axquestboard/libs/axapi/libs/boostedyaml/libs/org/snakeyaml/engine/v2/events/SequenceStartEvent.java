package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.Anchor;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.FlowStyle;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.Mark;
import java.util.Optional;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/events/SequenceStartEvent.class */
public final class SequenceStartEvent extends CollectionStartEvent {
    private static transient /* synthetic */ String nvYwUZgWOn = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public SequenceStartEvent(Optional<Anchor> optional, Optional<String> optional2, boolean z, FlowStyle flowStyle, Optional<Mark> optional3, Optional<Mark> optional4) {
        super(optional, optional2, z, flowStyle, optional3, optional4);
    }

    public SequenceStartEvent(Optional<Anchor> optional, Optional<String> optional2, boolean z, FlowStyle flowStyle) {
        this(optional, optional2, z, flowStyle, Optional.empty(), Optional.empty());
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.Event
    public Event.ID getEventId() {
        return Event.ID.SequenceStart;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.CollectionStartEvent
    public String toString() {
        StringBuilder sb = new StringBuilder("+SEQ");
        if (getFlowStyle() == FlowStyle.FLOW) {
            sb.append(" []");
        }
        sb.append(super.toString());
        return sb.toString();
    }
}
