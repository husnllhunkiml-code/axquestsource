package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions;

import java.util.Optional;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/exceptions/ScannerException.class */
public class ScannerException extends MarkedYamlEngineException {
    private static transient /* synthetic */ String QzseeGQOiP = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public ScannerException(String str, Optional<Mark> optional, String str2, Optional<Mark> optional2) {
        super(str, optional, str2, optional2, null);
    }

    public ScannerException(String str, Optional<Mark> optional) {
        super(null, Optional.empty(), str, optional, null);
    }
}
