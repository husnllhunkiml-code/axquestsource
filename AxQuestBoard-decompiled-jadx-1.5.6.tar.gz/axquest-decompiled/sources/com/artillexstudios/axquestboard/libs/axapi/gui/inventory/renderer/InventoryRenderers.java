package com.artillexstudios.axquestboard.libs.axapi.gui.inventory.renderer;

import java.util.Collection;
import java.util.Collections;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/gui/inventory/renderer/InventoryRenderers.class */
public final class InventoryRenderers {
    private static final ConcurrentHashMap<UUID, InventoryRenderer> renderers = new ConcurrentHashMap<>();
    private static final Collection<InventoryRenderer> rendererView = Collections.unmodifiableCollection(renderers.values());
    private static transient /* synthetic */ String sjkyKKnStu = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public static InventoryRenderer getRenderer(Player player) {
        return renderers.computeIfAbsent(player.getUniqueId(), uuid -> {
            return new InventoryRenderer(player);
        });
    }

    public static void disconnect(UUID uuid) {
        renderers.remove(uuid);
    }

    public static Collection<InventoryRenderer> getCurrentRenderers() {
        return rendererView;
    }
}
