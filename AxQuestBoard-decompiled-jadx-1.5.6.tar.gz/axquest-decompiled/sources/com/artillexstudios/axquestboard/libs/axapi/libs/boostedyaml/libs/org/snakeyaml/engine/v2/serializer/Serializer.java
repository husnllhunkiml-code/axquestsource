package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.serializer;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.DumpSettings;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.comments.CommentLine;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.Anchor;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.emitter.Emitable;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.AliasEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.CommentEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.DocumentEndEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.DocumentStartEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.ImplicitTuple;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.MappingEndEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.MappingStartEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.ScalarEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.SequenceEndEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.SequenceStartEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.StreamEndEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.StreamStartEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.YamlEngineException;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.AnchorNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.MappingNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Node;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.NodeTuple;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.NodeType;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.ScalarNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.SequenceNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Tag;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/serializer/Serializer.class */
public class Serializer {
    private final DumpSettings settings;
    private final Emitable emitable;
    private final boolean dereferenceAliases;
    private static transient /* synthetic */ String jggfsCpacK = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";
    private final Set<Node> serializedNodes = new HashSet();
    private final Map<Node, Anchor> anchors = new HashMap();
    private final Set<Node> recursive = Collections.newSetFromMap(new IdentityHashMap());

    public Serializer(DumpSettings dumpSettings, Emitable emitable) {
        this.settings = dumpSettings;
        this.emitable = emitable;
        this.dereferenceAliases = dumpSettings.isDereferenceAliases().booleanValue();
    }

    public void serializeDocument(Node node) {
        this.emitable.emit(new DocumentStartEvent(this.settings.isExplicitStart(), this.settings.getYamlDirective(), this.settings.getTagDirective()));
        anchorNode(node);
        Optional<Tag> explicitRootTag = this.settings.getExplicitRootTag();
        Objects.requireNonNull(node);
        explicitRootTag.ifPresent(node::setTag);
        serializeNode(node);
        this.emitable.emit(new DocumentEndEvent(this.settings.isExplicitEnd()));
        this.serializedNodes.clear();
        this.anchors.clear();
        this.recursive.clear();
    }

    public void emitStreamStart() {
        this.emitable.emit(new StreamStartEvent());
    }

    public void emitStreamEnd() {
        this.emitable.emit(new StreamEndEvent());
    }

    private void anchorNode(Node node) {
        Node realNode;
        if (node.getNodeType() == NodeType.ANCHOR) {
            realNode = ((AnchorNode) node).getRealNode();
        } else {
            realNode = node;
        }
        if (this.anchors.containsKey(realNode)) {
            Node node2 = realNode;
            this.anchors.computeIfAbsent(realNode, node3 -> {
                return this.settings.getAnchorGenerator().nextAnchor(node2);
            });
        }
        this.anchors.put(realNode, realNode.getAnchor().isPresent() ? this.settings.getAnchorGenerator().nextAnchor(realNode) : null);
        switch (realNode.getNodeType()) {
            case SEQUENCE:
                Iterator<Node> it = ((SequenceNode) realNode).getValue().iterator();
                while (it.hasNext()) {
                    anchorNode(it.next());
                }
                break;
            case MAPPING:
                for (NodeTuple nodeTuple : ((MappingNode) realNode).getValue()) {
                    Node keyNode = nodeTuple.getKeyNode();
                    Node valueNode = nodeTuple.getValueNode();
                    anchorNode(keyNode);
                    anchorNode(valueNode);
                }
                break;
        }
    }

    private void serializeNode(Node node) {
        Optional optionalEmpty;
        if (node.getNodeType() == NodeType.ANCHOR) {
            node = ((AnchorNode) node).getRealNode();
        }
        if (this.dereferenceAliases && this.recursive.contains(node)) {
            throw new YamlEngineException("Cannot dereferenceAliases for recursive structures.");
        }
        this.recursive.add(node);
        if (!this.dereferenceAliases) {
            optionalEmpty = Optional.ofNullable(this.anchors.get(node));
        } else {
            optionalEmpty = Optional.empty();
        }
        if (!this.dereferenceAliases && this.serializedNodes.contains(node)) {
            this.emitable.emit(new AliasEvent(optionalEmpty));
        } else {
            this.serializedNodes.add(node);
            switch (node.getNodeType()) {
                case SEQUENCE:
                    SequenceNode sequenceNode = (SequenceNode) node;
                    serializeComments(node.getBlockComments());
                    this.emitable.emit(new SequenceStartEvent(optionalEmpty, Optional.of(node.getTag().getValue()), node.getTag().equals(Tag.SEQ), sequenceNode.getFlowStyle()));
                    Iterator<Node> it = sequenceNode.getValue().iterator();
                    while (it.hasNext()) {
                        serializeNode(it.next());
                    }
                    this.emitable.emit(new SequenceEndEvent());
                    serializeComments(node.getInLineComments());
                    serializeComments(node.getEndComments());
                    break;
                case SCALAR:
                    ScalarNode scalarNode = (ScalarNode) node;
                    serializeComments(node.getBlockComments());
                    this.emitable.emit(new ScalarEvent(optionalEmpty, Optional.of(node.getTag().getValue()), new ImplicitTuple(node.getTag().equals(this.settings.getSchema().getScalarResolver().resolve(scalarNode.getValue(), true)), node.getTag().equals(this.settings.getSchema().getScalarResolver().resolve(scalarNode.getValue(), false))), scalarNode.getValue(), scalarNode.getScalarStyle()));
                    serializeComments(node.getInLineComments());
                    serializeComments(node.getEndComments());
                    break;
                default:
                    serializeComments(node.getBlockComments());
                    boolean zEquals = node.getTag().equals(Tag.MAP);
                    MappingNode mappingNode = (MappingNode) node;
                    List<NodeTuple> value = mappingNode.getValue();
                    if (mappingNode.getTag() != Tag.COMMENT) {
                        this.emitable.emit(new MappingStartEvent(optionalEmpty, Optional.of(mappingNode.getTag().getValue()), zEquals, mappingNode.getFlowStyle(), Optional.empty(), Optional.empty()));
                        for (NodeTuple nodeTuple : value) {
                            Node keyNode = nodeTuple.getKeyNode();
                            Node valueNode = nodeTuple.getValueNode();
                            serializeNode(keyNode);
                            serializeNode(valueNode);
                        }
                        this.emitable.emit(new MappingEndEvent());
                        serializeComments(node.getInLineComments());
                        serializeComments(node.getEndComments());
                    }
                    break;
            }
        }
        this.recursive.remove(node);
    }

    private void serializeComments(List<CommentLine> list) {
        if (list == null) {
            return;
        }
        for (CommentLine commentLine : list) {
            this.emitable.emit(new CommentEvent(commentLine.getCommentType(), commentLine.getValue(), commentLine.getStartMark(), commentLine.getEndMark()));
        }
    }
}
