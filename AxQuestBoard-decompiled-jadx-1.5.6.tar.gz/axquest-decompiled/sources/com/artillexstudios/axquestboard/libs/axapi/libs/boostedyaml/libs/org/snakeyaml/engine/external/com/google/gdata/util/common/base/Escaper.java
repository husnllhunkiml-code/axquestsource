package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.external.com.google.gdata.util.common.base;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/external/com/google/gdata/util/common/base/Escaper.class */
public interface Escaper {
    String escape(String str);

    Appendable escape(Appendable appendable);
}
