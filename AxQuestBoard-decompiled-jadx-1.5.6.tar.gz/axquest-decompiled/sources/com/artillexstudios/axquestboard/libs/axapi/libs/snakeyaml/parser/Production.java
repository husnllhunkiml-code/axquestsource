package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.parser;

import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.events.Event;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/parser/Production.class */
interface Production {
    Event produce();
}
