package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.route;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.route.implementation.MultiKeyRoute;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.route.implementation.SingleKeyRoute;
import java.util.Objects;
import java.util.regex.Pattern;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/route/Route.class */
public interface Route {
    @NotNull
    String join(char c);

    int length();

    @NotNull
    Object get(int i);

    @NotNull
    Route add(@NotNull Object obj);

    @NotNull
    Route parent();

    boolean equals(Object obj);

    int hashCode();

    @NotNull
    static Route from(@NotNull Object... route) {
        if (((Object[]) Objects.requireNonNull(route, "Route array cannot be null!")).length == 0) {
            throw new IllegalArgumentException("Empty routes are not allowed!");
        }
        return route.length == 1 ? new SingleKeyRoute(route[0]) : new MultiKeyRoute(route);
    }

    @NotNull
    static Route from(@NotNull Object key) {
        return new SingleKeyRoute(key);
    }

    @NotNull
    static Route fromSingleKey(@NotNull Object key) {
        return new SingleKeyRoute(key);
    }

    @NotNull
    static Route fromString(@NotNull String route) {
        return fromString(route, '.');
    }

    @NotNull
    static Route fromString(@NotNull String route, char separator) {
        return route.indexOf(separator) != -1 ? new MultiKeyRoute(route.split(Pattern.quote(String.valueOf(separator)))) : new SingleKeyRoute(route);
    }

    @NotNull
    static Route fromString(@NotNull String route, @NotNull RouteFactory routeFactory) {
        return route.indexOf(routeFactory.getSeparator()) != -1 ? new MultiKeyRoute(route.split(routeFactory.getEscapedSeparator())) : new SingleKeyRoute(route);
    }

    @NotNull
    static Route addTo(@Nullable Route route, @NotNull Object key) {
        return route == null ? fromSingleKey(key) : route.add(key);
    }
}
