package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.FlowStyle;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.Mark;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/nodes/MappingNode.class */
public class MappingNode extends CollectionNode<NodeTuple> {
    private List<NodeTuple> value;
    private static transient /* synthetic */ String WmedOUNlAn = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public MappingNode(Tag tag, boolean z, List<NodeTuple> list, FlowStyle flowStyle, Optional<Mark> optional, Optional<Mark> optional2) {
        super(tag, flowStyle, optional, optional2);
        Objects.requireNonNull(list);
        this.value = list;
        this.resolved = z;
    }

    public MappingNode(Tag tag, List<NodeTuple> list, FlowStyle flowStyle) {
        this(tag, true, list, flowStyle, Optional.empty(), Optional.empty());
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Node
    public NodeType getNodeType() {
        return NodeType.MAPPING;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.CollectionNode
    public List<NodeTuple> getValue() {
        return this.value;
    }

    public void setValue(List<NodeTuple> list) {
        Objects.requireNonNull(list);
        this.value = list;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (NodeTuple nodeTuple : getValue()) {
            sb.append("{ key=");
            sb.append(nodeTuple.getKeyNode());
            sb.append("; value=");
            if (nodeTuple.getValueNode() instanceof CollectionNode) {
                sb.append(System.identityHashCode(nodeTuple.getValueNode()));
            } else {
                sb.append(nodeTuple);
            }
            sb.append(" }");
        }
        return "<" + getClass().getName() + " (tag=" + getTag() + ", values=" + sb.toString() + ")>";
    }
}
