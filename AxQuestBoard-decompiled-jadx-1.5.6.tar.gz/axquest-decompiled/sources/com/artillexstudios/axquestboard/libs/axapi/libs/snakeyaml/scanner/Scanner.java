package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.scanner;

import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.tokens.Token;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/scanner/Scanner.class */
public interface Scanner {
    boolean checkToken(Token.ID... idArr);

    Token peekToken();

    Token getToken();

    void resetDocumentIndex();
}
