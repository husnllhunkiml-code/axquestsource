package com.artillexstudios.axquestboard.libs.axapi.config.adapters.collections;

import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapterHolder;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/adapters/collections/ListAdapter.class */
public final class ListAdapter implements TypeAdapter<List<Object>, List<Object>> {
    private static transient /* synthetic */ String vTaacwYyxs = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public List<Object> deserialize(TypeAdapterHolder holder, Object input, Type type) {
        Type type2 = null;
        if (type instanceof ParameterizedType) {
            type2 = ((ParameterizedType) type).getActualTypeArguments()[0];
        }
        if (input instanceof List) {
            List list = (List) input;
            ArrayList arrayList = new ArrayList(list.size());
            Iterator it = list.iterator();
            while (it.hasNext()) {
                arrayList.add(holder.deserialize(it.next(), type2));
            }
            return arrayList;
        }
        throw new RuntimeException();
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public List<Object> serialize(TypeAdapterHolder holder, List<Object> value, Type type) {
        if (!(type instanceof ParameterizedType)) {
            ArrayList arrayList = new ArrayList(value.size());
            for (Object obj : value) {
                arrayList.add(holder.serialize(obj, obj.getClass()));
            }
            return arrayList;
        }
        Type type2 = ((ParameterizedType) type).getActualTypeArguments()[0];
        ArrayList arrayList2 = new ArrayList(value.size());
        Iterator<Object> it = value.iterator();
        while (it.hasNext()) {
            arrayList2.add(holder.serialize(it.next(), type2));
        }
        return arrayList2;
    }
}
