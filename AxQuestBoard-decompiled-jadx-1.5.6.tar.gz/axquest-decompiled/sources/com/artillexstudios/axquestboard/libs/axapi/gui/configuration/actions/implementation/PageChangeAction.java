package com.artillexstudios.axquestboard.libs.axapi.gui.configuration.actions.implementation;

import com.artillexstudios.axquestboard.libs.axapi.context.HashMapContext;
import com.artillexstudios.axquestboard.libs.axapi.gui.configuration.actions.Action;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.Gui;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.GuiKeys;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.implementation.PaginatedGui;
import com.artillexstudios.axquestboard.libs.axapi.utils.NumberUtils;
import com.artillexstudios.axquestboard.libs.axapi.utils.featureflags.FeatureFlags;
import com.artillexstudios.axquestboard.libs.axapi.utils.logging.LogUtils;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.runtime.ObjectMethods;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang3.ArrayUtils;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/gui/configuration/actions/implementation/PageChangeAction.class */
public final class PageChangeAction extends Action<Direction> {
    private static transient /* synthetic */ String YTIZiNLAFz = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public PageChangeAction(String data) {
        super(data);
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.artillexstudios.axquestboard.libs.axapi.gui.configuration.actions.Action
    public Direction transform(String data) {
        return Direction.fetch(data);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.gui.configuration.actions.Action
    public void run(Player player, HashMapContext context) {
        Gui gui = (Gui) context.get(GuiKeys.GUI);
        if (!(gui instanceof PaginatedGui)) {
            if (FeatureFlags.DEBUG.get().booleanValue()) {
                LogUtils.debug("Gui is not a paginated gui! Gui: {}", gui);
                return;
            }
            return;
        }
        PaginatedGui paginatedGui = (PaginatedGui) gui;
        if (value().page == -1) {
            if (!paginatedGui.hasPreviousPage()) {
                if (FeatureFlags.DEBUG.get().booleanValue()) {
                    LogUtils.debug("Gui has no previous page!");
                    return;
                }
                return;
            }
            paginatedGui.page(paginatedGui.page() - 1);
        } else if (value().page == -2) {
            if (!paginatedGui.hasNextPage()) {
                if (FeatureFlags.DEBUG.get().booleanValue()) {
                    LogUtils.debug("Gui has no next page!");
                    return;
                }
                return;
            }
            paginatedGui.page(paginatedGui.page() + 1);
        } else {
            if (!paginatedGui.hasPage(value().page)) {
                if (FeatureFlags.DEBUG.get().booleanValue()) {
                    LogUtils.debug("Gui has no page with index {}!", Integer.valueOf(value().page));
                    return;
                }
                return;
            }
            paginatedGui.page(value().page);
        }
        paginatedGui.open();
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/gui/configuration/actions/implementation/PageChangeAction$Direction.class */
    public static final class Direction extends Record {
        private final int page;
        private final String[] aliases;
        private static final List<Direction> directions = new ArrayList();
        public static final Direction BACKWARDS = register(new Direction(-1, "back", "backwards", "prev", "previous"));
        public static final Direction FORWARDS = register(new Direction(-2, "forwards", "forward", "next"));
        private static transient /* synthetic */ String zbiDZVXvKK = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        public Direction(int page, String... aliases) {
            this.page = page;
            this.aliases = aliases;
        }

        @Override // java.lang.Record
        public final String toString() {
            return (String) ObjectMethods.bootstrap(MethodHandles.lookup(), "toString", MethodType.methodType(String.class, Direction.class), Direction.class, "page;aliases", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/gui/configuration/actions/implementation/PageChangeAction$Direction;->page:I", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/gui/configuration/actions/implementation/PageChangeAction$Direction;->aliases:[Ljava/lang/String;").dynamicInvoker().invoke(this) /* invoke-custom */;
        }

        @Override // java.lang.Record
        public final int hashCode() {
            return (int) ObjectMethods.bootstrap(MethodHandles.lookup(), "hashCode", MethodType.methodType(Integer.TYPE, Direction.class), Direction.class, "page;aliases", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/gui/configuration/actions/implementation/PageChangeAction$Direction;->page:I", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/gui/configuration/actions/implementation/PageChangeAction$Direction;->aliases:[Ljava/lang/String;").dynamicInvoker().invoke(this) /* invoke-custom */;
        }

        @Override // java.lang.Record
        public final boolean equals(Object o) {
            return (boolean) ObjectMethods.bootstrap(MethodHandles.lookup(), "equals", MethodType.methodType(Boolean.TYPE, Direction.class, Object.class), Direction.class, "page;aliases", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/gui/configuration/actions/implementation/PageChangeAction$Direction;->page:I", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/gui/configuration/actions/implementation/PageChangeAction$Direction;->aliases:[Ljava/lang/String;").dynamicInvoker().invoke(this, o) /* invoke-custom */;
        }

        public int page() {
            return this.page;
        }

        public String[] aliases() {
            return this.aliases;
        }

        public static Direction register(Direction direction) {
            directions.add(direction);
            return direction;
        }

        public static Direction fetch(String directionName) {
            if (NumberUtils.isInt(directionName)) {
                return new Direction(Integer.parseInt(directionName), new String[0]);
            }
            for (Direction direction : directions) {
                if (ArrayUtils.contains(direction.aliases, directionName)) {
                    return direction;
                }
            }
            return null;
        }
    }
}
