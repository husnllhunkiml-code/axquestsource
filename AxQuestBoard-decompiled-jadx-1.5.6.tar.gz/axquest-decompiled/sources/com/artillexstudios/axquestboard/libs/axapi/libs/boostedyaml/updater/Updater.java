package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.updater;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.block.implementation.Section;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.general.GeneralSettings;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.updater.UpdaterSettings;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.updater.operators.Merger;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/updater/Updater.class */
public class Updater {
    private static transient /* synthetic */ String zcYttwoQbK = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public static void update(@NotNull Section section, @NotNull Section section2, @NotNull UpdaterSettings updaterSettings, @NotNull GeneralSettings generalSettings) {
        if (VersionedOperations.run(section, section2, updaterSettings, generalSettings.getRouteSeparator())) {
            return;
        }
        Merger.merge(section, section2, updaterSettings);
        if (updaterSettings.getVersioning() != null) {
            updaterSettings.getVersioning().updateVersionID(section, section2);
        }
        if (updaterSettings.isAutoSave()) {
            section.getRoot().save();
        }
    }
}
