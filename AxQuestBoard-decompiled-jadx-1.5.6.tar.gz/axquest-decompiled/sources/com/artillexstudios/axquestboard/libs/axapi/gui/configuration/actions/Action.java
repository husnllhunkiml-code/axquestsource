package com.artillexstudios.axquestboard.libs.axapi.gui.configuration.actions;

import com.artillexstudios.axquestboard.libs.axapi.context.HashMapContext;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/gui/configuration/actions/Action.class */
public abstract class Action<T> {
    private final T value;

    public abstract T transform(String data);

    public abstract void run(Player player, HashMapContext context);

    public Action(String data) {
        this.value = transform(data);
        if (this.value == null) {
            throw new IllegalArgumentException();
        }
    }

    public T value() {
        return this.value;
    }
}
