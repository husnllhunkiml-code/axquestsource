package com.artillexstudios.axquestboard.libs.axapi.config;

import com.artillexstudios.axquestboard.libs.axapi.config.adapters.MapConfigurationGetter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.other.ObjectAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.annotation.Comment;
import com.artillexstudios.axquestboard.libs.axapi.config.annotation.ConfigurationPart;
import com.artillexstudios.axquestboard.libs.axapi.config.annotation.Serializable;
import com.artillexstudios.axquestboard.libs.axapi.config.reader.ClassConfigurationReader;
import com.artillexstudios.axquestboard.libs.axapi.config.reader.FileConfigurationReader;
import com.artillexstudios.axquestboard.libs.axapi.config.reader.Handler;
import com.artillexstudios.axquestboard.libs.axapi.config.renamer.KeyRenamer;
import com.artillexstudios.axquestboard.libs.axapi.config.renamer.LowerKebabCaseRenamer;
import com.artillexstudios.axquestboard.libs.axapi.config.service.Formatter;
import com.artillexstudios.axquestboard.libs.axapi.config.service.Writer;
import com.artillexstudios.axquestboard.libs.axapi.config.service.implementation.FileCreator;
import com.artillexstudios.axquestboard.libs.axapi.config.service.implementation.FileWriter;
import com.artillexstudios.axquestboard.libs.axapi.config.service.implementation.YamlFormatter;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.DumperOptions;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.LoaderOptions;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.Yaml;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.representer.Representer;
import com.artillexstudios.axquestboard.libs.axapi.reflection.ClassUtils;
import com.artillexstudios.axquestboard.libs.axapi.utils.UncheckedUtils;
import com.artillexstudios.axquestboard.libs.axapi.utils.logging.LogUtils;
import it.unimi.dsi.fastutil.Pair;
import it.unimi.dsi.fastutil.ints.IntIntPair;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Consumer;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/YamlConfiguration.class */
public final class YamlConfiguration<T extends ConfigurationPart> extends MapConfigurationGetter {
    private final LinkedHashMap<String, Object> contents;
    private final Map<String, Comment> comments;
    private final Builder<T> builder;
    private final YamlConstructor constructor;
    private final FileCreator creator;
    private final Handler reader;
    private final Yaml yaml;
    private static transient /* synthetic */ String MazYCtJAxu = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    YamlConfiguration(Builder<T> builder) {
        super(new LinkedHashMap());
        this.comments = new HashMap();
        this.contents = (LinkedHashMap) UncheckedUtils.unsafeCast(wrapped());
        this.builder = builder;
        this.creator = new FileCreator(((Builder) this.builder).writer);
        this.constructor = new YamlConstructor(((Builder) builder).loaderOptions);
        this.holder.registerAdapters(((Builder) builder).adapters);
        this.yaml = new Yaml(this.constructor, new Representer(((Builder) builder).dumperOptions), ((Builder) builder).dumperOptions, ((Builder) builder).loaderOptions);
        this.reader = ((Builder) this.builder).clazz == null ? new FileConfigurationReader(this.yaml, this.constructor, this.holder) : new ClassConfigurationReader(this.yaml, this.constructor, this.holder, ((Builder) this.builder).keyRenamer, ((Builder) this.builder).clazz);
    }

    public static <T extends ConfigurationPart> Builder<T> of(Path path, Class<T> clazz) {
        return new Builder<>(path, clazz);
    }

    public static Builder<?> of(Path path) {
        return new Builder<>(path, null);
    }

    public boolean load() {
        if (!this.creator.create(((Builder) this.builder).path, ((Builder) this.builder).defaults)) {
            return false;
        }
        if (((Builder) this.builder).configVersionPath != null) {
            runUpdaters();
        }
        try {
            BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream(((Builder) this.builder).path.toFile()));
            try {
                Pair<Map<String, Object>, Map<String, Comment>> pair = this.reader.read(bufferedInputStream, null);
                this.contents.putAll((Map) pair.first());
                this.comments.putAll((Map) pair.second());
                bufferedInputStream.close();
                save();
                return true;
            } catch (Throwable th) {
                try {
                    bufferedInputStream.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        } catch (IOException e) {
            return false;
        }
    }

    public T create(T instance) {
        if (!this.creator.create(((Builder) this.builder).path, ((Builder) this.builder).defaults)) {
            return null;
        }
        if (((Builder) this.builder).configVersionPath != null) {
            runUpdaters();
        }
        try {
            BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream(((Builder) this.builder).path.toFile()));
            try {
                Pair<Map<String, Object>, Map<String, Comment>> pair = this.reader.read(bufferedInputStream, instance);
                this.contents.putAll((Map) pair.first());
                this.comments.putAll((Map) pair.second());
                bufferedInputStream.close();
                save();
                return instance;
            } catch (Throwable th) {
                try {
                    bufferedInputStream.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        } catch (IOException e) {
            return null;
        }
    }

    public T create() {
        return (T) create((ConfigurationPart) ClassUtils.INSTANCE.create(((Builder) this.builder).clazz, new Object[0]));
    }

    public boolean save() {
        return ((Builder) this.builder).writer.write(((Builder) this.builder).path, ((Builder) this.builder).formatter.format(this.reader.write(this.contents, this.comments)));
    }

    public void move(String path, String newPath) {
        Object obj = get(path);
        remove(path);
        set(newPath, obj);
    }

    public void set(String path, Object value) {
        if (((Builder) this.builder).clazz == null) {
            value = this.holder.serialize(value, null);
        }
        set0(this.contents, path, value);
    }

    public Path path() {
        return ((Builder) this.builder).path;
    }

    private void set0(Map<String, Object> map, String path, Object value) {
        String[] strArrSplit = path.split("\\.");
        if (strArrSplit.length == 1) {
            map.put(strArrSplit[0], value);
            return;
        }
        int i = 0;
        Map<String, Object> map2 = map;
        while (i < strArrSplit.length) {
            Object obj = map2.get(strArrSplit[i]);
            if (obj == null) {
                LinkedHashMap linkedHashMap = new LinkedHashMap();
                obj = linkedHashMap;
                map2.put(strArrSplit[i], linkedHashMap);
            }
            if (!(obj instanceof Map)) {
                LogUtils.warn("Expected map class, but in reality it was: {}. Value: {}. Route: {} Full path: {}", obj.getClass(), obj, strArrSplit[i], path);
                return;
            }
            map2 = (Map) UncheckedUtils.unsafeCast(obj);
            i++;
            if (i == strArrSplit.length - 1) {
                map2.put(strArrSplit[i], value);
                return;
            }
        }
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.MapConfigurationGetter, com.artillexstudios.axquestboard.libs.axapi.config.adapters.ConfigurationGetter
    public <Z> Z get(String path, Class<Z> clazz) {
        if (((Builder) this.builder).clazz == null) {
            return clazz.cast(this.holder.deserialize(get(path), clazz));
        }
        return clazz.cast(get(path));
    }

    public Object get(String path) {
        return get0(this.contents, path);
    }

    public String dumpInternalData() {
        return dumpInternalData0(this.contents);
    }

    private String dumpInternalData0(Map<?, ?> map) {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<?, ?> entry : map.entrySet()) {
            Object value = entry.getValue();
            if (value instanceof Map) {
                Map<?, ?> map2 = (Map) value;
                sb.append(entry.getKey()).append("=").append(dumpInternalData0(map2)).append(";class=").append(map2.getClass()).append("\n");
            } else {
                sb.append(entry.getKey()).append(entry.getValue()).append(";class=").append(entry.getValue().getClass()).append("\n");
            }
        }
        return sb.toString();
    }

    private Object get0(Map<String, Object> map, String path) {
        Object obj;
        String[] strArrSplit = path.split("\\.");
        if (strArrSplit.length == 1) {
            return map.get(strArrSplit[0]);
        }
        int i = 0;
        Map<String, Object> map2 = map;
        while (i < strArrSplit.length && (obj = map2.get(strArrSplit[i])) != null) {
            if (!(obj instanceof Map)) {
                LogUtils.warn("Expected map class, but in reality it was: {}. Value: {}. Route: {} Full path: {}", obj.getClass(), obj, strArrSplit[i], path);
                return null;
            }
            map2 = (Map) UncheckedUtils.unsafeCast((Map) obj);
            i++;
            if (i == strArrSplit.length - 1) {
                return map2.get(strArrSplit[i]);
            }
        }
        return null;
    }

    public void remove(String path) {
        String[] strArrSplit = path.split("\\.");
        if (strArrSplit.length == 1) {
            this.contents.remove(strArrSplit[0]);
            return;
        }
        int i = 0;
        Map map = this.contents;
        while (i < strArrSplit.length) {
            Map linkedHashMap = (Map) UncheckedUtils.unsafeCast(map.get(strArrSplit[i]));
            if (linkedHashMap == null) {
                linkedHashMap = new LinkedHashMap();
                map.put(strArrSplit[i], linkedHashMap);
            }
            map = linkedHashMap;
            i++;
            if (i == strArrSplit.length - 1) {
                map.remove(strArrSplit[i]);
                return;
            }
        }
    }

    private boolean runUpdaters() {
        FileConfigurationReader fileConfigurationReader = new FileConfigurationReader(this.yaml, this.constructor, this.holder);
        try {
            BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream(((Builder) this.builder).path.toFile()));
            try {
                Pair<Map<String, Object>, Map<String, Comment>> pair = fileConfigurationReader.read(bufferedInputStream, null);
                this.contents.putAll((Map) pair.first());
                this.comments.putAll((Map) pair.second());
                bufferedInputStream.close();
                Integer integer = getInteger(((Builder) this.builder).configVersionPath);
                Integer numValueOf = Integer.valueOf(integer == null ? 1 : integer.intValue());
                if (numValueOf.intValue() == ((Builder) this.builder).configVersion) {
                    this.contents.clear();
                    this.comments.clear();
                    return false;
                }
                for (Map.Entry<IntIntPair, ConfigurationUpdater> entry : ((Builder) this.builder).updaters.entrySet()) {
                    if (entry.getKey().firstInt() == numValueOf.intValue()) {
                        entry.getValue().update(this);
                        numValueOf = Integer.valueOf(entry.getKey().secondInt());
                        set(((Builder) this.builder).configVersionPath, numValueOf);
                    }
                }
                ((Builder) this.builder).writer.write(((Builder) this.builder).path, ((Builder) this.builder).formatter.format(fileConfigurationReader.write(this.contents, this.comments)));
                this.contents.clear();
                this.comments.clear();
                return true;
            } catch (Throwable th) {
                try {
                    bufferedInputStream.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        } catch (IOException e) {
            return false;
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/YamlConfiguration$Builder.class */
    public static class Builder<T extends ConfigurationPart> {
        private final Path path;
        private final Class<T> clazz;
        private InputStream defaults;
        private static transient /* synthetic */ String uHNDdqRmxx = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";
        private final Map<IntIntPair, ConfigurationUpdater> updaters = new LinkedHashMap();
        private final Map<Class<?>, TypeAdapter<?, ?>> adapters = new HashMap();
        private final DumperOptions dumperOptions = new DumperOptions();
        private final LoaderOptions loaderOptions = new LoaderOptions();
        private Formatter formatter = new YamlFormatter();
        private Writer writer = new FileWriter();
        private KeyRenamer keyRenamer = new LowerKebabCaseRenamer();
        private int configVersion = 0;
        private String configVersionPath = null;

        private Builder(Path path, Class<T> clazz) {
            this.path = path;
            this.clazz = clazz;
            this.dumperOptions.setProcessComments(true);
            this.loaderOptions.setProcessComments(true);
        }

        public Builder<T> addUpdater(int fromVersion, int toVersion, ConfigurationUpdater updater) {
            this.updaters.put(IntIntPair.of(fromVersion, toVersion), updater);
            return this;
        }

        public Builder<T> withDefaults(InputStream defaults) {
            this.defaults = defaults;
            return this;
        }

        public Builder<T> withDumperOptions(Consumer<DumperOptions> dumperOptions) {
            dumperOptions.accept(this.dumperOptions);
            return this;
        }

        public Builder<T> withLoaderOptions(Consumer<LoaderOptions> loaderOptions) {
            loaderOptions.accept(this.loaderOptions);
            return this;
        }

        public Builder<T> configVersion(int configVersion, String configVersionPath) {
            this.configVersion = configVersion;
            this.configVersionPath = configVersionPath;
            return this;
        }

        public Builder<T> registerAdapter(Class<?> clazz, TypeAdapter<?, ?> adapter) {
            this.adapters.put(clazz, adapter);
            return this;
        }

        public Builder<T> withKeyRenamer(KeyRenamer keyRenamer) {
            this.keyRenamer = keyRenamer;
            return this;
        }

        public Builder<T> withFormatter(Formatter formatter) {
            this.formatter = formatter;
            return this;
        }

        public Builder<T> withWriter(Writer writer) {
            this.writer = writer;
            return this;
        }

        public KeyRenamer keyRenamer() {
            return this.keyRenamer;
        }

        public YamlConfiguration<T> build() {
            this.adapters.put(Serializable.class, new ObjectAdapter(this));
            return new YamlConfiguration<>(this);
        }
    }
}
