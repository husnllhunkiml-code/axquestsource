package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.nodes;

import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.DumperOptions;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.error.Mark;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/nodes/ScalarNode.class */
public class ScalarNode extends Node {
    private final DumperOptions.ScalarStyle style;
    private final String value;
    private static transient /* synthetic */ String KhGvgugxei = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public ScalarNode(Tag tag, String str, Mark mark, Mark mark2, DumperOptions.ScalarStyle scalarStyle) {
        this(tag, true, str, mark, mark2, scalarStyle);
    }

    public ScalarNode(Tag tag, boolean z, String str, Mark mark, Mark mark2, DumperOptions.ScalarStyle scalarStyle) {
        super(tag, mark, mark2);
        if (str == null) {
            throw new NullPointerException("value in a Node is required.");
        }
        this.value = str;
        if (scalarStyle == null) {
            throw new NullPointerException("Scalar style must be provided.");
        }
        this.style = scalarStyle;
        this.resolved = z;
    }

    public DumperOptions.ScalarStyle getScalarStyle() {
        return this.style;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.nodes.Node
    public NodeId getNodeId() {
        return NodeId.scalar;
    }

    public String getValue() {
        return this.value;
    }

    public String toString() {
        return "<" + getClass().getName() + " (tag=" + getTag() + ", value=" + getValue() + ")>";
    }

    public boolean isPlain() {
        return this.style == DumperOptions.ScalarStyle.PLAIN;
    }
}
