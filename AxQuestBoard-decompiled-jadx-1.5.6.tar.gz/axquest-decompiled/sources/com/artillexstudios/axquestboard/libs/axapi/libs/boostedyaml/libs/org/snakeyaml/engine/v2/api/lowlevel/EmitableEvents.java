package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.lowlevel;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.emitter.Emitable;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.Event;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: compiled from: Serialize.java */
/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/api/lowlevel/EmitableEvents.class */
class EmitableEvents implements Emitable {
    private final List<Event> events = new ArrayList();
    private static transient /* synthetic */ String IImGEbThxW = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    EmitableEvents() {
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.emitter.Emitable
    public void emit(Event event) {
        this.events.add(event);
    }

    public List<Event> getEvents() {
        return this.events;
    }
}
