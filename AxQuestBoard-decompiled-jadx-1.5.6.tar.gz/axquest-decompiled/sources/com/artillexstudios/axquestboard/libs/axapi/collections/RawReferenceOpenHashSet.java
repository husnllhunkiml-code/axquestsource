package com.artillexstudios.axquestboard.libs.axapi.collections;

import com.artillexstudios.axquestboard.libs.axapi.reflection.FieldAccessor;
import it.unimi.dsi.fastutil.objects.ReferenceOpenHashSet;
import it.unimi.dsi.fastutil.objects.ReferenceSet;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/collections/RawReferenceOpenHashSet.class */
public class RawReferenceOpenHashSet<K> extends ReferenceOpenHashSet<K> {
    private static final FieldAccessor accessor = FieldAccessor.builder().withClass("it.unimi.dsi.fastutil.objects.ReferenceCollections$SynchronizedCollection").withField("collection").build();
    private static transient /* synthetic */ String goRMthEbjn = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public RawReferenceOpenHashSet() {
    }

    public RawReferenceOpenHashSet(final int capacity) {
        super(capacity);
    }

    public static <E> Object[] rawSet(ReferenceSet<E> set) {
        return ((RawReferenceOpenHashSet) accessor.getUnchecked(set)).rawSet();
    }

    public boolean remove(Object k) {
        return super.remove(k);
    }

    /* JADX INFO: renamed from: clone, reason: merged with bridge method [inline-methods] and merged with bridge method [inline-methods] */
    public RawReferenceOpenHashSet<K> m33clone() {
        return (RawReferenceOpenHashSet) super.clone();
    }

    public Object[] rawSet() {
        return this.key;
    }
}
