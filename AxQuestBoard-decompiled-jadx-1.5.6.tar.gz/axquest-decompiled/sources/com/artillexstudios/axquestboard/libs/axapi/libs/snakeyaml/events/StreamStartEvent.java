package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.events;

import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.error.Mark;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/events/StreamStartEvent.class */
public final class StreamStartEvent extends Event {
    private static transient /* synthetic */ String IlvrZTItjF = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public StreamStartEvent(Mark mark, Mark mark2) {
        super(mark, mark2);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.events.Event
    public Event.ID getEventId() {
        return Event.ID.StreamStart;
    }
}
