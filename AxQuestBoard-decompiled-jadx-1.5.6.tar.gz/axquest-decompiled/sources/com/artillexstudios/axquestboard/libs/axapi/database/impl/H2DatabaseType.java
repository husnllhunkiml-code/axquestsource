package com.artillexstudios.axquestboard.libs.axapi.database.impl;

import com.artillexstudios.axquestboard.libs.axapi.AxPlugin;
import com.artillexstudios.axquestboard.libs.axapi.database.DatabaseConfig;
import com.artillexstudios.axquestboard.libs.axapi.database.DatabaseType;
import com.artillexstudios.axquestboard.libs.axapi.libs.hikari.HikariConfig;
import net.kyori.adventure.text.serializer.commons.ComponentTreeConstants;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/database/impl/H2DatabaseType.class */
public class H2DatabaseType extends DatabaseType {
    private final String relocated;
    private static transient /* synthetic */ String MXBIULeOHW = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public H2DatabaseType() {
        this("org.h2");
    }

    public H2DatabaseType(String relocated) {
        this.relocated = relocated;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.database.DatabaseType
    public HikariConfig config(DatabaseConfig databaseConfig) {
        HikariConfig hikariConfig = new HikariConfig();
        hikariConfig.setDataSourceClassName(this.relocated + ".jdbcx.JdbcDataSource");
        hikariConfig.addDataSourceProperty(ComponentTreeConstants.CLICK_EVENT_URL, "jdbc:h2:./" + String.valueOf(((AxPlugin) AxPlugin.getPlugin(AxPlugin.class)).getDataFolder()) + "/data");
        hikariConfig.setMaximumPoolSize(databaseConfig.pool.maximumPoolSize);
        hikariConfig.setMinimumIdle(databaseConfig.pool.minimumIdle);
        return hikariConfig;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.database.DatabaseType
    public String name() {
        return "h2";
    }
}
