package com.artillexstudios.axquestboard.libs.axapi.libs.hikari.util;

import java.util.concurrent.TimeUnit;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/hikari/util/ClockSource.class */
public interface ClockSource {
    public static final ClockSource CLOCK = Factory.create();
    public static final TimeUnit[] TIMEUNITS_DESCENDING = {TimeUnit.DAYS, TimeUnit.HOURS, TimeUnit.MINUTES, TimeUnit.SECONDS, TimeUnit.MILLISECONDS, TimeUnit.MICROSECONDS, TimeUnit.NANOSECONDS};
    public static final String[] TIMEUNIT_DISPLAY_VALUES = {"ns", "\u00b5s", "ms", "s", "m", "h", "d"};

    long currentTime0();

    long toMillis0(long j);

    long toNanos0(long j);

    long elapsedMillis0(long j);

    long elapsedMillis0(long j, long j2);

    long elapsedNanos0(long j);

    long elapsedNanos0(long j, long j2);

    long plusMillis0(long j, long j2);

    TimeUnit getSourceTimeUnit0();

    static long currentTime() {
        return CLOCK.currentTime0();
    }

    static long toMillis(long time) {
        return CLOCK.toMillis0(time);
    }

    static long toNanos(long time) {
        return CLOCK.toNanos0(time);
    }

    static long elapsedMillis(long startTime) {
        return CLOCK.elapsedMillis0(startTime);
    }

    static long elapsedMillis(long startTime, long endTime) {
        return CLOCK.elapsedMillis0(startTime, endTime);
    }

    static long elapsedNanos(long startTime) {
        return CLOCK.elapsedNanos0(startTime);
    }

    static long elapsedNanos(long startTime, long endTime) {
        return CLOCK.elapsedNanos0(startTime, endTime);
    }

    static long plusMillis(long time, long millis) {
        return CLOCK.plusMillis0(time, millis);
    }

    static TimeUnit getSourceTimeUnit() {
        return CLOCK.getSourceTimeUnit0();
    }

    static String elapsedDisplayString(long startTime, long endTime) {
        return CLOCK.elapsedDisplayString0(startTime, endTime);
    }

    default String elapsedDisplayString0(long startTime, long endTime) {
        long elapsedNanos = elapsedNanos0(startTime, endTime);
        StringBuilder sb = new StringBuilder(elapsedNanos < 0 ? "-" : "");
        long elapsedNanos2 = Math.abs(elapsedNanos);
        for (TimeUnit unit : TIMEUNITS_DESCENDING) {
            long converted = unit.convert(elapsedNanos2, TimeUnit.NANOSECONDS);
            if (converted > 0) {
                sb.append(converted).append(TIMEUNIT_DISPLAY_VALUES[unit.ordinal()]);
                elapsedNanos2 -= TimeUnit.NANOSECONDS.convert(converted, unit);
            }
        }
        return sb.toString();
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/hikari/util/ClockSource$Factory.class */
    public static class Factory {
        private static transient /* synthetic */ String MXmGmaIgfk = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        private static ClockSource create() {
            if ("Mac OS X".equals(System.getProperty("os.name"))) {
                return new MillisecondClockSource();
            }
            return new NanosecondClockSource();
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/hikari/util/ClockSource$MillisecondClockSource.class */
    public static final class MillisecondClockSource implements ClockSource {
        private static transient /* synthetic */ String APNwoqTHrD = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.hikari.util.ClockSource
        public long currentTime0() {
            return System.currentTimeMillis();
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.hikari.util.ClockSource
        public long elapsedMillis0(long j) {
            return System.currentTimeMillis() - j;
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.hikari.util.ClockSource
        public long elapsedMillis0(long j, long j2) {
            return j2 - j;
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.hikari.util.ClockSource
        public long elapsedNanos0(long j) {
            return TimeUnit.MILLISECONDS.toNanos(System.currentTimeMillis() - j);
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.hikari.util.ClockSource
        public long elapsedNanos0(long j, long j2) {
            return TimeUnit.MILLISECONDS.toNanos(j2 - j);
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.hikari.util.ClockSource
        public long toMillis0(long j) {
            return j;
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.hikari.util.ClockSource
        public long toNanos0(long j) {
            return TimeUnit.MILLISECONDS.toNanos(j);
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.hikari.util.ClockSource
        public long plusMillis0(long j, long j2) {
            return j + j2;
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.hikari.util.ClockSource
        public TimeUnit getSourceTimeUnit0() {
            return TimeUnit.MILLISECONDS;
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/hikari/util/ClockSource$NanosecondClockSource.class */
    public static class NanosecondClockSource implements ClockSource {
        private static transient /* synthetic */ String SmQzidpgPk = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.hikari.util.ClockSource
        public long currentTime0() {
            return System.nanoTime();
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.hikari.util.ClockSource
        public long toMillis0(long j) {
            return TimeUnit.NANOSECONDS.toMillis(j);
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.hikari.util.ClockSource
        public long toNanos0(long j) {
            return j;
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.hikari.util.ClockSource
        public long elapsedMillis0(long j) {
            return TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - j);
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.hikari.util.ClockSource
        public long elapsedMillis0(long j, long j2) {
            return TimeUnit.NANOSECONDS.toMillis(j2 - j);
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.hikari.util.ClockSource
        public long elapsedNanos0(long j) {
            return System.nanoTime() - j;
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.hikari.util.ClockSource
        public long elapsedNanos0(long j, long j2) {
            return j2 - j;
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.hikari.util.ClockSource
        public long plusMillis0(long j, long j2) {
            return j + TimeUnit.MILLISECONDS.toNanos(j2);
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.hikari.util.ClockSource
        public TimeUnit getSourceTimeUnit0() {
            return TimeUnit.NANOSECONDS;
        }
    }
}
