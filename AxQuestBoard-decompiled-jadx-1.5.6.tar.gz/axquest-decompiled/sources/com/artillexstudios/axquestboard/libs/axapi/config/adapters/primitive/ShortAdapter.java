package com.artillexstudios.axquestboard.libs.axapi.config.adapters.primitive;

import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapterHolder;
import java.lang.reflect.Type;
import java.math.BigInteger;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/adapters/primitive/ShortAdapter.class */
public final class ShortAdapter implements TypeAdapter<Short, Short> {
    private static transient /* synthetic */ String QDanLKHcom = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public Short deserialize(TypeAdapterHolder registry, Object input, Type type) {
        if (input instanceof Number) {
            return validate((Number) input);
        }
        if (input instanceof String) {
            return validate(Double.valueOf(Double.parseDouble((String) input)));
        }
        throw new IllegalArgumentException("Can't make a short from a " + String.valueOf(input.getClass()));
    }

    private Short validate(Number number) {
        long jLongValueExact = number instanceof BigInteger ? ((BigInteger) number).longValueExact() : number.longValue();
        if (jLongValueExact > 32767 || jLongValueExact < -32768) {
            throw new IllegalArgumentException("Short value is not actually a short! Should be between %s and %s, but was %s".formatted(Short.MIN_VALUE, Short.MAX_VALUE, Long.valueOf(jLongValueExact)));
        }
        return Short.valueOf((short) jLongValueExact);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public Short serialize(TypeAdapterHolder registry, Short value, Type type) {
        return value;
    }
}
