package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.Mark;
import java.util.Objects;
import java.util.Optional;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/tokens/TagToken.class */
public final class TagToken extends Token {
    private final TagTuple value;
    private static transient /* synthetic */ String KfdInxCarp = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public TagToken(TagTuple tagTuple, Optional<Mark> optional, Optional<Mark> optional2) {
        super(optional, optional2);
        Objects.requireNonNull(tagTuple);
        this.value = tagTuple;
    }

    public TagTuple getValue() {
        return this.value;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.Token
    public Token.ID getTokenId() {
        return Token.ID.Tag;
    }
}
