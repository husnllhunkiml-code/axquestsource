package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.dvs.segment;

import java.util.Arrays;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/dvs/segment/RangeSegment.class */
public class RangeSegment implements Segment {
    private final int start;
    private final int end;
    private final int step;
    private final int minStringLength;
    private final int maxStringLength;
    private final int fill;
    private final int length;
    private static transient /* synthetic */ String YuKhUlnRfp = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public RangeSegment(int i, int i2, int i3, int i4) {
        int iCountDigits;
        int iCountDigits2;
        this.start = i;
        this.end = i2;
        this.step = i3;
        this.fill = i4;
        if (i3 == 0) {
            throw new IllegalArgumentException("Step cannot be zero!");
        }
        if ((i < i2 && i3 < 0) || (i > i2 && i3 > 0)) {
            throw new IllegalArgumentException(String.format("Invalid step for the given range! start=%d end=%d step=%d", Integer.valueOf(i), Integer.valueOf(i2), Integer.valueOf(i3)));
        }
        if (i == i2) {
            throw new IllegalArgumentException(String.format("Parameters define an empty range, start=end! start=%d end=%d", Integer.valueOf(i), Integer.valueOf(i2)));
        }
        this.length = (int) Math.ceil(((double) Math.abs(i - i2)) / ((double) Math.abs(i3)));
        int i5 = i + (i3 * (this.length - 1));
        if (i < 0 || (i2 < 0 && i5 < 0)) {
            throw new IllegalArgumentException(String.format("Range contains negative integers! start=%d end=%d step=%d", Integer.valueOf(i), Integer.valueOf(i2), Integer.valueOf(i3)));
        }
        if (i4 > 0 && !validateFill(i4, Math.max(i, i5))) {
            throw new IllegalArgumentException(String.format("Some integer from the range exceeds maximum length defined by the filling parameter! start=%d end=%d last=%d fill=%d", Integer.valueOf(i), Integer.valueOf(i2), Integer.valueOf(i5), Integer.valueOf(i4)));
        }
        if (i4 > 0) {
            iCountDigits = i4;
        } else {
            iCountDigits = countDigits(i3 > 0 ? i2 : i);
        }
        this.maxStringLength = iCountDigits;
        if (i4 > 0) {
            iCountDigits2 = i4;
        } else {
            iCountDigits2 = countDigits(i3 > 0 ? i : i2);
        }
        this.minStringLength = iCountDigits2;
    }

    @Deprecated
    public RangeSegment(int i, int i2) {
        this(i, i2, i < i2 ? 1 : -1, 0);
    }

    @Deprecated
    public RangeSegment(int i, int i2, int i3) {
        this(i, i2, i3, 0);
    }

    private boolean validateFill(int i, int i2) {
        int i3 = 9;
        for (int i4 = 0; i4 < i; i4++) {
            if (i3 >= i2) {
                return true;
            }
            i3 = (i3 * 10) + 9;
        }
        return false;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.dvs.segment.Segment
    public int parse(String str, int i) {
        int iDigit;
        if (this.fill > 0) {
            if (this.fill > str.length() - i) {
                return -1;
            }
            try {
                return getRangeIndex(Integer.parseInt(str.substring(i, this.fill)));
            } catch (NumberFormatException e) {
                return -1;
            }
        }
        if (str.length() <= i) {
            return -1;
        }
        int i2 = 0;
        int i3 = 0;
        for (int i4 = 0; i4 < this.maxStringLength && i4 < str.length() - i && ((i4 != 1 || i2 != 0 || i3 != 1) && (iDigit = Character.digit(str.charAt(i + i4), 10)) != -1); i4++) {
            i2 = (i2 * 10) + iDigit;
            i3++;
        }
        if (i3 == 0) {
            return -1;
        }
        if (i2 == 0) {
            return getRangeIndex(0);
        }
        while (i2 > 0 && i3 >= this.minStringLength) {
            int rangeIndex = getRangeIndex(i2);
            if (rangeIndex != -1) {
                return rangeIndex;
            }
            i2 /= 10;
            i3--;
        }
        return -1;
    }

    private int countDigits(int i) {
        if (i == 0) {
            return 1;
        }
        int i2 = 0;
        while (i > 0) {
            i /= 10;
            i2++;
        }
        return i2;
    }

    private int getRangeIndex(int i) {
        if (this.step > 0) {
            if (this.start > i || this.end <= i) {
                return -1;
            }
        } else if (this.start < i || this.end >= i) {
            return -1;
        }
        int iAbs = Math.abs(i - this.start);
        if (i >= 0 && iAbs % this.step == 0) {
            return iAbs / Math.abs(this.step);
        }
        return -1;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.dvs.segment.Segment
    public String getElement(int i) {
        if (i >= this.length) {
            throw new IndexOutOfBoundsException(String.format("Index out of bounds! i=%d length=%d", Integer.valueOf(i), Integer.valueOf(this.length)));
        }
        String string = Integer.toString(this.start + (this.step * i), 10);
        if (this.fill <= 0 || string.length() == this.fill) {
            return string;
        }
        char[] cArr = new char[this.fill - string.length()];
        Arrays.fill(cArr, '0');
        return new StringBuilder(string).insert(0, cArr).toString();
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.dvs.segment.Segment
    public int getElementLength(int i) {
        if (i >= this.length) {
            throw new IndexOutOfBoundsException(String.format("Index out of bounds! i=%d length=%d", Integer.valueOf(i), Integer.valueOf(this.length)));
        }
        return this.fill > 0 ? this.fill : countDigits(this.start + (this.step * i));
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.dvs.segment.Segment
    public int length() {
        return this.length;
    }

    public String toString() {
        return "RangeSegment{start=" + this.start + ", end=" + this.end + ", step=" + this.step + ", fill=" + this.fill + ", length=" + this.length + '}';
    }
}
