package com.artillexstudios.axquestboard.libs.axapi.gui.inventory;

import com.artillexstudios.axquestboard.libs.axapi.context.ContextKey;
import net.kyori.adventure.text.serializer.commons.ComponentTreeConstants;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/gui/inventory/GuiKeys.class */
public class GuiKeys {
    public static final ContextKey<Player> PLAYER = ContextKey.of(ComponentTreeConstants.OBJECT_PLAYER, Player.class);
    public static final ContextKey<Gui> GUI = ContextKey.of("gui", Gui.class);
    private static transient /* synthetic */ String BvrQnRgrVy = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";
}
