package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.dvs.versioning;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.dvs.Pattern;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.dvs.segment.Segment;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/dvs/versioning/BasicVersioning.class */
public class BasicVersioning extends AutomaticVersioning {
    public static final Pattern PATTERN = new Pattern(Segment.range(1, Integer.MAX_VALUE));
    private static transient /* synthetic */ String UEOLtlRdSG = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public BasicVersioning(@NotNull String str) {
        super(PATTERN, str);
    }
}
