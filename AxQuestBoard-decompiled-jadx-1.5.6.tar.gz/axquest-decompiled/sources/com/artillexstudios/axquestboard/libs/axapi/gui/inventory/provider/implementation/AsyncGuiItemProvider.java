package com.artillexstudios.axquestboard.libs.axapi.gui.inventory.provider.implementation;

import com.artillexstudios.axquestboard.libs.axapi.context.HashMapContext;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.BakedGuiItem;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.GuiItem;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.modifier.WrappedItemStackModifier;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.provider.GuiItemProvider;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/gui/inventory/provider/implementation/AsyncGuiItemProvider.class */
public class AsyncGuiItemProvider implements GuiItemProvider {
    private final GuiItem item;
    private static transient /* synthetic */ String oUWcEXJFDT = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public AsyncGuiItemProvider(GuiItem item) {
        this.item = item;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.gui.inventory.provider.GuiItemProvider
    public CompletableFuture<BakedGuiItem> provide(HashMapContext context, List<WrappedItemStackModifier> modifiers) {
        return CompletableFuture.supplyAsync(() -> {
            return new BakedGuiItem(handleModifiers(this.item.stack().apply(context), modifiers).toBukkit(), inventoryClickEvent -> {
                this.item.eventConsumer().accept(context, inventoryClickEvent);
            });
        });
    }
}
