package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.constructor;

import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.error.YAMLException;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.nodes.Node;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/constructor/AbstractConstruct.class */
public abstract class AbstractConstruct implements Construct {
    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.constructor.Construct
    public void construct2ndStep(Node node, Object obj) {
        if (node.isTwoStepsConstruction()) {
            throw new IllegalStateException("Not Implemented in " + getClass().getName());
        }
        throw new YAMLException("Unexpected recursive structure for Node: " + node);
    }
}
