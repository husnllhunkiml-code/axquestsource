package com.artillexstudios.axquestboard.libs.axapi.libs.hikari.util;

import javax.management.ConstructorParameters;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/hikari/util/Credentials.class */
public final class Credentials {
    private final String username;
    private final String password;
    private static transient /* synthetic */ String VLkeNPrneV = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public static Credentials of(String str, String str2) {
        return new Credentials(str, str2);
    }

    @ConstructorParameters({"username", "password"})
    public Credentials(String str, String str2) {
        this.username = str;
        this.password = str2;
    }

    public String getUsername() {
        return this.username;
    }

    public String getPassword() {
        return this.password;
    }
}
