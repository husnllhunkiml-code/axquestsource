package com.artillexstudios.axquestboard.libs.axapi.config.adapters.collections;

import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapterHolder;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/adapters/collections/MapAdapter.class */
public final class MapAdapter implements TypeAdapter<Map<String, Object>, Map<String, Object>> {
    private static transient /* synthetic */ String WrZMfVUzJn = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public Map<String, Object> deserialize(TypeAdapterHolder holder, Object input, Type type) {
        Type type2 = null;
        if (type instanceof ParameterizedType) {
            type2 = ((ParameterizedType) type).getActualTypeArguments()[1];
        }
        if (input instanceof Map) {
            HashMap map = new HashMap();
            for (Map.Entry entry : ((Map) input).entrySet()) {
                map.put((String) entry.getKey(), holder.deserialize(entry.getValue(), type2));
            }
            return map;
        }
        throw new RuntimeException();
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public Map<String, Object> serialize(TypeAdapterHolder holder, Map<String, Object> value, Type type) {
        HashMap map = new HashMap();
        Type type2 = null;
        boolean z = false;
        if (type instanceof ParameterizedType) {
            type2 = ((ParameterizedType) type).getActualTypeArguments()[1];
            z = true;
        }
        for (Map.Entry<String, Object> entry : value.entrySet()) {
            if (!z) {
                type2 = entry.getValue().getClass();
            }
            map.put(entry.getKey(), holder.serialize(entry.getValue(), type2));
        }
        return map;
    }
}
