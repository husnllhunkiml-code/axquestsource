package com.artillexstudios.axquestboard.libs.axapi.hologram.page;

import com.artillexstudios.axquestboard.libs.axapi.hologram.Hologram;
import com.artillexstudios.axquestboard.libs.axapi.hologram.HologramType;
import com.artillexstudios.axquestboard.libs.axapi.hologram.HologramTypes;
import com.artillexstudios.axquestboard.libs.axapi.hologram.Holograms;
import com.artillexstudios.axquestboard.libs.axapi.nms.NMSHandlers;
import com.artillexstudios.axquestboard.libs.axapi.packetentity.PacketEntity;
import com.artillexstudios.axquestboard.libs.axapi.packetentity.meta.EntityMeta;
import com.artillexstudios.axquestboard.libs.axapi.packetentity.meta.entity.TextDisplayMeta;
import com.artillexstudios.axquestboard.libs.axapi.utils.ComponentSerializer;
import com.artillexstudios.axquestboard.libs.axapi.utils.StringUtils;
import com.artillexstudios.axquestboard.libs.axapi.utils.featureflags.FeatureFlags;
import java.util.Iterator;
import java.util.regex.Pattern;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Location;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/hologram/page/TextDisplayHologramPage.class */
public class TextDisplayHologramPage extends HologramPage<String, HologramType<String>> {
    private static final Pattern NEW_LINE = Pattern.compile("\n");
    private final PacketEntity textDisplay;
    private boolean containsPlaceholders;
    private String content;
    private boolean spawned;
    private LineData[] data;
    private static transient /* synthetic */ String jIfdThBQJx = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public TextDisplayHologramPage(Hologram hologram, boolean firstPage, Location location) {
        super(hologram, firstPage, location);
        this.spawned = false;
        this.textDisplay = NMSHandlers.getNmsHandler().createEntity(EntityType.TEXT_DISPLAY, getLocation());
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.hologram.page.HologramPage
    public void setContent(String content) {
        this.content = content;
        this.containsPlaceholders = false;
        String[] strArrSplit = NEW_LINE.split(content);
        this.data = new LineData[strArrSplit.length];
        int i = 0;
        while (i < strArrSplit.length) {
            String str = strArrSplit[i];
            boolean z = false;
            Component componentNewline = StringUtils.format(str + (i == strArrSplit.length - 1 ? "" : "\n"), new TagResolver[0]);
            String strM573serialize = PlainTextComponentSerializer.plainText().m573serialize(componentNewline);
            Iterator it = FeatureFlags.PLACEHOLDER_PATTERNS.get().iterator();
            while (it.hasNext()) {
                if (((Pattern) it.next()).matcher(strM573serialize).find()) {
                    z = true;
                    this.containsPlaceholders = true;
                    break;
                }
            }
            if (strM573serialize.isBlank()) {
                componentNewline = Component.newline();
            }
            this.data[i] = new LineData(str, ComponentSerializer.INSTANCE.toVanilla(z ? Component.empty() : componentNewline), z);
            i++;
        }
        create();
    }

    private void create() {
        TextDisplayMeta textDisplayMeta = (TextDisplayMeta) this.textDisplay.meta();
        textDisplayMeta.component(StringUtils.format(this.content, new TagResolver[0]));
        if (getEntityMetaHandler() != null) {
            getEntityMetaHandler().accept(textDisplayMeta);
        }
        if (!isFirstPage()) {
            this.textDisplay.setVisibleByDefault(false);
        }
        this.textDisplay.onInteract(packetEntityInteractEvent -> {
            if (getClickHandler() != null) {
                getClickHandler().accept(packetEntityInteractEvent);
            }
            getHologram().changePage(packetEntityInteractEvent.getPlayer(), packetEntityInteractEvent.isAttack() ? Hologram.PageChangeDirection.BACK : Hologram.PageChangeDirection.FORWARD);
        });
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.artillexstudios.axquestboard.libs.axapi.hologram.page.HologramPage
    public String getContent() {
        return this.content;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.hologram.page.HologramPage
    public HologramType<String> getType() {
        return HologramTypes.TEXT;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.hologram.page.HologramPage
    public boolean containsPlaceholders() {
        return this.containsPlaceholders;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.hologram.page.HologramPage
    public boolean contentEquals(HologramPage<?, ?> other) {
        if (!(other instanceof TextDisplayHologramPage)) {
            return false;
        }
        return ((TextDisplayHologramPage) other).getContent().equals(getContent());
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.hologram.page.HologramPage
    public void hide(Player player) {
        this.textDisplay.hide(player);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.hologram.page.HologramPage
    public void show(Player player) {
        this.textDisplay.show(player);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.hologram.page.HologramPage
    public void teleport(Location location) {
        setLocation(location);
        if (this.textDisplay == null) {
            return;
        }
        this.textDisplay.teleport(location);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.hologram.page.HologramPage
    public void remove() {
        if (this.textDisplay == null) {
            return;
        }
        this.spawned = false;
        Holograms.remove(this.textDisplay.id());
        this.textDisplay.remove();
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.hologram.page.HologramPage
    public void update() {
        if (this.textDisplay == null) {
            return;
        }
        this.textDisplay.update();
    }

    public LineData[] getData() {
        return this.data;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.hologram.page.HologramPage
    public EntityMeta getEntityMeta() {
        return this.textDisplay.meta();
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.hologram.page.HologramPage
    public synchronized boolean spawn() {
        if (this.spawned) {
            return false;
        }
        Holograms.put(this.textDisplay.id(), this);
        this.textDisplay.spawn();
        this.spawned = true;
        return true;
    }
}
