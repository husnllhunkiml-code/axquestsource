package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.nodes;

import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.DumperOptions;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.error.Mark;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/nodes/SequenceNode.class */
public class SequenceNode extends CollectionNode<Node> {
    private final List<Node> value;
    private static transient /* synthetic */ String jBnYqTEpZf = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public SequenceNode(Tag tag, boolean z, List<Node> list, Mark mark, Mark mark2, DumperOptions.FlowStyle flowStyle) {
        super(tag, mark, mark2, flowStyle);
        if (list == null) {
            throw new NullPointerException("value in a Node is required.");
        }
        this.value = list;
        this.resolved = z;
    }

    public SequenceNode(Tag tag, List<Node> list, DumperOptions.FlowStyle flowStyle) {
        this(tag, true, list, null, null, flowStyle);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.nodes.Node
    public NodeId getNodeId() {
        return NodeId.sequence;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.nodes.CollectionNode
    public List<Node> getValue() {
        return this.value;
    }

    public void setListType(Class<? extends Object> cls) {
        Iterator<Node> it = this.value.iterator();
        while (it.hasNext()) {
            it.next().setType(cls);
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Node node : getValue()) {
            if (node instanceof CollectionNode) {
                sb.append(System.identityHashCode(node));
            } else {
                sb.append(node.toString());
            }
            sb.append(",");
        }
        if (sb.length() > 0) {
            sb.deleteCharAt(sb.length() - 1);
        }
        return "<" + getClass().getName() + " (tag=" + getTag() + ", value=[" + ((Object) sb) + "])>";
    }
}
