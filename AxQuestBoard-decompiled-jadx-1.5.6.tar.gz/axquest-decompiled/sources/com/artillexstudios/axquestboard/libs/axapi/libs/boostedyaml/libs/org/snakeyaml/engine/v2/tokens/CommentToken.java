package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.comments.CommentType;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.Mark;
import java.util.Objects;
import java.util.Optional;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/tokens/CommentToken.class */
public final class CommentToken extends Token {
    private final CommentType type;
    private final String value;
    private static transient /* synthetic */ String VymzAfsnKT = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public CommentToken(CommentType commentType, String str, Optional<Mark> optional, Optional<Mark> optional2) {
        super(optional, optional2);
        Objects.requireNonNull(commentType);
        this.type = commentType;
        Objects.requireNonNull(str);
        this.value = str;
    }

    public CommentType getCommentType() {
        return this.type;
    }

    public String getValue() {
        return this.value;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.Token
    public Token.ID getTokenId() {
        return Token.ID.Comment;
    }
}
