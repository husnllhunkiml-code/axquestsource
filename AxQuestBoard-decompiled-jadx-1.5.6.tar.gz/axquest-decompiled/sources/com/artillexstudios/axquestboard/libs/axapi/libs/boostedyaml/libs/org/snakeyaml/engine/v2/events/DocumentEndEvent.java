package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.Mark;
import java.util.Optional;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/events/DocumentEndEvent.class */
public final class DocumentEndEvent extends Event {
    private final boolean explicit;
    private static transient /* synthetic */ String gtiTwKYYnM = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public DocumentEndEvent(boolean z, Optional<Mark> optional, Optional<Mark> optional2) {
        super(optional, optional2);
        this.explicit = z;
    }

    public DocumentEndEvent(boolean z) {
        this(z, Optional.empty(), Optional.empty());
    }

    public boolean isExplicit() {
        return this.explicit;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.Event
    public Event.ID getEventId() {
        return Event.ID.DocumentEnd;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("-DOC");
        if (isExplicit()) {
            sb.append(" ...");
        }
        return sb.toString();
    }
}
