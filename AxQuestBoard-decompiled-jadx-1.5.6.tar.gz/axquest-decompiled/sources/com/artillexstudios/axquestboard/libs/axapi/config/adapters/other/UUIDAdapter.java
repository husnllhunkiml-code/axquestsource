package com.artillexstudios.axquestboard.libs.axapi.config.adapters.other;

import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapterHolder;
import java.lang.reflect.Type;
import java.util.UUID;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/adapters/other/UUIDAdapter.class */
public final class UUIDAdapter implements TypeAdapter<UUID, String> {
    private static transient /* synthetic */ String BdWWosUwMo = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public UUID deserialize(TypeAdapterHolder holder, Object input, Type type) {
        if (input instanceof String) {
            return UUID.fromString((String) input);
        }
        if (input instanceof UUID) {
            return (UUID) input;
        }
        throw new IllegalArgumentException("Can't convert %s into a UUID!".formatted(input.getClass()));
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public String serialize(TypeAdapterHolder holder, UUID value, Type type) {
        return value.toString();
    }
}
