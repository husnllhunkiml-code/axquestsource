package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.tokens;

import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.error.Mark;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/tokens/DocumentStartToken.class */
public final class DocumentStartToken extends Token {
    private static transient /* synthetic */ String OQnnRExcHu = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public DocumentStartToken(Mark mark, Mark mark2) {
        super(mark, mark2);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.tokens.Token
    public Token.ID getTokenId() {
        return Token.ID.DocumentStart;
    }
}
