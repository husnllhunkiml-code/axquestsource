package com.artillexstudios.axquestboard.libs.axapi.config.renamer;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/renamer/LowerKebabCaseRenamer.class */
public final class LowerKebabCaseRenamer implements KeyRenamer {
    private static transient /* synthetic */ String ObrsdOBsFO = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    @Override // com.artillexstudios.axquestboard.libs.axapi.config.renamer.KeyRenamer
    public String rename(String fieldName) {
        StringBuilder sb = new StringBuilder(fieldName.length());
        for (int i = 0; i < fieldName.length(); i++) {
            char cCharAt = fieldName.charAt(i);
            if (Character.isUpperCase(cCharAt)) {
                if (i != 0) {
                    sb.append('-');
                }
                sb.append(Character.toLowerCase(cCharAt));
            } else {
                sb.append(cCharAt);
            }
        }
        return sb.toString();
    }
}
