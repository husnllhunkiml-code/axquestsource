package com.artillexstudios.axquestboard.libs.axapi.gui;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryType;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/gui/AnvilListener.class */
public final class AnvilListener implements Listener {
    private static transient /* synthetic */ String nIGvBgzUdd = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    @EventHandler
    public void onInventoryClickEvent(InventoryClickEvent event) {
        AnvilInput anvilInput;
        Player whoClicked = event.getWhoClicked();
        if (event.getInventory().getType() != InventoryType.ANVIL || (anvilInput = AnvilInput.get(whoClicked)) == null) {
            return;
        }
        anvilInput.event().accept(event);
    }

    @EventHandler
    public void onInventoryCloseEvent(InventoryCloseEvent event) {
        AnvilInput anvilInputRemove;
        Player player = event.getPlayer();
        if (event.getInventory().getType() != InventoryType.ANVIL || (anvilInputRemove = AnvilInput.remove(player)) == null) {
            return;
        }
        anvilInputRemove.closeEvent().accept(event);
    }
}
