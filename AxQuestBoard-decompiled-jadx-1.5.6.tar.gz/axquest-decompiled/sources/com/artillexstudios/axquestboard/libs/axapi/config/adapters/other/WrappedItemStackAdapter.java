package com.artillexstudios.axquestboard.libs.axapi.config.adapters.other;

import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapterHolder;
import com.artillexstudios.axquestboard.libs.axapi.items.WrappedItemStack;
import com.artillexstudios.axquestboard.libs.axapi.utils.ItemBuilder;
import com.artillexstudios.axquestboard.libs.axapi.utils.UncheckedUtils;
import java.lang.reflect.Type;
import java.util.Map;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/adapters/other/WrappedItemStackAdapter.class */
public final class WrappedItemStackAdapter implements TypeAdapter<WrappedItemStack, Map<String, Object>> {
    private static transient /* synthetic */ String ktkBqeUHyY = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public WrappedItemStack deserialize(TypeAdapterHolder holder, Object input, Type type) {
        if (input instanceof Map) {
            return ItemBuilder.create((Map) UncheckedUtils.unsafeCast((Map) input)).wrapped();
        }
        throw new IllegalArgumentException();
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public Map<String, Object> serialize(TypeAdapterHolder holder, WrappedItemStack value, Type type) {
        return (Map) UncheckedUtils.unsafeCast(ItemBuilder.create(value).serialize(true));
    }
}
