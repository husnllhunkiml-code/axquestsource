package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.util;

import java.util.AbstractList;
import java.util.Collections;
import java.util.List;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/util/ArrayUtils.class */
public class ArrayUtils {
    private static transient /* synthetic */ String lBuHktoiQv = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    private ArrayUtils() {
    }

    public static <E> List<E> toUnmodifiableList(E[] eArr) {
        return eArr.length == 0 ? Collections.emptyList() : new UnmodifiableArrayList(eArr);
    }

    public static <E> List<E> toUnmodifiableCompositeList(E[] eArr, E[] eArr2) {
        List<E> compositeUnmodifiableArrayList;
        if (eArr.length == 0) {
            compositeUnmodifiableArrayList = toUnmodifiableList(eArr2);
        } else if (eArr2.length == 0) {
            compositeUnmodifiableArrayList = toUnmodifiableList(eArr);
        } else {
            compositeUnmodifiableArrayList = new CompositeUnmodifiableArrayList(eArr, eArr2);
        }
        return compositeUnmodifiableArrayList;
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/util/ArrayUtils$UnmodifiableArrayList.class */
    private static class UnmodifiableArrayList<E> extends AbstractList<E> {
        private final E[] array;
        private static transient /* synthetic */ String hpryFpYhXN = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        UnmodifiableArrayList(E[] eArr) {
            this.array = eArr;
        }

        @Override // java.util.AbstractList, java.util.List
        public E get(int i) {
            if (i >= this.array.length) {
                throw new IndexOutOfBoundsException("Index: " + i + ", Size: " + size());
            }
            return this.array[i];
        }

        @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
        public int size() {
            return this.array.length;
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/util/ArrayUtils$CompositeUnmodifiableArrayList.class */
    private static class CompositeUnmodifiableArrayList<E> extends AbstractList<E> {
        private final E[] array1;
        private final E[] array2;
        private static transient /* synthetic */ String lqsJNadPzX = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        CompositeUnmodifiableArrayList(E[] eArr, E[] eArr2) {
            this.array1 = eArr;
            this.array2 = eArr2;
        }

        @Override // java.util.AbstractList, java.util.List
        public E get(int i) {
            E e;
            if (i < this.array1.length) {
                e = this.array1[i];
            } else if (i - this.array1.length < this.array2.length) {
                e = this.array2[i - this.array1.length];
            } else {
                throw new IndexOutOfBoundsException("Index: " + i + ", Size: " + size());
            }
            return e;
        }

        @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
        public int size() {
            return this.array1.length + this.array2.length;
        }
    }
}
