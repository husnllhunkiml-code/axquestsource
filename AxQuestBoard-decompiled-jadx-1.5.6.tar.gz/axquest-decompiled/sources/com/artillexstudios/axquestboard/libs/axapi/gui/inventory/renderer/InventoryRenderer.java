package com.artillexstudios.axquestboard.libs.axapi.gui.inventory.renderer;

import com.artillexstudios.axquestboard.libs.axapi.context.HashMapContext;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.BakedGuiItem;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.Gui;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.GuiKeys;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.renderer.strategy.RenderStrategy;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.renderer.strategy.StreamingRenderStrategy;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.renderer.strategy.WaitingRenderStrategy;
import com.artillexstudios.axquestboard.libs.axapi.nms.NMSHandlers;
import com.artillexstudios.axquestboard.libs.axapi.utils.StringUtils;
import com.artillexstudios.axquestboard.libs.axapi.utils.featureflags.FeatureFlags;
import com.artillexstudios.axquestboard.libs.axapi.utils.logging.LogUtils;
import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectMaps;
import java.util.concurrent.Semaphore;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.Blocking;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/gui/inventory/renderer/InventoryRenderer.class */
public class InventoryRenderer implements InventoryHolder {
    private final Player player;
    private long lastClick;
    private Inventory inventory;
    private Gui currentGui;
    private static transient /* synthetic */ String YklpSSqpeN = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";
    private final Semaphore renderLock = new Semaphore(1, true);
    private final Int2ObjectMap<BakedGuiItem> items = Int2ObjectMaps.synchronize(new Int2ObjectArrayMap());
    private boolean closed = true;

    public InventoryRenderer(Player player) {
        this.player = player;
    }

    public void queue(Gui gui) {
        if (FeatureFlags.DEBUG.get().booleanValue()) {
            LogUtils.debug("Enqueued!");
        }
        Thread.ofVirtual().start(() -> {
            if (FeatureFlags.DEBUG.get().booleanValue()) {
                LogUtils.debug("Running from thread!");
            }
            render(gui);
        });
    }

    @Blocking
    public void render(Gui gui) {
        if (this.currentGui == gui && !this.renderLock.tryAcquire()) {
            return;
        }
        if (this.currentGui != gui) {
            this.renderLock.acquireUninterruptibly();
        }
        HashMapContext hashMapContextCreateContext = createContext(gui);
        boolean zBuildInventory = buildInventory(gui, hashMapContextCreateContext);
        this.currentGui = gui;
        getStrategy().render(gui, hashMapContextCreateContext, zBuildInventory, this.items, this.inventory, this.renderLock);
    }

    private RenderStrategy getStrategy() {
        return FeatureFlags.GUI_WAIT_FOR_ALL.get().booleanValue() ? new WaitingRenderStrategy() : new StreamingRenderStrategy();
    }

    private HashMapContext createContext(Gui gui) {
        return new HashMapContext().with(GuiKeys.PLAYER, this.player).with(GuiKeys.GUI, gui).merge(gui.getContext());
    }

    public void onTitleUpdate(HashMapContext context) {
        NMSHandlers.getNmsHandler().setTitle(this.inventory, this.currentGui.provideTitle(context));
    }

    public boolean buildInventory(Gui gui, HashMapContext context) {
        if (this.currentGui == null || this.currentGui.getType() != gui.getType() || this.currentGui.getRows() != gui.getRows()) {
            recreateGui(gui, context);
            return true;
        }
        return false;
    }

    private void recreateGui(Gui gui, HashMapContext context) {
        if (gui.getType() == InventoryType.CHEST) {
            this.inventory = Bukkit.createInventory(this, gui.getRows() * 9, StringUtils.formatToString((String) MiniMessage.miniMessage().serialize(gui.provideTitle(context)), new TagResolver[0]));
        } else {
            this.inventory = Bukkit.createInventory(this, gui.getType(), StringUtils.formatToString((String) MiniMessage.miniMessage().serialize(gui.provideTitle(context)), new TagResolver[0]));
        }
    }

    public void handleClick(InventoryClickEvent event) {
        if (this.currentGui.isDisableAllInteractions()) {
            event.setCancelled(true);
        }
        long jCurrentTimeMillis = System.currentTimeMillis();
        if (jCurrentTimeMillis - this.lastClick < FeatureFlags.INVENTORY_CLICK_COOLDOWN.get().intValue()) {
            return;
        }
        this.lastClick = jCurrentTimeMillis;
        if (event.getClickedInventory() != null && event.getClickedInventory().getType() != InventoryType.PLAYER) {
            ((BakedGuiItem) this.items.get(event.getRawSlot())).eventConsumer().accept(event);
        } else {
            this.currentGui.getPlayerInventoryClickListener().accept(event);
        }
    }

    public Gui getCurrentGui() {
        return this.currentGui;
    }

    public boolean isClosed() {
        return this.closed;
    }

    public void setClosed(boolean closed) {
        this.closed = closed;
    }

    public void handleDrag(InventoryDragEvent event) {
        if (this.currentGui.isDisableAllInteractions()) {
            event.setCancelled(true);
        }
    }

    public void handleClose(InventoryCloseEvent event) {
        this.closed = true;
        this.currentGui.getInventoryCloseListener().accept(event);
    }

    public void handleOpen(InventoryOpenEvent event) {
        this.currentGui.getInventoryOpenListener().accept(event);
    }

    public Player getPlayer() {
        return this.player;
    }

    @NotNull
    public Inventory getInventory() {
        return this.inventory;
    }
}
