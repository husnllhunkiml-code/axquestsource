package com.artillexstudios.axquestboard.libs.axapi.config.adapters.other;

import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapterHolder;
import com.artillexstudios.axquestboard.libs.axapi.utils.UncheckedUtils;
import java.lang.reflect.Type;
import java.util.Arrays;
import java.util.List;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/adapters/other/EnumAdapter.class */
public final class EnumAdapter implements TypeAdapter<Enum<?>, String> {
    private static transient /* synthetic */ String wuZgwVMows = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public Enum<?> deserialize(TypeAdapterHolder holder, Object input, Type type) {
        if (input instanceof Enum) {
            return (Enum) input;
        }
        if (input instanceof String) {
            String str = (String) input;
            if (type instanceof Class) {
                Class cls = (Class) type;
                if (Enum.class.isAssignableFrom(cls)) {
                    Class cls2 = (Class) UncheckedUtils.unsafeCast(cls);
                    for (Enum<?> r0 : (Enum[]) cls2.getEnumConstants()) {
                        if (r0.name().equalsIgnoreCase(str)) {
                            return r0;
                        }
                    }
                    throw new IllegalArgumentException("No enum constant with the name " + str + " was found! Possible constants: " + Arrays.toString(Arrays.stream((Enum[]) cls2.getEnumConstants()).map((v0) -> {
                        return v0.name();
                    }).toArray()));
                }
            }
        }
        throw new IllegalArgumentException();
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public String serialize(TypeAdapterHolder holder, Enum<?> value, Type type) {
        return value.name();
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public List<String> values(Type type) {
        if (!(type instanceof Class)) {
            return List.of();
        }
        return Arrays.stream(((Class) type).getDeclaringClass().getEnumConstants()).map(obj -> {
            return ((Enum) obj).name();
        }).toList();
    }
}
