package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.YamlEngineException;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Node;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/api/ConstructNode.class */
public interface ConstructNode {
    Object construct(Node node);

    default void constructRecursive(Node node, Object object) {
        if (node.isRecursive()) {
            throw new IllegalStateException("Not implemented in " + getClass().getName());
        }
        throw new YamlEngineException("Unexpected recursive structure for Node: " + node);
    }
}
