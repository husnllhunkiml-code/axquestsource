package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.representer;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.DumpSettings;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.RepresentToNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.FlowStyle;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.NonPrintableStyle;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.ScalarStyle;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.YamlEngineException;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Node;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Tag;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.scanner.StreamReader;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Pattern;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/representer/StandardRepresenter.class */
public class StandardRepresenter extends BaseRepresenter {
    public static final Pattern MULTILINE_PATTERN = Pattern.compile("\n|\u0085");
    protected Map<Class<? extends Object>, Tag> classTags;
    protected DumpSettings settings;
    private static transient /* synthetic */ String uAvIGmXTkV = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public StandardRepresenter(DumpSettings dumpSettings) {
        this.defaultFlowStyle = dumpSettings.getDefaultFlowStyle();
        this.defaultScalarStyle = dumpSettings.getDefaultScalarStyle();
        this.nullRepresenter = new RepresentNull();
        this.representers.put(String.class, new RepresentString());
        this.representers.put(Boolean.class, new RepresentBoolean());
        this.representers.put(Character.class, new RepresentString());
        this.representers.put(UUID.class, new RepresentUuid());
        this.representers.put(Optional.class, new RepresentOptional());
        this.representers.put(byte[].class, new RepresentByteArray());
        RepresentPrimitiveArray representPrimitiveArray = new RepresentPrimitiveArray();
        this.representers.put(short[].class, representPrimitiveArray);
        this.representers.put(int[].class, representPrimitiveArray);
        this.representers.put(long[].class, representPrimitiveArray);
        this.representers.put(float[].class, representPrimitiveArray);
        this.representers.put(double[].class, representPrimitiveArray);
        this.representers.put(char[].class, representPrimitiveArray);
        this.representers.put(boolean[].class, representPrimitiveArray);
        this.parentClassRepresenters.put(Number.class, new RepresentNumber());
        this.parentClassRepresenters.put(List.class, new RepresentList());
        this.parentClassRepresenters.put(Map.class, new RepresentMap());
        this.parentClassRepresenters.put(Set.class, new RepresentSet());
        this.parentClassRepresenters.put(Iterator.class, new RepresentIterator());
        this.parentClassRepresenters.put(new Object[0].getClass(), new RepresentArray());
        this.parentClassRepresenters.put(Enum.class, new RepresentEnum());
        this.classTags = new HashMap();
        this.settings = dumpSettings;
    }

    protected Tag getTag(Class<?> cls, Tag tag) {
        return this.classTags.getOrDefault(cls, tag);
    }

    @Deprecated
    public Tag addClassTag(Class<? extends Object> cls, Tag tag) {
        if (tag == null) {
            throw new NullPointerException("Tag must be provided.");
        }
        return this.classTags.put(cls, tag);
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/representer/StandardRepresenter$IteratorWrapper.class */
    private static class IteratorWrapper implements Iterable<Object> {
        private final Iterator<Object> iter;
        private static transient /* synthetic */ String SwnwzaykiJ = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        public IteratorWrapper(Iterator<Object> it) {
            this.iter = it;
        }

        @Override // java.lang.Iterable
        public Iterator<Object> iterator() {
            return this.iter;
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/representer/StandardRepresenter$RepresentNull.class */
    protected class RepresentNull implements RepresentToNode {
        private static transient /* synthetic */ String vZtZzKRajg = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        protected RepresentNull() {
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.RepresentToNode
        public Node representData(Object obj) {
            return StandardRepresenter.this.representScalar(Tag.NULL, "null");
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/representer/StandardRepresenter$RepresentString.class */
    public class RepresentString implements RepresentToNode {
        private static transient /* synthetic */ String ObEtvxHYvC = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        public RepresentString() {
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.RepresentToNode
        public Node representData(Object obj) {
            Tag tag = Tag.STR;
            ScalarStyle scalarStyle = ScalarStyle.PLAIN;
            String string = obj.toString();
            if (StandardRepresenter.this.settings.getNonPrintableStyle() == NonPrintableStyle.BINARY && !StreamReader.isPrintable(string)) {
                tag = Tag.BINARY;
                byte[] bytes = string.getBytes(StandardCharsets.UTF_8);
                if (!new String(bytes, StandardCharsets.UTF_8).equals(string)) {
                    throw new YamlEngineException("invalid string value has occurred");
                }
                string = Base64.getEncoder().encodeToString(bytes);
                scalarStyle = ScalarStyle.LITERAL;
            }
            if (StandardRepresenter.this.defaultScalarStyle == ScalarStyle.PLAIN && StandardRepresenter.MULTILINE_PATTERN.matcher(string).find()) {
                scalarStyle = ScalarStyle.LITERAL;
            }
            return StandardRepresenter.this.representScalar(tag, string, scalarStyle);
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/representer/StandardRepresenter$RepresentBoolean.class */
    public class RepresentBoolean implements RepresentToNode {
        private static transient /* synthetic */ String wRuBxBdPDO = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        public RepresentBoolean() {
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.RepresentToNode
        public Node representData(Object obj) {
            String str;
            if (Boolean.TRUE.equals(obj)) {
                str = "true";
            } else {
                str = "false";
            }
            return StandardRepresenter.this.representScalar(Tag.BOOL, str);
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/representer/StandardRepresenter$RepresentNumber.class */
    public class RepresentNumber implements RepresentToNode {
        private static transient /* synthetic */ String CXvASFTArR = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        public RepresentNumber() {
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.RepresentToNode
        public Node representData(Object obj) {
            Tag tag;
            String string;
            if ((obj instanceof Byte) || (obj instanceof Short) || (obj instanceof Integer) || (obj instanceof Long) || (obj instanceof BigInteger)) {
                tag = Tag.INT;
                string = obj.toString();
            } else {
                Number number = (Number) obj;
                tag = Tag.FLOAT;
                if (number.equals(Double.valueOf(Double.NaN)) || number.equals(Float.valueOf(Float.NaN))) {
                    string = ".nan";
                } else if (number.equals(Double.valueOf(Double.POSITIVE_INFINITY)) || number.equals(Float.valueOf(Float.POSITIVE_INFINITY))) {
                    string = ".inf";
                } else if (number.equals(Double.valueOf(Double.NEGATIVE_INFINITY)) || number.equals(Float.valueOf(Float.NEGATIVE_INFINITY))) {
                    string = "-.inf";
                } else {
                    string = number.toString();
                }
            }
            return StandardRepresenter.this.representScalar(StandardRepresenter.this.getTag(obj.getClass(), tag), string);
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/representer/StandardRepresenter$RepresentList.class */
    public class RepresentList implements RepresentToNode {
        private static transient /* synthetic */ String HGiFtZLflA = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        public RepresentList() {
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.RepresentToNode
        public Node representData(Object obj) {
            return StandardRepresenter.this.representSequence(StandardRepresenter.this.getTag(obj.getClass(), Tag.SEQ), (List) obj, StandardRepresenter.this.settings.getDefaultFlowStyle());
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/representer/StandardRepresenter$RepresentIterator.class */
    public class RepresentIterator implements RepresentToNode {
        private static transient /* synthetic */ String xMomMVDZPh = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        public RepresentIterator() {
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.RepresentToNode
        public Node representData(Object obj) {
            return StandardRepresenter.this.representSequence(StandardRepresenter.this.getTag(obj.getClass(), Tag.SEQ), new IteratorWrapper((Iterator) obj), StandardRepresenter.this.settings.getDefaultFlowStyle());
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/representer/StandardRepresenter$RepresentArray.class */
    public class RepresentArray implements RepresentToNode {
        private static transient /* synthetic */ String LNlHJADAhd = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        public RepresentArray() {
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.RepresentToNode
        public Node representData(Object obj) {
            return StandardRepresenter.this.representSequence(Tag.SEQ, Arrays.asList((Object[]) obj), StandardRepresenter.this.settings.getDefaultFlowStyle());
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/representer/StandardRepresenter$RepresentPrimitiveArray.class */
    public class RepresentPrimitiveArray implements RepresentToNode {
        private static transient /* synthetic */ String aFeDdzpJFK = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        public RepresentPrimitiveArray() {
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.RepresentToNode
        public Node representData(Object obj) {
            Class<?> componentType = obj.getClass().getComponentType();
            FlowStyle defaultFlowStyle = StandardRepresenter.this.settings.getDefaultFlowStyle();
            if (Byte.TYPE == componentType) {
                return StandardRepresenter.this.representSequence(Tag.SEQ, asByteList(obj), defaultFlowStyle);
            }
            if (Short.TYPE == componentType) {
                return StandardRepresenter.this.representSequence(Tag.SEQ, asShortList(obj), defaultFlowStyle);
            }
            if (Integer.TYPE == componentType) {
                return StandardRepresenter.this.representSequence(Tag.SEQ, asIntList(obj), defaultFlowStyle);
            }
            if (Long.TYPE == componentType) {
                return StandardRepresenter.this.representSequence(Tag.SEQ, asLongList(obj), defaultFlowStyle);
            }
            if (Float.TYPE == componentType) {
                return StandardRepresenter.this.representSequence(Tag.SEQ, asFloatList(obj), defaultFlowStyle);
            }
            if (Double.TYPE == componentType) {
                return StandardRepresenter.this.representSequence(Tag.SEQ, asDoubleList(obj), defaultFlowStyle);
            }
            if (Character.TYPE == componentType) {
                return StandardRepresenter.this.representSequence(Tag.SEQ, asCharList(obj), defaultFlowStyle);
            }
            if (Boolean.TYPE == componentType) {
                return StandardRepresenter.this.representSequence(Tag.SEQ, asBooleanList(obj), defaultFlowStyle);
            }
            throw new YamlEngineException("Unexpected primitive '" + componentType.getCanonicalName() + "'");
        }

        private List<Byte> asByteList(Object obj) {
            byte[] bArr = (byte[]) obj;
            ArrayList arrayList = new ArrayList(bArr.length);
            for (byte b : bArr) {
                arrayList.add(Byte.valueOf(b));
            }
            return arrayList;
        }

        private List<Short> asShortList(Object obj) {
            short[] sArr = (short[]) obj;
            ArrayList arrayList = new ArrayList(sArr.length);
            for (short s : sArr) {
                arrayList.add(Short.valueOf(s));
            }
            return arrayList;
        }

        private List<Integer> asIntList(Object obj) {
            int[] iArr = (int[]) obj;
            ArrayList arrayList = new ArrayList(iArr.length);
            for (int i : iArr) {
                arrayList.add(Integer.valueOf(i));
            }
            return arrayList;
        }

        private List<Long> asLongList(Object obj) {
            long[] jArr = (long[]) obj;
            ArrayList arrayList = new ArrayList(jArr.length);
            for (long j : jArr) {
                arrayList.add(Long.valueOf(j));
            }
            return arrayList;
        }

        private List<Float> asFloatList(Object obj) {
            float[] fArr = (float[]) obj;
            ArrayList arrayList = new ArrayList(fArr.length);
            for (float f : fArr) {
                arrayList.add(Float.valueOf(f));
            }
            return arrayList;
        }

        private List<Double> asDoubleList(Object obj) {
            double[] dArr = (double[]) obj;
            ArrayList arrayList = new ArrayList(dArr.length);
            for (double d : dArr) {
                arrayList.add(Double.valueOf(d));
            }
            return arrayList;
        }

        private List<Character> asCharList(Object obj) {
            char[] cArr = (char[]) obj;
            ArrayList arrayList = new ArrayList(cArr.length);
            for (char c : cArr) {
                arrayList.add(Character.valueOf(c));
            }
            return arrayList;
        }

        private List<Boolean> asBooleanList(Object obj) {
            boolean[] zArr = (boolean[]) obj;
            ArrayList arrayList = new ArrayList(zArr.length);
            for (boolean z : zArr) {
                arrayList.add(Boolean.valueOf(z));
            }
            return arrayList;
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/representer/StandardRepresenter$RepresentMap.class */
    public class RepresentMap implements RepresentToNode {
        private static transient /* synthetic */ String PWnsOyBJNQ = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        public RepresentMap() {
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.RepresentToNode
        public Node representData(Object obj) {
            return StandardRepresenter.this.representMapping(StandardRepresenter.this.getTag(obj.getClass(), Tag.MAP), (Map) obj, StandardRepresenter.this.settings.getDefaultFlowStyle());
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/representer/StandardRepresenter$RepresentSet.class */
    public class RepresentSet implements RepresentToNode {
        private static transient /* synthetic */ String aYSLtOYQbK = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        public RepresentSet() {
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.RepresentToNode
        public Node representData(Object obj) {
            LinkedHashMap linkedHashMap = new LinkedHashMap();
            Iterator it = ((Set) obj).iterator();
            while (it.hasNext()) {
                linkedHashMap.put(it.next(), null);
            }
            return StandardRepresenter.this.representMapping(StandardRepresenter.this.getTag(obj.getClass(), Tag.SET), linkedHashMap, StandardRepresenter.this.settings.getDefaultFlowStyle());
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/representer/StandardRepresenter$RepresentEnum.class */
    public class RepresentEnum implements RepresentToNode {
        private static transient /* synthetic */ String mbYAcBOxHQ = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        public RepresentEnum() {
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.RepresentToNode
        public Node representData(Object obj) {
            return StandardRepresenter.this.representScalar(StandardRepresenter.this.getTag(obj.getClass(), new Tag((Class<? extends Object>) obj.getClass())), ((Enum) obj).name());
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/representer/StandardRepresenter$RepresentByteArray.class */
    public class RepresentByteArray implements RepresentToNode {
        private static transient /* synthetic */ String vWFAfALExk = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        public RepresentByteArray() {
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.RepresentToNode
        public Node representData(Object obj) {
            return StandardRepresenter.this.representScalar(Tag.BINARY, Base64.getEncoder().encodeToString((byte[]) obj), ScalarStyle.LITERAL);
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/representer/StandardRepresenter$RepresentUuid.class */
    public class RepresentUuid implements RepresentToNode {
        private static transient /* synthetic */ String akmXXzMCyh = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        public RepresentUuid() {
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.RepresentToNode
        public Node representData(Object obj) {
            return StandardRepresenter.this.representScalar(StandardRepresenter.this.getTag(obj.getClass(), new Tag((Class<? extends Object>) UUID.class)), obj.toString());
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/representer/StandardRepresenter$RepresentOptional.class */
    public class RepresentOptional implements RepresentToNode {
        private static transient /* synthetic */ String ipjWejPmSL = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        public RepresentOptional() {
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.RepresentToNode
        public Node representData(Object obj) {
            Optional optional = (Optional) obj;
            if (optional.isPresent()) {
                Node nodeRepresent = StandardRepresenter.this.represent(optional.get());
                nodeRepresent.setTag(new Tag((Class<? extends Object>) Optional.class));
                return nodeRepresent;
            }
            return StandardRepresenter.this.representScalar(Tag.NULL, "null");
        }
    }
}
