package com.artillexstudios.axquestboard.libs.axapi.config.adapters.other;

import com.artillexstudios.axquestboard.libs.axapi.config.YamlConfiguration;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapterHolder;
import com.artillexstudios.axquestboard.libs.axapi.config.annotation.ConfigurationPart;
import com.artillexstudios.axquestboard.libs.axapi.config.annotation.Hidden;
import com.artillexstudios.axquestboard.libs.axapi.config.annotation.Ignored;
import com.artillexstudios.axquestboard.libs.axapi.config.annotation.PostProcess;
import com.artillexstudios.axquestboard.libs.axapi.config.annotation.Serializable;
import com.artillexstudios.axquestboard.libs.axapi.utils.UncheckedUtils;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Type;
import java.util.LinkedHashMap;
import java.util.Map;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/adapters/other/ObjectAdapter.class */
public final class ObjectAdapter<T extends ConfigurationPart> implements TypeAdapter<Object, Map<String, Object>> {
    private final YamlConfiguration.Builder<T> configuration;
    private static transient /* synthetic */ String aCHzmjuQFV = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public ObjectAdapter(YamlConfiguration.Builder<T> configuration) {
        this.configuration = configuration;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public Object deserialize(TypeAdapterHolder holder, Object input, Type type) {
        if (input.getClass().isAnnotationPresent(Serializable.class)) {
            return input;
        }
        if (input instanceof Map) {
            Map map = (Map) UncheckedUtils.unsafeCast((Map) input);
            try {
                Object objNewInstance = ((Class) type).getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
                for (Field field : objNewInstance.getClass().getFields()) {
                    if (!Modifier.isFinal(field.getModifiers()) && !field.isAnnotationPresent(Ignored.class)) {
                        Object obj = map.get(this.configuration.keyRenamer().rename(field.getName()));
                        if (obj == null) {
                            if (!field.isAnnotationPresent(Hidden.class)) {
                                map.put(this.configuration.keyRenamer().rename(field.getName()), field.get(objNewInstance));
                            }
                        } else {
                            field.set(objNewInstance, holder.deserialize(obj, field.getGenericType()));
                        }
                    }
                }
                for (Method method : ((Class) type).getMethods()) {
                    if (method.isAnnotationPresent(PostProcess.class)) {
                        try {
                            method.invoke(objNewInstance, new Object[0]);
                        } catch (InvocationTargetException e) {
                            throw new RuntimeException(e);
                        }
                    }
                }
                return objNewInstance;
            } catch (IllegalAccessException | InstantiationException | NoSuchMethodException | InvocationTargetException e2) {
                throw new RuntimeException(e2);
            }
        }
        throw new RuntimeException();
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public Map<String, Object> serialize(TypeAdapterHolder holder, Object value, Type type) {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        try {
            for (Field field : value.getClass().getFields()) {
                if (!Modifier.isFinal(field.getModifiers()) && !field.isAnnotationPresent(Ignored.class)) {
                    Object obj = field.get(value);
                    if (!field.isAnnotationPresent(Hidden.class) || obj != null) {
                        linkedHashMap.put(this.configuration.keyRenamer().rename(field.getName()), holder.serialize(obj, field.getGenericType()));
                    }
                }
            }
            return linkedHashMap;
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }
}
