package com.artillexstudios.axquestboard.libs.axapi.database;

import com.artillexstudios.axquestboard.libs.axapi.libs.hikari.HikariConfig;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/database/DatabaseType.class */
public abstract class DatabaseType {
    private final Map<Class<Object>, Function<Object, List<Object>>> transformers = new HashMap();

    public abstract HikariConfig config(DatabaseConfig config);

    public abstract String name();

    public Function<Object, List<Object>> transformers(Class<?> clazz) {
        return this.transformers.get(clazz);
    }

    public <T, Z> void registerTransformer(Class<T> clazz, Function<T, List<Z>> from) {
        this.transformers.put(clazz, from);
    }
}
