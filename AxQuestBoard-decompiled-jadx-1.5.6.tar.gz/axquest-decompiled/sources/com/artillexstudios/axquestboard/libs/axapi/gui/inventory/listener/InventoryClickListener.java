package com.artillexstudios.axquestboard.libs.axapi.gui.inventory.listener;

import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.renderer.InventoryRenderer;
import com.artillexstudios.axquestboard.libs.axapi.items.WrappedItemStack;
import com.artillexstudios.axquestboard.libs.axapi.items.component.DataComponents;
import com.artillexstudios.axquestboard.libs.axapi.items.nbt.CompoundTag;
import com.artillexstudios.axquestboard.libs.axapi.utils.PaperUtils;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/gui/inventory/listener/InventoryClickListener.class */
public final class InventoryClickListener implements Listener {
    private static transient /* synthetic */ String yjzBtRLhHD = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    @EventHandler
    public void onInventoryClickEvent(InventoryClickEvent event) {
        if (event.getCurrentItem() != null && event.getClickedInventory() != null && event.getClickedInventory().equals(event.getView().getBottomInventory())) {
            checkAndRemove(event.getCurrentItem());
        }
        InventoryHolder holder = PaperUtils.getHolder(event.getInventory(), false);
        if (!(holder instanceof InventoryRenderer)) {
            return;
        }
        ((InventoryRenderer) holder).handleClick(event);
    }

    @EventHandler
    public void onInventoryDragEvent(InventoryDragEvent event) {
        InventoryHolder holder = PaperUtils.getHolder(event.getInventory(), false);
        if (!(holder instanceof InventoryRenderer)) {
            return;
        }
        ((InventoryRenderer) holder).handleDrag(event);
    }

    @EventHandler
    public void onInventoryCloseEvent(InventoryCloseEvent event) {
        checkAndRemove(event.getPlayer().getInventory().getContents());
        InventoryHolder holder = PaperUtils.getHolder(event.getInventory(), false);
        if (!(holder instanceof InventoryRenderer)) {
            return;
        }
        ((InventoryRenderer) holder).handleClose(event);
    }

    @EventHandler
    public void onInventoryOpenEvent(InventoryOpenEvent event) {
        checkAndRemove(event.getPlayer().getInventory().getContents());
        InventoryHolder holder = PaperUtils.getHolder(event.getInventory(), false);
        if (!(holder instanceof InventoryRenderer)) {
            return;
        }
        ((InventoryRenderer) holder).handleOpen(event);
    }

    @EventHandler
    public void onPlayerDropItemEvent(PlayerDropItemEvent event) {
        checkAndRemove(event.getItemDrop().getItemStack());
    }

    @EventHandler
    public void onPlayerInteractEvent(PlayerInteractEvent event) {
        checkAndRemove(event.getItem());
    }

    private void checkAndRemove(ItemStack[] items) {
        for (ItemStack itemStack : items) {
            checkAndRemove(itemStack);
        }
    }

    private void checkAndRemove(ItemStack stack) {
        if (stack == null || !((CompoundTag) WrappedItemStack.wrap(stack).get(DataComponents.customData())).contains("axapi-gui")) {
            return;
        }
        stack.setAmount(0);
    }
}
