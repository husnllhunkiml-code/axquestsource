package com.artillexstudios.axquestboard.libs.axapi.gui.inventory.renderer.strategy;

import com.artillexstudios.axquestboard.libs.axapi.context.HashMapContext;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.BakedGuiItem;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.Gui;
import com.artillexstudios.axquestboard.libs.axapi.scheduler.Scheduler;
import com.artillexstudios.axquestboard.libs.axapi.utils.logging.LogUtils;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Semaphore;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/gui/inventory/renderer/strategy/StreamingRenderStrategy.class */
public class StreamingRenderStrategy implements RenderStrategy {
    private static transient /* synthetic */ String eiwGGbKKiK = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    @Override // com.artillexstudios.axquestboard.libs.axapi.gui.inventory.renderer.strategy.RenderStrategy
    public void render(Gui gui, HashMapContext context, boolean newInventory, Int2ObjectMap<BakedGuiItem> items, Inventory inventory, Semaphore lock) {
        CompletableFuture[] completableFutureArr = new CompletableFuture[gui.getProviders().size()];
        Player player = gui.getRenderer().getPlayer();
        if (newInventory || gui.getRenderer().isClosed()) {
            gui.getRenderer().setClosed(false);
            Scheduler.get().runAt(player.getLocation(), () -> {
                player.openInventory(inventory);
            });
        }
        gui.getProviders().forEach((num, guiItemProvider) -> {
            CompletableFuture<BakedGuiItem> completableFutureProvide = guiItemProvider.provide(context, gui.getModifiers());
            completableFutureArr[num.intValue()] = completableFutureProvide;
            completableFutureProvide.thenAccept(bakedGuiItem -> {
                BakedGuiItem bakedGuiItem = (BakedGuiItem) items.put(num.intValue(), bakedGuiItem);
                if (bakedGuiItem != null && bakedGuiItem.stack().equals(bakedGuiItem.stack())) {
                    return;
                }
                inventory.setItem(num.intValue(), bakedGuiItem.stack());
            });
        });
        CompletableFuture.allOf(completableFutureArr).whenComplete((r4, th) -> {
            if (th != null) {
                LogUtils.error("An exception occurred", new Object[0]);
            }
            lock.release();
        });
    }
}
