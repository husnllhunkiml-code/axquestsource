package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common;

import java.io.Serializable;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/common/SpecVersion.class */
public class SpecVersion implements Serializable {
    private final int major;
    private final int minor;
    private static transient /* synthetic */ String uiDINQMwqw = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public SpecVersion(int i, int i2) {
        this.major = i;
        this.minor = i2;
    }

    public int getMajor() {
        return this.major;
    }

    public int getMinor() {
        return this.minor;
    }

    public String getRepresentation() {
        return this.major + "." + this.minor;
    }

    public String toString() {
        return "Version{major=" + this.major + ", minor=" + this.minor + '}';
    }
}
