package com.artillexstudios.axquestboard.libs.axapi.items;

import com.artillexstudios.axquestboard.libs.axapi.nms.wrapper.ServerPlayerWrapper;
import com.artillexstudios.axquestboard.libs.axapi.packet.ClientboundPacketTypes;
import com.artillexstudios.axquestboard.libs.axapi.packet.PacketEvent;
import com.artillexstudios.axquestboard.libs.axapi.packet.PacketEvents;
import com.artillexstudios.axquestboard.libs.axapi.packet.PacketListener;
import com.artillexstudios.axquestboard.libs.axapi.packet.ServerboundPacketTypes;
import com.artillexstudios.axquestboard.libs.axapi.packet.data.MerchantOffer;
import com.artillexstudios.axquestboard.libs.axapi.packet.wrapper.clientbound.ClientboundContainerSetContentWrapper;
import com.artillexstudios.axquestboard.libs.axapi.packet.wrapper.clientbound.ClientboundContainerSetSlotWrapper;
import com.artillexstudios.axquestboard.libs.axapi.packet.wrapper.clientbound.ClientboundEntityMetadataWrapper;
import com.artillexstudios.axquestboard.libs.axapi.packet.wrapper.clientbound.ClientboundMerchantOffersWrapper;
import com.artillexstudios.axquestboard.libs.axapi.packet.wrapper.clientbound.ClientboundSetCursorItemWrapper;
import com.artillexstudios.axquestboard.libs.axapi.packet.wrapper.clientbound.ClientboundSetEquipmentWrapper;
import com.artillexstudios.axquestboard.libs.axapi.packet.wrapper.serverbound.ServerboundContainerClickWrapper;
import com.artillexstudios.axquestboard.libs.axapi.packet.wrapper.serverbound.ServerboundSetCreativeModeSlotWrapper;
import com.artillexstudios.axquestboard.libs.axapi.packetentity.meta.Metadata;
import com.artillexstudios.axquestboard.libs.axapi.utils.EquipmentSlot;
import com.artillexstudios.axquestboard.libs.axapi.utils.Pair;
import com.artillexstudios.axquestboard.libs.axapi.utils.Version;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import it.unimi.dsi.fastutil.objects.ObjectListIterator;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/items/PacketItemModifier.class */
public class PacketItemModifier {
    private static boolean listening = false;
    private static final ObjectArrayList<PacketItemModifierListener> listeners = new ObjectArrayList<>();
    private static final Map<Player, HashedStack> stacks = new ConcurrentHashMap();
    private static transient /* synthetic */ String oRFSXHdiXS = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/items/PacketItemModifier$Context.class */
    public enum Context {
        SET_SLOT,
        SET_CURSOR,
        SET_CONTENTS,
        EQUIPMENT,
        DROPPED_ITEM,
        MERCHANT_OFFER
    }

    public static void registerModifierListener(PacketItemModifierListener listener) {
        if (!listening) {
            registerListener();
        }
        if (!listeners.contains(listener)) {
            listeners.add(listener);
            listening = true;
        }
    }

    private static void registerListener() {
        PacketEvents.INSTANCE.addListener(new PacketListener() { // from class: com.artillexstudios.axquestboard.libs.axapi.items.PacketItemModifier.1
            private static transient /* synthetic */ String hjFbJOuuXB = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

            @Override // com.artillexstudios.axquestboard.libs.axapi.packet.PacketListener
            public void onPacketSending(PacketEvent event) {
                if (!PacketItemModifier.isListening()) {
                    return;
                }
                if (event.type() == ClientboundPacketTypes.CONTAINER_SET_SLOT) {
                    ClientboundContainerSetSlotWrapper clientboundContainerSetSlotWrapper = new ClientboundContainerSetSlotWrapper(event);
                    PacketItemModifier.callModify(clientboundContainerSetSlotWrapper.stack(), event.player(), Context.SET_SLOT);
                    clientboundContainerSetSlotWrapper.markDirty();
                    return;
                }
                if (event.type() == ClientboundPacketTypes.CONTAINER_CONTENT) {
                    ClientboundContainerSetContentWrapper clientboundContainerSetContentWrapper = new ClientboundContainerSetContentWrapper(event);
                    Iterator<WrappedItemStack> it = clientboundContainerSetContentWrapper.items().iterator();
                    while (it.hasNext()) {
                        PacketItemModifier.callModify(it.next(), event.player(), Context.SET_CONTENTS);
                    }
                    PacketItemModifier.callModify(clientboundContainerSetContentWrapper.carriedItem(), event.player(), Context.SET_CONTENTS);
                    clientboundContainerSetContentWrapper.markDirty();
                    return;
                }
                if (event.type() == ClientboundPacketTypes.SET_CURSOR_ITEM) {
                    ClientboundSetCursorItemWrapper clientboundSetCursorItemWrapper = new ClientboundSetCursorItemWrapper(event);
                    ServerPlayerWrapper serverPlayerWrapperWrap = ServerPlayerWrapper.wrap(event.player());
                    if (Version.getServerVersion().isNewerThanOrEqualTo(Version.v1_21_4)) {
                        WrappedItemStack wrappedItemStackCopy = clientboundSetCursorItemWrapper.getItemStack().copy();
                        HashedStack hashedStack = wrappedItemStackCopy.toHashedStack(serverPlayerWrapperWrap.hashGenerator());
                        PacketItemModifier.callModify(clientboundSetCursorItemWrapper.getItemStack(), event.player(), Context.SET_CURSOR);
                        if (!wrappedItemStackCopy.equals(clientboundSetCursorItemWrapper.getItemStack())) {
                            PacketItemModifier.stacks.put(event.player(), hashedStack);
                        }
                    } else {
                        PacketItemModifier.callModify(clientboundSetCursorItemWrapper.getItemStack(), event.player(), Context.SET_CURSOR);
                    }
                    clientboundSetCursorItemWrapper.markDirty();
                    return;
                }
                if (event.type() == ClientboundPacketTypes.SET_EQUIPMENT) {
                    ClientboundSetEquipmentWrapper clientboundSetEquipmentWrapper = new ClientboundSetEquipmentWrapper(event);
                    Iterator<Pair<EquipmentSlot, WrappedItemStack>> it2 = clientboundSetEquipmentWrapper.items().iterator();
                    while (it2.hasNext()) {
                        PacketItemModifier.callModify(it2.next().second(), event.player(), Context.EQUIPMENT);
                    }
                    clientboundSetEquipmentWrapper.markDirty();
                    return;
                }
                if (event.type() == ClientboundPacketTypes.MERCHANT_OFFERS) {
                    ClientboundMerchantOffersWrapper clientboundMerchantOffersWrapper = new ClientboundMerchantOffersWrapper(event);
                    for (MerchantOffer merchantOffer : clientboundMerchantOffersWrapper.merchantOffers()) {
                        PacketItemModifier.callModify(merchantOffer.getItem1(), event.player(), Context.MERCHANT_OFFER);
                        merchantOffer.getItem2().ifPresent(wrappedItemStack -> {
                            PacketItemModifier.callModify(wrappedItemStack, event.player(), Context.MERCHANT_OFFER);
                        });
                        PacketItemModifier.callModify(merchantOffer.getOutput(), event.player(), Context.MERCHANT_OFFER);
                    }
                    clientboundMerchantOffersWrapper.markDirty();
                    return;
                }
                if (event.type() == ClientboundPacketTypes.SET_ENTITY_DATA) {
                    ClientboundEntityMetadataWrapper clientboundEntityMetadataWrapper = new ClientboundEntityMetadataWrapper(event);
                    Iterator<Metadata.DataItem<?>> it3 = clientboundEntityMetadataWrapper.items().iterator();
                    while (it3.hasNext()) {
                        Object value = it3.next().getValue();
                        if (value instanceof WrappedItemStack) {
                            PacketItemModifier.callModify((WrappedItemStack) value, event.player(), Context.DROPPED_ITEM);
                        }
                    }
                    clientboundEntityMetadataWrapper.markDirty();
                }
            }

            @Override // com.artillexstudios.axquestboard.libs.axapi.packet.PacketListener
            public void onPacketReceive(PacketEvent event) {
                if (event.type() == ServerboundPacketTypes.SET_CREATIVE_MODE_SLOT) {
                    ServerboundSetCreativeModeSlotWrapper serverboundSetCreativeModeSlotWrapper = new ServerboundSetCreativeModeSlotWrapper(event);
                    PacketItemModifier.restore(serverboundSetCreativeModeSlotWrapper.stack());
                    serverboundSetCreativeModeSlotWrapper.markDirty();
                } else if (event.type() == ServerboundPacketTypes.CONTAINER_CLICK && Version.getServerVersion().isNewerThanOrEqualTo(Version.v1_21_4)) {
                    ServerboundContainerClickWrapper serverboundContainerClickWrapper = new ServerboundContainerClickWrapper(event);
                    HashedStack hashedStackRemove = PacketItemModifier.stacks.remove(event.player());
                    if (hashedStackRemove != null) {
                        serverboundContainerClickWrapper.setCarriedItem(hashedStackRemove);
                        serverboundContainerClickWrapper.markDirty();
                    }
                }
            }
        });
    }

    public static void unregister(PacketItemModifierListener listener) {
        listeners.remove(listener);
        if (listeners.isEmpty()) {
            listening = false;
        }
    }

    public static boolean isListening() {
        return listening;
    }

    public static void callModify(WrappedItemStack itemStack, Player player, Context context) {
        ObjectListIterator it = listeners.iterator();
        while (it.hasNext()) {
            ((PacketItemModifierListener) it.next()).modifyItemStack(player, itemStack, context);
        }
    }

    public static void restore(WrappedItemStack itemStack) {
        ObjectListIterator it = listeners.iterator();
        while (it.hasNext()) {
            ((PacketItemModifierListener) it.next()).restore(itemStack);
        }
    }
}
