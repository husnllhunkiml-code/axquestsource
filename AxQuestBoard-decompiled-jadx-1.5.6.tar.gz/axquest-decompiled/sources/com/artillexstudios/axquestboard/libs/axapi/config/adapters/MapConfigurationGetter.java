package com.artillexstudios.axquestboard.libs.axapi.config.adapters;

import com.artillexstudios.axquestboard.libs.axapi.utils.UncheckedUtils;
import java.util.Collections;
import java.util.Map;
import java.util.Set;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/adapters/MapConfigurationGetter.class */
public class MapConfigurationGetter implements ConfigurationGetter {
    protected final TypeAdapterHolder holder = new TypeAdapterHolder();
    private final Map<String, Object> wrapped;
    private final Set<String> unmodifiableKeys;
    private static transient /* synthetic */ String LVyhhiLlmY = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public <T, Z> MapConfigurationGetter(Map<T, Z> section) {
        this.wrapped = (Map) UncheckedUtils.unsafeCast(section);
        this.unmodifiableKeys = Collections.unmodifiableSet(this.wrapped.keySet());
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.ConfigurationGetter
    public <T> T get(String path, Class<T> clazz) {
        Object obj = this.wrapped.get(path);
        if (obj == null) {
            return null;
        }
        return clazz.cast(this.holder.deserialize(obj, clazz));
    }

    public void registerAdapter(Class<?> clazz, TypeAdapter<?, ?> adapter) {
        this.holder.registerAdapter(clazz, adapter);
    }

    public void registerAdapters(Map<Class<?>, TypeAdapter<?, ?>> adapters) {
        this.holder.registerAdapters(adapters);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.ConfigurationGetter
    public Set<String> getKeys() {
        return this.unmodifiableKeys;
    }

    public Map<String, Object> wrapped() {
        return this.wrapped;
    }
}
