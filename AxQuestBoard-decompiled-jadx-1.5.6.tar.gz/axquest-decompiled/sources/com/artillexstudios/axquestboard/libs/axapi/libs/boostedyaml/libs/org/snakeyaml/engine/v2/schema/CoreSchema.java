package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.schema;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.ConstructNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.constructor.core.ConstructYamlCoreBool;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.constructor.core.ConstructYamlCoreFloat;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.constructor.core.ConstructYamlCoreInt;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Tag;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.resolver.CoreScalarResolver;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.resolver.ScalarResolver;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/schema/CoreSchema.class */
public class CoreSchema extends JsonSchema {
    private final Map<Tag, ConstructNode> tagConstructors = new HashMap();
    private static transient /* synthetic */ String gwJkUSPsgc = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public CoreSchema() {
        this.tagConstructors.put(Tag.BOOL, new ConstructYamlCoreBool());
        this.tagConstructors.put(Tag.INT, new ConstructYamlCoreInt());
        this.tagConstructors.put(Tag.FLOAT, new ConstructYamlCoreFloat());
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.schema.JsonSchema, com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.schema.Schema
    public ScalarResolver getScalarResolver() {
        return new CoreScalarResolver();
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.schema.JsonSchema, com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.schema.Schema
    public Map<Tag, ConstructNode> getSchemaTagConstructors() {
        Map<Tag, ConstructNode> schemaTagConstructors = super.getSchemaTagConstructors();
        schemaTagConstructors.putAll(this.tagConstructors);
        return schemaTagConstructors;
    }
}
