package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.events;

import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.error.Mark;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/events/MappingEndEvent.class */
public final class MappingEndEvent extends CollectionEndEvent {
    private static transient /* synthetic */ String ZMkgoSiFMk = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public MappingEndEvent(Mark mark, Mark mark2) {
        super(mark, mark2);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.events.Event
    public Event.ID getEventId() {
        return Event.ID.MappingEnd;
    }
}
