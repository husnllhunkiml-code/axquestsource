package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.general;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.serialization.YamlSerializer;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.serialization.standard.StandardSerializer;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.Settings;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.utils.supplier.ListSupplier;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.utils.supplier.MapSupplier;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.utils.supplier.SetSupplier;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/settings/general/GeneralSettings.class */
public class GeneralSettings implements Settings {
    public static final char DEFAULT_ROUTE_SEPARATOR = '.';
    public static final boolean DEFAULT_USE_DEFAULTS = true;
    private final KeyFormat keyFormat;
    private final char separator;
    private final String escapedSeparator;
    private final YamlSerializer serializer;
    private final boolean useDefaults;
    private final Object defaultObject;
    private final Number defaultNumber;
    private final String defaultString;
    private final Character defaultChar;
    private final Boolean defaultBoolean;
    private final ListSupplier defaultList;
    private final SetSupplier defaultSet;
    private final MapSupplier defaultMap;
    private static transient /* synthetic */ String MAzdWbgTub = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";
    public static final String DEFAULT_ESCAPED_SEPARATOR = Pattern.quote(String.valueOf('.'));
    public static final KeyFormat DEFAULT_KEY_FORMATTING = KeyFormat.STRING;
    public static final YamlSerializer DEFAULT_SERIALIZER = StandardSerializer.getDefault();
    public static final Object DEFAULT_OBJECT = null;
    public static final Number DEFAULT_NUMBER = 0;
    public static final String DEFAULT_STRING = null;
    public static final Character DEFAULT_CHAR = ' ';
    public static final Boolean DEFAULT_BOOLEAN = false;
    public static final ListSupplier DEFAULT_LIST = ArrayList::new;
    public static final SetSupplier DEFAULT_SET = LinkedHashSet::new;
    public static final MapSupplier DEFAULT_MAP = LinkedHashMap::new;
    public static final GeneralSettings DEFAULT = builder().build();

    /* JADX INFO: renamed from: com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.general.GeneralSettings$1 */
    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/settings/general/GeneralSettings$1.class */
    static /* synthetic */ class C00231 {
        private static transient /* synthetic */ String BrHJKXNlVy = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/settings/general/GeneralSettings$KeyFormat.class */
    public enum KeyFormat {
        STRING,
        OBJECT
    }

    /* synthetic */ GeneralSettings(Builder builder, C00231 c00231) {
        this(builder);
    }

    private GeneralSettings(Builder builder) {
        this.keyFormat = builder.keyFormat;
        this.separator = builder.routeSeparator;
        this.escapedSeparator = Pattern.quote(String.valueOf(this.separator));
        this.serializer = builder.serializer;
        this.defaultObject = builder.defaultObject;
        this.defaultNumber = builder.defaultNumber;
        this.defaultString = builder.defaultString;
        this.defaultChar = builder.defaultChar;
        this.defaultBoolean = builder.defaultBoolean;
        this.defaultList = builder.defaultList;
        this.defaultSet = builder.defaultSet;
        this.defaultMap = builder.defaultMap;
        this.useDefaults = builder.useDefaults;
    }

    public KeyFormat getKeyFormat() {
        return this.keyFormat;
    }

    public char getRouteSeparator() {
        return this.separator;
    }

    public String getEscapedSeparator() {
        return this.escapedSeparator;
    }

    public YamlSerializer getSerializer() {
        return this.serializer;
    }

    public boolean isUseDefaults() {
        return this.useDefaults;
    }

    public Object getDefaultObject() {
        return this.defaultObject;
    }

    public String getDefaultString() {
        return this.defaultString;
    }

    public Character getDefaultChar() {
        return this.defaultChar;
    }

    public Number getDefaultNumber() {
        return this.defaultNumber;
    }

    public Boolean getDefaultBoolean() {
        return this.defaultBoolean;
    }

    public <T> List<T> getDefaultList(int i) {
        return this.defaultList.supply(i);
    }

    public <T> List<T> getDefaultList() {
        return getDefaultList(0);
    }

    public <T> Set<T> getDefaultSet(int i) {
        return this.defaultSet.supply(i);
    }

    public <T> Set<T> getDefaultSet() {
        return getDefaultSet(0);
    }

    public <K, V> Map<K, V> getDefaultMap(int i) {
        return this.defaultMap.supply(i);
    }

    public <K, V> Map<K, V> getDefaultMap() {
        return getDefaultMap(0);
    }

    public MapSupplier getDefaultMapSupplier() {
        return this.defaultMap;
    }

    public static Builder builder() {
        return new Builder(null);
    }

    public static Builder builder(GeneralSettings generalSettings) {
        return builder().setKeyFormat(generalSettings.keyFormat).setRouteSeparator(generalSettings.separator).setSerializer(generalSettings.serializer).setUseDefaults(generalSettings.useDefaults).setDefaultObject(generalSettings.defaultObject).setDefaultNumber(generalSettings.defaultNumber).setDefaultString(generalSettings.defaultString).setDefaultChar(generalSettings.defaultChar).setDefaultBoolean(generalSettings.defaultBoolean).setDefaultList(generalSettings.defaultList).setDefaultSet(generalSettings.defaultSet).setDefaultMap(generalSettings.defaultMap);
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/settings/general/GeneralSettings$Builder.class */
    public static class Builder {
        private KeyFormat keyFormat;
        private char routeSeparator;
        private YamlSerializer serializer;
        private boolean useDefaults;
        private Object defaultObject;
        private Number defaultNumber;
        private String defaultString;
        private Character defaultChar;
        private Boolean defaultBoolean;
        private ListSupplier defaultList;
        private SetSupplier defaultSet;
        private MapSupplier defaultMap;
        private static transient /* synthetic */ String qlLCofwvaY = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        /* synthetic */ Builder(C00231 c00231) {
            this();
        }

        private Builder() {
            this.keyFormat = GeneralSettings.DEFAULT_KEY_FORMATTING;
            this.routeSeparator = '.';
            this.serializer = GeneralSettings.DEFAULT_SERIALIZER;
            this.useDefaults = true;
            this.defaultObject = GeneralSettings.DEFAULT_OBJECT;
            this.defaultNumber = GeneralSettings.DEFAULT_NUMBER;
            this.defaultString = GeneralSettings.DEFAULT_STRING;
            this.defaultChar = GeneralSettings.DEFAULT_CHAR;
            this.defaultBoolean = GeneralSettings.DEFAULT_BOOLEAN;
            this.defaultList = GeneralSettings.DEFAULT_LIST;
            this.defaultSet = GeneralSettings.DEFAULT_SET;
            this.defaultMap = GeneralSettings.DEFAULT_MAP;
        }

        public Builder setKeyFormat(@NotNull KeyFormat keyFormat) {
            this.keyFormat = keyFormat;
            return this;
        }

        public Builder setRouteSeparator(char c) {
            this.routeSeparator = c;
            return this;
        }

        public Builder setSerializer(@NotNull YamlSerializer yamlSerializer) {
            this.serializer = yamlSerializer;
            return this;
        }

        public Builder setUseDefaults(boolean z) {
            this.useDefaults = z;
            return this;
        }

        public Builder setDefaultObject(@Nullable Object obj) {
            this.defaultObject = obj;
            return this;
        }

        public Builder setDefaultNumber(@NotNull Number number) {
            this.defaultNumber = number;
            return this;
        }

        public Builder setDefaultString(@Nullable String str) {
            this.defaultString = str;
            return this;
        }

        public Builder setDefaultChar(@Nullable Character ch) {
            this.defaultChar = ch;
            return this;
        }

        public Builder setDefaultBoolean(@Nullable Boolean bool) {
            this.defaultBoolean = bool;
            return this;
        }

        public Builder setDefaultList(@NotNull ListSupplier listSupplier) {
            this.defaultList = listSupplier;
            return this;
        }

        public Builder setDefaultSet(@NotNull SetSupplier setSupplier) {
            this.defaultSet = setSupplier;
            return this;
        }

        public Builder setDefaultMap(@NotNull MapSupplier mapSupplier) {
            this.defaultMap = mapSupplier;
            return this;
        }

        public GeneralSettings build() {
            return new GeneralSettings(this, null);
        }
    }
}
