package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.block.implementation;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.block.Block;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Node;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/block/implementation/TerminatedBlock.class */
public class TerminatedBlock extends Block<Object> {
    private static transient /* synthetic */ String DYlMJKiRdZ = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public TerminatedBlock(@Nullable Node node, @Nullable Node node2, @Nullable Object obj) {
        super(node, node2, obj);
    }

    public TerminatedBlock(@Nullable Block<?> block, @Nullable Object obj) {
        super(block, obj);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.block.Block
    public boolean isSection() {
        return false;
    }
}
