package com.artillexstudios.axquestboard.libs.axapi.hologram;

import com.artillexstudios.axquestboard.libs.axapi.hologram.page.DroppedItemHologramPage;
import com.artillexstudios.axquestboard.libs.axapi.hologram.page.TextDisplayHologramPage;
import com.artillexstudios.axquestboard.libs.axapi.items.WrappedItemStack;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/hologram/HologramTypes.class */
public final class HologramTypes {
    public static final HologramType<String> TEXT = new HologramType<>((v1, v2, v3) -> {
        return new TextDisplayHologramPage(v1, v2, v3);
    });
    public static final HologramType<WrappedItemStack> ITEM_STACK = new HologramType<>((v1, v2, v3) -> {
        return new DroppedItemHologramPage(v1, v2, v3);
    });
    private static transient /* synthetic */ String DcMdCNIMgJ = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";
}
