package com.artillexstudios.axquestboard.libs.axapi.items.component.type;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import org.bukkit.enchantments.Enchantment;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/items/component/type/ItemEnchantments.class */
public final class ItemEnchantments {
    private final HashMap<Enchantment, Integer> enchantments;
    private final Set<Map.Entry<Enchantment, Integer>> entrySet;
    private final Set<Enchantment> keySet;
    private final boolean showInTooltip;
    private static transient /* synthetic */ String mFrgoeyMsa = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public ItemEnchantments(HashMap<Enchantment, Integer> enchantments, boolean showInTooltip) {
        this.enchantments = enchantments;
        this.entrySet = Collections.unmodifiableSet(this.enchantments.entrySet());
        this.keySet = Collections.unmodifiableSet(this.enchantments.keySet());
        this.showInTooltip = showInTooltip;
    }

    public ItemEnchantments remove(Enchantment enchantment) {
        HashMap map = (HashMap) this.enchantments.clone();
        map.remove(enchantment);
        return new ItemEnchantments(map, this.showInTooltip);
    }

    public ItemEnchantments add(Enchantment enchantment, int level) {
        if (level <= 0) {
            return remove(enchantment);
        }
        HashMap map = (HashMap) this.enchantments.clone();
        map.put(enchantment, Integer.valueOf(Math.min(level, 255)));
        return new ItemEnchantments(map, this.showInTooltip);
    }

    public boolean showInTooltip() {
        return this.showInTooltip;
    }

    public ItemEnchantments withTooltip(boolean showInTooltip) {
        return new ItemEnchantments(this.enchantments, showInTooltip);
    }

    public Set<Enchantment> keySet() {
        return this.keySet;
    }

    public Set<Map.Entry<Enchantment, Integer>> entrySet() {
        return this.entrySet;
    }

    public Integer getLevel(Enchantment enchantment) {
        return this.enchantments.get(enchantment);
    }

    public int size() {
        return this.enchantments.size();
    }

    public boolean isEmpty() {
        return this.enchantments.isEmpty();
    }
}
