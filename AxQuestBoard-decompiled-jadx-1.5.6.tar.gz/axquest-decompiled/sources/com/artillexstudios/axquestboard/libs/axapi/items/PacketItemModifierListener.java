package com.artillexstudios.axquestboard.libs.axapi.items;

import org.bukkit.entity.Player;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/items/PacketItemModifierListener.class */
public interface PacketItemModifierListener {
    void modifyItemStack(Player player, WrappedItemStack stack, PacketItemModifier.Context context);

    void restore(WrappedItemStack stack);
}
