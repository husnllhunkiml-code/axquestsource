package com.artillexstudios.axquestboard.libs.axapi.collections;

import com.artillexstudios.axquestboard.libs.axapi.utils.mutable.MutableInteger;
import java.util.ArrayDeque;
import java.util.Collection;
import java.util.concurrent.locks.ReentrantLock;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/collections/NodeCachingLockingQueue.class */
public class NodeCachingLockingQueue<E> {
    private final Node<E> head;
    private Node<E> tail;
    private final ArrayDeque<Node<E>> nodeCache;
    private final ReentrantLock lock;
    private final MutableInteger size;
    private static transient /* synthetic */ String SOEmwWlMNv = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/collections/NodeCachingLockingQueue$Node.class */
    private static final class Node<E> {
        E item;
        Node<E> next;
        private static transient /* synthetic */ String zwvLWaqdJa = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        private Node() {
        }
    }

    public NodeCachingLockingQueue() {
        this(0);
    }

    public NodeCachingLockingQueue(int cacheSize) {
        this.head = new Node<>();
        this.nodeCache = new ArrayDeque<>();
        this.lock = new ReentrantLock();
        this.size = new MutableInteger();
        for (int i = 0; i < cacheSize; i++) {
            this.nodeCache.add(new Node<>());
        }
        this.tail = this.head;
    }

    private Node<E> getOrCreateNode() {
        Node<E> nodePollFirst = this.nodeCache.pollFirst();
        return nodePollFirst == null ? new Node<>() : nodePollFirst;
    }

    private void releaseNode(Node<E> node) {
        node.item = null;
        node.next = null;
        this.nodeCache.addFirst(node);
        this.size.decrementAndGet();
    }

    public void addAll(Collection<E> collection) {
        this.lock.lock();
        try {
            for (E e : collection) {
                Node<E> orCreateNode = getOrCreateNode();
                orCreateNode.item = e;
                this.tail.next = orCreateNode;
                this.tail = orCreateNode;
                this.size.incrementAndGet();
            }
            this.lock.unlock();
        } catch (Throwable th) {
            this.lock.unlock();
            throw th;
        }
    }

    public void offer(E item) {
        this.lock.lock();
        try {
            Node<E> orCreateNode = getOrCreateNode();
            orCreateNode.item = item;
            this.tail.next = orCreateNode;
            this.tail = orCreateNode;
            this.size.incrementAndGet();
        } finally {
            this.lock.unlock();
        }
    }

    public E poll() {
        this.lock.lock();
        try {
            Node<E> node = this.head.next;
            if (node == null) {
                return null;
            }
            E e = node.item;
            this.head.next = node.next;
            if (this.tail == node) {
                this.tail = this.head;
            }
            releaseNode(node);
            return e;
        } finally {
            this.lock.unlock();
        }
    }

    public boolean isEmpty() {
        return this.head.next == null;
    }

    public int size() {
        return this.size.intValue();
    }
}
