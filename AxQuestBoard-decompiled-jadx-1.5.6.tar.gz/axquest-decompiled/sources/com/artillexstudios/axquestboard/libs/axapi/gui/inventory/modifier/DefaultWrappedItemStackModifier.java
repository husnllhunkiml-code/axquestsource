package com.artillexstudios.axquestboard.libs.axapi.gui.inventory.modifier;

import com.artillexstudios.axquestboard.libs.axapi.items.WrappedItemStack;
import com.artillexstudios.axquestboard.libs.axapi.items.component.DataComponents;
import com.artillexstudios.axquestboard.libs.axapi.items.nbt.CompoundTag;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/gui/inventory/modifier/DefaultWrappedItemStackModifier.class */
public enum DefaultWrappedItemStackModifier implements WrappedItemStackModifier {
    INSTANCE;

    @Override // com.artillexstudios.axquestboard.libs.axapi.gui.inventory.modifier.WrappedItemStackModifier
    public WrappedItemStack modify(WrappedItemStack stack) {
        CompoundTag compoundTag = (CompoundTag) stack.get(DataComponents.customData());
        compoundTag.putBoolean("axapi-gui", true);
        stack.set(DataComponents.customData(), compoundTag);
        return stack;
    }
}
