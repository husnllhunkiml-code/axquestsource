package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.internal;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/internal/Logger.class */
public class Logger {
    private final java.util.logging.Logger logger;
    private static transient /* synthetic */ String zpzZTjpwAa = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/internal/Logger$Level.class */
    public enum Level {
        WARNING(java.util.logging.Level.FINE);

        private final java.util.logging.Level level;

        Level(java.util.logging.Level level) {
            this.level = level;
        }
    }

    private Logger(String str) {
        this.logger = java.util.logging.Logger.getLogger(str);
    }

    public static Logger getLogger(String str) {
        return new Logger(str);
    }

    public boolean isLoggable(Level level) {
        return this.logger.isLoggable(level.level);
    }

    public void warn(String str) {
        this.logger.log(Level.WARNING.level, str);
    }
}
