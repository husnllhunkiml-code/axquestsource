package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.Anchor;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.FlowStyle;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.Mark;
import java.util.Objects;
import java.util.Optional;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/events/CollectionStartEvent.class */
public abstract class CollectionStartEvent extends NodeEvent {
    private final Optional<String> tag;
    private final boolean implicit;
    private final FlowStyle flowStyle;

    public CollectionStartEvent(Optional<Anchor> optional, Optional<String> optional2, boolean z, FlowStyle flowStyle, Optional<Mark> optional3, Optional<Mark> optional4) {
        super(optional, optional3, optional4);
        Objects.requireNonNull(optional2);
        this.tag = optional2;
        this.implicit = z;
        Objects.requireNonNull(flowStyle);
        this.flowStyle = flowStyle;
    }

    public Optional<String> getTag() {
        return this.tag;
    }

    public boolean isImplicit() {
        return this.implicit;
    }

    public FlowStyle getFlowStyle() {
        return this.flowStyle;
    }

    public boolean isFlow() {
        return FlowStyle.FLOW == this.flowStyle;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        getAnchor().ifPresent(anchor -> {
            sb.append(" &" + anchor);
        });
        if (!this.implicit) {
            getTag().ifPresent(str -> {
                sb.append(" <" + str + ">");
            });
        }
        return sb.toString();
    }
}
