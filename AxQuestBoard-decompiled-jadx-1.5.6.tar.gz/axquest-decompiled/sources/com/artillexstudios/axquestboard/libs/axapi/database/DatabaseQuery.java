package com.artillexstudios.axquestboard.libs.axapi.database;

import java.util.Objects;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Function;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/database/DatabaseQuery.class */
public class DatabaseQuery<T> {
    private final DatabaseHandler handler;
    private final ResultHandler<T> resultHandler;
    private final String sql;
    private static transient /* synthetic */ String SYuCQNoeHu = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public DatabaseQuery(DatabaseHandler handler, ResultHandler<T> resultHandler, String sql) {
        this.handler = handler;
        this.resultHandler = resultHandler;
        this.sql = sql;
    }

    public void execute(Object... parameters) {
        create().execute(parameters);
    }

    public RunnableQuery<T> create() {
        DatabaseHandler databaseHandler = this.handler;
        Objects.requireNonNull(databaseHandler);
        Function function = databaseHandler::transformer;
        DatabaseHandler databaseHandler2 = this.handler;
        Objects.requireNonNull(databaseHandler2);
        return new RunnableQuery<>(function, databaseHandler2::connection, this.resultHandler, this.sql);
    }

    public AsyncRunnableQuery<T> createAsync() {
        return new AsyncRunnableQuery<>(Executors::newVirtualThreadPerTaskExecutor, create());
    }

    public AsyncRunnableQuery<T> createAsync(ExecutorService service) {
        return new AsyncRunnableQuery<>(() -> {
            return service;
        }, create());
    }

    public AsyncRunnableQuery<T> createAsync(Executor executor) {
        return new AsyncRunnableQuery<>(() -> {
            return executor;
        }, create());
    }
}
