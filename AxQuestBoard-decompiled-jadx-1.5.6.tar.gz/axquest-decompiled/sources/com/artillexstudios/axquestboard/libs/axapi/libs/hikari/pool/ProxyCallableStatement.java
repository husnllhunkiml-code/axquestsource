package com.artillexstudios.axquestboard.libs.axapi.libs.hikari.pool;

import java.sql.CallableStatement;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/hikari/pool/ProxyCallableStatement.class */
public abstract class ProxyCallableStatement extends ProxyPreparedStatement implements CallableStatement {
    protected ProxyCallableStatement(ProxyConnection proxyConnection, CallableStatement callableStatement) {
        super(proxyConnection, callableStatement);
    }
}
