package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.comments;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.CommentEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.Mark;
import java.util.Objects;
import java.util.Optional;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/comments/CommentLine.class */
public class CommentLine {
    private final Optional<Mark> startMark;
    private final Optional<Mark> endMark;
    private final String value;
    private final CommentType commentType;
    private static transient /* synthetic */ String KKrTZfScif = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public CommentLine(CommentEvent commentEvent) {
        this(commentEvent.getStartMark(), commentEvent.getEndMark(), commentEvent.getValue(), commentEvent.getCommentType());
    }

    public CommentLine(Optional<Mark> optional, Optional<Mark> optional2, String str, CommentType commentType) {
        Objects.requireNonNull(optional);
        this.startMark = optional;
        Objects.requireNonNull(optional2);
        this.endMark = optional2;
        Objects.requireNonNull(str);
        this.value = str;
        Objects.requireNonNull(commentType);
        this.commentType = commentType;
    }

    public Optional<Mark> getEndMark() {
        return this.endMark;
    }

    public Optional<Mark> getStartMark() {
        return this.startMark;
    }

    public CommentType getCommentType() {
        return this.commentType;
    }

    public String getValue() {
        return this.value;
    }

    public String toString() {
        return "<" + getClass().getName() + " (type=" + getCommentType() + ", value=" + getValue() + ")>";
    }
}
