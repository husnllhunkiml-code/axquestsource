package com.artillexstudios.axquestboard.libs.axapi.gui.configuration;

import com.artillexstudios.axquestboard.libs.axapi.config.adapters.MapConfigurationGetter;
import com.artillexstudios.axquestboard.libs.axapi.context.HashMapContext;
import com.artillexstudios.axquestboard.libs.axapi.gui.configuration.actions.Action;
import com.artillexstudios.axquestboard.libs.axapi.gui.configuration.actions.Actions;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.Gui;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.GuiItem;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.GuiKeys;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.implementation.PaginatedGui;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.provider.implementation.CachingGuiItemProvider;
import com.artillexstudios.axquestboard.libs.axapi.placeholders.PlaceholderParameters;
import com.artillexstudios.axquestboard.libs.axapi.utils.ItemBuilder;
import com.artillexstudios.axquestboard.libs.axapi.utils.UncheckedUtils;
import com.artillexstudios.axquestboard.libs.axapi.utils.featureflags.FeatureFlags;
import com.artillexstudios.axquestboard.libs.axapi.utils.logging.LogUtils;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.ints.IntList;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.runtime.SwitchBootstraps;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.regex.Pattern;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/gui/configuration/ConfigurationBackedGui.class */
public class ConfigurationBackedGui<T extends Gui> {
    private static final Pattern SPLIT_PATTERN = Pattern.compile("-");
    private final ConfigurationBackedGuiBuilder builder;
    private static transient /* synthetic */ String RFdDVpbJNT = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public ConfigurationBackedGui(ConfigurationBackedGuiBuilder builder) {
        this.builder = builder;
    }

    private void setItems(T gui, HashMapContext globalContext) {
        List<MapConfigurationGetter> list = this.builder.configuration().getList("items", MapConfigurationGetter::new);
        if (list == null) {
            list = new ArrayList();
            if (this.builder.supportsLegacy()) {
                Iterator<String> it = this.builder.configuration().getKeys().iterator();
                while (it.hasNext()) {
                    String string = it.next().toString();
                    if (!this.builder.overrideItems().containsKey(string) && !this.builder.ignoredKeys().contains(string)) {
                        list.add(this.builder.configuration().getConfiguration(string));
                    }
                }
            }
        }
        for (MapConfigurationGetter mapConfigurationGetter : list) {
            Object object = mapConfigurationGetter.getObject("slots");
            if (object == null) {
                LogUtils.warn("Failed to add item: {} to the gui, because it didn't have any slots set up!", mapConfigurationGetter);
            } else {
                IntList intListSlots = slots(object);
                List<Action<?>> all = Actions.INSTANCE.parseAll(mapConfigurationGetter.getList("actions"));
                CachingGuiItemProvider cachingGuiItemProvider = new CachingGuiItemProvider(new GuiItem(hashMapContext -> {
                    return ItemBuilder.create(mapConfigurationGetter, new PlaceholderParameters(hashMapContext)).wrapped();
                }, (hashMapContext2, inventoryClickEvent) -> {
                    hashMapContext2.merge(globalContext);
                    Iterator it2 = all.iterator();
                    while (it2.hasNext()) {
                        ((Action) it2.next()).run((Player) inventoryClickEvent.getWhoClicked(), hashMapContext2);
                    }
                }));
                intListSlots.intIterator().forEachRemaining(i -> {
                    gui.setItem(i, cachingGuiItemProvider);
                });
            }
        }
        for (Map.Entry<String, Consumer<InventoryClickEvent>> entry : this.builder.overrideItems().entrySet()) {
            MapConfigurationGetter configuration = this.builder.configuration().getConfiguration(entry.getKey());
            if (configuration == null) {
                if (FeatureFlags.STRICT_ITEM_OVERRIDE_HANDLING.get().booleanValue()) {
                    LogUtils.error("Could not find item within section {} in file! Did you remove it? This is not allowed! Please regenerate the file!", entry.getKey());
                    throw new IllegalStateException();
                }
                return;
            } else {
                Object object2 = configuration.getObject("slots");
                if (object2 == null) {
                    LogUtils.warn("Failed to add item: {} to the gui, because it didn't have any slots set up!", configuration);
                } else {
                    IntList intListSlots2 = slots(object2);
                    List<Action<?>> all2 = Actions.INSTANCE.parseAll(configuration.getList("actions"));
                    CachingGuiItemProvider cachingGuiItemProvider2 = new CachingGuiItemProvider(new GuiItem(hashMapContext3 -> {
                        return ItemBuilder.create(configuration, new PlaceholderParameters(hashMapContext3)).wrapped();
                    }, (hashMapContext4, inventoryClickEvent2) -> {
                        hashMapContext4.merge(globalContext);
                        Iterator it2 = all2.iterator();
                        while (it2.hasNext()) {
                            ((Action) it2.next()).run((Player) inventoryClickEvent2.getWhoClicked(), hashMapContext4);
                        }
                        ((Consumer) entry.getValue()).accept(inventoryClickEvent2);
                    }));
                    intListSlots2.intIterator().forEachRemaining(i2 -> {
                        gui.setItem(i2, cachingGuiItemProvider2);
                    });
                }
            }
        }
    }

    public IntList slots(Object slots) {
        Objects.requireNonNull(slots);
        switch ((int) SwitchBootstraps.typeSwitch(MethodHandles.lookup(), "typeSwitch", MethodType.methodType(Integer.TYPE, Object.class, Integer.TYPE), Number.class, String.class, List.class).dynamicInvoker().invoke(slots, 0) /* invoke-custom */) {
            case 0:
                return IntList.of(((Number) slots).intValue());
            case 1:
                return parseSlot((String) slots);
            case 2:
                List list = (List) slots;
                IntArrayList intArrayList = new IntArrayList(list.size());
                Iterator it = list.iterator();
                while (it.hasNext()) {
                    intArrayList.addAll(slots(it.next()));
                }
                return intArrayList;
            default:
                return IntList.of();
        }
    }

    public ConfigurationBackedGuiBuilder builder() {
        return this.builder;
    }

    private IntList parseSlot(String str) {
        if (str.contains("-")) {
            IntArrayList intArrayList = new IntArrayList();
            String[] strArrSplit = SPLIT_PATTERN.split(str);
            int i = Integer.parseInt(strArrSplit[0]);
            int i2 = Integer.parseInt(strArrSplit[1]);
            int iMin = Math.min(i, i2);
            int iMax = Math.max(i, i2);
            for (int i3 = iMin; i3 <= iMax; i3++) {
                intArrayList.add(i3);
            }
            return intArrayList;
        }
        return IntList.of(Integer.parseInt(str));
    }

    public synchronized T create(Player player, HashMapContext globalContext) {
        this.builder.guiBuilder().context(globalContext);
        T t = (T) UncheckedUtils.unsafeCast(this.builder.guiBuilder().build(player));
        if (t instanceof PaginatedGui) {
            PaginatedGui paginatedGui = (PaginatedGui) t;
            if (this.builder.objectProvider() != null) {
                paginatedGui.setItemsProvider(this.builder.objectProvider().apply(globalContext));
            }
        }
        t.disableAllInteractions();
        try {
            setItems(t, globalContext);
            if (this.builder.inventoryCloseListener() != null) {
                t.onClose(this.builder.inventoryCloseListener());
            }
            if (this.builder.inventoryOpenListener() != null) {
                t.onOpen(this.builder.inventoryOpenListener());
            }
            if (this.builder.playerInventoryClickListener() != null) {
                t.onPlayerInventoryClick(this.builder.playerInventoryClickListener());
            }
            if (this.builder.refreshInterval() != null) {
                t.setRefreshInterval(this.builder.refreshInterval().intValue());
            }
            return t;
        } catch (IllegalStateException e) {
            return null;
        }
    }

    public T create(Player player) {
        return (T) create(player, HashMapContext.create().with(GuiKeys.PLAYER, player));
    }
}
