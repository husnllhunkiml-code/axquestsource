package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.utils.supplier;

import java.util.Map;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/utils/supplier/MapSupplier.class */
public interface MapSupplier {
    @NotNull
    <K, V> Map<K, V> supply(int i);
}
