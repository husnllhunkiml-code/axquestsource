package com.artillexstudios.axquestboard.libs.axapi.gui.inventory.implementation;

import com.artillexstudios.axquestboard.libs.axapi.context.HashMapContext;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.Gui;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.GuiItem;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.modifier.WrappedItemStackModifier;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.provider.GuiItemProvider;
import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;
import java.util.List;
import java.util.function.Function;
import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryType;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/gui/inventory/implementation/StaticGui.class */
public class StaticGui extends Gui {
    private static transient /* synthetic */ String ZRFVRLXyGm = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public StaticGui(Player player, Function<HashMapContext, Component> titleProvider, InventoryType type, int rows, Int2ObjectArrayMap<GuiItemProvider> providers, HashMapContext context, List<WrappedItemStackModifier> modifiers) {
        super(player, titleProvider, type, rows, context, modifiers);
        this.providers.clear();
        this.providers.putAll(providers);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.gui.inventory.Gui
    public void setItem(int slot, GuiItem item) {
        throw new UnsupportedOperationException();
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.gui.inventory.Gui
    public void setItem(int slot, GuiItemProvider provider) {
        throw new UnsupportedOperationException();
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.gui.inventory.Gui
    public void setItem(int slot, GuiItem item, Function<GuiItem, GuiItemProvider> provider) {
        throw new UnsupportedOperationException();
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.gui.inventory.Gui
    public void updateTitle() {
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.gui.inventory.Gui
    public Int2ObjectArrayMap<GuiItemProvider> getProviders() {
        return super.getProviders();
    }
}
