package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.ScalarStyle;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.Mark;
import java.util.Objects;
import java.util.Optional;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/nodes/ScalarNode.class */
public class ScalarNode extends Node {
    private final ScalarStyle style;
    private final String value;
    private static transient /* synthetic */ String oikaZxlyWp = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public ScalarNode(Tag tag, boolean z, String str, ScalarStyle scalarStyle, Optional<Mark> optional, Optional<Mark> optional2) {
        super(tag, optional, optional2);
        Objects.requireNonNull(str, "value in a Node is required.");
        this.value = str;
        Objects.requireNonNull(scalarStyle, "Scalar style must be provided.");
        this.style = scalarStyle;
        this.resolved = z;
    }

    public ScalarNode(Tag tag, String str, ScalarStyle scalarStyle) {
        this(tag, true, str, scalarStyle, Optional.empty(), Optional.empty());
    }

    public ScalarStyle getScalarStyle() {
        return this.style;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Node
    public NodeType getNodeType() {
        return NodeType.SCALAR;
    }

    public String getValue() {
        return this.value;
    }

    public String toString() {
        return "<" + getClass().getName() + " (tag=" + getTag() + ", value=" + getValue() + ")>";
    }

    public boolean isPlain() {
        return this.style == ScalarStyle.PLAIN;
    }
}
