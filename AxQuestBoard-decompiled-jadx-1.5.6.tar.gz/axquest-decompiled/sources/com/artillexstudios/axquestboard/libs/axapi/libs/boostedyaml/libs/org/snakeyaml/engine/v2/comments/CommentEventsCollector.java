package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.comments;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.CommentEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.Event;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser.Parser;
import java.util.AbstractQueue;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Queue;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/comments/CommentEventsCollector.class */
public class CommentEventsCollector {
    private final Queue<Event> eventSource;
    private final CommentType[] expectedCommentTypes;
    private List<CommentLine> commentLineList = new ArrayList();
    private static transient /* synthetic */ String GRUYuytCWw = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public CommentEventsCollector(final Parser parser, CommentType... commentTypeArr) {
        this.eventSource = new AbstractQueue<Event>() { // from class: com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.comments.CommentEventsCollector.1
            private static transient /* synthetic */ String BHbiinpYot = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

            @Override // java.util.Queue
            public boolean offer(Event event) {
                throw new UnsupportedOperationException();
            }

            @Override // java.util.Queue
            public Event poll() {
                return parser.next();
            }

            @Override // java.util.Queue
            public Event peek() {
                return parser.peekEvent();
            }

            @Override // java.util.AbstractCollection, java.util.Collection, java.lang.Iterable
            public Iterator<Event> iterator() {
                throw new UnsupportedOperationException();
            }

            @Override // java.util.AbstractCollection, java.util.Collection
            public int size() {
                throw new UnsupportedOperationException();
            }
        };
        this.expectedCommentTypes = commentTypeArr;
    }

    public CommentEventsCollector(Queue<Event> queue, CommentType... commentTypeArr) {
        this.eventSource = queue;
        this.expectedCommentTypes = commentTypeArr;
    }

    private boolean isEventExpected(Event event) {
        if (event == null || event.getEventId() != Event.ID.Comment) {
            return false;
        }
        CommentEvent commentEvent = (CommentEvent) event;
        for (CommentType commentType : this.expectedCommentTypes) {
            if (commentEvent.getCommentType() == commentType) {
                return true;
            }
        }
        return false;
    }

    public CommentEventsCollector collectEvents() {
        collectEvents(null);
        return this;
    }

    public Event collectEvents(Event event) {
        if (event != null) {
            if (isEventExpected(event)) {
                this.commentLineList.add(new CommentLine((CommentEvent) event));
            } else {
                return event;
            }
        }
        while (isEventExpected(this.eventSource.peek())) {
            this.commentLineList.add(new CommentLine((CommentEvent) this.eventSource.poll()));
        }
        return null;
    }

    public Event collectEventsAndPoll(Event event) {
        Event eventCollectEvents = collectEvents(event);
        return eventCollectEvents != null ? eventCollectEvents : this.eventSource.poll();
    }

    public List<CommentLine> consume() {
        try {
            return this.commentLineList;
        } finally {
            this.commentLineList = new ArrayList();
        }
    }

    public boolean isEmpty() {
        return this.commentLineList.isEmpty();
    }
}
