package com.artillexstudios.axquestboard.libs.axapi.libs.hikari.pool;

import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/hikari/pool/ProxyLeakTask.class */
class ProxyLeakTask implements Runnable {
    private static final Logger LOGGER = LoggerFactory.getLogger(ProxyLeakTask.class);
    static final ProxyLeakTask NO_LEAK = new ProxyLeakTask() { // from class: com.artillexstudios.axquestboard.libs.axapi.libs.hikari.pool.ProxyLeakTask.1
        private static transient /* synthetic */ String URNCsQYvWy = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.hikari.pool.ProxyLeakTask
        void schedule(ScheduledExecutorService scheduledExecutorService, long j) {
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.hikari.pool.ProxyLeakTask, java.lang.Runnable
        public void run() {
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.hikari.pool.ProxyLeakTask
        public void cancel() {
        }
    };
    private ScheduledFuture<?> scheduledFuture;
    private String connectionName;
    private Exception exception;
    private String threadName;
    private boolean isLeaked;
    private static transient /* synthetic */ String xuRHVTHmpE = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    ProxyLeakTask(PoolEntry poolEntry) {
        this.exception = new Exception("Apparent connection leak detected");
        this.threadName = Thread.currentThread().getName();
        this.connectionName = poolEntry.connection.toString();
    }

    private ProxyLeakTask() {
    }

    void schedule(ScheduledExecutorService scheduledExecutorService, long j) {
        this.scheduledFuture = scheduledExecutorService.schedule(this, j, TimeUnit.MILLISECONDS);
    }

    @Override // java.lang.Runnable
    public void run() {
        this.isLeaked = true;
        StackTraceElement[] stackTrace = this.exception.getStackTrace();
        StackTraceElement[] stackTraceElementArr = new StackTraceElement[stackTrace.length - 5];
        System.arraycopy(stackTrace, 5, stackTraceElementArr, 0, stackTraceElementArr.length);
        this.exception.setStackTrace(stackTraceElementArr);
        LOGGER.warn("Connection leak detection triggered for {} on thread {}, stack trace follows", new Object[]{this.connectionName, this.threadName, this.exception});
    }

    void cancel() {
        this.scheduledFuture.cancel(false);
        if (this.isLeaked) {
            LOGGER.info("Previously reported leaked connection {} on thread {} was returned to the pool (unleaked)", this.connectionName, this.threadName);
        }
    }
}
