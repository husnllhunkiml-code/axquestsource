package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.extensions.compactnotation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/extensions/compactnotation/CompactData.class */
public class CompactData {
    private final String prefix;
    private final List<String> arguments = new ArrayList();
    private final Map<String, String> properties = new HashMap();
    private static transient /* synthetic */ String LhfbPZKxAQ = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public CompactData(String str) {
        this.prefix = str;
    }

    public String getPrefix() {
        return this.prefix;
    }

    public Map<String, String> getProperties() {
        return this.properties;
    }

    public List<String> getArguments() {
        return this.arguments;
    }

    public String toString() {
        return "CompactData: " + this.prefix + " " + this.properties;
    }
}
