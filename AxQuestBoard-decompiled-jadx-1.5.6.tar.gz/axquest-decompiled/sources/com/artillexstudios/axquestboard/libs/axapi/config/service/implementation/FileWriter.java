package com.artillexstudios.axquestboard.libs.axapi.config.service.implementation;

import com.artillexstudios.axquestboard.libs.axapi.config.service.Writer;
import com.artillexstudios.axquestboard.libs.axapi.utils.logging.LogUtils;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/service/implementation/FileWriter.class */
public final class FileWriter implements Writer {
    private static transient /* synthetic */ String lfRypgtlWK = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    @Override // com.artillexstudios.axquestboard.libs.axapi.config.service.Writer
    public boolean write(Path path, String dumped) {
        try {
            File file = path.toFile();
            File parentFile = file.getParentFile();
            if (parentFile != null) {
                parentFile.mkdirs();
            }
            File file2 = new File(parentFile, file.getName() + ".tmp");
            file2.delete();
            file2.createNewFile();
            if (dumped != null) {
                try {
                    BufferedWriter bufferedWriter = new BufferedWriter(new java.io.FileWriter(file2));
                    try {
                        bufferedWriter.write(dumped);
                        bufferedWriter.flush();
                        bufferedWriter.close();
                    } catch (Throwable th) {
                        try {
                            bufferedWriter.close();
                        } catch (Throwable th2) {
                            th.addSuppressed(th2);
                        }
                        throw th;
                    }
                } catch (Throwable th3) {
                    file2.delete();
                    throw th3;
                }
            }
            try {
                Files.move(file2.toPath(), path, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(file2.toPath(), path, StandardCopyOption.REPLACE_EXISTING);
            }
            file2.delete();
            return true;
        } catch (IOException e2) {
            LogUtils.error("An unexpected error occurred while saving file!", e2);
            return false;
        }
    }
}
