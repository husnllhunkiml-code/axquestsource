package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.introspector;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/introspector/BeanAccess.class */
public enum BeanAccess {
    DEFAULT,
    FIELD,
    PROPERTY
}
