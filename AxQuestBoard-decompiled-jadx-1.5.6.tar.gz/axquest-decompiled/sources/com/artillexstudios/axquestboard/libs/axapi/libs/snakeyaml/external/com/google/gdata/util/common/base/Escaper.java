package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.external.com.google.gdata.util.common.base;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/external/com/google/gdata/util/common/base/Escaper.class */
public interface Escaper {
    String escape(String str);

    Appendable escape(Appendable appendable);
}
