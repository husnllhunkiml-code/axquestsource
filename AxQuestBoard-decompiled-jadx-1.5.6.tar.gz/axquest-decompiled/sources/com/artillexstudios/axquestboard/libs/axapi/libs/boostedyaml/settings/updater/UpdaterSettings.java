package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.updater;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.YamlDocument;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.dvs.Pattern;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.dvs.versioning.AutomaticVersioning;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.dvs.versioning.ManualVersioning;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.dvs.versioning.Versioning;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.route.Route;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.route.RouteFactory;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.Settings;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Function;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/settings/updater/UpdaterSettings.class */
public class UpdaterSettings implements Settings {
    public static final boolean DEFAULT_AUTO_SAVE = true;
    public static final boolean DEFAULT_ENABLE_DOWNGRADING = true;
    public static final boolean DEFAULT_KEEP_ALL = false;
    public static final OptionSorting DEFAULT_OPTION_SORTING = OptionSorting.SORT_BY_DEFAULTS;
    public static final Map<MergeRule, Boolean> DEFAULT_MERGE_RULES = Collections.unmodifiableMap(new HashMap<MergeRule, Boolean>() { // from class: com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.updater.UpdaterSettings.1
        private static transient /* synthetic */ String mTxctuHjSm = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        {
            put(MergeRule.MAPPINGS, true);
            put(MergeRule.MAPPING_AT_SECTION, false);
            put(MergeRule.SECTION_AT_MAPPING, false);
        }
    });
    public static final Versioning DEFAULT_VERSIONING = null;
    public static final UpdaterSettings DEFAULT = builder().build();
    private final boolean autoSave;
    private final boolean enableDowngrading;
    private final boolean keepAll;
    private final Map<MergeRule, Boolean> mergeRules;
    private final Map<String, RouteSet> ignored;
    private final Map<String, RouteMap<Route, String>> relocations;
    private final Map<String, Map<Route, ValueMapper>> mappers;
    private final Map<String, List<Consumer<YamlDocument>>> customLogic;
    private final Versioning versioning;
    private final OptionSorting optionSorting;
    private static transient /* synthetic */ String qofTfStmRe = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/settings/updater/UpdaterSettings$OptionSorting.class */
    public enum OptionSorting {
        NONE,
        SORT_BY_DEFAULTS
    }

    public UpdaterSettings(Builder builder) {
        this.autoSave = builder.autoSave;
        this.enableDowngrading = builder.enableDowngrading;
        this.keepAll = builder.keepAll;
        this.optionSorting = builder.optionSorting;
        this.mergeRules = builder.mergeRules;
        this.ignored = builder.ignored;
        this.relocations = builder.relocations;
        this.mappers = builder.mappers;
        this.customLogic = builder.customLogic;
        this.versioning = builder.versioning;
    }

    public Map<MergeRule, Boolean> getMergeRules() {
        return this.mergeRules;
    }

    public Set<Route> getIgnoredRoutes(@NotNull String str, char c) {
        RouteSet routeSet = this.ignored.get(str);
        return routeSet == null ? Collections.emptySet() : routeSet.merge(c);
    }

    public Map<Route, Route> getRelocations(@NotNull String str, char c) {
        RouteMap<Route, String> routeMap = this.relocations.get(str);
        return routeMap == null ? Collections.emptyMap() : routeMap.merge(Function.identity(), str2 -> {
            return Route.fromString(str2, c);
        }, c);
    }

    public Map<Route, ValueMapper> getMappers(@NotNull String str, char c) {
        return this.mappers.getOrDefault(str, Collections.emptyMap());
    }

    public List<Consumer<YamlDocument>> getCustomLogic(@NotNull String str) {
        return this.customLogic.getOrDefault(str, Collections.emptyList());
    }

    public Versioning getVersioning() {
        return this.versioning;
    }

    public boolean isEnableDowngrading() {
        return this.enableDowngrading;
    }

    public boolean isKeepAll() {
        return this.keepAll;
    }

    public boolean isAutoSave() {
        return this.autoSave;
    }

    public OptionSorting getOptionSorting() {
        return this.optionSorting;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static Builder builder(UpdaterSettings updaterSettings) {
        return builder().setAutoSave(updaterSettings.autoSave).setEnableDowngrading(updaterSettings.enableDowngrading).setKeepAll(updaterSettings.keepAll).setOptionSorting(updaterSettings.optionSorting).setMergeRules(updaterSettings.mergeRules).setIgnoredRoutesInternal(updaterSettings.ignored).setRelocationsInternal(updaterSettings.relocations).addMappers(updaterSettings.mappers).addCustomLogic(updaterSettings.customLogic).setVersioning(updaterSettings.versioning);
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/settings/updater/UpdaterSettings$Builder.class */
    public static class Builder {
        private boolean autoSave;
        private boolean enableDowngrading;
        private boolean keepAll;
        private final Map<MergeRule, Boolean> mergeRules;
        private final Map<String, RouteSet> ignored;
        private final Map<String, RouteMap<Route, String>> relocations;
        private final Map<String, Map<Route, ValueMapper>> mappers;
        private final Map<String, List<Consumer<YamlDocument>>> customLogic;
        private Versioning versioning;
        private OptionSorting optionSorting;
        private static transient /* synthetic */ String tJsntCuyON = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        private Builder() {
            this.autoSave = true;
            this.enableDowngrading = true;
            this.keepAll = false;
            this.mergeRules = new HashMap(UpdaterSettings.DEFAULT_MERGE_RULES);
            this.ignored = new HashMap();
            this.relocations = new HashMap();
            this.mappers = new HashMap();
            this.customLogic = new HashMap();
            this.versioning = UpdaterSettings.DEFAULT_VERSIONING;
            this.optionSorting = UpdaterSettings.DEFAULT_OPTION_SORTING;
        }

        public Builder setAutoSave(boolean z) {
            this.autoSave = z;
            return this;
        }

        public Builder setEnableDowngrading(boolean z) {
            this.enableDowngrading = z;
            return this;
        }

        public Builder setKeepAll(boolean z) {
            this.keepAll = z;
            return this;
        }

        public Builder setOptionSorting(@NotNull OptionSorting optionSorting) {
            this.optionSorting = optionSorting;
            return this;
        }

        public Builder setMergeRules(@NotNull Map<MergeRule, Boolean> map) {
            this.mergeRules.putAll(map);
            return this;
        }

        public Builder setMergeRule(@NotNull MergeRule mergeRule, boolean z) {
            this.mergeRules.put(mergeRule, Boolean.valueOf(z));
            return this;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public Builder setIgnoredRoutesInternal(@NotNull Map<String, RouteSet> map) {
            this.ignored.putAll(map);
            return this;
        }

        @Deprecated
        public Builder setIgnoredRoutes(@NotNull Map<String, Set<Route>> map) {
            map.forEach((str, set) -> {
                this.ignored.computeIfAbsent(str, str -> {
                    return new RouteSet();
                }).getRouteSet().addAll(set);
            });
            return this;
        }

        @Deprecated
        public Builder setIgnoredRoutes(@NotNull String str, @NotNull Set<Route> set) {
            this.ignored.computeIfAbsent(str, str2 -> {
                return new RouteSet();
            }).getRouteSet().addAll(set);
            return this;
        }

        @Deprecated
        public Builder setIgnoredStringRoutes(@NotNull Map<String, Set<String>> map) {
            map.forEach((str, set) -> {
                this.ignored.computeIfAbsent(str, str -> {
                    return new RouteSet();
                }).getStringSet().addAll(set);
            });
            return this;
        }

        @Deprecated
        public Builder setIgnoredStringRoutes(@NotNull String str, @NotNull Set<String> set) {
            this.ignored.computeIfAbsent(str, str2 -> {
                return new RouteSet();
            }).getStringSet().addAll(set);
            return this;
        }

        public Builder addIgnoredRoute(@NotNull String str, @NotNull Route route) {
            return addIgnoredRoutes(str, Collections.singleton(route));
        }

        public Builder addIgnoredRoutes(@NotNull String str, @NotNull Set<Route> set) {
            return addIgnoredRoutes(Collections.singletonMap(str, set));
        }

        public Builder addIgnoredRoutes(@NotNull Map<String, Set<Route>> map) {
            map.forEach((str, set) -> {
                this.ignored.computeIfAbsent(str, str -> {
                    return new RouteSet();
                }).getRouteSet().addAll(set);
            });
            return this;
        }

        public Builder addIgnoredRoute(@NotNull String str, @NotNull String str2, char c) {
            return addIgnoredRoutes(str, Collections.singleton(str2), c);
        }

        public Builder addIgnoredRoutes(@NotNull String str, @NotNull Set<String> set, char c) {
            addIgnoredRoutes(str, set, new RouteFactory(c));
            return this;
        }

        public Builder addIgnoredRoutes(@NotNull Map<String, Set<String>> map, char c) {
            RouteFactory routeFactory = new RouteFactory(c);
            map.forEach((str, set) -> {
                addIgnoredRoutes(str, (Set<String>) set, routeFactory);
            });
            return this;
        }

        private void addIgnoredRoutes(@NotNull String str, @NotNull Set<String> set, @NotNull RouteFactory routeFactory) {
            Set<Route> routeSet = this.ignored.computeIfAbsent(str, str2 -> {
                return new RouteSet();
            }).getRouteSet();
            set.forEach(v2 -> {
                routeSet.add(routeFactory.create(v2));
            });
        }

        /* JADX INFO: Access modifiers changed from: private */
        public Builder setRelocationsInternal(@NotNull Map<String, RouteMap<Route, String>> map) {
            this.relocations.putAll(map);
            return this;
        }

        @Deprecated
        public Builder setRelocations(@NotNull Map<String, Map<Route, Route>> map) {
            map.forEach((str, map2) -> {
                this.relocations.computeIfAbsent(str, str -> {
                    return new RouteMap();
                }).getRouteMap().putAll(map2);
            });
            return this;
        }

        @Deprecated
        public Builder setRelocations(@NotNull String str, @NotNull Map<Route, Route> map) {
            this.relocations.computeIfAbsent(str, str2 -> {
                return new RouteMap();
            }).getRouteMap().putAll(map);
            return this;
        }

        @Deprecated
        public Builder setStringRelocations(@NotNull Map<String, Map<String, String>> map) {
            map.forEach((str, map2) -> {
                this.relocations.computeIfAbsent(str, str -> {
                    return new RouteMap();
                }).getStringMap().putAll(map2);
            });
            return this;
        }

        @Deprecated
        public Builder setStringRelocations(@NotNull String str, @NotNull Map<String, String> map) {
            this.relocations.computeIfAbsent(str, str2 -> {
                return new RouteMap();
            }).getStringMap().putAll(map);
            return this;
        }

        public Builder addRelocation(@NotNull String str, @NotNull Route route, @NotNull Route route2) {
            return addRelocations(str, Collections.singletonMap(route, route2));
        }

        public Builder addRelocations(@NotNull String str, @NotNull Map<Route, Route> map) {
            return addRelocations(Collections.singletonMap(str, map));
        }

        public Builder addRelocations(@NotNull Map<String, Map<Route, Route>> map) {
            map.forEach((str, map2) -> {
                this.relocations.computeIfAbsent(str, str -> {
                    return new RouteMap();
                }).getRouteMap().putAll(map2);
            });
            return this;
        }

        public Builder addRelocation(@NotNull String str, @NotNull String str2, @NotNull String str3, char c) {
            return addRelocations(str, Collections.singletonMap(str2, str3), c);
        }

        public Builder addRelocations(@NotNull String str, @NotNull Map<String, String> map, char c) {
            addRelocations(Collections.singletonMap(str, map), c);
            return this;
        }

        public Builder addRelocations(@NotNull Map<String, Map<String, String>> map, char c) {
            RouteFactory routeFactory = new RouteFactory(c);
            map.forEach((str, map2) -> {
                Map<Route, Route> routeMap = this.relocations.computeIfAbsent(str, str -> {
                    return new RouteMap();
                }).getRouteMap();
                map2.forEach((str2, str3) -> {
                });
            });
            return this;
        }

        public Builder addMapper(@NotNull String str, @NotNull Route route, @NotNull ValueMapper valueMapper) {
            return addMappers(str, Collections.singletonMap(route, valueMapper));
        }

        public Builder addMappers(@NotNull String str, @NotNull Map<Route, ValueMapper> map) {
            return addMappers(Collections.singletonMap(str, map));
        }

        public Builder addMappers(@NotNull Map<String, Map<Route, ValueMapper>> map) {
            map.forEach((str, map2) -> {
                this.mappers.computeIfAbsent(str, str -> {
                    return new HashMap();
                }).putAll(map2);
            });
            return this;
        }

        public Builder addMapper(@NotNull String str, @NotNull String str2, @NotNull ValueMapper valueMapper, char c) {
            return addMappers(str, Collections.singletonMap(str2, valueMapper), c);
        }

        public Builder addMappers(@NotNull String str, @NotNull Map<String, ValueMapper> map, char c) {
            return addMappers(Collections.singletonMap(str, map), c);
        }

        public Builder addMappers(@NotNull Map<String, Map<String, ValueMapper>> map, char c) {
            RouteFactory routeFactory = new RouteFactory(c);
            map.forEach((str, map2) -> {
                Map<Route, ValueMapper> mapComputeIfAbsent = this.mappers.computeIfAbsent(str, str -> {
                    return new HashMap();
                });
                map2.forEach((str2, valueMapper) -> {
                });
            });
            return this;
        }

        public Builder addCustomLogic(@NotNull String str, @NotNull Consumer<YamlDocument> consumer) {
            return addCustomLogic(str, Collections.singletonList(consumer));
        }

        public Builder addCustomLogic(@NotNull Map<String, List<Consumer<YamlDocument>>> map) {
            map.forEach((v1, v2) -> {
                addCustomLogic(v1, v2);
            });
            return this;
        }

        public Builder addCustomLogic(@NotNull String str, @NotNull Collection<Consumer<YamlDocument>> collection) {
            this.customLogic.computeIfAbsent(str, str2 -> {
                return new ArrayList();
            }).addAll(collection);
            return this;
        }

        public Builder setVersioning(@NotNull Versioning versioning) {
            this.versioning = versioning;
            return this;
        }

        public Builder setVersioning(@NotNull Pattern pattern, @Nullable String str, @NotNull String str2) {
            return setVersioning(new ManualVersioning(pattern, str, str2));
        }

        public Builder setVersioning(@NotNull Pattern pattern, @NotNull Route route) {
            return setVersioning(new AutomaticVersioning(pattern, route));
        }

        public Builder setVersioning(@NotNull Pattern pattern, @NotNull String str) {
            return setVersioning(new AutomaticVersioning(pattern, str));
        }

        public UpdaterSettings build() {
            return new UpdaterSettings(this);
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/settings/updater/UpdaterSettings$RouteMap.class */
    private static class RouteMap<R, S> {
        private Map<Route, R> routes;
        private Map<String, S> strings;
        private static transient /* synthetic */ String KaXhKhOglw = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        private RouteMap() {
            this.routes = null;
            this.strings = null;
        }

        @NotNull
        public <T> Map<Route, T> merge(@NotNull Function<R, T> function, @NotNull Function<S, T> function2, char c) {
            if ((this.routes == null || this.routes.isEmpty()) && (this.strings == null || this.strings.isEmpty())) {
                return Collections.emptyMap();
            }
            HashMap map = new HashMap();
            if (this.strings != null) {
                this.strings.forEach((str, obj) -> {
                    map.put(Route.fromString(str, c), function2.apply(obj));
                });
            }
            if (this.routes != null) {
                this.routes.forEach((route, obj2) -> {
                    map.put(route, function.apply(obj2));
                });
            }
            return map;
        }

        @NotNull
        public Map<Route, R> getRouteMap() {
            if (this.routes != null) {
                return this.routes;
            }
            HashMap map = new HashMap();
            this.routes = map;
            return map;
        }

        @NotNull
        public Map<String, S> getStringMap() {
            if (this.strings != null) {
                return this.strings;
            }
            HashMap map = new HashMap();
            this.strings = map;
            return map;
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/settings/updater/UpdaterSettings$RouteSet.class */
    private static class RouteSet {
        private Set<Route> routes;
        private Set<String> strings;
        private static transient /* synthetic */ String SluWGlGGev = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        private RouteSet() {
            this.routes = null;
            this.strings = null;
        }

        public Set<Route> merge(char c) {
            if ((this.routes == null || this.routes.isEmpty()) && (this.strings == null || this.strings.isEmpty())) {
                return Collections.emptySet();
            }
            HashSet hashSet = new HashSet();
            if (this.strings != null) {
                this.strings.forEach(str -> {
                    hashSet.add(Route.fromString(str, c));
                });
            }
            if (this.routes != null) {
                hashSet.addAll(this.routes);
            }
            return hashSet;
        }

        public Set<Route> getRouteSet() {
            if (this.routes != null) {
                return this.routes;
            }
            HashSet hashSet = new HashSet();
            this.routes = hashSet;
            return hashSet;
        }

        public Set<String> getStringSet() {
            if (this.strings != null) {
                return this.strings;
            }
            HashSet hashSet = new HashSet();
            this.strings = hashSet;
            return hashSet;
        }
    }
}
