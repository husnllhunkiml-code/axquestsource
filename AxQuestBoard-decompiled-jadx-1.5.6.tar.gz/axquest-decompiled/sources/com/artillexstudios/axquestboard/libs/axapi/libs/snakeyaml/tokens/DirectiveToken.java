package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.tokens;

import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.error.Mark;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.error.YAMLException;
import java.util.List;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/tokens/DirectiveToken.class */
public final class DirectiveToken<T> extends Token {
    private final String name;
    private final List<T> value;
    private static transient /* synthetic */ String QRniAsoOQj = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public DirectiveToken(String str, List<T> list, Mark mark, Mark mark2) {
        super(mark, mark2);
        this.name = str;
        if (list != null && list.size() != 2) {
            throw new YAMLException("Two strings must be provided instead of " + list.size());
        }
        this.value = list;
    }

    public String getName() {
        return this.name;
    }

    public List<T> getValue() {
        return this.value;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.tokens.Token
    public Token.ID getTokenId() {
        return Token.ID.Directive;
    }
}
