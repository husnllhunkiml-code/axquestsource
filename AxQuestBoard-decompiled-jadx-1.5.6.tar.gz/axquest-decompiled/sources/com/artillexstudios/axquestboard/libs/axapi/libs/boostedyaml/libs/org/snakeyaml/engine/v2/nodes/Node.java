package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.comments.CommentLine;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.Anchor;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.Mark;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/nodes/Node.class */
public abstract class Node {
    private final Optional<Mark> startMark;
    protected Optional<Mark> endMark;
    protected boolean resolved;
    private Tag tag;
    private boolean recursive;
    private Optional<Anchor> anchor;
    private List<CommentLine> inLineComments;
    private List<CommentLine> blockComments;
    private List<CommentLine> endComments;
    private Map<String, Object> properties;

    public abstract NodeType getNodeType();

    public Node(Tag tag, Optional<Mark> optional, Optional<Mark> optional2) {
        setTag(tag);
        this.startMark = optional;
        this.endMark = optional2;
        this.recursive = false;
        this.resolved = true;
        this.anchor = Optional.empty();
        this.inLineComments = null;
        this.blockComments = null;
        this.endComments = null;
        this.properties = null;
    }

    public Tag getTag() {
        return this.tag;
    }

    public void setTag(Tag tag) {
        Objects.requireNonNull(tag, "tag in a Node is required.");
        this.tag = tag;
    }

    public Optional<Mark> getEndMark() {
        return this.endMark;
    }

    public Optional<Mark> getStartMark() {
        return this.startMark;
    }

    public final boolean equals(Object obj) {
        return super.equals(obj);
    }

    public boolean isRecursive() {
        return this.recursive;
    }

    public void setRecursive(boolean z) {
        this.recursive = z;
    }

    public final int hashCode() {
        return super.hashCode();
    }

    public Optional<Anchor> getAnchor() {
        return this.anchor;
    }

    public void setAnchor(Optional<Anchor> optional) {
        this.anchor = optional;
    }

    public Object setProperty(String str, Object obj) {
        if (this.properties == null) {
            this.properties = new HashMap();
        }
        return this.properties.put(str, obj);
    }

    public Object getProperty(String str) {
        if (this.properties == null) {
            return null;
        }
        return this.properties.get(str);
    }

    public List<CommentLine> getInLineComments() {
        return this.inLineComments;
    }

    public void setInLineComments(List<CommentLine> list) {
        this.inLineComments = list;
    }

    public List<CommentLine> getBlockComments() {
        return this.blockComments;
    }

    public void setBlockComments(List<CommentLine> list) {
        this.blockComments = list;
    }

    public List<CommentLine> getEndComments() {
        return this.endComments;
    }

    public void setEndComments(List<CommentLine> list) {
        this.endComments = list;
    }
}
