package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.parser;

import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.DumperOptions;
import java.util.Map;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/parser/VersionTagsTuple.class */
class VersionTagsTuple {
    private final DumperOptions.Version version;
    private final Map<String, String> tags;
    private static transient /* synthetic */ String NSJRJsYTMu = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public VersionTagsTuple(DumperOptions.Version version, Map<String, String> map) {
        this.version = version;
        this.tags = map;
    }

    public DumperOptions.Version getVersion() {
        return this.version;
    }

    public Map<String, String> getTags() {
        return this.tags;
    }

    public String toString() {
        return String.format("VersionTagsTuple<%s, %s>", this.version, this.tags);
    }
}
