package com.artillexstudios.axquestboard.libs.axapi.gui.inventory;

import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.runtime.ObjectMethods;
import java.util.function.Consumer;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/gui/inventory/BakedGuiItem.class */
public final class BakedGuiItem extends Record {
    private final ItemStack stack;
    private final Consumer<InventoryClickEvent> eventConsumer;
    private static transient /* synthetic */ String CldngzVicR = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public BakedGuiItem(ItemStack stack, Consumer<InventoryClickEvent> eventConsumer) {
        this.stack = stack;
        this.eventConsumer = eventConsumer;
    }

    @Override // java.lang.Record
    public final String toString() {
        return (String) ObjectMethods.bootstrap(MethodHandles.lookup(), "toString", MethodType.methodType(String.class, BakedGuiItem.class), BakedGuiItem.class, "stack;eventConsumer", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/gui/inventory/BakedGuiItem;->stack:Lorg/bukkit/inventory/ItemStack;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/gui/inventory/BakedGuiItem;->eventConsumer:Ljava/util/function/Consumer;").dynamicInvoker().invoke(this) /* invoke-custom */;
    }

    @Override // java.lang.Record
    public final int hashCode() {
        return (int) ObjectMethods.bootstrap(MethodHandles.lookup(), "hashCode", MethodType.methodType(Integer.TYPE, BakedGuiItem.class), BakedGuiItem.class, "stack;eventConsumer", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/gui/inventory/BakedGuiItem;->stack:Lorg/bukkit/inventory/ItemStack;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/gui/inventory/BakedGuiItem;->eventConsumer:Ljava/util/function/Consumer;").dynamicInvoker().invoke(this) /* invoke-custom */;
    }

    @Override // java.lang.Record
    public final boolean equals(Object o) {
        return (boolean) ObjectMethods.bootstrap(MethodHandles.lookup(), "equals", MethodType.methodType(Boolean.TYPE, BakedGuiItem.class, Object.class), BakedGuiItem.class, "stack;eventConsumer", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/gui/inventory/BakedGuiItem;->stack:Lorg/bukkit/inventory/ItemStack;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/gui/inventory/BakedGuiItem;->eventConsumer:Ljava/util/function/Consumer;").dynamicInvoker().invoke(this, o) /* invoke-custom */;
    }

    public ItemStack stack() {
        return this.stack;
    }

    public Consumer<InventoryClickEvent> eventConsumer() {
        return this.eventConsumer;
    }
}
