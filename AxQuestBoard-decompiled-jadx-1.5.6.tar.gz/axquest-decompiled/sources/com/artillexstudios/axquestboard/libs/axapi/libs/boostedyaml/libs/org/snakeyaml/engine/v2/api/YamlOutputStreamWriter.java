package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/api/YamlOutputStreamWriter.class */
public abstract class YamlOutputStreamWriter extends OutputStreamWriter implements StreamDataWriter {
    public abstract void processIOException(IOException iOException);

    public YamlOutputStreamWriter(OutputStream outputStream, Charset charset) {
        super(outputStream, charset);
    }

    @Override // java.io.OutputStreamWriter, java.io.Writer, java.io.Flushable, com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.StreamDataWriter
    public void flush() {
        try {
            super.flush();
        } catch (IOException e) {
            processIOException(e);
        }
    }

    @Override // java.io.OutputStreamWriter, java.io.Writer, com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.StreamDataWriter
    public void write(String str, int i, int i2) {
        try {
            super.write(str, i, i2);
        } catch (IOException e) {
            processIOException(e);
        }
    }

    @Override // java.io.Writer, com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.StreamDataWriter
    public void write(String str) {
        try {
            super.write(str);
        } catch (IOException e) {
            processIOException(e);
        }
    }
}
