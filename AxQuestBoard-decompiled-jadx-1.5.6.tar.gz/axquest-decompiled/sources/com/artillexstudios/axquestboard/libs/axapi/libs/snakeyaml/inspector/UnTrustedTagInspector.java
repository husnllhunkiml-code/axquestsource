package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.inspector;

import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.nodes.Tag;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/inspector/UnTrustedTagInspector.class */
public final class UnTrustedTagInspector implements TagInspector {
    private static transient /* synthetic */ String ovcgdAspwO = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.inspector.TagInspector
    public boolean isGlobalTagAllowed(Tag tag) {
        return false;
    }
}
