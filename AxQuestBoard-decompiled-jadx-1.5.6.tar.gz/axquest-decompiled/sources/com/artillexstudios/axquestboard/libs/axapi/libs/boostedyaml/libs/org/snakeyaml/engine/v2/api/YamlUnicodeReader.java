package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PushbackInputStream;
import java.io.Reader;
import java.nio.charset.Charset;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/api/YamlUnicodeReader.class */
public class YamlUnicodeReader extends Reader {
    private static final Charset UTF8 = StandardCharsets.UTF_8;
    private static final Charset UTF16BE = StandardCharsets.UTF_16BE;
    private static final Charset UTF16LE = StandardCharsets.UTF_16LE;
    private static final Charset UTF32BE = Charset.forName("UTF-32BE");
    private static final Charset UTF32LE = Charset.forName("UTF-32LE");
    private static final int BOM_SIZE = 4;
    PushbackInputStream internalIn;
    InputStreamReader internalIn2 = null;
    Charset encoding = UTF8;
    private static transient /* synthetic */ String bbHnLdsXSU = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public YamlUnicodeReader(InputStream inputStream) {
        this.internalIn = new PushbackInputStream(inputStream, BOM_SIZE);
    }

    public Charset getEncoding() {
        return this.encoding;
    }

    protected void init() throws IOException {
        int i;
        if (this.internalIn2 != null) {
            return;
        }
        byte[] bArr = new byte[BOM_SIZE];
        int i2 = this.internalIn.read(bArr, 0, bArr.length);
        if (bArr[0] == 0 && bArr[1] == 0 && bArr[2] == -2 && bArr[3] == -1) {
            this.encoding = UTF32BE;
            i = i2 - BOM_SIZE;
        } else if (bArr[0] == -1 && bArr[1] == -2 && bArr[2] == 0 && bArr[3] == 0) {
            this.encoding = UTF32LE;
            i = i2 - BOM_SIZE;
        } else if (bArr[0] == -17 && bArr[1] == -69 && bArr[2] == -65) {
            this.encoding = UTF8;
            i = i2 - 3;
        } else if (bArr[0] == -2 && bArr[1] == -1) {
            this.encoding = UTF16BE;
            i = i2 - 2;
        } else if (bArr[0] == -1 && bArr[1] == -2) {
            this.encoding = UTF16LE;
            i = i2 - 2;
        } else {
            this.encoding = UTF8;
            i = i2;
        }
        if (i > 0) {
            this.internalIn.unread(bArr, i2 - i, i);
        }
        this.internalIn2 = new InputStreamReader(this.internalIn, this.encoding.newDecoder().onUnmappableCharacter(CodingErrorAction.REPORT));
    }

    @Override // java.io.Reader, java.io.Closeable, java.lang.AutoCloseable
    public void close() throws IOException {
        init();
        this.internalIn2.close();
    }

    @Override // java.io.Reader
    public int read(char[] cArr, int i, int i2) throws IOException {
        init();
        return this.internalIn2.read(cArr, i, i2);
    }
}
