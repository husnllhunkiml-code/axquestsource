package com.artillexstudios.axquestboard.libs.axapi.database;

import it.unimi.dsi.fastutil.objects.Object2ObjectArrayMap;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.util.List;
import java.util.Map;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/database/DatabaseTypes.class */
public class DatabaseTypes {
    private static DatabaseType defaultType;
    private static final Object2ObjectArrayMap<String, DatabaseType> registry = new Object2ObjectArrayMap<>();
    private static transient /* synthetic */ String GaRPmWcdGL = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public static DatabaseType defaultType() {
        return defaultType;
    }

    public static DatabaseType register(DatabaseType type) {
        return register(type, false);
    }

    public static DatabaseType register(DatabaseType type, boolean def) {
        registry.put(type.name(), type);
        if (def) {
            defaultType = type;
        }
        return type;
    }

    public static DatabaseType fetch(String name) {
        ObjectIterator it = registry.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry entry = (Map.Entry) it.next();
            if (((String) entry.getKey()).equalsIgnoreCase(name)) {
                return (DatabaseType) entry.getValue();
            }
        }
        return null;
    }

    public static List<String> keys() {
        return registry.keySet().stream().toList();
    }
}
