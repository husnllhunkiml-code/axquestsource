package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.utils.supplier;

import java.util.Set;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/utils/supplier/SetSupplier.class */
public interface SetSupplier {
    @NotNull
    <T> Set<T> supply(int i);
}
