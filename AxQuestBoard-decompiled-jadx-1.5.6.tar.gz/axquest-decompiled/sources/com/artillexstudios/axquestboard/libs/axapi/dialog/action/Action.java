package com.artillexstudios.axquestboard.libs.axapi.dialog.action;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/dialog/action/Action.class */
public interface Action {
}
