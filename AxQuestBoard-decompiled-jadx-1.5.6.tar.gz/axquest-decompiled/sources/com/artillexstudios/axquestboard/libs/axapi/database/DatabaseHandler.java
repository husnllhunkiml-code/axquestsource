package com.artillexstudios.axquestboard.libs.axapi.database;

import com.artillexstudios.axquestboard.libs.axapi.AxPlugin;
import com.artillexstudios.axquestboard.libs.axapi.database.handler.SimpleHandler;
import com.artillexstudios.axquestboard.libs.axapi.database.impl.MySQLDatabaseType;
import com.artillexstudios.axquestboard.libs.axapi.libs.hikari.HikariConfig;
import com.artillexstudios.axquestboard.libs.axapi.libs.hikari.HikariDataSource;
import com.artillexstudios.axquestboard.libs.axapi.utils.logging.LogUtils;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.function.Function;
import java.util.function.Supplier;
import net.kyori.adventure.text.serializer.commons.ComponentTreeConstants;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/database/DatabaseHandler.class */
public class DatabaseHandler {
    private final AxPlugin plugin;
    private final DatabaseConfig config;
    private final Supplier<Connection> connectionSupplier;
    private HikariDataSource dataSource;
    private static transient /* synthetic */ String kEdzQBXlLd = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public DatabaseHandler(AxPlugin plugin, DatabaseConfig config, Supplier<Connection> connectionSupplier) {
        this.plugin = plugin;
        this.config = config;
        this.connectionSupplier = connectionSupplier;
    }

    public DatabaseHandler(AxPlugin plugin, DatabaseConfig config) {
        this.plugin = plugin;
        this.config = config;
        this.connectionSupplier = createHikariConfig();
    }

    private Supplier<Connection> createHikariConfig() {
        HikariConfig hikariConfigConfig = this.config.type.config(this.config);
        hikariConfigConfig.setPoolName("axapi-" + this.plugin.getName() + "-database-pool");
        editConfig(hikariConfigConfig);
        if (this.config.url != null && !(this.config.type instanceof MySQLDatabaseType)) {
            hikariConfigConfig.addDataSourceProperty(ComponentTreeConstants.CLICK_EVENT_URL, this.config.url);
        }
        this.dataSource = new HikariDataSource(hikariConfigConfig);
        return () -> {
            try {
                return this.dataSource.getConnection();
            } catch (SQLException e) {
                LogUtils.error("Failed to acquire connection from datasource!", e);
                throw new RuntimeException(e);
            }
        };
    }

    public void editConfig(HikariConfig config) {
    }

    public <T, Z> void addTransformer(Class<T> clazz, Function<T, List<Z>> from) {
        this.config.type.registerTransformer(clazz, from);
    }

    public Function<Object, List<Object>> transformer(Class<?> clazz) {
        return this.config.type.transformers(clazz);
    }

    public <T> DatabaseQuery<T> rawQuery(String sql) {
        return rawQuery(sql, new SimpleHandler());
    }

    public <T> DatabaseQuery<T> rawQuery(String sql, ResultHandler<T> resultHandler) {
        return new DatabaseQuery<>(this, resultHandler, processSQL(sql));
    }

    public <T> DatabaseQuery<T> query(String name) {
        return query(name, new SimpleHandler());
    }

    public <T> DatabaseQuery<T> query(String name, ResultHandler<T> resultHandler) {
        return new DatabaseQuery<>(this, resultHandler, processSQL(fetchQuery(name)));
    }

    private String fetchQuery(String name) {
        try {
            return fetchQuery0(name);
        } catch (IOException e) {
            LogUtils.error("An exception occurred while fetching query {}!", name, e);
            throw new RuntimeException(e);
        }
    }

    private String processSQL(String sql) {
        return sql.replace("$table_prefix", this.config.tablePrefix());
    }

    private String fetchQuery0(String name) throws IOException {
        InputStream resource = null;
        Path pathResolve = this.plugin.getDataFolder().toPath().resolve("sql/" + this.config.type.name() + "/" + name + ".sql");
        if (Files.exists(pathResolve, new LinkOption[0])) {
            resource = Files.newInputStream(pathResolve, new OpenOption[0]);
        }
        Path pathResolve2 = this.plugin.getDataFolder().toPath().resolve("sql/base/" + name + ".sql");
        if (Files.exists(pathResolve2, new LinkOption[0])) {
            resource = Files.newInputStream(pathResolve2, new OpenOption[0]);
        }
        if (resource == null) {
            resource = this.plugin.getResource("sql/" + this.config.type.name() + "/" + name + ".sql");
        }
        if (resource == null) {
            resource = this.plugin.getResource("sql/base/" + name + ".sql");
        }
        if (resource == null) {
            LogUtils.warn("Failed to find sql query with name {}!", name);
            return "";
        }
        try {
            return new String(resource.readAllBytes(), StandardCharsets.UTF_8);
        } finally {
            resource.close();
        }
    }

    public Connection connection() {
        return this.connectionSupplier.get();
    }

    public void close() {
        if (this.dataSource == null) {
            return;
        }
        this.dataSource.close();
    }
}
