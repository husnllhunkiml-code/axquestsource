package com.artillexstudios.axquestboard.libs.axapi.items.nbt;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/items/nbt/ListTag.class */
public interface ListTag extends Tag {
    void add(Tag tag);

    void remove(Tag tag);

    boolean contains(Tag tag);
}
