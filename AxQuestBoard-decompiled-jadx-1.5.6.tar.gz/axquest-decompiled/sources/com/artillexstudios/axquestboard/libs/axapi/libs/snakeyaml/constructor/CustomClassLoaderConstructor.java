package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.constructor;

import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.LoaderOptions;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/constructor/CustomClassLoaderConstructor.class */
public class CustomClassLoaderConstructor extends Constructor {
    private final ClassLoader loader;
    private static transient /* synthetic */ String kFCCGKaJfx = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public CustomClassLoaderConstructor(ClassLoader classLoader, LoaderOptions loaderOptions) {
        this(Object.class, classLoader, loaderOptions);
    }

    public CustomClassLoaderConstructor(Class<? extends Object> cls, ClassLoader classLoader, LoaderOptions loaderOptions) {
        super(cls, loaderOptions);
        if (classLoader == null) {
            throw new NullPointerException("Loader must be provided.");
        }
        this.loader = classLoader;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.constructor.Constructor
    protected Class<?> getClassForName(String str) {
        return Class.forName(str, true, this.loader);
    }
}
