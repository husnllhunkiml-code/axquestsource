package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.LoadSettings;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.ArrayStack;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.FlowStyle;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.ScalarStyle;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.SpecVersion;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.AliasEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.CommentEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.DocumentEndEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.DocumentStartEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.Event;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.ImplicitTuple;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.MappingEndEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.MappingStartEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.ScalarEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.SequenceEndEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.SequenceStartEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.StreamEndEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.StreamStartEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.Mark;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.ParserException;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.YamlEngineException;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.scanner.Scanner;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.scanner.ScannerImpl;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.scanner.StreamReader;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.AliasToken;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.AnchorToken;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.BlockEntryToken;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.CommentToken;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.DirectiveToken;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.ScalarToken;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.StreamEndToken;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.StreamStartToken;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.TagToken;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.TagTuple;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.Token;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Optional;
import net.kyori.adventure.text.minimessage.tag.standard.DecorationTag;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/parser/ParserImpl.class */
public class ParserImpl implements Parser {
    private static final Map<String, String> DEFAULT_TAGS = new HashMap();
    protected final Scanner scanner;
    private final LoadSettings settings;
    private final ArrayStack<Production> states;
    private final ArrayStack<Optional<Mark>> marksStack;
    private Optional<Event> currentEvent;
    private Optional<Production> state;
    private Map<String, String> directiveTags;
    private static transient /* synthetic */ String MWeBFGOmQh = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    /* JADX INFO: renamed from: com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser.ParserImpl$1 */
    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/parser/ParserImpl$1.class */
    static /* synthetic */ class C00191 {
        private static transient /* synthetic */ String SfCBAnffXo = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";
    }

    static {
        DEFAULT_TAGS.put(DecorationTag.REVERT, DecorationTag.REVERT);
        DEFAULT_TAGS.put("!!", "tag:yaml.org,2002:");
    }

    @Deprecated
    public ParserImpl(StreamReader streamReader, LoadSettings loadSettings) {
        this(loadSettings, streamReader);
    }

    public ParserImpl(LoadSettings loadSettings, StreamReader streamReader) {
        this(loadSettings, new ScannerImpl(loadSettings, streamReader));
    }

    @Deprecated
    public ParserImpl(Scanner scanner, LoadSettings loadSettings) {
        this(loadSettings, scanner);
    }

    public ParserImpl(LoadSettings loadSettings, Scanner scanner) {
        this.scanner = scanner;
        this.settings = loadSettings;
        this.currentEvent = Optional.empty();
        this.directiveTags = new HashMap(DEFAULT_TAGS);
        this.states = new ArrayStack<>(100);
        this.marksStack = new ArrayStack<>(10);
        this.state = Optional.of(new ParseStreamStart(this, null));
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser.Parser
    public boolean checkEvent(Event.ID id) {
        peekEvent();
        return this.currentEvent.isPresent() && this.currentEvent.get().getEventId() == id;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser.Parser
    public Event peekEvent() {
        produce();
        return this.currentEvent.orElseThrow(() -> {
            return new NoSuchElementException("No more Events found.");
        });
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser.Parser, java.util.Iterator
    public Event next() {
        Event eventPeekEvent = peekEvent();
        this.currentEvent = Optional.empty();
        return eventPeekEvent;
    }

    @Override // java.util.Iterator
    public boolean hasNext() {
        produce();
        return this.currentEvent.isPresent();
    }

    private void produce() {
        if (!this.currentEvent.isPresent()) {
            this.state.ifPresent(production -> {
                this.currentEvent = Optional.of(production.produce());
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public CommentEvent produceCommentEvent(CommentToken commentToken) {
        return new CommentEvent(commentToken.getCommentType(), commentToken.getValue(), commentToken.getStartMark(), commentToken.getEndMark());
    }

    /* JADX INFO: Access modifiers changed from: private */
    public VersionTagsTuple processDirectives() {
        Optional optionalEmpty = Optional.empty();
        HashMap map = new HashMap();
        while (this.scanner.checkToken(Token.ID.Directive)) {
            DirectiveToken directiveToken = (DirectiveToken) this.scanner.next();
            Optional value = directiveToken.getValue();
            if (value.isPresent()) {
                List list = (List) value.get();
                if (directiveToken.getName().equals(DirectiveToken.YAML_DIRECTIVE)) {
                    if (optionalEmpty.isPresent()) {
                        throw new ParserException("found duplicate YAML directive", directiveToken.getStartMark());
                    }
                    optionalEmpty = Optional.of(this.settings.getVersionFunction().apply(new SpecVersion(((Integer) list.get(0)).intValue(), ((Integer) list.get(1)).intValue())));
                } else if (directiveToken.getName().equals(DirectiveToken.TAG_DIRECTIVE)) {
                    String str = (String) list.get(0);
                    String str2 = (String) list.get(1);
                    if (map.containsKey(str)) {
                        throw new ParserException("duplicate tag handle " + str, directiveToken.getStartMark());
                    }
                    map.put(str, str2);
                } else {
                    continue;
                }
            }
        }
        HashMap map2 = new HashMap();
        if (!map.isEmpty()) {
            map2.putAll(map);
        }
        for (Map.Entry<String, String> entry : DEFAULT_TAGS.entrySet()) {
            if (!map.containsKey(entry.getKey())) {
                map.put(entry.getKey(), entry.getValue());
            }
        }
        this.directiveTags = map;
        return new VersionTagsTuple(optionalEmpty, map2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public Event parseFlowNode() {
        return parseNode(false, false);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public Event parseBlockNodeOrIndentlessSequence() {
        return parseNode(true, true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public Event parseNode(boolean z, boolean z2) {
        Event scalarEvent;
        ImplicitTuple implicitTuple;
        Optional<Mark> optionalEmpty = Optional.empty();
        Optional<Mark> optionalEmpty2 = Optional.empty();
        Optional<Mark> optionalEmpty3 = Optional.empty();
        if (this.scanner.checkToken(Token.ID.Alias)) {
            AliasToken aliasToken = (AliasToken) this.scanner.next();
            scalarEvent = new AliasEvent(Optional.of(aliasToken.getValue()), aliasToken.getStartMark(), aliasToken.getEndMark());
            this.state = Optional.of(this.states.pop());
        } else {
            Optional optionalEmpty4 = Optional.empty();
            TagTuple value = null;
            if (this.scanner.checkToken(Token.ID.Anchor)) {
                AnchorToken anchorToken = (AnchorToken) this.scanner.next();
                optionalEmpty = anchorToken.getStartMark();
                optionalEmpty2 = anchorToken.getEndMark();
                optionalEmpty4 = Optional.of(anchorToken.getValue());
                if (this.scanner.checkToken(Token.ID.Tag)) {
                    TagToken tagToken = (TagToken) this.scanner.next();
                    optionalEmpty3 = tagToken.getStartMark();
                    optionalEmpty2 = tagToken.getEndMark();
                    value = tagToken.getValue();
                }
            } else if (this.scanner.checkToken(Token.ID.Tag)) {
                TagToken tagToken2 = (TagToken) this.scanner.next();
                optionalEmpty = tagToken2.getStartMark();
                optionalEmpty3 = optionalEmpty;
                optionalEmpty2 = tagToken2.getEndMark();
                value = tagToken2.getValue();
                if (this.scanner.checkToken(Token.ID.Anchor)) {
                    AnchorToken anchorToken2 = (AnchorToken) this.scanner.next();
                    optionalEmpty2 = anchorToken2.getEndMark();
                    optionalEmpty4 = Optional.of(anchorToken2.getValue());
                }
            }
            Optional optionalEmpty5 = Optional.empty();
            if (value != null) {
                Optional<String> handle = value.getHandle();
                String suffix = value.getSuffix();
                if (handle.isPresent()) {
                    String str = handle.get();
                    if (!this.directiveTags.containsKey(str)) {
                        throw new ParserException("while parsing a node", optionalEmpty, "found undefined tag handle " + str, optionalEmpty3);
                    }
                    optionalEmpty5 = Optional.of(this.directiveTags.get(str) + suffix);
                } else {
                    optionalEmpty5 = Optional.of(suffix);
                }
            }
            if (!optionalEmpty.isPresent()) {
                optionalEmpty = this.scanner.peekToken().getStartMark();
                optionalEmpty2 = optionalEmpty;
            }
            boolean z3 = !optionalEmpty5.isPresent();
            if (z2 && this.scanner.checkToken(Token.ID.BlockEntry)) {
                scalarEvent = new SequenceStartEvent(optionalEmpty4, optionalEmpty5, z3, FlowStyle.BLOCK, optionalEmpty, this.scanner.peekToken().getEndMark());
                this.state = Optional.of(new ParseIndentlessSequenceEntryKey(this, null));
            } else if (this.scanner.checkToken(Token.ID.Scalar)) {
                ScalarToken scalarToken = (ScalarToken) this.scanner.next();
                Optional<Mark> endMark = scalarToken.getEndMark();
                if (scalarToken.isPlain() && !optionalEmpty5.isPresent()) {
                    implicitTuple = new ImplicitTuple(true, false);
                } else if (!optionalEmpty5.isPresent()) {
                    implicitTuple = new ImplicitTuple(false, true);
                } else {
                    implicitTuple = new ImplicitTuple(false, false);
                }
                scalarEvent = new ScalarEvent(optionalEmpty4, optionalEmpty5, implicitTuple, scalarToken.getValue(), scalarToken.getStyle(), optionalEmpty, endMark);
                this.state = Optional.of(this.states.pop());
            } else if (this.scanner.checkToken(Token.ID.FlowSequenceStart)) {
                scalarEvent = new SequenceStartEvent(optionalEmpty4, optionalEmpty5, z3, FlowStyle.FLOW, optionalEmpty, this.scanner.peekToken().getEndMark());
                this.state = Optional.of(new ParseFlowSequenceFirstEntry(this, null));
            } else if (this.scanner.checkToken(Token.ID.FlowMappingStart)) {
                scalarEvent = new MappingStartEvent(optionalEmpty4, optionalEmpty5, z3, FlowStyle.FLOW, optionalEmpty, this.scanner.peekToken().getEndMark());
                this.state = Optional.of(new ParseFlowMappingFirstKey(this, null));
            } else if (z && this.scanner.checkToken(Token.ID.BlockSequenceStart)) {
                scalarEvent = new SequenceStartEvent(optionalEmpty4, optionalEmpty5, z3, FlowStyle.BLOCK, optionalEmpty, this.scanner.peekToken().getStartMark());
                this.state = Optional.of(new ParseBlockSequenceFirstEntry(this, null));
            } else if (z && this.scanner.checkToken(Token.ID.BlockMappingStart)) {
                scalarEvent = new MappingStartEvent(optionalEmpty4, optionalEmpty5, z3, FlowStyle.BLOCK, optionalEmpty, this.scanner.peekToken().getStartMark());
                this.state = Optional.of(new ParseBlockMappingFirstKey(this, null));
            } else if (optionalEmpty4.isPresent() || optionalEmpty5.isPresent()) {
                scalarEvent = new ScalarEvent(optionalEmpty4, optionalEmpty5, new ImplicitTuple(z3, false), "", ScalarStyle.PLAIN, optionalEmpty, optionalEmpty2);
                this.state = Optional.of(this.states.pop());
            } else {
                Token tokenPeekToken = this.scanner.peekToken();
                throw new ParserException("while parsing a " + (z ? "block" : "flow") + " node", optionalEmpty, "expected the node content, but found '" + tokenPeekToken.getTokenId() + "'", tokenPeekToken.getStartMark());
            }
        }
        return scalarEvent;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public Event processEmptyScalar(Optional<Mark> optional) {
        return new ScalarEvent(Optional.empty(), Optional.empty(), new ImplicitTuple(true, false), "", ScalarStyle.PLAIN, optional, optional);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public Optional<Mark> markPop() {
        return this.marksStack.pop();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void markPush(Optional<Mark> optional) {
        this.marksStack.push(optional);
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/parser/ParserImpl$ParseStreamStart.class */
    private class ParseStreamStart implements Production {
        private static transient /* synthetic */ String xGWoOnaoxb = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        private ParseStreamStart() {
        }

        /* synthetic */ ParseStreamStart(ParserImpl parserImpl, C00191 c00191) {
            this();
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser.Production
        public Event produce() {
            StreamStartToken streamStartToken = (StreamStartToken) ParserImpl.this.scanner.next();
            StreamStartEvent streamStartEvent = new StreamStartEvent(streamStartToken.getStartMark(), streamStartToken.getEndMark());
            ParserImpl.this.state = Optional.of(new ParseImplicitDocumentStart(ParserImpl.this, null));
            return streamStartEvent;
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/parser/ParserImpl$ParseImplicitDocumentStart.class */
    private class ParseImplicitDocumentStart implements Production {
        private static transient /* synthetic */ String fOOTBMccWq = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        private ParseImplicitDocumentStart() {
        }

        /* synthetic */ ParseImplicitDocumentStart(ParserImpl parserImpl, C00191 c00191) {
            this();
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser.Production
        public Event produce() {
            if (ParserImpl.this.scanner.checkToken(Token.ID.Comment)) {
                ParserImpl.this.state = Optional.of(ParserImpl.this.new ParseImplicitDocumentStart());
                return ParserImpl.this.produceCommentEvent((CommentToken) ParserImpl.this.scanner.next());
            }
            if (!ParserImpl.this.scanner.checkToken(Token.ID.Directive, Token.ID.DocumentStart, Token.ID.StreamEnd)) {
                Optional<Mark> startMark = ParserImpl.this.scanner.peekToken().getStartMark();
                DocumentStartEvent documentStartEvent = new DocumentStartEvent(false, Optional.empty(), Collections.emptyMap(), startMark, startMark);
                ParserImpl.this.states.push(new ParseDocumentEnd(ParserImpl.this, null));
                ParserImpl.this.state = Optional.of(new ParseBlockNode(ParserImpl.this, null));
                return documentStartEvent;
            }
            return new ParseDocumentStart(ParserImpl.this, null).produce();
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/parser/ParserImpl$ParseDocumentStart.class */
    private class ParseDocumentStart implements Production {
        private static transient /* synthetic */ String FDqEmKYdCt = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        private ParseDocumentStart() {
        }

        /* synthetic */ ParseDocumentStart(ParserImpl parserImpl, C00191 c00191) {
            this();
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser.Production
        public Event produce() {
            if (ParserImpl.this.scanner.checkToken(Token.ID.Comment)) {
                ParserImpl.this.state = Optional.of(ParserImpl.this.new ParseDocumentStart());
                return ParserImpl.this.produceCommentEvent((CommentToken) ParserImpl.this.scanner.next());
            }
            while (ParserImpl.this.scanner.checkToken(Token.ID.DocumentEnd)) {
                ParserImpl.this.scanner.next();
            }
            if (ParserImpl.this.scanner.checkToken(Token.ID.Comment)) {
                ParserImpl.this.state = Optional.of(ParserImpl.this.new ParseDocumentStart());
                return ParserImpl.this.produceCommentEvent((CommentToken) ParserImpl.this.scanner.next());
            }
            if (!ParserImpl.this.scanner.checkToken(Token.ID.StreamEnd)) {
                ParserImpl.this.scanner.resetDocumentIndex();
                Optional<Mark> startMark = ParserImpl.this.scanner.peekToken().getStartMark();
                VersionTagsTuple versionTagsTupleProcessDirectives = ParserImpl.this.processDirectives();
                while (ParserImpl.this.scanner.checkToken(Token.ID.Comment)) {
                    ParserImpl.this.scanner.next();
                }
                if (ParserImpl.this.scanner.checkToken(Token.ID.StreamEnd)) {
                    throw new ParserException("expected '<document start>', but found '" + ParserImpl.this.scanner.peekToken().getTokenId() + "'", ParserImpl.this.scanner.peekToken().getStartMark());
                }
                if (!ParserImpl.this.scanner.checkToken(Token.ID.DocumentStart)) {
                    throw new ParserException("expected '<document start>', but found '" + ParserImpl.this.scanner.peekToken().getTokenId() + "'", ParserImpl.this.scanner.peekToken().getStartMark());
                }
                DocumentStartEvent documentStartEvent = new DocumentStartEvent(true, versionTagsTupleProcessDirectives.getSpecVersion(), versionTagsTupleProcessDirectives.getTags(), startMark, ParserImpl.this.scanner.next().getEndMark());
                ParserImpl.this.states.push(new ParseDocumentEnd(ParserImpl.this, null));
                ParserImpl.this.state = Optional.of(new ParseDocumentContent(ParserImpl.this, null));
                return documentStartEvent;
            }
            StreamEndToken streamEndToken = (StreamEndToken) ParserImpl.this.scanner.next();
            StreamEndEvent streamEndEvent = new StreamEndEvent(streamEndToken.getStartMark(), streamEndToken.getEndMark());
            if (!ParserImpl.this.states.isEmpty()) {
                throw new YamlEngineException("Unexpected end of stream. States left: " + ParserImpl.this.states);
            }
            if (markEmpty()) {
                ParserImpl.this.state = Optional.empty();
                return streamEndEvent;
            }
            throw new YamlEngineException("Unexpected end of stream. Marks left: " + ParserImpl.this.marksStack);
        }

        private boolean markEmpty() {
            return ParserImpl.this.marksStack.isEmpty();
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/parser/ParserImpl$ParseDocumentEnd.class */
    private class ParseDocumentEnd implements Production {
        private static transient /* synthetic */ String qgIONBtrSC = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        private ParseDocumentEnd() {
        }

        /* synthetic */ ParseDocumentEnd(ParserImpl parserImpl, C00191 c00191) {
            this();
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser.Production
        public Event produce() {
            Optional<Mark> startMark = ParserImpl.this.scanner.peekToken().getStartMark();
            Optional<Mark> endMark = startMark;
            boolean z = false;
            if (ParserImpl.this.scanner.checkToken(Token.ID.DocumentEnd)) {
                endMark = ParserImpl.this.scanner.next().getEndMark();
                z = true;
            } else if (ParserImpl.this.scanner.checkToken(Token.ID.Directive)) {
                throw new ParserException("expected '<document end>' before directives, but found '" + ParserImpl.this.scanner.peekToken().getTokenId() + "'", ParserImpl.this.scanner.peekToken().getStartMark());
            }
            ParserImpl.this.directiveTags.clear();
            DocumentEndEvent documentEndEvent = new DocumentEndEvent(z, startMark, endMark);
            ParserImpl.this.state = Optional.of(new ParseDocumentStart(ParserImpl.this, null));
            return documentEndEvent;
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/parser/ParserImpl$ParseDocumentContent.class */
    private class ParseDocumentContent implements Production {
        private static transient /* synthetic */ String TMllPszLbM = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        private ParseDocumentContent() {
        }

        /* synthetic */ ParseDocumentContent(ParserImpl parserImpl, C00191 c00191) {
            this();
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser.Production
        public Event produce() {
            if (ParserImpl.this.scanner.checkToken(Token.ID.Comment)) {
                ParserImpl.this.state = Optional.of(ParserImpl.this.new ParseDocumentContent());
                return ParserImpl.this.produceCommentEvent((CommentToken) ParserImpl.this.scanner.next());
            }
            if (ParserImpl.this.scanner.checkToken(Token.ID.Directive, Token.ID.DocumentStart, Token.ID.DocumentEnd, Token.ID.StreamEnd)) {
                Event eventProcessEmptyScalar = ParserImpl.this.processEmptyScalar(ParserImpl.this.scanner.peekToken().getStartMark());
                ParserImpl.this.state = Optional.of((Production) ParserImpl.this.states.pop());
                return eventProcessEmptyScalar;
            }
            return new ParseBlockNode(ParserImpl.this, null).produce();
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/parser/ParserImpl$ParseBlockNode.class */
    private class ParseBlockNode implements Production {
        private static transient /* synthetic */ String bRyJjndGNj = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        private ParseBlockNode() {
        }

        /* synthetic */ ParseBlockNode(ParserImpl parserImpl, C00191 c00191) {
            this();
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser.Production
        public Event produce() {
            return ParserImpl.this.parseNode(true, false);
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/parser/ParserImpl$ParseBlockSequenceFirstEntry.class */
    private class ParseBlockSequenceFirstEntry implements Production {
        private static transient /* synthetic */ String hCAZoKAXlv = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        private ParseBlockSequenceFirstEntry() {
        }

        /* synthetic */ ParseBlockSequenceFirstEntry(ParserImpl parserImpl, C00191 c00191) {
            this();
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser.Production
        public Event produce() {
            ParserImpl.this.markPush(ParserImpl.this.scanner.next().getStartMark());
            return new ParseBlockSequenceEntryKey(ParserImpl.this, null).produce();
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/parser/ParserImpl$ParseBlockSequenceEntryKey.class */
    private class ParseBlockSequenceEntryKey implements Production {
        private static transient /* synthetic */ String RgdCtiyoJa = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        private ParseBlockSequenceEntryKey() {
        }

        /* synthetic */ ParseBlockSequenceEntryKey(ParserImpl parserImpl, C00191 c00191) {
            this();
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser.Production
        public Event produce() {
            if (ParserImpl.this.scanner.checkToken(Token.ID.Comment)) {
                ParserImpl.this.state = Optional.of(ParserImpl.this.new ParseBlockSequenceEntryKey());
                return ParserImpl.this.produceCommentEvent((CommentToken) ParserImpl.this.scanner.next());
            }
            if (ParserImpl.this.scanner.checkToken(Token.ID.BlockEntry)) {
                return ParserImpl.this.new ParseBlockSequenceEntryValue((BlockEntryToken) ParserImpl.this.scanner.next()).produce();
            }
            if (!ParserImpl.this.scanner.checkToken(Token.ID.BlockEnd)) {
                Token tokenPeekToken = ParserImpl.this.scanner.peekToken();
                throw new ParserException("while parsing a block collection", ParserImpl.this.markPop(), "expected <block end>, but found '" + tokenPeekToken.getTokenId() + "'", tokenPeekToken.getStartMark());
            }
            Token next = ParserImpl.this.scanner.next();
            SequenceEndEvent sequenceEndEvent = new SequenceEndEvent(next.getStartMark(), next.getEndMark());
            ParserImpl.this.state = Optional.of((Production) ParserImpl.this.states.pop());
            ParserImpl.this.markPop();
            return sequenceEndEvent;
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/parser/ParserImpl$ParseBlockSequenceEntryValue.class */
    private class ParseBlockSequenceEntryValue implements Production {
        BlockEntryToken token;
        private static transient /* synthetic */ String bwEJtwskqH = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        public ParseBlockSequenceEntryValue(BlockEntryToken blockEntryToken) {
            this.token = blockEntryToken;
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser.Production
        public Event produce() {
            if (ParserImpl.this.scanner.checkToken(Token.ID.Comment)) {
                ParserImpl.this.state = Optional.of(ParserImpl.this.new ParseBlockSequenceEntryValue(this.token));
                return ParserImpl.this.produceCommentEvent((CommentToken) ParserImpl.this.scanner.next());
            }
            if (!ParserImpl.this.scanner.checkToken(Token.ID.BlockEntry, Token.ID.BlockEnd)) {
                ParserImpl.this.states.push(new ParseBlockSequenceEntryKey(ParserImpl.this, null));
                return new ParseBlockNode(ParserImpl.this, null).produce();
            }
            ParserImpl.this.state = Optional.of(new ParseBlockSequenceEntryKey(ParserImpl.this, null));
            return ParserImpl.this.processEmptyScalar(this.token.getEndMark());
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/parser/ParserImpl$ParseIndentlessSequenceEntryKey.class */
    private class ParseIndentlessSequenceEntryKey implements Production {
        private static transient /* synthetic */ String xAnozlFJIq = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        private ParseIndentlessSequenceEntryKey() {
        }

        /* synthetic */ ParseIndentlessSequenceEntryKey(ParserImpl parserImpl, C00191 c00191) {
            this();
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser.Production
        public Event produce() {
            if (ParserImpl.this.scanner.checkToken(Token.ID.Comment)) {
                ParserImpl.this.state = Optional.of(ParserImpl.this.new ParseIndentlessSequenceEntryKey());
                return ParserImpl.this.produceCommentEvent((CommentToken) ParserImpl.this.scanner.next());
            }
            if (ParserImpl.this.scanner.checkToken(Token.ID.BlockEntry)) {
                return ParserImpl.this.new ParseIndentlessSequenceEntryValue((BlockEntryToken) ParserImpl.this.scanner.next()).produce();
            }
            Token tokenPeekToken = ParserImpl.this.scanner.peekToken();
            SequenceEndEvent sequenceEndEvent = new SequenceEndEvent(tokenPeekToken.getStartMark(), tokenPeekToken.getEndMark());
            ParserImpl.this.state = Optional.of((Production) ParserImpl.this.states.pop());
            return sequenceEndEvent;
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/parser/ParserImpl$ParseIndentlessSequenceEntryValue.class */
    private class ParseIndentlessSequenceEntryValue implements Production {
        BlockEntryToken token;
        private static transient /* synthetic */ String DWnUaVCgSw = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        public ParseIndentlessSequenceEntryValue(BlockEntryToken blockEntryToken) {
            this.token = blockEntryToken;
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser.Production
        public Event produce() {
            if (ParserImpl.this.scanner.checkToken(Token.ID.Comment)) {
                ParserImpl.this.state = Optional.of(ParserImpl.this.new ParseIndentlessSequenceEntryValue(this.token));
                return ParserImpl.this.produceCommentEvent((CommentToken) ParserImpl.this.scanner.next());
            }
            if (!ParserImpl.this.scanner.checkToken(Token.ID.BlockEntry, Token.ID.Key, Token.ID.Value, Token.ID.BlockEnd)) {
                ParserImpl.this.states.push(new ParseIndentlessSequenceEntryKey(ParserImpl.this, null));
                return new ParseBlockNode(ParserImpl.this, null).produce();
            }
            ParserImpl.this.state = Optional.of(new ParseIndentlessSequenceEntryKey(ParserImpl.this, null));
            return ParserImpl.this.processEmptyScalar(this.token.getEndMark());
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/parser/ParserImpl$ParseBlockMappingFirstKey.class */
    private class ParseBlockMappingFirstKey implements Production {
        private static transient /* synthetic */ String CaTgBcTVTk = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        private ParseBlockMappingFirstKey() {
        }

        /* synthetic */ ParseBlockMappingFirstKey(ParserImpl parserImpl, C00191 c00191) {
            this();
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser.Production
        public Event produce() {
            ParserImpl.this.markPush(ParserImpl.this.scanner.next().getStartMark());
            return new ParseBlockMappingKey(ParserImpl.this, null).produce();
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/parser/ParserImpl$ParseBlockMappingKey.class */
    private class ParseBlockMappingKey implements Production {
        private static transient /* synthetic */ String uKzLzESrjy = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        private ParseBlockMappingKey() {
        }

        /* synthetic */ ParseBlockMappingKey(ParserImpl parserImpl, C00191 c00191) {
            this();
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser.Production
        public Event produce() {
            if (ParserImpl.this.scanner.checkToken(Token.ID.Comment)) {
                ParserImpl.this.state = Optional.of(ParserImpl.this.new ParseBlockMappingKey());
                return ParserImpl.this.produceCommentEvent((CommentToken) ParserImpl.this.scanner.next());
            }
            if (ParserImpl.this.scanner.checkToken(Token.ID.Key)) {
                Token next = ParserImpl.this.scanner.next();
                if (!ParserImpl.this.scanner.checkToken(Token.ID.Key, Token.ID.Value, Token.ID.BlockEnd)) {
                    ParserImpl.this.states.push(new ParseBlockMappingValue(ParserImpl.this, null));
                    return ParserImpl.this.parseBlockNodeOrIndentlessSequence();
                }
                ParserImpl.this.state = Optional.of(new ParseBlockMappingValue(ParserImpl.this, null));
                return ParserImpl.this.processEmptyScalar(next.getEndMark());
            }
            if (!ParserImpl.this.scanner.checkToken(Token.ID.BlockEnd)) {
                Token tokenPeekToken = ParserImpl.this.scanner.peekToken();
                throw new ParserException("while parsing a block mapping", ParserImpl.this.markPop(), "expected <block end>, but found '" + tokenPeekToken.getTokenId() + "'", tokenPeekToken.getStartMark());
            }
            Token next2 = ParserImpl.this.scanner.next();
            MappingEndEvent mappingEndEvent = new MappingEndEvent(next2.getStartMark(), next2.getEndMark());
            ParserImpl.this.state = Optional.of((Production) ParserImpl.this.states.pop());
            ParserImpl.this.markPop();
            return mappingEndEvent;
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/parser/ParserImpl$ParseBlockMappingValue.class */
    private class ParseBlockMappingValue implements Production {
        private static transient /* synthetic */ String hVrAYqIkGI = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        private ParseBlockMappingValue() {
        }

        /* synthetic */ ParseBlockMappingValue(ParserImpl parserImpl, C00191 c00191) {
            this();
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser.Production
        public Event produce() {
            if (!ParserImpl.this.scanner.checkToken(Token.ID.Value)) {
                if (ParserImpl.this.scanner.checkToken(Token.ID.Scalar)) {
                    ParserImpl.this.states.push(new ParseBlockMappingKey(ParserImpl.this, null));
                    return ParserImpl.this.parseBlockNodeOrIndentlessSequence();
                }
                ParserImpl.this.state = Optional.of(new ParseBlockMappingKey(ParserImpl.this, null));
                return ParserImpl.this.processEmptyScalar(ParserImpl.this.scanner.peekToken().getStartMark());
            }
            Token next = ParserImpl.this.scanner.next();
            if (ParserImpl.this.scanner.checkToken(Token.ID.Comment)) {
                ParseBlockMappingValueComment parseBlockMappingValueComment = new ParseBlockMappingValueComment(ParserImpl.this, null);
                ParserImpl.this.state = Optional.of(parseBlockMappingValueComment);
                return parseBlockMappingValueComment.produce();
            }
            if (!ParserImpl.this.scanner.checkToken(Token.ID.Key, Token.ID.Value, Token.ID.BlockEnd)) {
                ParserImpl.this.states.push(new ParseBlockMappingKey(ParserImpl.this, null));
                return ParserImpl.this.parseBlockNodeOrIndentlessSequence();
            }
            ParserImpl.this.state = Optional.of(new ParseBlockMappingKey(ParserImpl.this, null));
            return ParserImpl.this.processEmptyScalar(next.getEndMark());
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/parser/ParserImpl$ParseBlockMappingValueComment.class */
    private class ParseBlockMappingValueComment implements Production {
        List<CommentToken> tokens;
        private static transient /* synthetic */ String MRtfiTLqZB = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        private ParseBlockMappingValueComment() {
            this.tokens = new LinkedList();
        }

        /* synthetic */ ParseBlockMappingValueComment(ParserImpl parserImpl, C00191 c00191) {
            this();
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser.Production
        public Event produce() {
            if (ParserImpl.this.scanner.checkToken(Token.ID.Comment)) {
                this.tokens.add((CommentToken) ParserImpl.this.scanner.next());
                return produce();
            }
            if (ParserImpl.this.scanner.checkToken(Token.ID.Key, Token.ID.Value, Token.ID.BlockEnd)) {
                ParserImpl.this.state = Optional.of(ParserImpl.this.new ParseBlockMappingValueCommentList(this.tokens));
                return ParserImpl.this.processEmptyScalar(ParserImpl.this.scanner.peekToken().getStartMark());
            }
            if (!this.tokens.isEmpty()) {
                return ParserImpl.this.produceCommentEvent(this.tokens.remove(0));
            }
            ParserImpl.this.states.push(new ParseBlockMappingKey(ParserImpl.this, null));
            return ParserImpl.this.parseBlockNodeOrIndentlessSequence();
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/parser/ParserImpl$ParseBlockMappingValueCommentList.class */
    private class ParseBlockMappingValueCommentList implements Production {
        List<CommentToken> tokens;
        private static transient /* synthetic */ String CEDeTGNypN = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        public ParseBlockMappingValueCommentList(List<CommentToken> list) {
            this.tokens = list;
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser.Production
        public Event produce() {
            if (!this.tokens.isEmpty()) {
                return ParserImpl.this.produceCommentEvent(this.tokens.remove(0));
            }
            return new ParseBlockMappingKey(ParserImpl.this, null).produce();
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/parser/ParserImpl$ParseFlowSequenceFirstEntry.class */
    private class ParseFlowSequenceFirstEntry implements Production {
        private static transient /* synthetic */ String qFdGTOZXLz = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        private ParseFlowSequenceFirstEntry() {
        }

        /* synthetic */ ParseFlowSequenceFirstEntry(ParserImpl parserImpl, C00191 c00191) {
            this();
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser.Production
        public Event produce() {
            ParserImpl.this.markPush(ParserImpl.this.scanner.next().getStartMark());
            return ParserImpl.this.new ParseFlowSequenceEntry(true).produce();
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/parser/ParserImpl$ParseFlowSequenceEntry.class */
    private class ParseFlowSequenceEntry implements Production {
        private final boolean first;
        private static transient /* synthetic */ String knBPtvyEcN = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        public ParseFlowSequenceEntry(boolean z) {
            this.first = z;
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser.Production
        public Event produce() {
            if (ParserImpl.this.scanner.checkToken(Token.ID.Comment)) {
                ParserImpl.this.state = Optional.of(ParserImpl.this.new ParseFlowSequenceEntry(this.first));
                return ParserImpl.this.produceCommentEvent((CommentToken) ParserImpl.this.scanner.next());
            }
            if (!ParserImpl.this.scanner.checkToken(Token.ID.FlowSequenceEnd)) {
                if (!this.first) {
                    if (ParserImpl.this.scanner.checkToken(Token.ID.FlowEntry)) {
                        ParserImpl.this.scanner.next();
                        if (ParserImpl.this.scanner.checkToken(Token.ID.Comment)) {
                            ParserImpl.this.state = Optional.of(ParserImpl.this.new ParseFlowSequenceEntry(true));
                            return ParserImpl.this.produceCommentEvent((CommentToken) ParserImpl.this.scanner.next());
                        }
                    } else {
                        Token tokenPeekToken = ParserImpl.this.scanner.peekToken();
                        throw new ParserException("while parsing a flow sequence", ParserImpl.this.markPop(), "expected ',' or ']', but got " + tokenPeekToken.getTokenId(), tokenPeekToken.getStartMark());
                    }
                }
                if (ParserImpl.this.scanner.checkToken(Token.ID.Key)) {
                    Token tokenPeekToken2 = ParserImpl.this.scanner.peekToken();
                    MappingStartEvent mappingStartEvent = new MappingStartEvent(Optional.empty(), Optional.empty(), true, FlowStyle.FLOW, tokenPeekToken2.getStartMark(), tokenPeekToken2.getEndMark());
                    ParserImpl.this.state = Optional.of(new ParseFlowSequenceEntryMappingKey(ParserImpl.this, null));
                    return mappingStartEvent;
                }
                if (!ParserImpl.this.scanner.checkToken(Token.ID.FlowSequenceEnd)) {
                    ParserImpl.this.states.push(ParserImpl.this.new ParseFlowSequenceEntry(false));
                    return ParserImpl.this.parseFlowNode();
                }
            }
            Token next = ParserImpl.this.scanner.next();
            SequenceEndEvent sequenceEndEvent = new SequenceEndEvent(next.getStartMark(), next.getEndMark());
            if (!ParserImpl.this.scanner.checkToken(Token.ID.Comment)) {
                ParserImpl.this.state = Optional.of((Production) ParserImpl.this.states.pop());
            } else {
                ParserImpl.this.state = Optional.of(new ParseFlowEndComment(ParserImpl.this, null));
            }
            ParserImpl.this.markPop();
            return sequenceEndEvent;
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/parser/ParserImpl$ParseFlowEndComment.class */
    private class ParseFlowEndComment implements Production {
        private static transient /* synthetic */ String TMZmmFeJDc = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        private ParseFlowEndComment() {
        }

        /* synthetic */ ParseFlowEndComment(ParserImpl parserImpl, C00191 c00191) {
            this();
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser.Production
        public Event produce() {
            CommentEvent commentEventProduceCommentEvent = ParserImpl.this.produceCommentEvent((CommentToken) ParserImpl.this.scanner.next());
            if (!ParserImpl.this.scanner.checkToken(Token.ID.Comment)) {
                ParserImpl.this.state = Optional.of((Production) ParserImpl.this.states.pop());
            }
            return commentEventProduceCommentEvent;
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/parser/ParserImpl$ParseFlowSequenceEntryMappingKey.class */
    private class ParseFlowSequenceEntryMappingKey implements Production {
        private static transient /* synthetic */ String bpPeKePTOA = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        private ParseFlowSequenceEntryMappingKey() {
        }

        /* synthetic */ ParseFlowSequenceEntryMappingKey(ParserImpl parserImpl, C00191 c00191) {
            this();
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser.Production
        public Event produce() {
            Token next = ParserImpl.this.scanner.next();
            if (!ParserImpl.this.scanner.checkToken(Token.ID.Value, Token.ID.FlowEntry, Token.ID.FlowSequenceEnd)) {
                ParserImpl.this.states.push(new ParseFlowSequenceEntryMappingValue(ParserImpl.this, null));
                return ParserImpl.this.parseFlowNode();
            }
            ParserImpl.this.state = Optional.of(new ParseFlowSequenceEntryMappingValue(ParserImpl.this, null));
            return ParserImpl.this.processEmptyScalar(next.getEndMark());
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/parser/ParserImpl$ParseFlowSequenceEntryMappingValue.class */
    private class ParseFlowSequenceEntryMappingValue implements Production {
        private static transient /* synthetic */ String mJvlpciaMr = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        private ParseFlowSequenceEntryMappingValue() {
        }

        /* synthetic */ ParseFlowSequenceEntryMappingValue(ParserImpl parserImpl, C00191 c00191) {
            this();
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser.Production
        public Event produce() {
            if (!ParserImpl.this.scanner.checkToken(Token.ID.Value)) {
                ParserImpl.this.state = Optional.of(new ParseFlowSequenceEntryMappingEnd(ParserImpl.this, null));
                return ParserImpl.this.processEmptyScalar(ParserImpl.this.scanner.peekToken().getStartMark());
            }
            Token next = ParserImpl.this.scanner.next();
            if (!ParserImpl.this.scanner.checkToken(Token.ID.FlowEntry, Token.ID.FlowSequenceEnd)) {
                ParserImpl.this.states.push(new ParseFlowSequenceEntryMappingEnd(ParserImpl.this, null));
                return ParserImpl.this.parseFlowNode();
            }
            ParserImpl.this.state = Optional.of(new ParseFlowSequenceEntryMappingEnd(ParserImpl.this, null));
            return ParserImpl.this.processEmptyScalar(next.getEndMark());
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/parser/ParserImpl$ParseFlowSequenceEntryMappingEnd.class */
    private class ParseFlowSequenceEntryMappingEnd implements Production {
        private static transient /* synthetic */ String BsvznlMOTf = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        private ParseFlowSequenceEntryMappingEnd() {
        }

        /* synthetic */ ParseFlowSequenceEntryMappingEnd(ParserImpl parserImpl, C00191 c00191) {
            this();
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser.Production
        public Event produce() {
            ParserImpl.this.state = Optional.of(ParserImpl.this.new ParseFlowSequenceEntry(false));
            Token tokenPeekToken = ParserImpl.this.scanner.peekToken();
            return new MappingEndEvent(tokenPeekToken.getStartMark(), tokenPeekToken.getEndMark());
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/parser/ParserImpl$ParseFlowMappingFirstKey.class */
    private class ParseFlowMappingFirstKey implements Production {
        private static transient /* synthetic */ String IvOnRJdOBc = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        private ParseFlowMappingFirstKey() {
        }

        /* synthetic */ ParseFlowMappingFirstKey(ParserImpl parserImpl, C00191 c00191) {
            this();
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser.Production
        public Event produce() {
            ParserImpl.this.markPush(ParserImpl.this.scanner.next().getStartMark());
            return ParserImpl.this.new ParseFlowMappingKey(true).produce();
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/parser/ParserImpl$ParseFlowMappingKey.class */
    private class ParseFlowMappingKey implements Production {
        private final boolean first;
        private static transient /* synthetic */ String KvDMNcDYxS = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        public ParseFlowMappingKey(boolean z) {
            this.first = z;
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser.Production
        public Event produce() {
            if (!ParserImpl.this.scanner.checkToken(Token.ID.FlowMappingEnd)) {
                if (!this.first) {
                    if (ParserImpl.this.scanner.checkToken(Token.ID.FlowEntry)) {
                        ParserImpl.this.scanner.next();
                    } else {
                        Token tokenPeekToken = ParserImpl.this.scanner.peekToken();
                        throw new ParserException("while parsing a flow mapping", ParserImpl.this.markPop(), "expected ',' or '}', but got " + tokenPeekToken.getTokenId(), tokenPeekToken.getStartMark());
                    }
                }
                if (ParserImpl.this.scanner.checkToken(Token.ID.Key)) {
                    Token next = ParserImpl.this.scanner.next();
                    if (!ParserImpl.this.scanner.checkToken(Token.ID.Value, Token.ID.FlowEntry, Token.ID.FlowMappingEnd)) {
                        ParserImpl.this.states.push(new ParseFlowMappingValue(ParserImpl.this, null));
                        return ParserImpl.this.parseFlowNode();
                    }
                    ParserImpl.this.state = Optional.of(new ParseFlowMappingValue(ParserImpl.this, null));
                    return ParserImpl.this.processEmptyScalar(next.getEndMark());
                }
                if (!ParserImpl.this.scanner.checkToken(Token.ID.FlowMappingEnd)) {
                    ParserImpl.this.states.push(new ParseFlowMappingEmptyValue(ParserImpl.this, null));
                    return ParserImpl.this.parseFlowNode();
                }
            }
            Token next2 = ParserImpl.this.scanner.next();
            MappingEndEvent mappingEndEvent = new MappingEndEvent(next2.getStartMark(), next2.getEndMark());
            ParserImpl.this.markPop();
            if (!ParserImpl.this.scanner.checkToken(Token.ID.Comment)) {
                ParserImpl.this.state = Optional.of((Production) ParserImpl.this.states.pop());
            } else {
                ParserImpl.this.state = Optional.of(new ParseFlowEndComment(ParserImpl.this, null));
            }
            return mappingEndEvent;
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/parser/ParserImpl$ParseFlowMappingValue.class */
    private class ParseFlowMappingValue implements Production {
        private static transient /* synthetic */ String xlmoMmddtI = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        private ParseFlowMappingValue() {
        }

        /* synthetic */ ParseFlowMappingValue(ParserImpl parserImpl, C00191 c00191) {
            this();
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser.Production
        public Event produce() {
            if (!ParserImpl.this.scanner.checkToken(Token.ID.Value)) {
                ParserImpl.this.state = Optional.of(ParserImpl.this.new ParseFlowMappingKey(false));
                return ParserImpl.this.processEmptyScalar(ParserImpl.this.scanner.peekToken().getStartMark());
            }
            Token next = ParserImpl.this.scanner.next();
            if (!ParserImpl.this.scanner.checkToken(Token.ID.FlowEntry, Token.ID.FlowMappingEnd)) {
                ParserImpl.this.states.push(ParserImpl.this.new ParseFlowMappingKey(false));
                return ParserImpl.this.parseFlowNode();
            }
            ParserImpl.this.state = Optional.of(ParserImpl.this.new ParseFlowMappingKey(false));
            return ParserImpl.this.processEmptyScalar(next.getEndMark());
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/parser/ParserImpl$ParseFlowMappingEmptyValue.class */
    private class ParseFlowMappingEmptyValue implements Production {
        private static transient /* synthetic */ String tdnIoSFnbe = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        private ParseFlowMappingEmptyValue() {
        }

        /* synthetic */ ParseFlowMappingEmptyValue(ParserImpl parserImpl, C00191 c00191) {
            this();
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser.Production
        public Event produce() {
            ParserImpl.this.state = Optional.of(ParserImpl.this.new ParseFlowMappingKey(false));
            return ParserImpl.this.processEmptyScalar(ParserImpl.this.scanner.peekToken().getStartMark());
        }
    }
}
