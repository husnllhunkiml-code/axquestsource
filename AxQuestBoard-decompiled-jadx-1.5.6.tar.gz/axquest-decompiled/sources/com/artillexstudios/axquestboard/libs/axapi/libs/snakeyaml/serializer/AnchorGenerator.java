package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.serializer;

import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.nodes.Node;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/serializer/AnchorGenerator.class */
public interface AnchorGenerator {
    String nextAnchor(Node node);
}
