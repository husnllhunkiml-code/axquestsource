package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.SpecVersion;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/parser/VersionTagsTuple.class */
class VersionTagsTuple {
    private final Optional<SpecVersion> specVersion;
    private final Map<String, String> tags;
    private static transient /* synthetic */ String WePRZstTbO = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public VersionTagsTuple(Optional<SpecVersion> optional, Map<String, String> map) {
        Objects.requireNonNull(optional);
        this.specVersion = optional;
        this.tags = map;
    }

    public Optional<SpecVersion> getSpecVersion() {
        return this.specVersion;
    }

    public Map<String, String> getTags() {
        return this.tags;
    }

    public String toString() {
        return String.format("VersionTagsTuple<%s, %s>", this.specVersion, this.tags);
    }
}
