package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.updater;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.block.implementation.Section;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.dvs.Version;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.dvs.versioning.Versioning;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.updater.UpdaterSettings;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.updater.operators.Mapper;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.updater.operators.Relocator;
import java.util.Objects;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/updater/VersionedOperations.class */
public class VersionedOperations {
    private static transient /* synthetic */ String CzCYkiFVXx = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public static boolean run(@NotNull Section section, @NotNull Section section2, @NotNull UpdaterSettings updaterSettings, char c) {
        Versioning versioning = updaterSettings.getVersioning();
        if (versioning == null) {
            return false;
        }
        Version documentVersion = versioning.getDocumentVersion(section, false);
        Version version = (Version) Objects.requireNonNull(versioning.getDocumentVersion(section2, true), "Version ID of the defaults cannot be null! Is it malformed or not specified?");
        int iCompareTo = documentVersion != null ? documentVersion.compareTo(version) : -1;
        if (iCompareTo > 0 && !updaterSettings.isEnableDowngrading()) {
            throw new UnsupportedOperationException(String.format("Downgrading is not enabled (%s > %s)!", version.asID(), documentVersion.asID()));
        }
        if (iCompareTo == 0) {
            return true;
        }
        if (iCompareTo < 0) {
            iterate(section, documentVersion != null ? documentVersion : versioning.getFirstVersion(), version, updaterSettings, c);
        }
        updaterSettings.getIgnoredRoutes(version.asID(), c).forEach(route -> {
            section.getOptionalBlock(route).ifPresent(block -> {
                block.setIgnored(true);
            });
        });
        return false;
    }

    private static void iterate(@NotNull Section section, @NotNull Version version, @NotNull Version version2, @NotNull UpdaterSettings updaterSettings, char c) {
        Version versionCopy = version.copy();
        while (versionCopy.compareTo(version2) <= 0) {
            versionCopy.next();
            Relocator.apply(section, updaterSettings.getRelocations(versionCopy.asID(), c));
            Mapper.apply(section, updaterSettings.getMappers(versionCopy.asID(), c));
            updaterSettings.getCustomLogic(versionCopy.asID()).forEach(consumer -> {
                consumer.accept(section.getRoot());
            });
        }
    }
}
