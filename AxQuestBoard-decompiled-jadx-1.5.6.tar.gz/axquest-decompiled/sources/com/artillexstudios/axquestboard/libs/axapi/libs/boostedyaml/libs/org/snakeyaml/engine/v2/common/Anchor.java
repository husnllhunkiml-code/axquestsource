package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.EmitterException;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.regex.Pattern;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/common/Anchor.class */
public class Anchor {
    private static final Set<Character> INVALID_ANCHOR = new HashSet();
    private static final Pattern SPACES_PATTERN = Pattern.compile("\\s");
    private final String value;
    private static transient /* synthetic */ String ZpBhMHqBCX = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    static {
        INVALID_ANCHOR.add('[');
        INVALID_ANCHOR.add(']');
        INVALID_ANCHOR.add('{');
        INVALID_ANCHOR.add('}');
        INVALID_ANCHOR.add(',');
        INVALID_ANCHOR.add('*');
        INVALID_ANCHOR.add('&');
    }

    public Anchor(String str) {
        Objects.requireNonNull(str);
        if (str.isEmpty()) {
            throw new IllegalArgumentException("Empty anchor.");
        }
        for (int i = 0; i < str.length(); i++) {
            char cCharAt = str.charAt(i);
            if (INVALID_ANCHOR.contains(Character.valueOf(cCharAt))) {
                throw new EmitterException("Invalid character '" + cCharAt + "' in the anchor: " + str);
            }
        }
        if (SPACES_PATTERN.matcher(str).find()) {
            throw new EmitterException("Anchor may not contain spaces: " + str);
        }
        this.value = str;
    }

    public String getValue() {
        return this.value;
    }

    public String toString() {
        return this.value;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        return Objects.equals(this.value, ((Anchor) obj).value);
    }

    public int hashCode() {
        return Objects.hash(this.value);
    }
}
