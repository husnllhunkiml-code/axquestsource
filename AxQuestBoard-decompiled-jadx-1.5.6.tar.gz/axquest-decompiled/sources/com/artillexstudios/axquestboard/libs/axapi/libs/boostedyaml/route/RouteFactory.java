package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.route;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.general.GeneralSettings;
import java.util.regex.Pattern;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/route/RouteFactory.class */
public class RouteFactory {
    private final char separator;
    private final String escapedSeparator;
    private static transient /* synthetic */ String zUxzNfNxxI = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public RouteFactory(@NotNull GeneralSettings generalSettings) {
        this.separator = generalSettings.getRouteSeparator();
        this.escapedSeparator = generalSettings.getEscapedSeparator();
    }

    public RouteFactory(char c) {
        this.separator = c;
        this.escapedSeparator = Pattern.quote(String.valueOf(c));
    }

    public RouteFactory() {
        this.separator = '.';
        this.escapedSeparator = GeneralSettings.DEFAULT_ESCAPED_SEPARATOR;
    }

    @NotNull
    public Route create(String str) {
        return Route.fromString(str, this);
    }

    public char getSeparator() {
        return this.separator;
    }

    @NotNull
    public String getEscapedSeparator() {
        return this.escapedSeparator;
    }
}
