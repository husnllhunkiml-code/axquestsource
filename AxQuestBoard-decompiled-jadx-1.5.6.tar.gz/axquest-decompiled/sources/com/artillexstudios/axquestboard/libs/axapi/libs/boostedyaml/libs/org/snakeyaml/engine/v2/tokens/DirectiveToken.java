package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.Mark;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.YamlEngineException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/tokens/DirectiveToken.class */
public final class DirectiveToken<T> extends Token {
    public static final String YAML_DIRECTIVE = "YAML";
    public static final String TAG_DIRECTIVE = "TAG";
    private final String name;
    private final Optional<List<T>> value;
    private static transient /* synthetic */ String mNhWrrYnwu = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public DirectiveToken(String str, Optional<List<T>> optional, Optional<Mark> optional2, Optional<Mark> optional3) {
        super(optional2, optional3);
        Objects.requireNonNull(str);
        this.name = str;
        Objects.requireNonNull(optional);
        if (optional.isPresent() && optional.get().size() != 2) {
            throw new YamlEngineException("Two strings/integers must be provided instead of " + optional.get().size());
        }
        this.value = optional;
    }

    public String getName() {
        return this.name;
    }

    public Optional<List<T>> getValue() {
        return this.value;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.Token
    public Token.ID getTokenId() {
        return Token.ID.Directive;
    }
}
