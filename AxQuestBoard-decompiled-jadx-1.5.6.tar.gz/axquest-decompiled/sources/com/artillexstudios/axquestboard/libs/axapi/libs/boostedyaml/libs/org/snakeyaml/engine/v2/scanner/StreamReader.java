package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.scanner;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.LoadSettings;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.CharConstants;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.Mark;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.ReaderException;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.YamlEngineException;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.Arrays;
import java.util.Optional;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/scanner/StreamReader.class */
public final class StreamReader {
    private final String name;
    private final Reader stream;
    private final int bufferSize;
    private final char[] buffer;
    private final boolean useMarks;
    private int[] codePointsWindow;
    private int dataLength;
    private int pointer;
    private boolean eof;
    private int index;
    private int documentIndex;
    private int line;
    private int column;
    private static transient /* synthetic */ String qIzdwMcdTB = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    @Deprecated
    public StreamReader(Reader reader, LoadSettings loadSettings) {
        this(loadSettings, reader);
    }

    public StreamReader(LoadSettings loadSettings, Reader reader) {
        this.pointer = 0;
        this.index = 0;
        this.documentIndex = 0;
        this.line = 0;
        this.column = 0;
        this.name = loadSettings.getLabel();
        this.codePointsWindow = new int[0];
        this.dataLength = 0;
        this.stream = reader;
        this.eof = false;
        this.bufferSize = loadSettings.getBufferSize().intValue();
        this.buffer = new char[this.bufferSize];
        this.useMarks = loadSettings.getUseMarks();
    }

    @Deprecated
    public StreamReader(String str, LoadSettings loadSettings) {
        this(loadSettings, new StringReader(str));
    }

    public StreamReader(LoadSettings loadSettings, String str) {
        this(loadSettings, new StringReader(str));
    }

    public static boolean isPrintable(String str) {
        int length = str.length();
        int iCharCount = 0;
        while (true) {
            int i = iCharCount;
            if (i < length) {
                int iCodePointAt = str.codePointAt(i);
                if (!isPrintable(iCodePointAt)) {
                    return false;
                }
                iCharCount = i + Character.charCount(iCodePointAt);
            } else {
                return true;
            }
        }
    }

    public static boolean isPrintable(int i) {
        return (i >= 32 && i <= 126) || i == 9 || i == 10 || i == 13 || i == 133 || (i >= 160 && i <= 55295) || ((i >= 57344 && i <= 65533) || (i >= 65536 && i <= 1114111));
    }

    public Optional<Mark> getMark() {
        if (this.useMarks) {
            return Optional.of(new Mark(this.name, this.index, this.line, this.column, this.codePointsWindow, this.pointer));
        }
        return Optional.empty();
    }

    public void forward() {
        forward(1);
    }

    public void forward(int i) {
        for (int i2 = 0; i2 < i && ensureEnoughData(); i2++) {
            int[] iArr = this.codePointsWindow;
            int i3 = this.pointer;
            this.pointer = i3 + 1;
            int i4 = iArr[i3];
            moveIndices(1);
            if (CharConstants.LINEBR.has(i4) || (i4 == 13 && ensureEnoughData() && this.codePointsWindow[this.pointer] != 10)) {
                this.line++;
                this.column = 0;
            } else if (i4 != 65279) {
                this.column++;
            }
        }
    }

    public int peek() {
        if (ensureEnoughData()) {
            return this.codePointsWindow[this.pointer];
        }
        return 0;
    }

    public int peek(int i) {
        if (ensureEnoughData(i)) {
            return this.codePointsWindow[this.pointer + i];
        }
        return 0;
    }

    public String prefix(int i) {
        if (i == 0) {
            return "";
        }
        if (ensureEnoughData(i)) {
            return new String(this.codePointsWindow, this.pointer, i);
        }
        return new String(this.codePointsWindow, this.pointer, Math.min(i, this.dataLength - this.pointer));
    }

    public String prefixForward(int i) {
        String strPrefix = prefix(i);
        this.pointer += i;
        moveIndices(i);
        this.column += i;
        return strPrefix;
    }

    private boolean ensureEnoughData() {
        return ensureEnoughData(0);
    }

    private boolean ensureEnoughData(int i) {
        if (!this.eof && this.pointer + i >= this.dataLength) {
            update();
        }
        return this.pointer + i < this.dataLength;
    }

    private void update() {
        try {
            int i = this.stream.read(this.buffer, 0, this.bufferSize);
            if (i > 0) {
                int i2 = this.dataLength - this.pointer;
                this.codePointsWindow = Arrays.copyOfRange(this.codePointsWindow, this.pointer, this.dataLength + i);
                if (Character.isHighSurrogate(this.buffer[i - 1])) {
                    if (this.stream.read(this.buffer, i, 1) == -1) {
                        this.eof = true;
                    } else {
                        i++;
                    }
                }
                Optional optionalEmpty = Optional.empty();
                int iCharCount = 0;
                while (iCharCount < i) {
                    int iCodePointAt = Character.codePointAt(this.buffer, iCharCount);
                    this.codePointsWindow[i2] = iCodePointAt;
                    if (isPrintable(iCodePointAt)) {
                        iCharCount += Character.charCount(iCodePointAt);
                    } else {
                        optionalEmpty = Optional.of(Integer.valueOf(iCodePointAt));
                        iCharCount = i;
                    }
                    i2++;
                }
                this.dataLength = i2;
                this.pointer = 0;
                if (optionalEmpty.isPresent()) {
                    throw new ReaderException(this.name, i2 - 1, ((Integer) optionalEmpty.get()).intValue(), "special characters are not allowed");
                }
            } else {
                this.eof = true;
            }
        } catch (IOException e) {
            throw new YamlEngineException(e);
        }
    }

    public int getColumn() {
        return this.column;
    }

    private void moveIndices(int i) {
        this.index += i;
        this.documentIndex += i;
    }

    public int getDocumentIndex() {
        return this.documentIndex;
    }

    public void resetDocumentIndex() {
        this.documentIndex = 0;
    }

    public int getIndex() {
        return this.index;
    }

    public int getLine() {
        return this.line;
    }
}
