package com.artillexstudios.axquestboard.libs.axapi.gui.inventory.builder;

import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.GuiBuilder;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.implementation.PaginatedGui;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.provider.GuiItemProvider;
import java.util.HashMap;
import java.util.function.Function;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/gui/inventory/builder/PaginatedGuiBuilder.class */
public class PaginatedGuiBuilder extends GuiBuilder<PaginatedGui, PaginatedGuiBuilder> {
    private final HashMap<Class<?>, Function<?, GuiItemProvider>> providers = new HashMap<>();
    private static transient /* synthetic */ String fYEFHiVXnd = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public <T> PaginatedGuiBuilder withProvider(Class<T> clazz, Function<T, GuiItemProvider> provider) {
        this.providers.put(clazz, provider);
        return this;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.gui.inventory.GuiBuilder
    public PaginatedGui build(Player player) {
        return new PaginatedGui(player, this.titleProvider, this.type, this.rows, this.providers, this.context, this.modifiers);
    }
}
