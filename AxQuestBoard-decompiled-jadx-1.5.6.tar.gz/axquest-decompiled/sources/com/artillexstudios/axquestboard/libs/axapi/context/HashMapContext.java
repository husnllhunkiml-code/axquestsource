package com.artillexstudios.axquestboard.libs.axapi.context;

import com.artillexstudios.axquestboard.libs.axapi.utils.UncheckedUtils;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/context/HashMapContext.class */
public class HashMapContext {
    protected final HashMap<ContextKey<?>, Object> values;
    private static transient /* synthetic */ String hwbhKHonwS = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public HashMapContext() {
        this((HashMap<ContextKey<?>, Object>) new HashMap(1));
    }

    public HashMapContext(HashMapContext context) {
        this((HashMap<ContextKey<?>, Object>) new HashMap(context.values));
    }

    public HashMapContext(HashMap<ContextKey<?>, Object> contents) {
        this.values = contents;
    }

    public static HashMapContext create() {
        return new HashMapContext();
    }

    public <T> HashMapContext with(ContextKey<T> key, T value) {
        this.values.put(key, value);
        return this;
    }

    public <T> T getByClass(Class<T> clazz) {
        for (Map.Entry<ContextKey<?>, Object> entry : this.values.entrySet()) {
            if (entry.getKey().type().equals(clazz)) {
                return clazz.cast(entry.getValue());
            }
        }
        return null;
    }

    public <T> T getByName(String str) {
        for (Map.Entry<ContextKey<?>, Object> entry : this.values.entrySet()) {
            if (entry.getKey().name().equals(str)) {
                return (T) UncheckedUtils.unsafeCast(entry.getValue());
            }
        }
        return null;
    }

    public <T> T get(ContextKey<T> key) {
        return key.type().cast(this.values.get(key));
    }

    public HashMapContext copy() {
        return new HashMapContext(this);
    }

    public HashMapContext merge(HashMapContext other) {
        for (Map.Entry<ContextKey<?>, Object> entry : other.values.entrySet()) {
            if (!this.values.containsKey(entry.getKey())) {
                this.values.put(entry.getKey(), entry.getValue());
            }
        }
        return this;
    }

    public final boolean equals(Object object) {
        if (!(object instanceof HashMapContext)) {
            return false;
        }
        return Objects.equals(this.values, ((HashMapContext) object).values);
    }

    public int hashCode() {
        return Objects.hashCode(this.values);
    }
}
