package com.artillexstudios.axquestboard.libs.axapi.database;

import com.artillexstudios.axquestboard.libs.axapi.utils.logging.LogUtils;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Supplier;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/database/RunnableQuery.class */
public class RunnableQuery<T> {
    private final Function<Class<?>, Function<Object, List<Object>>> transformer;
    private final Supplier<Connection> connectionSupplier;
    private final ResultHandler<T> resultHandler;
    private final String sql;
    private static transient /* synthetic */ String pbcORtWayt = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public RunnableQuery(Function<Class<?>, Function<Object, List<Object>>> transformer, Supplier<Connection> connectionSupplier, ResultHandler<T> resultHandler, String sql) {
        this.transformer = transformer;
        this.connectionSupplier = connectionSupplier;
        this.resultHandler = resultHandler;
        this.sql = sql;
    }

    public int update(Object... parameters) {
        try {
            Connection connection = this.connectionSupplier.get();
            try {
                PreparedStatement preparedStatementPrepareStatement = connection.prepareStatement(this.sql);
                try {
                    handleStatement(parameters, preparedStatementPrepareStatement);
                    int iExecuteUpdate = preparedStatementPrepareStatement.executeUpdate();
                    if (preparedStatementPrepareStatement != null) {
                        preparedStatementPrepareStatement.close();
                    }
                    if (connection != null) {
                        connection.close();
                    }
                    return iExecuteUpdate;
                } catch (Throwable th) {
                    if (preparedStatementPrepareStatement != null) {
                        try {
                            preparedStatementPrepareStatement.close();
                        } catch (Throwable th2) {
                            th.addSuppressed(th2);
                        }
                    }
                    throw th;
                }
            } catch (Throwable th3) {
                if (connection != null) {
                    try {
                        connection.close();
                    } catch (Throwable th4) {
                        th3.addSuppressed(th4);
                    }
                }
                throw th3;
            }
        } catch (SQLException e) {
            LogUtils.error("An exception occurred while executing sql query {} with parameters: {}!", this.sql, Arrays.toString(parameters));
            throw new RuntimeException(e);
        }
    }

    public T execute(Object... parameters) {
        try {
            Connection connection = this.connectionSupplier.get();
            try {
                PreparedStatement preparedStatementPrepareStatement = connection.prepareStatement(this.sql, 1);
                try {
                    handleStatement(parameters, preparedStatementPrepareStatement);
                    preparedStatementPrepareStatement.executeUpdate();
                    ResultSet generatedKeys = preparedStatementPrepareStatement.getGeneratedKeys();
                    try {
                        T tHandle = this.resultHandler.handle(generatedKeys);
                        if (generatedKeys != null) {
                            generatedKeys.close();
                        }
                        if (preparedStatementPrepareStatement != null) {
                            preparedStatementPrepareStatement.close();
                        }
                        if (connection != null) {
                            connection.close();
                        }
                        return tHandle;
                    } catch (Throwable th) {
                        if (generatedKeys != null) {
                            try {
                                generatedKeys.close();
                            } catch (Throwable th2) {
                                th.addSuppressed(th2);
                            }
                        }
                        throw th;
                    }
                } catch (Throwable th3) {
                    if (preparedStatementPrepareStatement != null) {
                        try {
                            preparedStatementPrepareStatement.close();
                        } catch (Throwable th4) {
                            th3.addSuppressed(th4);
                        }
                    }
                    throw th3;
                }
            } catch (Throwable th5) {
                if (connection != null) {
                    try {
                        connection.close();
                    } catch (Throwable th6) {
                        th5.addSuppressed(th6);
                    }
                }
                throw th5;
            }
        } catch (SQLException e) {
            LogUtils.error("An exception occurred while executing sql query {} with parameters: {}!", this.sql, Arrays.toString(parameters));
            throw new RuntimeException(e);
        }
    }

    public T query(Object... parameters) {
        try {
            Connection connection = this.connectionSupplier.get();
            try {
                PreparedStatement preparedStatementPrepareStatement = connection.prepareStatement(this.sql);
                try {
                    handleStatement(parameters, preparedStatementPrepareStatement);
                    ResultSet resultSetExecuteQuery = preparedStatementPrepareStatement.executeQuery();
                    try {
                        T tHandle = this.resultHandler.handle(resultSetExecuteQuery);
                        if (resultSetExecuteQuery != null) {
                            resultSetExecuteQuery.close();
                        }
                        if (preparedStatementPrepareStatement != null) {
                            preparedStatementPrepareStatement.close();
                        }
                        if (connection != null) {
                            connection.close();
                        }
                        return tHandle;
                    } catch (Throwable th) {
                        if (resultSetExecuteQuery != null) {
                            try {
                                resultSetExecuteQuery.close();
                            } catch (Throwable th2) {
                                th.addSuppressed(th2);
                            }
                        }
                        throw th;
                    }
                } catch (Throwable th3) {
                    if (preparedStatementPrepareStatement != null) {
                        try {
                            preparedStatementPrepareStatement.close();
                        } catch (Throwable th4) {
                            th3.addSuppressed(th4);
                        }
                    }
                    throw th3;
                }
            } catch (Throwable th5) {
                if (connection != null) {
                    try {
                        connection.close();
                    } catch (Throwable th6) {
                        th5.addSuppressed(th6);
                    }
                }
                throw th5;
            }
        } catch (SQLException e) {
            LogUtils.error("An exception occurred while executing sql query {} with parameters: {}!", this.sql, Arrays.toString(parameters));
            throw new RuntimeException(e);
        }
    }

    public int[] batch(List<Object[]> batch) {
        try {
            Connection connection = this.connectionSupplier.get();
            try {
                PreparedStatement preparedStatementPrepareStatement = connection.prepareStatement(this.sql);
                try {
                    Iterator<Object[]> it = batch.iterator();
                    while (it.hasNext()) {
                        handleStatement(it.next(), preparedStatementPrepareStatement);
                        preparedStatementPrepareStatement.addBatch();
                    }
                    int[] iArrExecuteBatch = preparedStatementPrepareStatement.executeBatch();
                    if (preparedStatementPrepareStatement != null) {
                        preparedStatementPrepareStatement.close();
                    }
                    if (connection != null) {
                        connection.close();
                    }
                    return iArrExecuteBatch;
                } catch (Throwable th) {
                    if (preparedStatementPrepareStatement != null) {
                        try {
                            preparedStatementPrepareStatement.close();
                        } catch (Throwable th2) {
                            th.addSuppressed(th2);
                        }
                    }
                    throw th;
                }
            } catch (Throwable th3) {
                if (connection != null) {
                    try {
                        connection.close();
                    } catch (Throwable th4) {
                        th3.addSuppressed(th4);
                    }
                }
                throw th3;
            }
        } catch (SQLException e) {
            LogUtils.error("An exception occurred while executing sql query {} with parameters: {}!", this.sql, batch);
            throw new RuntimeException(e);
        }
    }

    private void handleStatement(Object[] parameters, PreparedStatement statement) throws SQLException {
        int i = 0;
        while (i < parameters.length) {
            Object obj = parameters[i];
            if (obj == null) {
                statement.setObject(i + 1, null);
            } else {
                Function<Object, List<Object>> functionApply = this.transformer.apply(obj.getClass());
                if (functionApply != null) {
                    List<Object> listApply = functionApply.apply(obj);
                    int i2 = 0;
                    int i3 = i;
                    while (i3 < i + listApply.size()) {
                        statement.setObject(i3 + 1, listApply.get(i2));
                        i2++;
                        i3++;
                    }
                    i = i3;
                } else {
                    statement.setObject(i + 1, obj);
                }
            }
            i++;
        }
    }
}
