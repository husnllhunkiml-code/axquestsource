package com.artillexstudios.axquestboard.libs.axapi.database.handler;

import com.artillexstudios.axquestboard.libs.axapi.database.ResultHandler;
import java.sql.ResultSet;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/database/handler/SimpleHandler.class */
public class SimpleHandler<T> implements ResultHandler<T> {
    private final Integer columnId;
    private final String columnName;
    private static transient /* synthetic */ String BkgNyOsUKl = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public SimpleHandler() {
        this(1, null);
    }

    public SimpleHandler(Integer columnId) {
        this(columnId, null);
    }

    public SimpleHandler(String columnName) {
        this(null, columnName);
    }

    public SimpleHandler(Integer columnId, String columnName) {
        this.columnId = columnId;
        this.columnName = columnName;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.database.ResultHandler
    public T handle(ResultSet resultSet, boolean z) {
        if (z && !resultSet.next()) {
            return null;
        }
        if (this.columnName != null) {
            return (T) resultSet.getObject(this.columnName);
        }
        return (T) resultSet.getObject(this.columnId.intValue());
    }
}
