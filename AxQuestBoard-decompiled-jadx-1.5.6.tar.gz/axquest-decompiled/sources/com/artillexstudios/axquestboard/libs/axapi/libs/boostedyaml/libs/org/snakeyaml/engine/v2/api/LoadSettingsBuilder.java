package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.SpecVersion;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.env.EnvConfig;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.YamlVersionException;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Tag;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.schema.JsonSchema;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.schema.Schema;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.IntFunction;
import java.util.function.UnaryOperator;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/api/LoadSettingsBuilder.class */
public final class LoadSettingsBuilder {
    private final Map<SettingKey, Object> customProperties = new HashMap();
    private String label = "reader";
    private Map<Tag, ConstructNode> tagConstructors = new HashMap();
    private IntFunction<List<Object>> defaultList = ArrayList::new;
    private IntFunction<Set<Object>> defaultSet = LinkedHashSet::new;
    private IntFunction<Map<Object, Object>> defaultMap = LinkedHashMap::new;
    private UnaryOperator<SpecVersion> versionFunction = specVersion -> {
        if (specVersion.getMajor() != 1) {
            throw new YamlVersionException(specVersion);
        }
        return specVersion;
    };
    private Integer bufferSize = 1024;
    private boolean allowDuplicateKeys = false;
    private boolean allowRecursiveKeys = false;
    private boolean parseComments = false;
    private int maxAliasesForCollections = 50;
    private boolean useMarks = true;
    private Optional<EnvConfig> envConfig = Optional.empty();
    private int codePointLimit = 3145728;
    private Schema schema = new JsonSchema();
    private static transient /* synthetic */ String woXSEsMPpW = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    LoadSettingsBuilder() {
    }

    public LoadSettingsBuilder setLabel(String str) {
        Objects.requireNonNull(str, "label cannot be null");
        this.label = str;
        return this;
    }

    public LoadSettingsBuilder setTagConstructors(Map<Tag, ConstructNode> map) {
        this.tagConstructors = map;
        return this;
    }

    public LoadSettingsBuilder setDefaultList(IntFunction<List<Object>> intFunction) {
        Objects.requireNonNull(intFunction, "defaultList cannot be null");
        this.defaultList = intFunction;
        return this;
    }

    public LoadSettingsBuilder setDefaultSet(IntFunction<Set<Object>> intFunction) {
        Objects.requireNonNull(intFunction, "defaultSet cannot be null");
        this.defaultSet = intFunction;
        return this;
    }

    public LoadSettingsBuilder setDefaultMap(IntFunction<Map<Object, Object>> intFunction) {
        Objects.requireNonNull(intFunction, "defaultMap cannot be null");
        this.defaultMap = intFunction;
        return this;
    }

    public LoadSettingsBuilder setBufferSize(Integer num) {
        this.bufferSize = num;
        return this;
    }

    public LoadSettingsBuilder setAllowDuplicateKeys(boolean z) {
        this.allowDuplicateKeys = z;
        return this;
    }

    public LoadSettingsBuilder setAllowRecursiveKeys(boolean z) {
        this.allowRecursiveKeys = z;
        return this;
    }

    public LoadSettingsBuilder setMaxAliasesForCollections(int i) {
        this.maxAliasesForCollections = i;
        return this;
    }

    public LoadSettingsBuilder setUseMarks(boolean z) {
        this.useMarks = z;
        return this;
    }

    public LoadSettingsBuilder setVersionFunction(UnaryOperator<SpecVersion> unaryOperator) {
        Objects.requireNonNull(unaryOperator, "versionFunction cannot be null");
        this.versionFunction = unaryOperator;
        return this;
    }

    public LoadSettingsBuilder setEnvConfig(Optional<EnvConfig> optional) {
        this.envConfig = optional;
        return this;
    }

    public LoadSettingsBuilder setCustomProperty(SettingKey settingKey, Object obj) {
        this.customProperties.put(settingKey, obj);
        return this;
    }

    public LoadSettingsBuilder setParseComments(boolean z) {
        this.parseComments = z;
        return this;
    }

    public LoadSettingsBuilder setCodePointLimit(int i) {
        this.codePointLimit = i;
        return this;
    }

    public LoadSettingsBuilder setSchema(Schema schema) {
        this.schema = schema;
        return this;
    }

    public LoadSettings build() {
        return new LoadSettings(this.label, this.tagConstructors, this.defaultList, this.defaultSet, this.defaultMap, this.versionFunction, this.bufferSize, this.allowDuplicateKeys, this.allowRecursiveKeys, this.maxAliasesForCollections, this.useMarks, this.customProperties, this.envConfig, this.parseComments, this.codePointLimit, this.schema);
    }
}
