package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.utils.conversion;

import java.math.BigInteger;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/utils/conversion/PrimitiveConversions.class */
public class PrimitiveConversions {
    public static final Map<Class<?>, Class<?>> NUMERIC_PRIMITIVES = Collections.unmodifiableMap(new HashMap<Class<?>, Class<?>>() { // from class: com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.utils.conversion.PrimitiveConversions.1
        private static transient /* synthetic */ String JHJWfaEFAa = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        {
            put(Integer.TYPE, Integer.class);
            put(Byte.TYPE, Byte.class);
            put(Short.TYPE, Short.class);
            put(Long.TYPE, Long.class);
            put(Float.TYPE, Float.class);
            put(Double.TYPE, Double.class);
        }
    });
    public static final Map<Class<?>, Class<?>> PRIMITIVES_TO_OBJECTS = Collections.unmodifiableMap(new HashMap<Class<?>, Class<?>>() { // from class: com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.utils.conversion.PrimitiveConversions.2
        private static transient /* synthetic */ String rCazDNNLZv = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        {
            putAll(PrimitiveConversions.NUMERIC_PRIMITIVES);
            put(Boolean.TYPE, Boolean.class);
            put(Character.TYPE, Character.class);
        }
    });
    public static final Map<Class<?>, Class<?>> NON_NUMERIC_CONVERSIONS = Collections.unmodifiableMap(new HashMap<Class<?>, Class<?>>() { // from class: com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.utils.conversion.PrimitiveConversions.3
        private static transient /* synthetic */ String GXiendihdW = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        {
            put(Boolean.TYPE, Boolean.class);
            put(Character.TYPE, Character.class);
            put(Boolean.class, Boolean.TYPE);
            put(Character.class, Character.TYPE);
        }
    });
    public static final Set<Class<?>> NUMERIC_CLASSES = Collections.unmodifiableSet(new HashSet<Class<?>>() { // from class: com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.utils.conversion.PrimitiveConversions.4
        private static transient /* synthetic */ String dILvubiqKe = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        {
            add(Integer.TYPE);
            add(Byte.TYPE);
            add(Short.TYPE);
            add(Long.TYPE);
            add(Float.TYPE);
            add(Double.TYPE);
            add(Integer.class);
            add(Byte.class);
            add(Short.class);
            add(Long.class);
            add(Float.class);
            add(Double.class);
        }
    });
    private static transient /* synthetic */ String sEkjAaGCrH = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public static boolean isNumber(@NotNull Class<?> cls) {
        return NUMERIC_CLASSES.contains(cls);
    }

    public static Object convertNumber(@NotNull Object obj, @NotNull Class<?> cls) {
        Number number = (Number) obj;
        if (cls.isPrimitive()) {
            cls = NUMERIC_PRIMITIVES.get(cls);
        }
        if (cls == Integer.class) {
            return Integer.valueOf(number.intValue());
        }
        if (cls == Byte.class) {
            return Byte.valueOf(number.byteValue());
        }
        if (cls == Short.class) {
            return Short.valueOf(number.shortValue());
        }
        if (cls == Long.class) {
            return Long.valueOf(number.longValue());
        }
        if (cls == Float.class) {
            return Float.valueOf(number.floatValue());
        }
        return Double.valueOf(number.doubleValue());
    }

    public static Optional<Integer> toInt(@Nullable Object obj) {
        if (obj == null) {
            return Optional.empty();
        }
        if (obj instanceof Number) {
            return Optional.of(Integer.valueOf(((Number) obj).intValue()));
        }
        try {
            return Optional.of(Integer.valueOf(obj.toString()));
        } catch (NumberFormatException e) {
            return Optional.empty();
        }
    }

    public static Optional<Byte> toByte(@Nullable Object obj) {
        if (obj == null) {
            return Optional.empty();
        }
        if (obj instanceof Number) {
            return Optional.of(Byte.valueOf(((Number) obj).byteValue()));
        }
        try {
            return Optional.of(Byte.valueOf(obj.toString()));
        } catch (NumberFormatException e) {
            return Optional.empty();
        }
    }

    public static Optional<Long> toLong(@Nullable Object obj) {
        if (obj == null) {
            return Optional.empty();
        }
        if (obj instanceof Number) {
            return Optional.of(Long.valueOf(((Number) obj).longValue()));
        }
        try {
            return Optional.of(Long.valueOf(obj.toString()));
        } catch (NumberFormatException e) {
            return Optional.empty();
        }
    }

    public static Optional<Double> toDouble(@Nullable Object obj) {
        if (obj == null) {
            return Optional.empty();
        }
        if (obj instanceof Number) {
            return Optional.of(Double.valueOf(((Number) obj).doubleValue()));
        }
        try {
            return Optional.of(Double.valueOf(obj.toString()));
        } catch (NumberFormatException e) {
            return Optional.empty();
        }
    }

    public static Optional<Float> toFloat(@Nullable Object obj) {
        if (obj == null) {
            return Optional.empty();
        }
        if (obj instanceof Number) {
            return Optional.of(Float.valueOf(((Number) obj).floatValue()));
        }
        try {
            return Optional.of(Float.valueOf(obj.toString()));
        } catch (NumberFormatException e) {
            return Optional.empty();
        }
    }

    public static Optional<Short> toShort(@Nullable Object obj) {
        if (obj == null) {
            return Optional.empty();
        }
        if (obj instanceof Number) {
            return Optional.of(Short.valueOf(((Number) obj).shortValue()));
        }
        try {
            return Optional.of(Short.valueOf(obj.toString()));
        } catch (NumberFormatException e) {
            return Optional.empty();
        }
    }

    public static Optional<BigInteger> toBigInt(@Nullable Object obj) {
        if (obj == null) {
            return Optional.empty();
        }
        if (obj instanceof BigInteger) {
            return Optional.of((BigInteger) obj);
        }
        if (obj instanceof Number) {
            return Optional.of(BigInteger.valueOf(((Number) obj).longValue()));
        }
        try {
            return Optional.of(new BigInteger(obj.toString()));
        } catch (NumberFormatException e) {
            return Optional.empty();
        }
    }
}
