package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.composer.Composer;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.constructor.BaseConstructor;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.constructor.StandardConstructor;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser.ParserImpl;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.scanner.StreamReader;
import java.io.InputStream;
import java.io.Reader;
import java.util.Iterator;
import java.util.Objects;
import java.util.Optional;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/api/Load.class */
public class Load {
    private final LoadSettings settings;
    private final BaseConstructor constructor;
    private static transient /* synthetic */ String pXcnktKiKp = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public Load(LoadSettings loadSettings) {
        this(loadSettings, new StandardConstructor(loadSettings));
    }

    public Load(LoadSettings loadSettings, BaseConstructor baseConstructor) {
        Objects.requireNonNull(loadSettings, "LoadSettings cannot be null");
        Objects.requireNonNull(baseConstructor, "BaseConstructor cannot be null");
        this.settings = loadSettings;
        this.constructor = baseConstructor;
    }

    private Composer createComposer(StreamReader streamReader) {
        return new Composer(this.settings, new ParserImpl(this.settings, streamReader));
    }

    protected Composer createComposer(InputStream inputStream) {
        return createComposer(new StreamReader(this.settings, new YamlUnicodeReader(inputStream)));
    }

    protected Composer createComposer(String str) {
        return createComposer(new StreamReader(this.settings, str));
    }

    protected Composer createComposer(Reader reader) {
        return createComposer(new StreamReader(this.settings, reader));
    }

    protected Object loadOne(Composer composer) {
        return this.constructor.constructSingleDocument(composer.getSingleNode());
    }

    public Object loadFromInputStream(InputStream inputStream) {
        Objects.requireNonNull(inputStream, "InputStream cannot be null");
        return loadOne(createComposer(inputStream));
    }

    public Object loadFromReader(Reader reader) {
        Objects.requireNonNull(reader, "Reader cannot be null");
        return loadOne(createComposer(reader));
    }

    public Object loadFromString(String str) {
        Objects.requireNonNull(str, "String cannot be null");
        return loadOne(createComposer(str));
    }

    private Iterable<Object> loadAll(Composer composer) {
        return new YamlIterable(new YamlIterator(composer, this.constructor));
    }

    public Iterable<Object> loadAllFromInputStream(InputStream inputStream) {
        Objects.requireNonNull(inputStream, "InputStream cannot be null");
        return loadAll(createComposer(new StreamReader(this.settings, new YamlUnicodeReader(inputStream))));
    }

    public Iterable<Object> loadAllFromReader(Reader reader) {
        Objects.requireNonNull(reader, "Reader cannot be null");
        return loadAll(createComposer(new StreamReader(this.settings, reader)));
    }

    public Iterable<Object> loadAllFromString(String str) {
        Objects.requireNonNull(str, "String cannot be null");
        return loadAll(createComposer(new StreamReader(this.settings, str)));
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/api/Load$YamlIterable.class */
    private static class YamlIterable implements Iterable<Object> {
        private final Iterator<Object> iterator;
        private static transient /* synthetic */ String jVaGTbVPZQ = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        public YamlIterable(Iterator<Object> it) {
            this.iterator = it;
        }

        @Override // java.lang.Iterable
        public Iterator<Object> iterator() {
            return this.iterator;
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/api/Load$YamlIterator.class */
    private static class YamlIterator implements Iterator<Object> {
        private final Composer composer;
        private final BaseConstructor constructor;
        private boolean composerInitiated = false;
        private static transient /* synthetic */ String piCjzrATaE = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        public YamlIterator(Composer composer, BaseConstructor baseConstructor) {
            this.composer = composer;
            this.constructor = baseConstructor;
        }

        @Override // java.util.Iterator
        public boolean hasNext() {
            this.composerInitiated = true;
            return this.composer.hasNext();
        }

        @Override // java.util.Iterator
        public Object next() {
            if (!this.composerInitiated) {
                hasNext();
            }
            return this.constructor.constructSingleDocument(Optional.of(this.composer.next()));
        }

        @Override // java.util.Iterator
        public void remove() {
            throw new UnsupportedOperationException("Removing is not supported.");
        }
    }
}
