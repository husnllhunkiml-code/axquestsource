package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.events;

import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.error.Mark;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/events/AliasEvent.class */
public final class AliasEvent extends NodeEvent {
    private static transient /* synthetic */ String ljVZupiZTX = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public AliasEvent(String str, Mark mark, Mark mark2) {
        super(str, mark, mark2);
        if (str == null) {
            throw new NullPointerException("anchor is not specified for alias");
        }
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.events.Event
    public Event.ID getEventId() {
        return Event.ID.Alias;
    }
}
