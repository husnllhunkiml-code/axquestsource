package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.constructor.json;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.constructor.ConstructScalar;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.ConstructorException;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Node;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.NodeType;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Tag;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.resolver.ScalarResolver;
import java.util.Optional;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/constructor/json/ConstructOptionalClass.class */
public class ConstructOptionalClass extends ConstructScalar {
    private final ScalarResolver scalarResolver;
    private static transient /* synthetic */ String JamfmrsniP = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public ConstructOptionalClass(ScalarResolver scalarResolver) {
        this.scalarResolver = scalarResolver;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.ConstructNode
    public Object construct(Node node) {
        if (node.getNodeType() != NodeType.SCALAR) {
            throw new ConstructorException("while constructing Optional", Optional.empty(), "found non scalar node", node.getStartMark());
        }
        String strConstructScalar = constructScalar(node);
        if (this.scalarResolver.resolve(strConstructScalar, true).equals(Tag.NULL)) {
            return Optional.empty();
        }
        return Optional.of(strConstructScalar);
    }
}
