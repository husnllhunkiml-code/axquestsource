package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.Anchor;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.Mark;
import java.util.Objects;
import java.util.Optional;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/events/NodeEvent.class */
public abstract class NodeEvent extends Event {
    private final Optional<Anchor> anchor;

    public NodeEvent(Optional<Anchor> optional, Optional<Mark> optional2, Optional<Mark> optional3) {
        super(optional2, optional3);
        Objects.requireNonNull(optional);
        this.anchor = optional;
    }

    public Optional<Anchor> getAnchor() {
        return this.anchor;
    }
}
