package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.dvs.versioning;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.block.implementation.Section;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.dvs.Version;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/dvs/versioning/Versioning.class */
public interface Versioning {
    @Nullable
    Version getDocumentVersion(@NotNull Section section, boolean z);

    @NotNull
    Version getFirstVersion();

    default void updateVersionID(@NotNull Section updated, @NotNull Section def) {
    }
}
