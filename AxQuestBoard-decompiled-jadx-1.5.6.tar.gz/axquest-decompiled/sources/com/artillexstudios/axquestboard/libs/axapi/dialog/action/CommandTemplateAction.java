package com.artillexstudios.axquestboard.libs.axapi.dialog.action;

import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.runtime.ObjectMethods;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/dialog/action/CommandTemplateAction.class */
public final class CommandTemplateAction extends Record implements Action {
    private final String template;
    private static transient /* synthetic */ String UWyuKMwAWZ = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public CommandTemplateAction(String template) {
        this.template = template;
    }

    @Override // java.lang.Record
    public final String toString() {
        return (String) ObjectMethods.bootstrap(MethodHandles.lookup(), "toString", MethodType.methodType(String.class, CommandTemplateAction.class), CommandTemplateAction.class, "template", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/dialog/action/CommandTemplateAction;->template:Ljava/lang/String;").dynamicInvoker().invoke(this) /* invoke-custom */;
    }

    @Override // java.lang.Record
    public final int hashCode() {
        return (int) ObjectMethods.bootstrap(MethodHandles.lookup(), "hashCode", MethodType.methodType(Integer.TYPE, CommandTemplateAction.class), CommandTemplateAction.class, "template", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/dialog/action/CommandTemplateAction;->template:Ljava/lang/String;").dynamicInvoker().invoke(this) /* invoke-custom */;
    }

    @Override // java.lang.Record
    public final boolean equals(Object o) {
        return (boolean) ObjectMethods.bootstrap(MethodHandles.lookup(), "equals", MethodType.methodType(Boolean.TYPE, CommandTemplateAction.class, Object.class), CommandTemplateAction.class, "template", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/dialog/action/CommandTemplateAction;->template:Ljava/lang/String;").dynamicInvoker().invoke(this, o) /* invoke-custom */;
    }

    public String template() {
        return this.template;
    }
}
