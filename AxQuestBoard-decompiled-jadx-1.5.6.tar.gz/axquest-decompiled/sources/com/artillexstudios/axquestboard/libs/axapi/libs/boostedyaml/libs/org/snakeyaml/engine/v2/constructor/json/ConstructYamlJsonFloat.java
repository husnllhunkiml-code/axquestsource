package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.constructor.json;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.constructor.ConstructScalar;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Node;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/constructor/json/ConstructYamlJsonFloat.class */
public class ConstructYamlJsonFloat extends ConstructScalar {
    private static transient /* synthetic */ String ubomBhlraw = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.ConstructNode
    public Object construct(Node node) {
        String strConstructScalar = constructScalar(node);
        if (".inf".equals(strConstructScalar)) {
            return Double.valueOf(Double.POSITIVE_INFINITY);
        }
        if ("-.inf".equals(strConstructScalar)) {
            return Double.valueOf(Double.NEGATIVE_INFINITY);
        }
        if (".nan".equals(strConstructScalar)) {
            return Double.valueOf(Double.NaN);
        }
        return constructFromString(strConstructScalar);
    }

    protected Object constructFromString(String str) {
        int i = 1;
        char cCharAt = str.charAt(0);
        if (cCharAt == '-') {
            i = -1;
            str = str.substring(1);
        } else if (cCharAt == '+') {
            str = str.substring(1);
        }
        return Double.valueOf(Double.valueOf(str).doubleValue() * ((double) i));
    }
}
