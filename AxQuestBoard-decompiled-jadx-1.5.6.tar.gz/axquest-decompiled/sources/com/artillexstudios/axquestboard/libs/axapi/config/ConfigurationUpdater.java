package com.artillexstudios.axquestboard.libs.axapi.config;

import com.artillexstudios.axquestboard.libs.axapi.config.annotation.ConfigurationPart;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/ConfigurationUpdater.class */
@FunctionalInterface
public interface ConfigurationUpdater {
    <T extends ConfigurationPart> void update(YamlConfiguration<T> config);
}
