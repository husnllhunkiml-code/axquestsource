package com.artillexstudios.axquestboard.libs.axapi.database.handler;

import com.artillexstudios.axquestboard.libs.axapi.database.ResultHandler;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/database/handler/ListHandler.class */
public class ListHandler<T> implements ResultHandler<List<T>> {
    private final ResultHandler<T> handler;
    private static transient /* synthetic */ String mpzHSBAdIw = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public ListHandler(ResultHandler<T> handler) {
        this.handler = handler;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.database.ResultHandler
    public List<T> handle(ResultSet resultSet, boolean checkNext) {
        ArrayList arrayList = new ArrayList();
        while (resultSet.next()) {
            arrayList.add(this.handler.handle(resultSet, false));
        }
        return arrayList;
    }
}
