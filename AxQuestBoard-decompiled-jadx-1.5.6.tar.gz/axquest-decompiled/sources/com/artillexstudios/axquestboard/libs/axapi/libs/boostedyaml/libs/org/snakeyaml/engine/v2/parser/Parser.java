package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.Event;
import java.util.Iterator;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/parser/Parser.class */
public interface Parser extends Iterator<Event> {
    boolean checkEvent(Event.ID id);

    Event peekEvent();

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // java.util.Iterator
    Event next();
}
