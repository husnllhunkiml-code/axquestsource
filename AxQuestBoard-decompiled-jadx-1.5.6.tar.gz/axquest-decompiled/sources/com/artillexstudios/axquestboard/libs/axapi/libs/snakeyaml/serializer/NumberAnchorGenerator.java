package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.serializer;

import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.nodes.Node;
import java.text.NumberFormat;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/serializer/NumberAnchorGenerator.class */
public class NumberAnchorGenerator implements AnchorGenerator {
    private int lastAnchorId;
    private static transient /* synthetic */ String kDbbQUllXI = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public NumberAnchorGenerator(int i) {
        this.lastAnchorId = 0;
        this.lastAnchorId = i;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.serializer.AnchorGenerator
    public String nextAnchor(Node node) {
        this.lastAnchorId++;
        NumberFormat numberInstance = NumberFormat.getNumberInstance();
        numberInstance.setMinimumIntegerDigits(3);
        numberInstance.setMaximumFractionDigits(0);
        numberInstance.setGroupingUsed(false);
        return "id" + numberInstance.format(this.lastAnchorId);
    }
}
