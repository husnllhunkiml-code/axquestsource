package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.FlowStyle;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.NonPrintableStyle;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.ScalarStyle;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.SpecVersion;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.EmitterException;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.YamlEngineException;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Tag;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.schema.JsonSchema;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.schema.Schema;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.serializer.AnchorGenerator;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.serializer.NumberAnchorGenerator;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/api/DumpSettingsBuilder.class */
public final class DumpSettingsBuilder {
    private boolean multiLineFlow;
    private static transient /* synthetic */ String iPuqTSykyF = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";
    Map<SettingKey, Object> customProperties = new HashMap();
    private Optional<Tag> explicitRootTag = Optional.empty();
    private Map<String, String> tagDirective = new HashMap();
    private AnchorGenerator anchorGenerator = new NumberAnchorGenerator(0);
    private String bestLineBreak = "\n";
    private boolean canonical = false;
    private boolean useUnicodeEncoding = true;
    private int indent = 2;
    private int indicatorIndent = 0;
    private int width = 80;
    private boolean splitLines = true;
    private boolean explicitStart = false;
    private boolean explicitEnd = false;
    private Optional<SpecVersion> yamlDirective = Optional.empty();
    private FlowStyle defaultFlowStyle = FlowStyle.AUTO;
    private ScalarStyle defaultScalarStyle = ScalarStyle.PLAIN;
    private NonPrintableStyle nonPrintableStyle = NonPrintableStyle.ESCAPE;
    private int maxSimpleKeyLength = 128;
    private boolean indentWithIndicator = false;
    private boolean dumpComments = false;
    private Schema schema = new JsonSchema();
    private boolean dereferenceAliases = false;

    DumpSettingsBuilder() {
    }

    public DumpSettingsBuilder setDefaultFlowStyle(FlowStyle flowStyle) {
        this.defaultFlowStyle = flowStyle;
        return this;
    }

    public DumpSettingsBuilder setDefaultScalarStyle(ScalarStyle scalarStyle) {
        this.defaultScalarStyle = scalarStyle;
        return this;
    }

    public DumpSettingsBuilder setExplicitStart(boolean z) {
        this.explicitStart = z;
        return this;
    }

    public DumpSettingsBuilder setAnchorGenerator(AnchorGenerator anchorGenerator) {
        Objects.requireNonNull(anchorGenerator, "anchorGenerator cannot be null");
        this.anchorGenerator = anchorGenerator;
        return this;
    }

    public DumpSettingsBuilder setExplicitRootTag(Optional<Tag> optional) {
        Objects.requireNonNull(optional, "explicitRootTag cannot be null");
        this.explicitRootTag = optional;
        return this;
    }

    public DumpSettingsBuilder setExplicitEnd(boolean z) {
        this.explicitEnd = z;
        return this;
    }

    public DumpSettingsBuilder setYamlDirective(Optional<SpecVersion> optional) {
        Objects.requireNonNull(optional, "yamlDirective cannot be null");
        this.yamlDirective = optional;
        return this;
    }

    public DumpSettingsBuilder setTagDirective(Map<String, String> map) {
        Objects.requireNonNull(map, "tagDirective cannot be null");
        this.tagDirective = map;
        return this;
    }

    public DumpSettingsBuilder setCanonical(boolean z) {
        this.canonical = z;
        return this;
    }

    public DumpSettingsBuilder setMultiLineFlow(boolean z) {
        this.multiLineFlow = z;
        return this;
    }

    public DumpSettingsBuilder setUseUnicodeEncoding(boolean z) {
        this.useUnicodeEncoding = z;
        return this;
    }

    public DumpSettingsBuilder setIndent(int i) {
        if (i < 1) {
            throw new EmitterException("Indent must be at least 1");
        }
        if (i > 10) {
            throw new EmitterException("Indent must be at most 10");
        }
        this.indent = i;
        return this;
    }

    public DumpSettingsBuilder setIndicatorIndent(int i) {
        if (i < 0) {
            throw new EmitterException("Indicator indent must be non-negative");
        }
        if (i > 9) {
            throw new EmitterException("Indicator indent must be at most Emitter.MAX_INDENT-1: 9");
        }
        this.indicatorIndent = i;
        return this;
    }

    public DumpSettingsBuilder setWidth(int i) {
        this.width = i;
        return this;
    }

    public DumpSettingsBuilder setBestLineBreak(String str) {
        Objects.requireNonNull(str, "bestLineBreak cannot be null");
        this.bestLineBreak = str;
        return this;
    }

    public DumpSettingsBuilder setSplitLines(boolean z) {
        this.splitLines = z;
        return this;
    }

    public DumpSettingsBuilder setMaxSimpleKeyLength(int i) {
        if (i > 1024) {
            throw new YamlEngineException("The simple key must not span more than 1024 stream characters. See https://yaml.org/spec/1.2/spec.html#id2798057");
        }
        this.maxSimpleKeyLength = i;
        return this;
    }

    public DumpSettingsBuilder setNonPrintableStyle(NonPrintableStyle nonPrintableStyle) {
        this.nonPrintableStyle = nonPrintableStyle;
        return this;
    }

    public DumpSettingsBuilder setCustomProperty(SettingKey settingKey, Object obj) {
        this.customProperties.put(settingKey, obj);
        return this;
    }

    public DumpSettingsBuilder setIndentWithIndicator(boolean z) {
        this.indentWithIndicator = z;
        return this;
    }

    public DumpSettingsBuilder setDumpComments(boolean z) {
        this.dumpComments = z;
        return this;
    }

    public DumpSettingsBuilder setSchema(Schema schema) {
        this.schema = schema;
        return this;
    }

    public DumpSettingsBuilder setDereferenceAliases(Boolean bool) {
        this.dereferenceAliases = bool.booleanValue();
        return this;
    }

    public DumpSettings build() {
        return new DumpSettings(this.explicitStart, this.explicitEnd, this.explicitRootTag, this.anchorGenerator, this.yamlDirective, this.tagDirective, this.defaultFlowStyle, this.defaultScalarStyle, this.nonPrintableStyle, this.schema, Boolean.valueOf(this.dereferenceAliases), this.canonical, this.multiLineFlow, this.useUnicodeEncoding, this.indent, this.indicatorIndent, this.width, this.bestLineBreak, this.splitLines, this.maxSimpleKeyLength, this.customProperties, this.indentWithIndicator, this.dumpComments);
    }
}
