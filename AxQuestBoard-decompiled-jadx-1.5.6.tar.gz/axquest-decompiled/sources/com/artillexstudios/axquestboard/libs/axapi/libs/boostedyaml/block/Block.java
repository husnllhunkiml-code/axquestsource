package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.block;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.comments.CommentLine;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.comments.CommentType;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.MappingNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Node;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.NodeTuple;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.SequenceNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.utils.format.NodeRole;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/block/Block.class */
public abstract class Block<T> {

    @Nullable
    List<CommentLine> beforeKeyComments;

    @Nullable
    List<CommentLine> inlineKeyComments;

    @Nullable
    List<CommentLine> afterKeyComments;

    @Nullable
    List<CommentLine> beforeValueComments;

    @Nullable
    List<CommentLine> inlineValueComments;

    @Nullable
    List<CommentLine> afterValueComments;
    private T value;
    private boolean ignored;

    public abstract boolean isSection();

    public Block(@Nullable Node node, @Nullable Node node2, @Nullable T t) {
        this.beforeKeyComments = null;
        this.inlineKeyComments = null;
        this.afterKeyComments = null;
        this.beforeValueComments = null;
        this.inlineValueComments = null;
        this.afterValueComments = null;
        this.value = t;
        init(node, node2);
    }

    public Block(@Nullable T t) {
        this(null, null, t);
    }

    public Block(@Nullable Block<?> block, @Nullable T t) {
        this.beforeKeyComments = null;
        this.inlineKeyComments = null;
        this.afterKeyComments = null;
        this.beforeValueComments = null;
        this.inlineValueComments = null;
        this.afterValueComments = null;
        this.value = t;
        if (block == null) {
            return;
        }
        this.beforeKeyComments = block.beforeKeyComments;
        this.inlineKeyComments = block.inlineKeyComments;
        this.afterKeyComments = block.afterKeyComments;
        this.beforeValueComments = block.beforeValueComments;
        this.inlineValueComments = block.inlineValueComments;
        this.afterValueComments = block.afterValueComments;
    }

    protected void init(@Nullable Node node, @Nullable Node node2) {
        if (node != null) {
            this.beforeKeyComments = node.getBlockComments() == null ? new ArrayList<>(0) : node.getBlockComments();
            this.inlineKeyComments = node.getInLineComments();
            this.afterKeyComments = node.getEndComments();
            collectComments(node, this.beforeKeyComments, true);
        }
        if (node2 != null) {
            this.beforeValueComments = node2.getBlockComments() == null ? new ArrayList<>(0) : node2.getBlockComments();
            this.inlineValueComments = node2.getInLineComments();
            this.afterValueComments = node2.getEndComments();
            collectComments(node2, this.beforeValueComments, true);
        }
    }

    private void collectComments(@NotNull Node node, @NotNull List<CommentLine> list, boolean z) {
        if (!z) {
            if (node.getBlockComments() != null) {
                list.addAll(toBlockComments(node.getBlockComments()));
            }
            if (node.getInLineComments() != null) {
                list.addAll(toBlockComments(node.getInLineComments()));
            }
            if (node.getEndComments() != null) {
                list.addAll(toBlockComments(node.getEndComments()));
            }
        }
        if (node instanceof SequenceNode) {
            Iterator<Node> it = ((SequenceNode) node).getValue().iterator();
            while (it.hasNext()) {
                collectComments(it.next(), list, false);
            }
        } else if (!z && (node instanceof MappingNode)) {
            for (NodeTuple nodeTuple : ((MappingNode) node).getValue()) {
                collectComments(nodeTuple.getKeyNode(), list, false);
                collectComments(nodeTuple.getValueNode(), list, false);
            }
        }
    }

    private List<CommentLine> toBlockComments(@NotNull List<CommentLine> list) {
        int i = -1;
        for (CommentLine commentLine : list) {
            i++;
            list.set(i, commentLine.getCommentType() != CommentType.IN_LINE ? commentLine : new CommentLine(commentLine.getStartMark(), commentLine.getEndMark(), commentLine.getValue(), CommentType.BLOCK));
        }
        return list;
    }

    public void setValue(T t) {
        this.value = t;
    }

    @Nullable
    public List<String> getComments() {
        List<CommentLine> list = Comments.get((Block<?>) this, NodeRole.KEY, Comments.Position.BEFORE);
        if (list == null) {
            return null;
        }
        return (List) list.stream().map((v0) -> {
            return v0.getValue();
        }).collect(Collectors.toList());
    }

    public void setComments(@Nullable List<String> list) {
        Comments.set((Block<?>) this, NodeRole.KEY, Comments.Position.BEFORE, (List<CommentLine>) (list == null ? null : (List) list.stream().map(str -> {
            return Comments.create(str, Comments.Position.BEFORE);
        }).collect(Collectors.toList())));
    }

    public void removeComments() {
        Comments.remove((Block<?>) this, NodeRole.KEY, Comments.Position.BEFORE);
    }

    public void addComments(@NotNull List<String> list) {
        Comments.add((Block<?>) this, NodeRole.KEY, Comments.Position.BEFORE, (List<CommentLine>) list.stream().map(str -> {
            return Comments.create(str, Comments.Position.BEFORE);
        }).collect(Collectors.toList()));
    }

    public void addComment(@NotNull String str) {
        Comments.add((Block<?>) this, NodeRole.KEY, Comments.Position.BEFORE, Comments.create(str, Comments.Position.BEFORE));
    }

    public void setIgnored(boolean z) {
        this.ignored = z;
    }

    public boolean isIgnored() {
        return this.ignored;
    }

    public T getStoredValue() {
        return this.value;
    }
}
