package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.Mark;
import java.util.Optional;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/tokens/BlockEntryToken.class */
public final class BlockEntryToken extends Token {
    private static transient /* synthetic */ String wjxZSHfyhw = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public BlockEntryToken(Optional<Mark> optional, Optional<Mark> optional2) {
        super(optional, optional2);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.Token
    public Token.ID getTokenId() {
        return Token.ID.BlockEntry;
    }
}
