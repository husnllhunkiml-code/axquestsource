package com.artillexstudios.axquestboard.libs.axapi.gui.inventory.renderer.strategy;

import com.artillexstudios.axquestboard.libs.axapi.context.HashMapContext;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.BakedGuiItem;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.Gui;
import com.artillexstudios.axquestboard.libs.axapi.scheduler.Scheduler;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Semaphore;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/gui/inventory/renderer/strategy/WaitingRenderStrategy.class */
public class WaitingRenderStrategy implements RenderStrategy {
    private static transient /* synthetic */ String wSZiwNUAra = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    @Override // com.artillexstudios.axquestboard.libs.axapi.gui.inventory.renderer.strategy.RenderStrategy
    public void render(Gui gui, HashMapContext context, boolean newInventory, Int2ObjectMap<BakedGuiItem> items, Inventory inventory, Semaphore lock) {
        CompletableFuture[] completableFutureArr = new CompletableFuture[gui.getProviders().size()];
        Player player = gui.getRenderer().getPlayer();
        gui.getProviders().forEach((num, guiItemProvider) -> {
            completableFutureArr[num.intValue()] = guiItemProvider.provide(context, gui.getModifiers());
        });
        CompletableFuture.allOf(completableFutureArr).whenComplete((r12, th) -> {
            for (int i = 0; i < completableFutureArr.length; i++) {
                BakedGuiItem bakedGuiItem = (BakedGuiItem) completableFutureArr[i].join();
                BakedGuiItem bakedGuiItem2 = (BakedGuiItem) items.put(i, bakedGuiItem);
                if (bakedGuiItem2 == null || !bakedGuiItem2.stack().equals(bakedGuiItem.stack())) {
                    inventory.setItem(i, bakedGuiItem.stack());
                }
            }
            if (newInventory || gui.getRenderer().isClosed()) {
                gui.getRenderer().setClosed(false);
                Scheduler.get().runAt(player.getLocation(), () -> {
                    player.openInventory(inventory);
                });
            }
            lock.release();
        });
    }
}
