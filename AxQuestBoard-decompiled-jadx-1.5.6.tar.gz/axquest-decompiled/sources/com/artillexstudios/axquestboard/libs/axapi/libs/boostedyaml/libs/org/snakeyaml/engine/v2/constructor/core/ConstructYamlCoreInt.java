package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.constructor.core;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.constructor.ConstructScalar;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.ConstructorException;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Node;
import java.math.BigInteger;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/constructor/core/ConstructYamlCoreInt.class */
public class ConstructYamlCoreInt extends ConstructScalar {
    private static final int[][] RADIX_MAX = new int[17][2];
    private static transient /* synthetic */ String xRdfqSugTF = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    static {
        for (int i : new int[]{8, 10, 16}) {
            RADIX_MAX[i] = new int[]{maxLen(Integer.MAX_VALUE, i), maxLen(Long.MAX_VALUE, i)};
        }
    }

    private static int maxLen(int i, int i2) {
        return Integer.toString(i, i2).length();
    }

    private static int maxLen(long j, int i) {
        return Long.toString(j, i).length();
    }

    protected static Number createLongOrBigInteger(String str, int i) {
        try {
            return Long.valueOf(str, i);
        } catch (NumberFormatException e) {
            return new BigInteger(str, i);
        }
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.ConstructNode
    public Object construct(Node node) {
        String strConstructScalar = constructScalar(node);
        if (strConstructScalar.isEmpty()) {
            throw new ConstructorException("while constructing an int", node.getStartMark(), "found empty value", node.getStartMark());
        }
        return createIntNumber(strConstructScalar);
    }

    public Object createIntNumber(String str) {
        String strSubstring;
        int i;
        int i2 = 1;
        char cCharAt = str.charAt(0);
        if (cCharAt == '-') {
            i2 = -1;
            str = str.substring(1);
        } else if (cCharAt == '+') {
            str = str.substring(1);
        }
        if ("0".equals(str)) {
            return 0;
        }
        if (str.startsWith("0x")) {
            strSubstring = str.substring(2);
            i = 16;
        } else if (str.startsWith("0o")) {
            strSubstring = str.substring(2);
            i = 8;
        } else {
            return createNumber(i2, str, 10);
        }
        return createNumber(i2, strSubstring, i);
    }

    private Number createNumber(int i, String str, int i2) {
        Number numberCreateLongOrBigInteger;
        int length = str != null ? str.length() : 0;
        if (i < 0) {
            str = "-" + str;
        }
        int[] iArr = i2 < RADIX_MAX.length ? RADIX_MAX[i2] : null;
        if (iArr != null) {
            if (length > iArr[0]) {
                if (length > iArr[1]) {
                    return new BigInteger(str, i2);
                }
                return createLongOrBigInteger(str, i2);
            }
        }
        try {
            numberCreateLongOrBigInteger = Integer.valueOf(str, i2);
        } catch (NumberFormatException e) {
            numberCreateLongOrBigInteger = createLongOrBigInteger(str, i2);
        }
        return numberCreateLongOrBigInteger;
    }
}
