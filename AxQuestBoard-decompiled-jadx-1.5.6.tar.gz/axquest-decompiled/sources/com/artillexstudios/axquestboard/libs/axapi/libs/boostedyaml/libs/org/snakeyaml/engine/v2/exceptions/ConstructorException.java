package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions;

import java.util.Optional;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/exceptions/ConstructorException.class */
public class ConstructorException extends MarkedYamlEngineException {
    private static transient /* synthetic */ String pdYgkyCpti = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public ConstructorException(String str, Optional<Mark> optional, String str2, Optional<Mark> optional2, Throwable th) {
        super(str, optional, str2, optional2, th);
    }

    public ConstructorException(String str, Optional<Mark> optional, String str2, Optional<Mark> optional2) {
        this(str, optional, str2, optional2, null);
    }
}
