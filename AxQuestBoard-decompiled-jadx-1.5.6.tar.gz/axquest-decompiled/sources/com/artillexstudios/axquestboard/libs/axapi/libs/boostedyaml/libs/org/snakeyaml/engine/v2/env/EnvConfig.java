package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.env;

import java.util.Optional;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/env/EnvConfig.class */
public interface EnvConfig {
    default Optional<String> getValueFor(String name, String separator, String value, String environment) {
        return Optional.empty();
    }
}
