package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.block.implementation.Section;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.engine.ExtendedConstructor;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.engine.ExtendedRepresenter;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.DumpSettings;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.LoadSettings;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.StreamDataWriter;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.YamlUnicodeReader;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.composer.Composer;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.emitter.Emitter;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.MappingNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Node;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser.ParserImpl;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.scanner.StreamReader;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.serializer.Serializer;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.Settings;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.dumper.DumperSettings;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.general.GeneralSettings;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.loader.LoaderSettings;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.updater.UpdaterSettings;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.updater.Updater;
import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InvalidObjectException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.StringWriter;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Objects;
import java.util.Optional;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/YamlDocument.class */
public class YamlDocument extends Section {
    private final File file;
    private final YamlDocument defaults;
    private GeneralSettings generalSettings;
    private LoaderSettings loaderSettings;
    private DumperSettings dumperSettings;
    private UpdaterSettings updaterSettings;
    private static transient /* synthetic */ String tXQVFxiwEZ = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    /* JADX INFO: renamed from: com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.YamlDocument$1 */
    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/YamlDocument$1.class */
    static /* synthetic */ class C00081 {
        private static transient /* synthetic */ String nJwkerlBKc = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";
    }

    protected YamlDocument(@NotNull InputStream inputStream, @Nullable InputStream inputStream2, @NotNull Settings... settingsArr) throws IOException {
        super(Collections.emptyMap());
        setSettingsInternal(settingsArr);
        setValue(this.generalSettings.getDefaultMap());
        this.file = null;
        this.defaults = inputStream2 == null ? null : new YamlDocument(inputStream2, (InputStream) null, settingsArr);
        reload(inputStream);
    }

    protected YamlDocument(@NotNull File file, @Nullable InputStream inputStream, @NotNull Settings... settingsArr) throws IOException {
        super(Collections.emptyMap());
        setSettingsInternal(settingsArr);
        setValue(this.generalSettings.getDefaultMap());
        this.file = file;
        this.defaults = inputStream == null ? null : new YamlDocument(inputStream, (InputStream) null, this.generalSettings, this.loaderSettings, this.dumperSettings, this.updaterSettings);
        reload();
    }

    private void setSettingsInternal(@NotNull Settings... settingsArr) {
        for (Settings settings : settingsArr) {
            if (settings instanceof GeneralSettings) {
                if (this.generalSettings != null && this.generalSettings.getKeyFormat() != ((GeneralSettings) settings).getKeyFormat()) {
                    throw new IllegalArgumentException("Cannot change the key format! Recreate the file if needed to do so.");
                }
                this.generalSettings = (GeneralSettings) settings;
            } else if (settings instanceof LoaderSettings) {
                this.loaderSettings = (LoaderSettings) settings;
            } else if (settings instanceof DumperSettings) {
                this.dumperSettings = (DumperSettings) settings;
            } else if (settings instanceof UpdaterSettings) {
                this.updaterSettings = (UpdaterSettings) settings;
            } else {
                throw new IllegalArgumentException("Unknown settings object!");
            }
        }
        this.generalSettings = this.generalSettings == null ? GeneralSettings.DEFAULT : this.generalSettings;
        this.loaderSettings = this.loaderSettings == null ? LoaderSettings.DEFAULT : this.loaderSettings;
        this.dumperSettings = this.dumperSettings == null ? DumperSettings.DEFAULT : this.dumperSettings;
        this.updaterSettings = this.updaterSettings == null ? UpdaterSettings.DEFAULT : this.updaterSettings;
    }

    public boolean reload() throws IOException {
        if (this.file == null) {
            return false;
        }
        reload(this.file);
        return true;
    }

    private void reload(@NotNull File file) throws IOException {
        clear();
        if (((File) Objects.requireNonNull(file, "File cannot be null!")).exists()) {
            reload(new BufferedInputStream(new FileInputStream(file)));
            return;
        }
        if (this.loaderSettings.isCreateFileIfAbsent()) {
            if (file.getParentFile() != null) {
                file.getParentFile().mkdirs();
            }
            file.createNewFile();
        }
        if (this.defaults == null) {
            initEmpty(this);
            return;
        }
        String strDump = this.defaults.dump();
        BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file, false), StandardCharsets.UTF_8));
        Throwable th = null;
        try {
            try {
                bufferedWriter.write(strDump);
                if (bufferedWriter != null) {
                    if (0 != 0) {
                        try {
                            bufferedWriter.close();
                        } catch (Throwable th2) {
                            th.addSuppressed(th2);
                        }
                    } else {
                        bufferedWriter.close();
                    }
                }
                reload(new BufferedInputStream(new ByteArrayInputStream(strDump.getBytes(StandardCharsets.UTF_8))));
            } catch (Throwable th3) {
                th = th3;
                throw th3;
            }
        } catch (Throwable th4) {
            if (bufferedWriter != null) {
                if (th != null) {
                    try {
                        bufferedWriter.close();
                    } catch (Throwable th5) {
                        th.addSuppressed(th5);
                    }
                } else {
                    bufferedWriter.close();
                }
            }
            throw th4;
        }
    }

    public void reload(@NotNull InputStream inputStream) throws IOException {
        reload(inputStream, this.loaderSettings);
    }

    public void reload(@NotNull InputStream inputStream, @NotNull LoaderSettings loaderSettings) throws IOException {
        clear();
        LoadSettings loadSettingsBuildEngineSettings = ((LoaderSettings) Objects.requireNonNull(loaderSettings, "Loader settings cannot be null!")).buildEngineSettings(this.generalSettings);
        ExtendedConstructor extendedConstructor = new ExtendedConstructor(loadSettingsBuildEngineSettings, this.generalSettings.getSerializer());
        Composer composer = new Composer(loadSettingsBuildEngineSettings, new ParserImpl(loadSettingsBuildEngineSettings, new StreamReader(loadSettingsBuildEngineSettings, new YamlUnicodeReader((InputStream) Objects.requireNonNull(inputStream, "Input stream cannot be null!")))));
        if (composer.hasNext()) {
            Node next = composer.next();
            if (composer.hasNext()) {
                throw new InvalidObjectException("Multiple documents are not supported!");
            }
            if (!(next instanceof MappingNode)) {
                throw new IllegalArgumentException(String.format("Top level object is not a map! Parsed node: %s", next.toString()));
            }
            extendedConstructor.constructSingleDocument(Optional.of(next));
            init(this, null, (MappingNode) next, extendedConstructor);
            extendedConstructor.clear();
        } else {
            initEmpty(this);
        }
        if (this.file != null && loaderSettings.isCreateFileIfAbsent() && !this.file.exists()) {
            if (this.file.getParentFile() != null) {
                this.file.getParentFile().mkdirs();
            }
            this.file.createNewFile();
            save();
        }
        if (this.defaults != null && loaderSettings.isAutoUpdate()) {
            Updater.update(this, this.defaults, this.updaterSettings, this.generalSettings);
        }
    }

    public boolean update() {
        return update(this.updaterSettings);
    }

    public boolean update(@NotNull UpdaterSettings updaterSettings) {
        if (this.defaults == null) {
            return false;
        }
        Updater.update(this, this.defaults, (UpdaterSettings) Objects.requireNonNull(updaterSettings, "Updater settings cannot be null!"), this.generalSettings);
        return true;
    }

    public void update(@NotNull InputStream inputStream) {
        update(inputStream, this.updaterSettings);
    }

    public void update(@NotNull InputStream inputStream, @NotNull UpdaterSettings updaterSettings) {
        Updater.update(this, create((InputStream) Objects.requireNonNull(inputStream, "Defaults cannot be null!"), this.generalSettings, this.loaderSettings, this.dumperSettings, UpdaterSettings.DEFAULT), (UpdaterSettings) Objects.requireNonNull(updaterSettings, "Updater settings cannot be null!"), this.generalSettings);
    }

    public boolean save() {
        if (this.file == null) {
            return false;
        }
        save(this.file);
        return true;
    }

    /* JADX WARN: Bottom block not found for handler: all -> 0x004e */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public void save(@NotNull File file) throws IOException {
        BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file, false), StandardCharsets.UTF_8));
        Throwable th = null;
        try {
            bufferedWriter.write(dump());
            if (bufferedWriter != null) {
                if (0 != 0) {
                    try {
                        bufferedWriter.close();
                        return;
                    } catch (Throwable th2) {
                        th.addSuppressed(th2);
                        return;
                    }
                }
                bufferedWriter.close();
            }
        } catch (Throwable th3) {
            th = th3;
            throw th3;
        }
    }

    public void save(@NotNull OutputStream outputStream, Charset charset) throws IOException {
        outputStream.write(dump().getBytes(charset));
    }

    public void save(@NotNull OutputStreamWriter outputStreamWriter) {
        outputStreamWriter.write(dump());
    }

    public String dump() {
        return dump(this.dumperSettings);
    }

    public String dump(@NotNull DumperSettings dumperSettings) {
        DumpSettings dumpSettingsBuildEngineSettings = dumperSettings.buildEngineSettings();
        SerializedStream serializedStream = new SerializedStream(null);
        ExtendedRepresenter extendedRepresenter = new ExtendedRepresenter(getClass(), this.generalSettings, dumperSettings, dumpSettingsBuildEngineSettings);
        Serializer serializer = new Serializer(dumpSettingsBuildEngineSettings, new Emitter(dumpSettingsBuildEngineSettings, serializedStream));
        serializer.emitStreamStart();
        serializer.serializeDocument(extendedRepresenter.represent(this));
        serializer.emitStreamEnd();
        return serializedStream.toString();
    }

    public void setSettings(@NotNull Settings... settingsArr) {
        setSettingsInternal(settingsArr);
    }

    @Deprecated
    public void setLoaderSettings(@NotNull LoaderSettings loaderSettings) {
        this.loaderSettings = loaderSettings;
    }

    public void setDumperSettings(@NotNull DumperSettings dumperSettings) {
        this.dumperSettings = dumperSettings;
    }

    public void setGeneralSettings(@NotNull GeneralSettings generalSettings) {
        if (generalSettings.getKeyFormat() != this.generalSettings.getKeyFormat()) {
            throw new IllegalArgumentException("Cannot change key format! Recreate the file if needed to do so.");
        }
        this.generalSettings = generalSettings;
    }

    public void setUpdaterSettings(@NotNull UpdaterSettings updaterSettings) {
        this.updaterSettings = updaterSettings;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.block.implementation.Section
    @Nullable
    public YamlDocument getDefaults() {
        return this.defaults;
    }

    @NotNull
    public GeneralSettings getGeneralSettings() {
        return this.generalSettings;
    }

    @NotNull
    public DumperSettings getDumperSettings() {
        return this.dumperSettings;
    }

    @NotNull
    public UpdaterSettings getUpdaterSettings() {
        return this.updaterSettings;
    }

    @NotNull
    public LoaderSettings getLoaderSettings() {
        return this.loaderSettings;
    }

    @Nullable
    public File getFile() {
        return this.file;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.block.implementation.Section
    public boolean isRoot() {
        return true;
    }

    public static YamlDocument create(@NotNull File file, @NotNull InputStream inputStream, @NotNull Settings... settingsArr) {
        return new YamlDocument(file, inputStream, settingsArr);
    }

    public static YamlDocument create(@NotNull InputStream inputStream, @NotNull InputStream inputStream2, @NotNull Settings... settingsArr) {
        return new YamlDocument(inputStream, inputStream2, settingsArr);
    }

    public static YamlDocument create(@NotNull File file, @NotNull Settings... settingsArr) {
        return new YamlDocument(file, (InputStream) null, settingsArr);
    }

    public static YamlDocument create(@NotNull InputStream inputStream, @NotNull Settings... settingsArr) {
        return new YamlDocument(inputStream, (InputStream) null, settingsArr);
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/YamlDocument$SerializedStream.class */
    private static class SerializedStream extends StringWriter implements StreamDataWriter {
        private static transient /* synthetic */ String XODjXvjTKf = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        private SerializedStream() {
        }

        /* synthetic */ SerializedStream(C00081 c00081) {
            this();
        }
    }
}
