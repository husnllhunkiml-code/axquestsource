package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.utils.format;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/utils/format/NodeRole.class */
public enum NodeRole {
    KEY,
    VALUE
}
