package com.artillexstudios.axquestboard.libs.axapi.items.component.type;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/items/component/type/Unit.class */
public enum Unit {
    INSTANCE
}
