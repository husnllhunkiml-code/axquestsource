package com.artillexstudios.axquestboard.libs.axapi.gui.configuration.actions;

import com.artillexstudios.axquestboard.libs.axapi.gui.configuration.actions.implementation.CloseAction;
import com.artillexstudios.axquestboard.libs.axapi.gui.configuration.actions.implementation.ConsoleCommandAction;
import com.artillexstudios.axquestboard.libs.axapi.gui.configuration.actions.implementation.MessageAction;
import com.artillexstudios.axquestboard.libs.axapi.gui.configuration.actions.implementation.PageChangeAction;
import com.artillexstudios.axquestboard.libs.axapi.gui.configuration.actions.implementation.PlayerCommandAction;
import com.artillexstudios.axquestboard.libs.axapi.gui.configuration.actions.implementation.RefreshAction;
import com.artillexstudios.axquestboard.libs.axapi.utils.featureflags.FeatureFlags;
import com.artillexstudios.axquestboard.libs.axapi.utils.logging.LogUtils;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.kyori.adventure.text.serializer.commons.ComponentTreeConstants;
import org.apache.commons.lang3.StringUtils;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/gui/configuration/actions/Actions.class */
public enum Actions {
    INSTANCE;

    private final Map<String, ActionProvider<?>> registered = new HashMap();

    Actions() {
        register("close", CloseAction::new);
        register("console", ConsoleCommandAction::new);
        register("message", MessageAction::new);
        register(ComponentTreeConstants.CLICK_EVENT_PAGE, PageChangeAction::new);
        register(ComponentTreeConstants.OBJECT_PLAYER, PlayerCommandAction::new);
        register("refresh", RefreshAction::new);
    }

    public void register(String id, ActionProvider<?> action) {
        this.registered.put(id.toLowerCase(Locale.ENGLISH), action);
    }

    public List<Action<?>> parseAll(List<String> lines) {
        if (lines == null || lines.isEmpty()) {
            return List.of();
        }
        ArrayList arrayList = new ArrayList(lines.size());
        Iterator<String> it = lines.iterator();
        while (it.hasNext()) {
            Action<?> action = parse(it.next());
            if (action != null) {
                arrayList.add(action);
            }
        }
        return arrayList;
    }

    public Action<?> parse(String line) {
        if (line == null || line.isBlank()) {
            return null;
        }
        String lowerCase = StringUtils.substringBetween(line, "[", "]").toLowerCase(Locale.ENGLISH);
        ActionProvider<?> actionProvider = this.registered.get(lowerCase);
        if (actionProvider == null) {
            LogUtils.info("No actionprovider found with id {}!", lowerCase);
            return null;
        }
        String strStrip = line.substring(lowerCase.length() + 2).strip();
        if (FeatureFlags.DEBUG.get().booleanValue()) {
            LogUtils.debug("Creating action with id: {} with arguments: {}", lowerCase, strStrip);
        }
        try {
            return actionProvider.provide(strStrip);
        } catch (IllegalArgumentException e) {
            LogUtils.error("Failed to construct action with id: {} and arguments: {}!", lowerCase, strStrip);
            return null;
        }
    }
}
