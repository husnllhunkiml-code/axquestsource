package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.dvs.segment;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/dvs/segment/Segment.class */
public interface Segment {
    int parse(String str, int i);

    String getElement(int i);

    int getElementLength(int i);

    int length();

    static Segment range(int start, int end, int step, int fill) {
        return new RangeSegment(start, end, step, fill);
    }

    static Segment range(int start, int end, int step) {
        return new RangeSegment(start, end, step, 0);
    }

    static Segment range(int start, int end) {
        return new RangeSegment(start, end, start < end ? 1 : -1, 0);
    }

    static Segment literal(String... elements) {
        return new LiteralSegment(elements);
    }
}
