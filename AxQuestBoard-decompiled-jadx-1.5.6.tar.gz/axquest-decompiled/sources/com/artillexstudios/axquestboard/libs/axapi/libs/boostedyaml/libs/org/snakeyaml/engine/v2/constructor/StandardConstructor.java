package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.constructor;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.ConstructNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.LoadSettings;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.env.EnvConfig;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.ConstructorException;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.DuplicateKeyException;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.Mark;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.MissingEnvironmentVariableException;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.YamlEngineException;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.MappingNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Node;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.NodeTuple;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.SequenceNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Tag;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.resolver.JsonScalarResolver;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/constructor/StandardConstructor.class */
public class StandardConstructor extends BaseConstructor {
    private static transient /* synthetic */ String QlkdQalZyk = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public StandardConstructor(LoadSettings loadSettings) {
        super(loadSettings);
        this.tagConstructors.put(Tag.SET, new ConstructYamlSet());
        this.tagConstructors.put(Tag.STR, new ConstructYamlStr());
        this.tagConstructors.put(Tag.SEQ, new ConstructYamlSeq());
        this.tagConstructors.put(Tag.MAP, new ConstructYamlMap());
        this.tagConstructors.put(Tag.ENV_TAG, new ConstructEnv());
        this.tagConstructors.putAll(loadSettings.getSchema().getSchemaTagConstructors());
        this.tagConstructors.putAll(loadSettings.getTagConstructors());
    }

    protected void flattenMapping(MappingNode mappingNode) {
        processDuplicateKeys(mappingNode);
    }

    protected void processDuplicateKeys(MappingNode mappingNode) {
        List<NodeTuple> value = mappingNode.getValue();
        HashMap map = new HashMap(value.size());
        TreeSet treeSet = new TreeSet();
        int i = 0;
        for (NodeTuple nodeTuple : value) {
            Object objConstructKey = constructKey(nodeTuple.getKeyNode(), mappingNode.getStartMark(), nodeTuple.getKeyNode().getStartMark());
            Integer num = (Integer) map.put(objConstructKey, Integer.valueOf(i));
            if (num != null) {
                if (!this.settings.getAllowDuplicateKeys()) {
                    throw new DuplicateKeyException(mappingNode.getStartMark(), objConstructKey, nodeTuple.getKeyNode().getStartMark());
                }
                treeSet.add(num);
            }
            i++;
        }
        Iterator itDescendingIterator = treeSet.descendingIterator();
        while (itDescendingIterator.hasNext()) {
            value.remove(((Integer) itDescendingIterator.next()).intValue());
        }
    }

    private Object constructKey(Node node, Optional<Mark> optional, Optional<Mark> optional2) {
        Object objConstructObject = constructObject(node);
        if (objConstructObject != null) {
            try {
                objConstructObject.hashCode();
            } catch (Exception e) {
                throw new ConstructorException("while constructing a mapping", optional, "found unacceptable key " + objConstructObject, optional2, e);
            }
        }
        return objConstructObject;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.constructor.BaseConstructor
    protected void constructMapping2ndStep(MappingNode mappingNode, Map<Object, Object> map) {
        flattenMapping(mappingNode);
        super.constructMapping2ndStep(mappingNode, map);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.constructor.BaseConstructor
    protected void constructSet2ndStep(MappingNode mappingNode, Set<Object> set) {
        flattenMapping(mappingNode);
        super.constructSet2ndStep(mappingNode, set);
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/constructor/StandardConstructor$ConstructYamlSet.class */
    public class ConstructYamlSet implements ConstructNode {
        private static transient /* synthetic */ String YpLApVhAfL = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        public ConstructYamlSet() {
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.ConstructNode
        public Object construct(Node node) {
            if (node.isRecursive()) {
                return StandardConstructor.this.constructedObjects.containsKey(node) ? StandardConstructor.this.constructedObjects.get(node) : StandardConstructor.this.createEmptySetForNode((MappingNode) node);
            }
            return StandardConstructor.this.constructSet((MappingNode) node);
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.ConstructNode
        public void constructRecursive(Node node, Object obj) {
            if (node.isRecursive()) {
                StandardConstructor.this.constructSet2ndStep((MappingNode) node, (Set) obj);
                return;
            }
            throw new YamlEngineException("Unexpected recursive set structure. Node: " + node);
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/constructor/StandardConstructor$ConstructYamlStr.class */
    public class ConstructYamlStr extends ConstructScalar {
        private static transient /* synthetic */ String WrvTPwUqoI = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        public ConstructYamlStr() {
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.ConstructNode
        public Object construct(Node node) {
            return constructScalar(node);
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/constructor/StandardConstructor$ConstructYamlSeq.class */
    public class ConstructYamlSeq implements ConstructNode {
        private static transient /* synthetic */ String HIPgeCshsN = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        public ConstructYamlSeq() {
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.ConstructNode
        public Object construct(Node node) {
            SequenceNode sequenceNode = (SequenceNode) node;
            if (node.isRecursive()) {
                return StandardConstructor.this.createEmptyListForNode(sequenceNode);
            }
            return StandardConstructor.this.constructSequence(sequenceNode);
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.ConstructNode
        public void constructRecursive(Node node, Object obj) {
            if (node.isRecursive()) {
                StandardConstructor.this.constructSequenceStep2((SequenceNode) node, (List) obj);
                return;
            }
            throw new YamlEngineException("Unexpected recursive sequence structure. Node: " + node);
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/constructor/StandardConstructor$ConstructYamlMap.class */
    public class ConstructYamlMap implements ConstructNode {
        private static transient /* synthetic */ String xfTBPYfSto = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        public ConstructYamlMap() {
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.ConstructNode
        public Object construct(Node node) {
            MappingNode mappingNode = (MappingNode) node;
            if (node.isRecursive()) {
                return StandardConstructor.this.createEmptyMapFor(mappingNode);
            }
            return StandardConstructor.this.constructMapping(mappingNode);
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.ConstructNode
        public void constructRecursive(Node node, Object obj) {
            if (node.isRecursive()) {
                StandardConstructor.this.constructMapping2ndStep((MappingNode) node, (Map) obj);
                return;
            }
            throw new YamlEngineException("Unexpected recursive mapping structure. Node: " + node);
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/constructor/StandardConstructor$ConstructEnv.class */
    public class ConstructEnv extends ConstructScalar {
        private static transient /* synthetic */ String GNzOyxmGPA = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        public ConstructEnv() {
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.ConstructNode
        public Object construct(Node node) {
            String strConstructScalar = constructScalar(node);
            Optional<EnvConfig> envConfig = StandardConstructor.this.settings.getEnvConfig();
            if (envConfig.isPresent()) {
                EnvConfig envConfig2 = envConfig.get();
                Matcher matcher = JsonScalarResolver.ENV_FORMAT.matcher(strConstructScalar);
                matcher.matches();
                String strGroup = matcher.group(1);
                String strGroup2 = matcher.group(3);
                String str = strGroup2 != null ? strGroup2 : "";
                String strGroup3 = matcher.group(2);
                String env = getEnv(strGroup);
                return envConfig2.getValueFor(strGroup, strGroup3, str, env).orElseGet(() -> {
                    return apply(strGroup, strGroup3, str, env);
                });
            }
            return strConstructScalar;
        }

        public String apply(String str, String str2, String str3, String str4) {
            if (str4 != null && !str4.isEmpty()) {
                return str4;
            }
            if (str2 != null) {
                if (str2.equals("?") && str4 == null) {
                    throw new MissingEnvironmentVariableException("Missing mandatory variable " + str + ": " + str3);
                }
                if (str2.equals(":?")) {
                    if (str4 == null) {
                        throw new MissingEnvironmentVariableException("Missing mandatory variable " + str + ": " + str3);
                    }
                    if (str4.isEmpty()) {
                        throw new MissingEnvironmentVariableException("Empty mandatory variable " + str + ": " + str3);
                    }
                }
                if (str2.startsWith(":")) {
                    if (str4 == null || str4.isEmpty()) {
                        return str3;
                    }
                    return "";
                }
                if (str4 == null) {
                    return str3;
                }
                return "";
            }
            return "";
        }

        public String getEnv(String str) {
            return System.getenv(str);
        }
    }
}
