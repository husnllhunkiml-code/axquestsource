package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.utils.conversion;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/utils/conversion/ListConversions.class */
public class ListConversions {
    private static transient /* synthetic */ String YbMyktGraM = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    @NotNull
    public static Optional<List<String>> toStringList(@Nullable List<?> list) {
        return construct(list, obj -> {
            return Optional.ofNullable(obj.toString());
        });
    }

    @NotNull
    public static Optional<List<Integer>> toIntList(@Nullable List<?> list) {
        return construct(list, PrimitiveConversions::toInt);
    }

    @NotNull
    public static Optional<List<BigInteger>> toBigIntList(@Nullable List<?> list) {
        return construct(list, PrimitiveConversions::toBigInt);
    }

    @NotNull
    public static Optional<List<Byte>> toByteList(@Nullable List<?> list) {
        return construct(list, PrimitiveConversions::toByte);
    }

    @NotNull
    public static Optional<List<Long>> toLongList(@Nullable List<?> list) {
        return construct(list, PrimitiveConversions::toLong);
    }

    @NotNull
    public static Optional<List<Double>> toDoubleList(@Nullable List<?> list) {
        return construct(list, PrimitiveConversions::toDouble);
    }

    @NotNull
    public static Optional<List<Float>> toFloatList(@Nullable List<?> list) {
        return construct(list, PrimitiveConversions::toFloat);
    }

    @NotNull
    public static Optional<List<Short>> toShortList(@Nullable List<?> list) {
        return construct(list, PrimitiveConversions::toShort);
    }

    @NotNull
    public static Optional<List<Map<?, ?>>> toMapList(@Nullable List<?> list) {
        return construct(list, obj -> {
            return obj instanceof Map ? Optional.of((Map) obj) : Optional.empty();
        });
    }

    @NotNull
    private static <T> Optional<List<T>> construct(@Nullable List<?> list, @NotNull Function<Object, Optional<T>> function) {
        if (list == null) {
            return Optional.empty();
        }
        ArrayList arrayList = new ArrayList();
        for (Object obj : list) {
            if (obj != null) {
                Optional<T> optionalApply = function.apply(obj);
                arrayList.getClass();
                optionalApply.ifPresent(arrayList::add);
            }
        }
        return Optional.of(arrayList);
    }
}
