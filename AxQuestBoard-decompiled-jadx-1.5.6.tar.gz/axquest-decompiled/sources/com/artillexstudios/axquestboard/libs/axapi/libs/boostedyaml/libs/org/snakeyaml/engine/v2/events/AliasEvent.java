package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.Anchor;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.Mark;
import java.util.Optional;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/events/AliasEvent.class */
public final class AliasEvent extends NodeEvent {
    private final Anchor alias;
    private static transient /* synthetic */ String rxOvAQEAYc = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public AliasEvent(Optional<Anchor> optional, Optional<Mark> optional2, Optional<Mark> optional3) {
        super(optional, optional2, optional3);
        this.alias = optional.orElseThrow(() -> {
            return new NullPointerException("Anchor is required in AliasEvent");
        });
    }

    public AliasEvent(Optional<Anchor> optional) {
        this(optional, Optional.empty(), Optional.empty());
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.Event
    public Event.ID getEventId() {
        return Event.ID.Alias;
    }

    public String toString() {
        return "=ALI *" + this.alias;
    }

    public Anchor getAlias() {
        return this.alias;
    }
}
