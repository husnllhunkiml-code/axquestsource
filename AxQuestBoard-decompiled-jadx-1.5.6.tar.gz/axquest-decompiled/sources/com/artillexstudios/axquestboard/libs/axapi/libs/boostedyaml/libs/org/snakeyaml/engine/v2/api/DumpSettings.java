package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.FlowStyle;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.NonPrintableStyle;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.ScalarStyle;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.SpecVersion;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Tag;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.schema.Schema;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.serializer.AnchorGenerator;
import java.util.Map;
import java.util.Optional;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/api/DumpSettings.class */
public final class DumpSettings {
    private final boolean explicitStart;
    private final boolean explicitEnd;
    private final NonPrintableStyle nonPrintableStyle;
    private final Optional<Tag> explicitRootTag;
    private final AnchorGenerator anchorGenerator;
    private final Optional<SpecVersion> yamlDirective;
    private final Map<String, String> tagDirective;
    private final FlowStyle defaultFlowStyle;
    private final ScalarStyle defaultScalarStyle;
    private final Boolean dereferenceAliases;
    private final boolean canonical;
    private final boolean multiLineFlow;
    private final boolean useUnicodeEncoding;
    private final int indent;
    private final int indicatorIndent;
    private final int width;
    private final String bestLineBreak;
    private final boolean splitLines;
    private final int maxSimpleKeyLength;
    private final boolean indentWithIndicator;
    private final boolean dumpComments;
    private final Schema schema;
    private final Map<SettingKey, Object> customProperties;
    private static transient /* synthetic */ String BnJmEdwDDZ = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    DumpSettings(boolean z, boolean z2, Optional<Tag> optional, AnchorGenerator anchorGenerator, Optional<SpecVersion> optional2, Map<String, String> map, FlowStyle flowStyle, ScalarStyle scalarStyle, NonPrintableStyle nonPrintableStyle, Schema schema, Boolean bool, boolean z3, boolean z4, boolean z5, int i, int i2, int i3, String str, boolean z6, int i4, Map<SettingKey, Object> map2, boolean z7, boolean z8) {
        this.explicitStart = z;
        this.explicitEnd = z2;
        this.nonPrintableStyle = nonPrintableStyle;
        this.explicitRootTag = optional;
        this.anchorGenerator = anchorGenerator;
        this.yamlDirective = optional2;
        this.tagDirective = map;
        this.defaultFlowStyle = flowStyle;
        this.defaultScalarStyle = scalarStyle;
        this.schema = schema;
        this.canonical = z3;
        this.multiLineFlow = z4;
        this.useUnicodeEncoding = z5;
        this.indent = i;
        this.indicatorIndent = i2;
        this.width = i3;
        this.bestLineBreak = str;
        this.splitLines = z6;
        this.maxSimpleKeyLength = i4;
        this.customProperties = map2;
        this.indentWithIndicator = z7;
        this.dumpComments = z8;
        this.dereferenceAliases = bool;
    }

    public static DumpSettingsBuilder builder() {
        return new DumpSettingsBuilder();
    }

    public FlowStyle getDefaultFlowStyle() {
        return this.defaultFlowStyle;
    }

    public ScalarStyle getDefaultScalarStyle() {
        return this.defaultScalarStyle;
    }

    public boolean isExplicitStart() {
        return this.explicitStart;
    }

    public AnchorGenerator getAnchorGenerator() {
        return this.anchorGenerator;
    }

    public boolean isExplicitEnd() {
        return this.explicitEnd;
    }

    public Optional<Tag> getExplicitRootTag() {
        return this.explicitRootTag;
    }

    public Optional<SpecVersion> getYamlDirective() {
        return this.yamlDirective;
    }

    public Map<String, String> getTagDirective() {
        return this.tagDirective;
    }

    public boolean isCanonical() {
        return this.canonical;
    }

    public boolean isMultiLineFlow() {
        return this.multiLineFlow;
    }

    public boolean isUseUnicodeEncoding() {
        return this.useUnicodeEncoding;
    }

    public int getIndent() {
        return this.indent;
    }

    public int getIndicatorIndent() {
        return this.indicatorIndent;
    }

    public int getWidth() {
        return this.width;
    }

    public String getBestLineBreak() {
        return this.bestLineBreak;
    }

    public boolean isSplitLines() {
        return this.splitLines;
    }

    public int getMaxSimpleKeyLength() {
        return this.maxSimpleKeyLength;
    }

    public NonPrintableStyle getNonPrintableStyle() {
        return this.nonPrintableStyle;
    }

    public Object getCustomProperty(SettingKey settingKey) {
        return this.customProperties.get(settingKey);
    }

    public boolean getIndentWithIndicator() {
        return this.indentWithIndicator;
    }

    public boolean getDumpComments() {
        return this.dumpComments;
    }

    public Schema getSchema() {
        return this.schema;
    }

    public Boolean isDereferenceAliases() {
        return this.dereferenceAliases;
    }
}
