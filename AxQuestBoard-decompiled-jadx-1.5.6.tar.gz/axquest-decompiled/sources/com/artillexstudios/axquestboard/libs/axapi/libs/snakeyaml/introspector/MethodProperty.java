package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.introspector;

import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.error.YAMLException;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.util.ArrayUtils;
import java.beans.PropertyDescriptor;
import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.util.List;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/introspector/MethodProperty.class */
public class MethodProperty extends GenericProperty {
    private final PropertyDescriptor property;
    private final boolean readable;
    private final boolean writable;
    private static transient /* synthetic */ String QJEWsQTuGR = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    private static Type discoverGenericType(PropertyDescriptor propertyDescriptor) {
        Method readMethod = propertyDescriptor.getReadMethod();
        if (readMethod != null) {
            return readMethod.getGenericReturnType();
        }
        Method writeMethod = propertyDescriptor.getWriteMethod();
        if (writeMethod != null) {
            Type[] genericParameterTypes = writeMethod.getGenericParameterTypes();
            if (genericParameterTypes.length > 0) {
                return genericParameterTypes[0];
            }
            return null;
        }
        return null;
    }

    public MethodProperty(PropertyDescriptor propertyDescriptor) {
        super(propertyDescriptor.getName(), propertyDescriptor.getPropertyType(), discoverGenericType(propertyDescriptor));
        this.property = propertyDescriptor;
        this.readable = propertyDescriptor.getReadMethod() != null;
        this.writable = propertyDescriptor.getWriteMethod() != null;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.introspector.Property
    public void set(Object obj, Object obj2) throws IllegalAccessException, InvocationTargetException {
        if (!this.writable) {
            throw new YAMLException("No writable property '" + getName() + "' on class: " + obj.getClass().getName());
        }
        this.property.getWriteMethod().invoke(obj, obj2);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.introspector.Property
    public Object get(Object obj) {
        try {
            this.property.getReadMethod().setAccessible(true);
            return this.property.getReadMethod().invoke(obj, new Object[0]);
        } catch (Exception e) {
            throw new YAMLException("Unable to find getter for property '" + this.property.getName() + "' on object " + obj + ":" + e);
        }
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.introspector.Property
    public List<Annotation> getAnnotations() {
        List<Annotation> unmodifiableList;
        if (isReadable() && isWritable()) {
            unmodifiableList = ArrayUtils.toUnmodifiableCompositeList(this.property.getReadMethod().getAnnotations(), this.property.getWriteMethod().getAnnotations());
        } else if (isReadable()) {
            unmodifiableList = ArrayUtils.toUnmodifiableList(this.property.getReadMethod().getAnnotations());
        } else {
            unmodifiableList = ArrayUtils.toUnmodifiableList(this.property.getWriteMethod().getAnnotations());
        }
        return unmodifiableList;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.introspector.Property
    public <A extends Annotation> A getAnnotation(Class<A> cls) {
        Annotation annotation = null;
        if (isReadable()) {
            annotation = this.property.getReadMethod().getAnnotation(cls);
        }
        if (annotation == null && isWritable()) {
            annotation = this.property.getWriteMethod().getAnnotation(cls);
        }
        return (A) annotation;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.introspector.Property
    public boolean isWritable() {
        return this.writable;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.introspector.Property
    public boolean isReadable() {
        return this.readable;
    }
}
