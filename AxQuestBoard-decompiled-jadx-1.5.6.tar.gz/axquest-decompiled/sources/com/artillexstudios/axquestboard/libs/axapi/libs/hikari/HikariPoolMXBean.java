package com.artillexstudios.axquestboard.libs.axapi.libs.hikari;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/hikari/HikariPoolMXBean.class */
public interface HikariPoolMXBean {
    int getIdleConnections();

    int getActiveConnections();

    int getTotalConnections();

    int getThreadsAwaitingConnection();

    void softEvictConnections();

    void suspendPool();

    void resumePool();
}
