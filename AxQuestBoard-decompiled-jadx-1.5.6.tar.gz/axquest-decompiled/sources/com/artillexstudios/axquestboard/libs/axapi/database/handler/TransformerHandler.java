package com.artillexstudios.axquestboard.libs.axapi.database.handler;

import com.artillexstudios.axquestboard.libs.axapi.database.ResultHandler;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/database/handler/TransformerHandler.class */
public class TransformerHandler<T> implements ResultHandler<T> {
    private final Class<T> clazz;
    private static transient /* synthetic */ String RPhVhMguyJ = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public TransformerHandler(Class<T> clazz) {
        this.clazz = clazz;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.database.ResultHandler
    public T handle(ResultSet resultSet, boolean z) throws SQLException {
        if (z && !resultSet.next()) {
            return null;
        }
        int columnCount = resultSet.getMetaData().getColumnCount();
        Object[] objArr = new Object[columnCount];
        for (int i = 0; i < columnCount; i++) {
            objArr[i] = resultSet.getObject(i + 1);
        }
        try {
            return this.clazz.cast(((Constructor) Arrays.stream(this.clazz.getDeclaredConstructors()).filter(constructor -> {
                return constructor.getParameterCount() == columnCount;
            }).filter(constructor2 -> {
                Class<?>[] parameterTypes = constructor2.getParameterTypes();
                for (int i2 = 0; i2 < parameterTypes.length; i2++) {
                    Class<?> cls = parameterTypes[i2];
                    Object obj = objArr[i2];
                    if (obj != null && !cls.isInstance(obj)) {
                        return false;
                    }
                }
                return true;
            }).findFirst().orElseThrow()).newInstance(objArr));
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException e) {
            throw new RuntimeException(e);
        }
    }
}
