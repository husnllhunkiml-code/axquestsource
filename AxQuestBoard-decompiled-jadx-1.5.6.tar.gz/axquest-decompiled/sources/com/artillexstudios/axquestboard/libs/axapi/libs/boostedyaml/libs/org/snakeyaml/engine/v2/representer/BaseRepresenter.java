package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.representer;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.RepresentToNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.FlowStyle;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.ScalarStyle;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.YamlEngineException;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.AnchorNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.MappingNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Node;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.NodeTuple;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.ScalarNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.SequenceNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Tag;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/representer/BaseRepresenter.class */
public abstract class BaseRepresenter {
    protected RepresentToNode nullRepresenter;
    protected Object objectToRepresent;
    protected final Map<Class<?>, RepresentToNode> representers = new HashMap();
    protected final Map<Class<?>, RepresentToNode> parentClassRepresenters = new LinkedHashMap();
    protected final Map<Object, Node> representedObjects = new IdentityHashMap<Object, Node>() { // from class: com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.representer.BaseRepresenter.1
        private static transient /* synthetic */ String cnwmKPJkNI = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        @Override // java.util.IdentityHashMap, java.util.AbstractMap, java.util.Map
        public Node put(Object obj, Node node) {
            return (Node) super.put(obj, new AnchorNode(node));
        }
    };
    protected ScalarStyle defaultScalarStyle = ScalarStyle.PLAIN;
    protected FlowStyle defaultFlowStyle = FlowStyle.AUTO;

    public Node represent(Object obj) {
        Node nodeRepresentData = representData(obj);
        this.representedObjects.clear();
        this.objectToRepresent = null;
        return nodeRepresentData;
    }

    protected Optional<RepresentToNode> findRepresenterFor(Object obj) {
        Class<?> cls = obj.getClass();
        if (this.representers.containsKey(cls)) {
            return Optional.of(this.representers.get(cls));
        }
        for (Map.Entry<Class<?>, RepresentToNode> entry : this.parentClassRepresenters.entrySet()) {
            if (entry.getKey().isInstance(obj)) {
                return Optional.of(entry.getValue());
            }
        }
        return Optional.empty();
    }

    protected final Node representData(Object obj) {
        this.objectToRepresent = obj;
        if (this.representedObjects.containsKey(this.objectToRepresent)) {
            return this.representedObjects.get(this.objectToRepresent);
        }
        if (obj == null) {
            return this.nullRepresenter.representData(null);
        }
        return findRepresenterFor(obj).orElseThrow(() -> {
            return new YamlEngineException("Representer is not defined for " + obj.getClass());
        }).representData(obj);
    }

    protected Node representScalar(Tag tag, String str, ScalarStyle scalarStyle) {
        if (scalarStyle == ScalarStyle.PLAIN) {
            scalarStyle = this.defaultScalarStyle;
        }
        return new ScalarNode(tag, str, scalarStyle);
    }

    protected Node representScalar(Tag tag, String str) {
        return representScalar(tag, str, ScalarStyle.PLAIN);
    }

    protected Node representSequence(Tag tag, Iterable<?> iterable, FlowStyle flowStyle) {
        int size = 10;
        if (iterable instanceof List) {
            size = ((List) iterable).size();
        }
        ArrayList arrayList = new ArrayList(size);
        SequenceNode sequenceNode = new SequenceNode(tag, arrayList, flowStyle);
        this.representedObjects.put(this.objectToRepresent, sequenceNode);
        FlowStyle flowStyle2 = FlowStyle.FLOW;
        Iterator<?> it = iterable.iterator();
        while (it.hasNext()) {
            Node nodeRepresentData = representData(it.next());
            if (!(nodeRepresentData instanceof ScalarNode) || !((ScalarNode) nodeRepresentData).isPlain()) {
                flowStyle2 = FlowStyle.BLOCK;
            }
            arrayList.add(nodeRepresentData);
        }
        if (flowStyle == FlowStyle.AUTO) {
            if (this.defaultFlowStyle != FlowStyle.AUTO) {
                sequenceNode.setFlowStyle(this.defaultFlowStyle);
            } else {
                sequenceNode.setFlowStyle(flowStyle2);
            }
        }
        return sequenceNode;
    }

    protected NodeTuple representMappingEntry(Map.Entry<?, ?> entry) {
        return new NodeTuple(representData(entry.getKey()), representData(entry.getValue()));
    }

    protected Node representMapping(Tag tag, Map<?, ?> map, FlowStyle flowStyle) {
        ArrayList arrayList = new ArrayList(map.size());
        MappingNode mappingNode = new MappingNode(tag, arrayList, flowStyle);
        this.representedObjects.put(this.objectToRepresent, mappingNode);
        FlowStyle flowStyle2 = FlowStyle.FLOW;
        Iterator<Map.Entry<?, ?>> it = map.entrySet().iterator();
        while (it.hasNext()) {
            NodeTuple nodeTupleRepresentMappingEntry = representMappingEntry(it.next());
            if (!(nodeTupleRepresentMappingEntry.getKeyNode() instanceof ScalarNode) || !((ScalarNode) nodeTupleRepresentMappingEntry.getKeyNode()).isPlain()) {
                flowStyle2 = FlowStyle.BLOCK;
            }
            if (!(nodeTupleRepresentMappingEntry.getValueNode() instanceof ScalarNode) || !((ScalarNode) nodeTupleRepresentMappingEntry.getValueNode()).isPlain()) {
                flowStyle2 = FlowStyle.BLOCK;
            }
            arrayList.add(nodeTupleRepresentMappingEntry);
        }
        if (flowStyle == FlowStyle.AUTO) {
            if (this.defaultFlowStyle != FlowStyle.AUTO) {
                mappingNode.setFlowStyle(this.defaultFlowStyle);
            } else {
                mappingNode.setFlowStyle(flowStyle2);
            }
        }
        return mappingNode;
    }
}
