package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.composer;

import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.error.Mark;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.error.MarkedYAMLException;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/composer/ComposerException.class */
public class ComposerException extends MarkedYAMLException {
    private static final long serialVersionUID = 2146314636913113935L;
    private static transient /* synthetic */ String hSRfFLKHaO = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    protected ComposerException(String str, Mark mark, String str2, Mark mark2) {
        super(str, mark, str2, mark2);
    }
}
