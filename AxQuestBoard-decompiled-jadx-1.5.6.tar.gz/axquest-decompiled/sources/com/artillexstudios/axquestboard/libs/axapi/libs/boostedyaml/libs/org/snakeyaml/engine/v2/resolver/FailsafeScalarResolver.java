package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.resolver;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Tag;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/resolver/FailsafeScalarResolver.class */
public class FailsafeScalarResolver extends BaseScalarResolver {
    private static transient /* synthetic */ String NZObCSYDQL = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.resolver.BaseScalarResolver
    protected void addImplicitResolvers() {
        addImplicitResolver(Tag.NULL, EMPTY, null);
    }
}
