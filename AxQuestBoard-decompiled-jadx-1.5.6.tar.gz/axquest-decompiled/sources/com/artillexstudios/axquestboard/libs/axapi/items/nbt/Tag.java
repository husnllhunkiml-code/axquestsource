package com.artillexstudios.axquestboard.libs.axapi.items.nbt;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/items/nbt/Tag.class */
public interface Tag {
    Object getParent();
}
