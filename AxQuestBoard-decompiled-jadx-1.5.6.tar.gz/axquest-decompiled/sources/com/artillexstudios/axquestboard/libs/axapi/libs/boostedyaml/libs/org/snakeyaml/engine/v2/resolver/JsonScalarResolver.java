package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.resolver;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Tag;
import java.util.regex.Pattern;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/resolver/JsonScalarResolver.class */
public class JsonScalarResolver extends BaseScalarResolver {
    public static final Pattern BOOL = Pattern.compile("^(?:true|false)$");
    public static final Pattern FLOAT = Pattern.compile("^(-?(0|[1-9][0-9]*)(\\.[0-9]*)?([eE][-+]?[0-9]+)?)|(-?\\.inf)|(\\.nan)$");
    public static final Pattern INT = Pattern.compile("^-?(0|[1-9][0-9]*)$");
    public static final Pattern NULL = Pattern.compile("^(?:null)$");
    private static transient /* synthetic */ String WWIIriTYCT = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.resolver.BaseScalarResolver
    protected void addImplicitResolvers() {
        addImplicitResolver(Tag.NULL, EMPTY, null);
        addImplicitResolver(Tag.BOOL, BOOL, "tf");
        addImplicitResolver(Tag.INT, INT, "-0123456789");
        addImplicitResolver(Tag.FLOAT, FLOAT, "-0123456789.");
        addImplicitResolver(Tag.NULL, NULL, "n\u0000");
        addImplicitResolver(Tag.ENV_TAG, ENV_FORMAT, "$");
    }
}
