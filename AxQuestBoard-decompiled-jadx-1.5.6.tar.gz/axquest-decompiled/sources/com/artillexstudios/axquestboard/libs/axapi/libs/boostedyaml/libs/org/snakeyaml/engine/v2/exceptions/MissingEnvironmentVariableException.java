package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/exceptions/MissingEnvironmentVariableException.class */
public class MissingEnvironmentVariableException extends YamlEngineException {
    private static transient /* synthetic */ String fNvfySumfn = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public MissingEnvironmentVariableException(String str) {
        super(str);
    }
}
