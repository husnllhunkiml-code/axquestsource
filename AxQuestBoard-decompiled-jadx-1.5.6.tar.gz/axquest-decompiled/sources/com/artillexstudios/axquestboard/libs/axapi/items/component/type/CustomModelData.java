package com.artillexstudios.axquestboard.libs.axapi.items.component.type;

import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.runtime.ObjectMethods;
import java.util.List;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/items/component/type/CustomModelData.class */
public final class CustomModelData extends Record {
    private final List<String> strings;
    private final List<Boolean> flags;
    private final List<Float> floats;
    private final List<Integer> colors;
    private static transient /* synthetic */ String mXnaPBncHx = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public CustomModelData(List<String> strings, List<Boolean> flags, List<Float> floats, List<Integer> colors) {
        this.strings = strings;
        this.flags = flags;
        this.floats = floats;
        this.colors = colors;
    }

    @Override // java.lang.Record
    public final String toString() {
        return (String) ObjectMethods.bootstrap(MethodHandles.lookup(), "toString", MethodType.methodType(String.class, CustomModelData.class), CustomModelData.class, "strings;flags;floats;colors", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/items/component/type/CustomModelData;->strings:Ljava/util/List;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/items/component/type/CustomModelData;->flags:Ljava/util/List;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/items/component/type/CustomModelData;->floats:Ljava/util/List;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/items/component/type/CustomModelData;->colors:Ljava/util/List;").dynamicInvoker().invoke(this) /* invoke-custom */;
    }

    @Override // java.lang.Record
    public final int hashCode() {
        return (int) ObjectMethods.bootstrap(MethodHandles.lookup(), "hashCode", MethodType.methodType(Integer.TYPE, CustomModelData.class), CustomModelData.class, "strings;flags;floats;colors", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/items/component/type/CustomModelData;->strings:Ljava/util/List;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/items/component/type/CustomModelData;->flags:Ljava/util/List;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/items/component/type/CustomModelData;->floats:Ljava/util/List;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/items/component/type/CustomModelData;->colors:Ljava/util/List;").dynamicInvoker().invoke(this) /* invoke-custom */;
    }

    @Override // java.lang.Record
    public final boolean equals(Object o) {
        return (boolean) ObjectMethods.bootstrap(MethodHandles.lookup(), "equals", MethodType.methodType(Boolean.TYPE, CustomModelData.class, Object.class), CustomModelData.class, "strings;flags;floats;colors", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/items/component/type/CustomModelData;->strings:Ljava/util/List;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/items/component/type/CustomModelData;->flags:Ljava/util/List;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/items/component/type/CustomModelData;->floats:Ljava/util/List;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/items/component/type/CustomModelData;->colors:Ljava/util/List;").dynamicInvoker().invoke(this, o) /* invoke-custom */;
    }

    public List<String> strings() {
        return this.strings;
    }

    public List<Boolean> flags() {
        return this.flags;
    }

    public List<Float> floats() {
        return this.floats;
    }

    public List<Integer> colors() {
        return this.colors;
    }
}
