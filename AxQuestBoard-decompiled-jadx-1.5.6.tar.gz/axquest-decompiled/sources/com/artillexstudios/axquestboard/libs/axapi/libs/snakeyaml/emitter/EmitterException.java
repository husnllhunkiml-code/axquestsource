package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.emitter;

import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.error.YAMLException;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/emitter/EmitterException.class */
public class EmitterException extends YAMLException {
    private static final long serialVersionUID = -8280070025452995908L;
    private static transient /* synthetic */ String AoZLxoIYzf = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public EmitterException(String str) {
        super(str);
    }
}
