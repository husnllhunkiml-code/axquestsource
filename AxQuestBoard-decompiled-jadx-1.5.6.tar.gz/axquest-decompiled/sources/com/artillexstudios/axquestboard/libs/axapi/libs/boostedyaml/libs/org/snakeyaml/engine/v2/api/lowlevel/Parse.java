package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.lowlevel;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.LoadSettings;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.YamlUnicodeReader;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.Event;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser.ParserImpl;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.scanner.StreamReader;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;
import java.util.Iterator;
import java.util.Objects;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/api/lowlevel/Parse.class */
public class Parse {
    private final LoadSettings settings;
    private static transient /* synthetic */ String MYKThiVYdg = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public Parse(LoadSettings loadSettings) {
        Objects.requireNonNull(loadSettings, "LoadSettings cannot be null");
        this.settings = loadSettings;
    }

    public Iterable<Event> parseInputStream(InputStream inputStream) {
        Objects.requireNonNull(inputStream, "InputStream cannot be null");
        return () -> {
            return new ParserImpl(this.settings, new StreamReader(this.settings, new YamlUnicodeReader(inputStream)));
        };
    }

    public Iterable<Event> parseReader(Reader reader) {
        Objects.requireNonNull(reader, "Reader cannot be null");
        return () -> {
            return new ParserImpl(this.settings, new StreamReader(this.settings, reader));
        };
    }

    public Iterable<Event> parseString(final String str) {
        Objects.requireNonNull(str, "String cannot be null");
        return new Iterable<Event>() { // from class: com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.lowlevel.Parse.1
            private static transient /* synthetic */ String kWJjVZEerS = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

            @Override // java.lang.Iterable
            public Iterator<Event> iterator() {
                return new ParserImpl(Parse.this.settings, new StreamReader(Parse.this.settings, new StringReader(str)));
            }
        };
    }
}
