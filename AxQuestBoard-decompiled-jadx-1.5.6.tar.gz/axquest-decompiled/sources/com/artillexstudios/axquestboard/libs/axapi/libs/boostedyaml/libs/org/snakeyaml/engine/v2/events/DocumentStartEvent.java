package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.SpecVersion;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.Mark;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/events/DocumentStartEvent.class */
public final class DocumentStartEvent extends Event {
    private final boolean explicit;
    private final Optional<SpecVersion> specVersion;
    private final Map<String, String> tags;
    private static transient /* synthetic */ String sXVBhgYdoK = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public DocumentStartEvent(boolean z, Optional<SpecVersion> optional, Map<String, String> map, Optional<Mark> optional2, Optional<Mark> optional3) {
        super(optional2, optional3);
        this.explicit = z;
        Objects.requireNonNull(optional);
        this.specVersion = optional;
        Objects.requireNonNull(map);
        this.tags = map;
    }

    public DocumentStartEvent(boolean z, Optional<SpecVersion> optional, Map<String, String> map) {
        this(z, optional, map, Optional.empty(), Optional.empty());
    }

    public boolean isExplicit() {
        return this.explicit;
    }

    public Optional<SpecVersion> getSpecVersion() {
        return this.specVersion;
    }

    public Map<String, String> getTags() {
        return this.tags;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.Event
    public Event.ID getEventId() {
        return Event.ID.DocumentStart;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("+DOC");
        if (isExplicit()) {
            sb.append(" ---");
        }
        return sb.toString();
    }
}
