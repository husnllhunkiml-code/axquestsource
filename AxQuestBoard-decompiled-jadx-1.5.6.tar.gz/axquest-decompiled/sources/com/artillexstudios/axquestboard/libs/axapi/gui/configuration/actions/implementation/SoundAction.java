package com.artillexstudios.axquestboard.libs.axapi.gui.configuration.actions.implementation;

import com.artillexstudios.axquestboard.libs.axapi.context.HashMapContext;
import com.artillexstudios.axquestboard.libs.axapi.gui.configuration.actions.Action;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/gui/configuration/actions/implementation/SoundAction.class */
public final class SoundAction extends Action<String> {
    private static transient /* synthetic */ String TZVvikhJUV = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public SoundAction(String data) {
        super(data);
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.artillexstudios.axquestboard.libs.axapi.gui.configuration.actions.Action
    public String transform(String data) {
        return "";
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.gui.configuration.actions.Action
    public void run(Player player, HashMapContext context) {
    }
}
