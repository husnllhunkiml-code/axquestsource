package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.error;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/error/MissingEnvironmentVariableException.class */
public class MissingEnvironmentVariableException extends YAMLException {
    private static transient /* synthetic */ String ritPFIBzBX = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public MissingEnvironmentVariableException(String str) {
        super(str);
    }
}
