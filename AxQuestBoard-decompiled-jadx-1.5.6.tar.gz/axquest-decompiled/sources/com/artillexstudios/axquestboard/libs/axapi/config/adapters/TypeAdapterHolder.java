package com.artillexstudios.axquestboard.libs.axapi.config.adapters;

import com.artillexstudios.axquestboard.libs.axapi.config.adapters.collections.LinkedHashMapAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.collections.ListAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.collections.MapAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.collections.MapConfigurationGetterAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.other.BigDecimalAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.other.BigIntegerAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.other.DatabaseTypeAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.other.EnumAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.other.ItemStackAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.other.PatternAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.other.UUIDAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.other.WrappedItemStackAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.primitive.BooleanAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.primitive.ByteAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.primitive.DoubleAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.primitive.FloatAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.primitive.IntegerAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.primitive.LongAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.primitive.ShortAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.primitive.StringAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.annotation.Serializable;
import com.artillexstudios.axquestboard.libs.axapi.database.DatabaseType;
import com.artillexstudios.axquestboard.libs.axapi.items.WrappedItemStack;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;
import org.bukkit.inventory.ItemStack;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/adapters/TypeAdapterHolder.class */
public final class TypeAdapterHolder {
    private final Map<Class<?>, TypeAdapter<?, ?>> adapters = new HashMap();
    private static transient /* synthetic */ String tfNHBZzEBJ = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public TypeAdapterHolder() {
        this.adapters.put(Boolean.TYPE, new BooleanAdapter());
        this.adapters.put(Byte.TYPE, new ByteAdapter());
        this.adapters.put(Double.TYPE, new DoubleAdapter());
        this.adapters.put(Float.TYPE, new FloatAdapter());
        this.adapters.put(Integer.TYPE, new IntegerAdapter());
        this.adapters.put(Long.TYPE, new LongAdapter());
        this.adapters.put(Short.TYPE, new ShortAdapter());
        this.adapters.put(Boolean.class, new BooleanAdapter());
        this.adapters.put(Byte.class, new ByteAdapter());
        this.adapters.put(Double.class, new DoubleAdapter());
        this.adapters.put(Float.class, new FloatAdapter());
        this.adapters.put(Integer.class, new IntegerAdapter());
        this.adapters.put(Long.class, new LongAdapter());
        this.adapters.put(Short.class, new ShortAdapter());
        this.adapters.put(String.class, new StringAdapter());
        this.adapters.put(Enum.class, new EnumAdapter());
        this.adapters.put(Pattern.class, new PatternAdapter());
        this.adapters.put(BigInteger.class, new BigIntegerAdapter());
        this.adapters.put(BigDecimal.class, new BigDecimalAdapter());
        this.adapters.put(UUID.class, new UUIDAdapter());
        this.adapters.put(ItemStack.class, new ItemStackAdapter());
        this.adapters.put(WrappedItemStack.class, new WrappedItemStackAdapter());
        this.adapters.put(List.class, new ListAdapter());
        this.adapters.put(ArrayList.class, new ListAdapter());
        this.adapters.put(Map.class, new MapAdapter());
        this.adapters.put(LinkedHashMap.class, new LinkedHashMapAdapter());
        this.adapters.put(DatabaseType.class, new DatabaseTypeAdapter());
        this.adapters.put(MapConfigurationGetter.class, new MapConfigurationGetterAdapter());
    }

    public void registerAdapter(Class<?> clazz, TypeAdapter<?, ?> adapter) {
        this.adapters.put(clazz, adapter);
    }

    public void registerAdapters(Map<Class<?>, TypeAdapter<?, ?>> adapters) {
        this.adapters.putAll(adapters);
    }

    public Object serialize(Object object, Type type) {
        if (object == null) {
            return null;
        }
        return adapter(object, type).serialize(this, object, type);
    }

    public Object deserialize(Object object, Type type) {
        if (object == null) {
            return null;
        }
        return adapter(object, type).deserialize(this, object, type);
    }

    public TypeAdapter<Object, Object> adapter(Object object, Type type) {
        TypeAdapter<?, ?> typeAdapter = null;
        if (type instanceof Class) {
            Class cls = (Class) type;
            if (cls.isAnnotationPresent(Serializable.class)) {
                typeAdapter = this.adapters.get(Serializable.class);
            } else if (Enum.class.isAssignableFrom(cls)) {
                typeAdapter = this.adapters.get(Enum.class);
            } else {
                typeAdapter = this.adapters.get(cls);
            }
        }
        if (typeAdapter == null && (type instanceof ParameterizedType)) {
            ParameterizedType parameterizedType = (ParameterizedType) type;
            if (parameterizedType.getRawType().getClass().isAnnotationPresent(Serializable.class)) {
                typeAdapter = this.adapters.get(Serializable.class);
            } else if (Enum.class.isAssignableFrom((Class) parameterizedType.getRawType())) {
                typeAdapter = this.adapters.get(Enum.class);
            } else {
                typeAdapter = this.adapters.get((Class) parameterizedType.getRawType());
            }
        }
        if (typeAdapter == null && object != null) {
            if (object.getClass().isAnnotationPresent(Serializable.class)) {
                typeAdapter = this.adapters.get(Serializable.class);
            } else {
                typeAdapter = this.adapters.get(object.getClass());
            }
        }
        Class<?> cls2 = null;
        if (typeAdapter == null && (type instanceof Class)) {
            Class<?> cls3 = (Class) type;
            for (Class<?> cls4 : this.adapters.keySet()) {
                if (cls4.isAssignableFrom(cls3)) {
                    cls2 = cls4;
                    break;
                }
            }
        }
        if (cls2 != null) {
            typeAdapter = this.adapters.get(cls2);
            this.adapters.put(cls2, typeAdapter);
        }
        if (typeAdapter == null) {
            throw new IllegalArgumentException("Failed to get adapter for object %s with type: %s".formatted(object, type));
        }
        return typeAdapter;
    }
}
