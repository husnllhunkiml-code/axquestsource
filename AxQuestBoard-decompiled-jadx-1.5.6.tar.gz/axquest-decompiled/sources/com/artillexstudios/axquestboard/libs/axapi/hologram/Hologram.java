package com.artillexstudios.axquestboard.libs.axapi.hologram;

import com.artillexstudios.axquestboard.libs.axapi.collections.ThreadSafeList;
import com.artillexstudios.axquestboard.libs.axapi.events.PacketEntityInteractEvent;
import com.artillexstudios.axquestboard.libs.axapi.hologram.page.HologramPage;
import com.artillexstudios.axquestboard.libs.axapi.utils.UncheckedUtils;
import java.util.WeakHashMap;
import java.util.function.Consumer;
import org.bukkit.Location;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/hologram/Hologram.class */
public class Hologram {
    private final WeakHashMap<Player, Integer> playerPages = new WeakHashMap<>();
    private final ThreadSafeList<HologramPage<?, ?>> pages = new ThreadSafeList<>();
    private Consumer<PacketEntityInteractEvent> clickHandler;
    private Location location;
    private static transient /* synthetic */ String rXVZgHViuZ = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/hologram/Hologram$PageChangeDirection.class */
    public enum PageChangeDirection {
        BACK,
        FORWARD
    }

    public Hologram(Location location) {
        this.location = location;
    }

    public void hide(Player player) {
        for (int i = 0; i < this.pages.size(); i++) {
            this.pages.get(i).hide(player);
        }
    }

    public void show(Player player) {
        ((HologramPage) this.pages.getFirst()).show(player);
    }

    public void teleport(Location location) {
        this.location = location;
        for (int i = 0; i < this.pages.size(); i++) {
            this.pages.get(i).teleport(location);
        }
    }

    public void remove() {
        for (int i = 0; i < this.pages.size(); i++) {
            this.pages.get(i).remove();
        }
    }

    public <T> void spawnWithContent(HologramType<T> type, T content) {
        HologramPage hologramPageCreatePage = createPage(type);
        hologramPageCreatePage.setContent(content);
        hologramPageCreatePage.spawn();
    }

    public <T> void setContent(int pageIndex, T content) {
        this.pages.get(pageIndex).setContent(content);
    }

    public <T, Z extends HologramType<T>> HologramPage<T, Z> createPage(Z type) {
        HologramPage<T, Z> hologramPage = (HologramPage) UncheckedUtils.unsafeCast(type.create(this, this.pages.isEmpty(), this.location));
        addPage(hologramPage);
        return hologramPage;
    }

    public void addPage(HologramPage<?, ?> page) {
        this.pages.add(page);
    }

    public void removePage(HologramPage<?, ?> page) {
        this.pages.remove(page);
    }

    public HologramPage<?, ?> page(int pageIndex) {
        return this.pages.get(pageIndex);
    }

    public void changePage(Player player, PageChangeDirection direction) {
        if (this.pages.isEmpty() || this.pages.size() == 1) {
            return;
        }
        Integer num = this.playerPages.get(player);
        if (direction == PageChangeDirection.BACK) {
            int iIntValue = num == null ? 0 : num.intValue();
            if (iIntValue - 1 < 0) {
                return;
            }
            this.pages.get(iIntValue).hide(player);
            this.pages.get(iIntValue - 1).show(player);
            this.playerPages.put(player, Integer.valueOf(iIntValue - 1));
            return;
        }
        int iIntValue2 = num == null ? 0 : num.intValue();
        if (iIntValue2 + 1 >= this.pages.size()) {
            return;
        }
        this.pages.get(iIntValue2).hide(player);
        this.pages.get(iIntValue2 + 1).show(player);
        this.playerPages.put(player, Integer.valueOf(iIntValue2 + 1));
    }

    public void event(Consumer<PacketEntityInteractEvent> clickHandler) {
        this.clickHandler = clickHandler;
        for (int i = 0; i < this.pages.size(); i++) {
            HologramPage<?, ?> hologramPage = this.pages.get(i);
            if (hologramPage.getClickHandler() == null) {
                hologramPage.setClickHandler(this.clickHandler);
            }
        }
    }

    public Consumer<PacketEntityInteractEvent> event() {
        return this.clickHandler;
    }

    public Location location() {
        return this.location.clone();
    }
}
