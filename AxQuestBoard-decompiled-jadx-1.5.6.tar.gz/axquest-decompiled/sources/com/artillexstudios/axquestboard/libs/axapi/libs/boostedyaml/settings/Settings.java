package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/settings/Settings.class */
public interface Settings {
}
