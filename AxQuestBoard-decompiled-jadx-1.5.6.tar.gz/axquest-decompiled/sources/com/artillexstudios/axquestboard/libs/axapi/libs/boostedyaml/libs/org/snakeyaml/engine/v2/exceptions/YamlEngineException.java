package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/exceptions/YamlEngineException.class */
public class YamlEngineException extends RuntimeException {
    private static transient /* synthetic */ String sNMuEXuXbG = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public YamlEngineException(String str) {
        super(str);
    }

    public YamlEngineException(Throwable th) {
        super(th);
    }

    public YamlEngineException(String str, Throwable th) {
        super(str, th);
    }
}
