package com.artillexstudios.axquestboard.libs.axapi.config.adapters.collections;

import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapterHolder;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.LinkedHashMap;
import java.util.Map;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/adapters/collections/LinkedHashMapAdapter.class */
public final class LinkedHashMapAdapter implements TypeAdapter<LinkedHashMap<String, Object>, LinkedHashMap<String, Object>> {
    private static transient /* synthetic */ String yZoKBzmaoT = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public LinkedHashMap<String, Object> deserialize(TypeAdapterHolder holder, Object input, Type type) {
        Type type2 = null;
        if (type instanceof ParameterizedType) {
            type2 = ((ParameterizedType) type).getActualTypeArguments()[1];
        }
        if (input instanceof LinkedHashMap) {
            LinkedHashMap<String, Object> linkedHashMap = new LinkedHashMap<>();
            for (Map.Entry entry : ((LinkedHashMap) input).entrySet()) {
                linkedHashMap.put((String) entry.getKey(), holder.deserialize(entry.getValue(), type2));
            }
            return linkedHashMap;
        }
        throw new RuntimeException();
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public LinkedHashMap<String, Object> serialize(TypeAdapterHolder holder, LinkedHashMap<String, Object> value, Type type) {
        LinkedHashMap<String, Object> linkedHashMap = new LinkedHashMap<>();
        Type type2 = null;
        boolean z = false;
        if (type instanceof ParameterizedType) {
            type2 = ((ParameterizedType) type).getActualTypeArguments()[1];
            z = true;
        }
        for (Map.Entry<String, Object> entry : value.entrySet()) {
            if (!z) {
                type2 = entry.getValue().getClass();
            }
            linkedHashMap.put(entry.getKey(), holder.serialize(entry.getValue(), type2));
        }
        return linkedHashMap;
    }
}
