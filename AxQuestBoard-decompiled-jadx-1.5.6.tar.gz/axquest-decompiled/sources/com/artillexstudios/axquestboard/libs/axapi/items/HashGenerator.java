package com.artillexstudios.axquestboard.libs.axapi.items;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/items/HashGenerator.class */
public interface HashGenerator {
    Integer apply(Object typed);
}
