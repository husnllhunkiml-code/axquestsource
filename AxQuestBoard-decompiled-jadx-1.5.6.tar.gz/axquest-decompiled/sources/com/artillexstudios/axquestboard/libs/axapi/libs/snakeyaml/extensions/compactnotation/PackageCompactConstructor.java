package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.extensions.compactnotation;

import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.LoaderOptions;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/extensions/compactnotation/PackageCompactConstructor.class */
public class PackageCompactConstructor extends CompactConstructor {
    private final String packageName;
    private static transient /* synthetic */ String MwSDCJultX = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public PackageCompactConstructor(String str) {
        super(new LoaderOptions());
        this.packageName = str;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.constructor.Constructor
    protected Class<?> getClassForName(String str) {
        if (str.indexOf(46) < 0) {
            try {
                return Class.forName(this.packageName + "." + str);
            } catch (ClassNotFoundException e) {
            }
        }
        return super.getClassForName(str);
    }
}
