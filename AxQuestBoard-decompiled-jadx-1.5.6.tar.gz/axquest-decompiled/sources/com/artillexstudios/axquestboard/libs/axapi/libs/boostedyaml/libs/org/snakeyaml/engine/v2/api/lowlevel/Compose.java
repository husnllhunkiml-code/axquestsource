package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.lowlevel;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.LoadSettings;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.YamlUnicodeReader;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.composer.Composer;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Node;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser.ParserImpl;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.scanner.StreamReader;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;
import java.util.Iterator;
import java.util.Objects;
import java.util.Optional;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/api/lowlevel/Compose.class */
public class Compose {
    private final LoadSettings settings;
    private static transient /* synthetic */ String TgLIciPkuH = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public Compose(LoadSettings loadSettings) {
        Objects.requireNonNull(loadSettings, "LoadSettings cannot be null");
        this.settings = loadSettings;
    }

    public Optional<Node> composeReader(Reader reader) {
        Objects.requireNonNull(reader, "Reader cannot be null");
        return new Composer(this.settings, new ParserImpl(this.settings, new StreamReader(this.settings, reader))).getSingleNode();
    }

    public Optional<Node> composeInputStream(InputStream inputStream) {
        Objects.requireNonNull(inputStream, "InputStream cannot be null");
        return new Composer(this.settings, new ParserImpl(this.settings, new StreamReader(this.settings, new YamlUnicodeReader(inputStream)))).getSingleNode();
    }

    public Optional<Node> composeString(String str) {
        Objects.requireNonNull(str, "String cannot be null");
        return new Composer(this.settings, new ParserImpl(this.settings, new StreamReader(this.settings, new StringReader(str)))).getSingleNode();
    }

    public Iterable<Node> composeAllFromReader(Reader reader) {
        Objects.requireNonNull(reader, "Reader cannot be null");
        return () -> {
            return new Composer(this.settings, new ParserImpl(this.settings, new StreamReader(this.settings, reader)));
        };
    }

    public Iterable<Node> composeAllFromInputStream(InputStream inputStream) {
        Objects.requireNonNull(inputStream, "InputStream cannot be null");
        return () -> {
            return new Composer(this.settings, new ParserImpl(this.settings, new StreamReader(this.settings, new YamlUnicodeReader(inputStream))));
        };
    }

    public Iterable<Node> composeAllFromString(final String str) {
        Objects.requireNonNull(str, "String cannot be null");
        return new Iterable<Node>() { // from class: com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.lowlevel.Compose.1
            private static transient /* synthetic */ String oQyeUcaksE = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

            @Override // java.lang.Iterable
            public Iterator<Node> iterator() {
                return new Composer(Compose.this.settings, new ParserImpl(Compose.this.settings, new StreamReader(Compose.this.settings, new StringReader(str))));
            }
        };
    }
}
