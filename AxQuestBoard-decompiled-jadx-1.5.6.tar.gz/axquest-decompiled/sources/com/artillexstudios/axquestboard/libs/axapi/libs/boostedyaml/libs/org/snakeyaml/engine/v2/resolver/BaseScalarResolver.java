package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.resolver;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Tag;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/resolver/BaseScalarResolver.class */
public abstract class BaseScalarResolver implements ScalarResolver {
    public static final Pattern EMPTY = Pattern.compile("^$");
    public static final Pattern ENV_FORMAT = Pattern.compile("^\\$\\{\\s*(?:(\\w+)(?:(:?[-?])(\\w+)?)?)\\s*\\}$");
    protected Map<Character, List<ResolverTuple>> yamlImplicitResolvers = new HashMap();

    abstract void addImplicitResolvers();

    public BaseScalarResolver() {
        addImplicitResolvers();
    }

    public void addImplicitResolver(Tag tag, Pattern pattern, String str) {
        if (str == null) {
            this.yamlImplicitResolvers.computeIfAbsent(null, ch -> {
                return new ArrayList();
            }).add(new ResolverTuple(tag, pattern));
            return;
        }
        for (char c : str.toCharArray()) {
            Character chValueOf = Character.valueOf(c);
            if (chValueOf.charValue() == 0) {
                chValueOf = null;
            }
            List<ResolverTuple> arrayList = this.yamlImplicitResolvers.get(chValueOf);
            if (arrayList == null) {
                arrayList = new ArrayList();
                this.yamlImplicitResolvers.put(chValueOf, arrayList);
            }
            arrayList.add(new ResolverTuple(tag, pattern));
        }
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.resolver.ScalarResolver
    public Tag resolve(String str, Boolean bool) {
        List<ResolverTuple> list;
        if (!bool.booleanValue()) {
            return Tag.STR;
        }
        if (str.isEmpty()) {
            list = this.yamlImplicitResolvers.get((char) 0);
        } else {
            list = this.yamlImplicitResolvers.get(Character.valueOf(str.charAt(0)));
        }
        if (list != null) {
            for (ResolverTuple resolverTuple : list) {
                Tag tag = resolverTuple.getTag();
                if (resolverTuple.getRegexp().matcher(str).matches()) {
                    return tag;
                }
            }
        }
        if (this.yamlImplicitResolvers.containsKey(null)) {
            for (ResolverTuple resolverTuple2 : this.yamlImplicitResolvers.get(null)) {
                Tag tag2 = resolverTuple2.getTag();
                if (resolverTuple2.getRegexp().matcher(str).matches()) {
                    return tag2;
                }
            }
        }
        return Tag.STR;
    }
}
