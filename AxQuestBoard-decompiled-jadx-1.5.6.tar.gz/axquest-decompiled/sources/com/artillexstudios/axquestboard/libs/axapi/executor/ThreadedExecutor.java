package com.artillexstudios.axquestboard.libs.axapi.executor;

import com.google.common.collect.Queues;
import java.util.Queue;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/executor/ThreadedExecutor.class */
public class ThreadedExecutor implements Runnable, Executor {
    private static final Logger log = LoggerFactory.getLogger(ThreadedExecutor.class);
    private final Thread thread;
    private static transient /* synthetic */ String aevPTuDFdi = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";
    private final Queue<Runnable> jobs = Queues.newArrayDeque();
    private final ReentrantLock lock = new ReentrantLock();
    private final Condition condition = this.lock.newCondition();
    private volatile boolean killed = false;

    public ThreadedExecutor(String threadName) {
        this.thread = new Thread(this, threadName);
        this.thread.start();
    }

    public void stop() {
        this.killed = true;
        this.lock.lock();
        try {
            this.condition.signalAll();
        } finally {
            this.lock.unlock();
        }
    }

    @Override // java.util.concurrent.Executor
    public void execute(Runnable task) {
        this.lock.lock();
        try {
            this.jobs.offer(task);
            this.condition.signalAll();
        } finally {
            this.lock.unlock();
        }
    }

    public CompletableFuture<Void> submit(Runnable task) {
        CompletableFuture<Void> completableFuture = new CompletableFuture<>();
        execute(() -> {
            try {
                task.run();
                completableFuture.complete(null);
            } catch (Throwable th) {
                completableFuture.completeExceptionally(th);
            }
        });
        return completableFuture;
    }

    @Override // java.lang.Runnable
    public void run() {
        while (!this.killed) {
            try {
                Runnable next = next();
                if (next != null) {
                    next.run();
                }
            } catch (Exception e) {
                log.error("An unexpected error occurred while running ThreadedExecutor {}!", this.thread.getName(), e);
            }
        }
    }

    public Runnable next() {
        this.lock.lock();
        while (this.jobs.isEmpty() && !this.killed) {
            try {
                this.condition.await();
            } catch (Throwable th) {
                this.lock.unlock();
                throw th;
            }
        }
        if (!this.jobs.isEmpty()) {
            Runnable runnableRemove = this.jobs.remove();
            this.lock.unlock();
            return runnableRemove;
        }
        this.lock.unlock();
        return null;
    }
}
