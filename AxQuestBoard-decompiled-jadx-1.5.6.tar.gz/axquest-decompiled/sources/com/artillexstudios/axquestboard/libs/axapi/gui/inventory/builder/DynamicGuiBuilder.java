package com.artillexstudios.axquestboard.libs.axapi.gui.inventory.builder;

import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.GuiBuilder;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.implementation.DynamicGui;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/gui/inventory/builder/DynamicGuiBuilder.class */
public class DynamicGuiBuilder extends GuiBuilder<DynamicGui, DynamicGuiBuilder> {
    private static transient /* synthetic */ String tNQbxYqcVr = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    @Override // com.artillexstudios.axquestboard.libs.axapi.gui.inventory.GuiBuilder
    public DynamicGui build(Player player) {
        return new DynamicGui(player, this.titleProvider, this.type, this.rows, this.context, this.modifiers);
    }
}
