package com.artillexstudios.axquestboard.libs.axapi.config.renamer;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/renamer/KeyRenamer.class */
public interface KeyRenamer {
    String rename(String fieldName);
}
