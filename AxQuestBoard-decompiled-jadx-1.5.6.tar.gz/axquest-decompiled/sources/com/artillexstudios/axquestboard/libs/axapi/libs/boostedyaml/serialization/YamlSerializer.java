package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.serialization;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.utils.supplier.MapSupplier;
import java.util.Map;
import java.util.Set;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/serialization/YamlSerializer.class */
public interface YamlSerializer {
    @Nullable
    Object deserialize(@NotNull Map<Object, Object> map);

    @Nullable
    <T> Map<Object, Object> serialize(@NotNull T t, @NotNull MapSupplier mapSupplier);

    @NotNull
    Set<Class<?>> getSupportedClasses();

    @NotNull
    Set<Class<?>> getSupportedParentClasses();
}
