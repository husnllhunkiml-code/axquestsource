package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.block;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.comments.CommentLine;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.comments.CommentType;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.utils.format.NodeRole;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/block/Comments.class */
public class Comments {
    public static final CommentLine BLANK_LINE = new CommentLine(Optional.empty(), Optional.empty(), "", CommentType.BLANK_LINE);
    private static transient /* synthetic */ String lqFMXdMrDF = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/block/Comments$Position.class */
    public enum Position {
        BEFORE,
        INLINE,
        AFTER
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/block/Comments$NodeType.class */
    public enum NodeType {
        KEY,
        VALUE;

        public NodeRole toRole() {
            return this == KEY ? NodeRole.KEY : NodeRole.VALUE;
        }
    }

    @Nullable
    public static List<CommentLine> get(@NotNull Block<?> block, @NotNull NodeRole nodeRole, @NotNull Position position) {
        switch (position) {
            case BEFORE:
                return nodeRole == NodeRole.KEY ? block.beforeKeyComments : block.beforeValueComments;
            case INLINE:
                return nodeRole == NodeRole.KEY ? block.inlineKeyComments : block.inlineValueComments;
            case AFTER:
                return nodeRole == NodeRole.KEY ? block.afterKeyComments : block.afterValueComments;
            default:
                return null;
        }
    }

    @Deprecated
    @Nullable
    public static List<CommentLine> get(@NotNull Block<?> block, @NotNull NodeType nodeType, @NotNull Position position) {
        return get(block, nodeType.toRole(), position);
    }

    public static void set(@NotNull Block<?> block, @NotNull NodeRole nodeRole, @NotNull Position position, @Nullable List<CommentLine> list) {
        if (list != null) {
            list = new ArrayList(list);
        }
        switch (position) {
            case BEFORE:
                if (nodeRole == NodeRole.KEY) {
                    block.beforeKeyComments = list;
                } else {
                    block.beforeValueComments = list;
                }
                break;
            case INLINE:
                if (nodeRole == NodeRole.KEY) {
                    block.inlineKeyComments = list;
                } else {
                    block.inlineValueComments = list;
                }
                break;
            case AFTER:
                if (nodeRole == NodeRole.KEY) {
                    block.afterKeyComments = list;
                } else {
                    block.afterValueComments = list;
                }
                break;
        }
    }

    @Deprecated
    public static void set(@NotNull Block<?> block, @NotNull NodeType nodeType, @NotNull Position position, @Nullable List<CommentLine> list) {
        set(block, nodeType.toRole(), position, list);
    }

    public static void remove(@NotNull Block<?> block, @NotNull NodeRole nodeRole, @NotNull Position position) {
        set(block, nodeRole, position, (List<CommentLine>) null);
    }

    @Deprecated
    public static void remove(@NotNull Block<?> block, @NotNull NodeType nodeType, @NotNull Position position) {
        set(block, nodeType.toRole(), position, (List<CommentLine>) null);
    }

    public static void add(@NotNull Block<?> block, @NotNull NodeRole nodeRole, @NotNull Position position, @NotNull List<CommentLine> list) {
        list.forEach(commentLine -> {
            add((Block<?>) block, nodeRole, position, commentLine);
        });
    }

    @Deprecated
    public static void add(@NotNull Block<?> block, @NotNull NodeType nodeType, @NotNull Position position, @NotNull List<CommentLine> list) {
        list.forEach(commentLine -> {
            add((Block<?>) block, nodeType.toRole(), position, commentLine);
        });
    }

    public static void add(@NotNull Block<?> block, @NotNull NodeRole nodeRole, @NotNull Position position, @NotNull CommentLine commentLine) {
        switch (position) {
            case BEFORE:
                if (nodeRole == NodeRole.KEY) {
                    if (block.beforeKeyComments == null) {
                        block.beforeKeyComments = new ArrayList();
                    }
                    block.beforeKeyComments.add(commentLine);
                } else {
                    if (block.beforeValueComments == null) {
                        block.beforeValueComments = new ArrayList();
                    }
                    block.beforeValueComments.add(commentLine);
                }
                break;
            case INLINE:
                if (nodeRole == NodeRole.KEY) {
                    if (block.inlineKeyComments == null) {
                        block.inlineKeyComments = new ArrayList();
                    }
                    block.inlineKeyComments.add(commentLine);
                } else {
                    if (block.inlineValueComments == null) {
                        block.inlineValueComments = new ArrayList();
                    }
                    block.inlineValueComments.add(commentLine);
                }
                break;
            case AFTER:
                if (nodeRole == NodeRole.KEY) {
                    if (block.afterKeyComments == null) {
                        block.afterKeyComments = new ArrayList();
                    }
                    block.afterKeyComments.add(commentLine);
                } else {
                    if (block.afterValueComments == null) {
                        block.afterValueComments = new ArrayList();
                    }
                    block.afterValueComments.add(commentLine);
                }
                break;
        }
    }

    @Deprecated
    public static void add(@NotNull Block<?> block, @NotNull NodeType nodeType, @NotNull Position position, @NotNull CommentLine commentLine) {
        add(block, nodeType.toRole(), position, commentLine);
    }

    @NotNull
    public static CommentLine create(@NotNull String str, @NotNull Position position) {
        return new CommentLine(Optional.empty(), Optional.empty(), str, position == Position.INLINE ? CommentType.IN_LINE : CommentType.BLOCK);
    }
}
