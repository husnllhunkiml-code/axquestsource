package com.artillexstudios.axquestboard.libs.axapi.hologram.page;

import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.runtime.ObjectMethods;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/hologram/page/LineData.class */
public final class LineData extends Record {
    private final String content;
    private final Object component;
    private final boolean containsPlaceholders;
    private static transient /* synthetic */ String dmWrqwKFbP = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public LineData(String content, Object component, boolean containsPlaceholders) {
        this.content = content;
        this.component = component;
        this.containsPlaceholders = containsPlaceholders;
    }

    @Override // java.lang.Record
    public final String toString() {
        return (String) ObjectMethods.bootstrap(MethodHandles.lookup(), "toString", MethodType.methodType(String.class, LineData.class), LineData.class, "content;component;containsPlaceholders", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/hologram/page/LineData;->content:Ljava/lang/String;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/hologram/page/LineData;->component:Ljava/lang/Object;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/hologram/page/LineData;->containsPlaceholders:Z").dynamicInvoker().invoke(this) /* invoke-custom */;
    }

    @Override // java.lang.Record
    public final int hashCode() {
        return (int) ObjectMethods.bootstrap(MethodHandles.lookup(), "hashCode", MethodType.methodType(Integer.TYPE, LineData.class), LineData.class, "content;component;containsPlaceholders", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/hologram/page/LineData;->content:Ljava/lang/String;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/hologram/page/LineData;->component:Ljava/lang/Object;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/hologram/page/LineData;->containsPlaceholders:Z").dynamicInvoker().invoke(this) /* invoke-custom */;
    }

    @Override // java.lang.Record
    public final boolean equals(Object o) {
        return (boolean) ObjectMethods.bootstrap(MethodHandles.lookup(), "equals", MethodType.methodType(Boolean.TYPE, LineData.class, Object.class), LineData.class, "content;component;containsPlaceholders", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/hologram/page/LineData;->content:Ljava/lang/String;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/hologram/page/LineData;->component:Ljava/lang/Object;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/hologram/page/LineData;->containsPlaceholders:Z").dynamicInvoker().invoke(this, o) /* invoke-custom */;
    }

    public String content() {
        return this.content;
    }

    public Object component() {
        return this.component;
    }

    public boolean containsPlaceholders() {
        return this.containsPlaceholders;
    }
}
