package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.lowlevel;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.DumpSettings;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.Event;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Node;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.serializer.Serializer;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/api/lowlevel/Serialize.class */
public class Serialize {
    private final DumpSettings settings;
    private static transient /* synthetic */ String aHFSqYjpyh = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public Serialize(DumpSettings dumpSettings) {
        Objects.requireNonNull(dumpSettings, "DumpSettings cannot be null");
        this.settings = dumpSettings;
    }

    public List<Event> serializeOne(Node node) {
        Objects.requireNonNull(node, "Node cannot be null");
        return serializeAll(Collections.singletonList(node));
    }

    public List<Event> serializeAll(List<Node> list) {
        Objects.requireNonNull(list, "Nodes cannot be null");
        EmitableEvents emitableEvents = new EmitableEvents();
        Serializer serializer = new Serializer(this.settings, emitableEvents);
        serializer.emitStreamStart();
        Iterator<Node> it = list.iterator();
        while (it.hasNext()) {
            serializer.serializeDocument(it.next());
        }
        serializer.emitStreamEnd();
        return emitableEvents.getEvents();
    }
}
