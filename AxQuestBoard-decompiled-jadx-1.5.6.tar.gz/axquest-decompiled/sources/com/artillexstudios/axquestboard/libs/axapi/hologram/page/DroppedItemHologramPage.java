package com.artillexstudios.axquestboard.libs.axapi.hologram.page;

import com.artillexstudios.axquestboard.libs.axapi.hologram.Hologram;
import com.artillexstudios.axquestboard.libs.axapi.hologram.HologramType;
import com.artillexstudios.axquestboard.libs.axapi.hologram.HologramTypes;
import com.artillexstudios.axquestboard.libs.axapi.hologram.Holograms;
import com.artillexstudios.axquestboard.libs.axapi.items.WrappedItemStack;
import com.artillexstudios.axquestboard.libs.axapi.nms.NMSHandlers;
import com.artillexstudios.axquestboard.libs.axapi.packetentity.PacketEntity;
import com.artillexstudios.axquestboard.libs.axapi.packetentity.meta.EntityMeta;
import com.artillexstudios.axquestboard.libs.axapi.packetentity.meta.entity.ItemEntityMeta;
import org.bukkit.Location;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/hologram/page/DroppedItemHologramPage.class */
public class DroppedItemHologramPage extends HologramPage<WrappedItemStack, HologramType<WrappedItemStack>> {
    private final PacketEntity droppedItem;
    private WrappedItemStack content;
    private boolean spawned;
    private static transient /* synthetic */ String ifAocaSxZn = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public DroppedItemHologramPage(Hologram hologram, boolean firstPage, Location location) {
        super(hologram, firstPage, location);
        this.spawned = false;
        this.droppedItem = NMSHandlers.getNmsHandler().createEntity(EntityType.DROPPED_ITEM, getLocation());
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.hologram.page.HologramPage
    public void setContent(WrappedItemStack content) {
        this.content = content;
        create();
    }

    private void create() {
        ItemEntityMeta itemEntityMeta = (ItemEntityMeta) this.droppedItem.meta();
        itemEntityMeta.itemStack(this.content);
        itemEntityMeta.hasNoGravity(true);
        if (getEntityMetaHandler() != null) {
            getEntityMetaHandler().accept(itemEntityMeta);
        }
        if (!isFirstPage()) {
            this.droppedItem.setVisibleByDefault(false);
        }
        this.droppedItem.onInteract(packetEntityInteractEvent -> {
            if (getClickHandler() != null) {
                getClickHandler().accept(packetEntityInteractEvent);
            }
            getHologram().changePage(packetEntityInteractEvent.getPlayer(), packetEntityInteractEvent.isAttack() ? Hologram.PageChangeDirection.BACK : Hologram.PageChangeDirection.FORWARD);
        });
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.artillexstudios.axquestboard.libs.axapi.hologram.page.HologramPage
    public WrappedItemStack getContent() {
        return this.content;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.hologram.page.HologramPage
    public HologramType<WrappedItemStack> getType() {
        return HologramTypes.ITEM_STACK;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.hologram.page.HologramPage
    public boolean containsPlaceholders() {
        return false;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.hologram.page.HologramPage
    public boolean contentEquals(HologramPage<?, ?> other) {
        if (!(other instanceof DroppedItemHologramPage)) {
            return false;
        }
        return ((DroppedItemHologramPage) other).getContent().equals(getContent());
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.hologram.page.HologramPage
    public void hide(Player player) {
        this.droppedItem.hide(player);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.hologram.page.HologramPage
    public void show(Player player) {
        this.droppedItem.show(player);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.hologram.page.HologramPage
    public void teleport(Location location) {
        setLocation(location);
        if (this.droppedItem == null) {
            return;
        }
        this.droppedItem.teleport(location);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.hologram.page.HologramPage
    public void remove() {
        if (this.droppedItem == null) {
            return;
        }
        this.spawned = false;
        Holograms.remove(this.droppedItem.id());
        this.droppedItem.remove();
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.hologram.page.HologramPage
    public void update() {
        if (this.droppedItem == null) {
            return;
        }
        this.droppedItem.update();
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.hologram.page.HologramPage
    public EntityMeta getEntityMeta() {
        return this.droppedItem.meta();
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.hologram.page.HologramPage
    public synchronized boolean spawn() {
        if (this.spawned) {
            return false;
        }
        Holograms.put(this.droppedItem.id(), this);
        this.droppedItem.spawn();
        this.spawned = true;
        return true;
    }
}
