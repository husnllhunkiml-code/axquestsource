package com.artillexstudios.axquestboard.libs.axapi.gui.inventory.modifier;

import com.artillexstudios.axquestboard.libs.axapi.items.WrappedItemStack;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/gui/inventory/modifier/WrappedItemStackModifier.class */
public interface WrappedItemStackModifier {
    WrappedItemStack modify(WrappedItemStack stack);
}
