package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.lowlevel;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.DumpSettings;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.emitter.Emitter;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.Event;
import java.util.Iterator;
import java.util.Objects;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/api/lowlevel/Present.class */
public class Present {
    private final DumpSettings settings;
    private static transient /* synthetic */ String CvtjlRHAUM = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public Present(DumpSettings dumpSettings) {
        Objects.requireNonNull(dumpSettings, "DumpSettings cannot be null");
        this.settings = dumpSettings;
    }

    public String emitToString(Iterator<Event> it) {
        Objects.requireNonNull(it, "events cannot be null");
        StreamToStringWriter streamToStringWriter = new StreamToStringWriter();
        Emitter emitter = new Emitter(this.settings, streamToStringWriter);
        Objects.requireNonNull(emitter);
        it.forEachRemaining(emitter::emit);
        return streamToStringWriter.toString();
    }
}
