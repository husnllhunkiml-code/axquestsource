package com.artillexstudios.axquestboard.libs.axapi.database.impl;

import com.artillexstudios.axquestboard.libs.axapi.database.DatabaseConfig;
import com.artillexstudios.axquestboard.libs.axapi.database.DatabaseType;
import com.artillexstudios.axquestboard.libs.axapi.libs.hikari.HikariConfig;
import java.util.List;
import java.util.UUID;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/database/impl/MySQLDatabaseType.class */
public class MySQLDatabaseType extends DatabaseType {
    private final String relocated;
    private static transient /* synthetic */ String YOznPcCiyZ = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public MySQLDatabaseType() {
        this("com.mysql");
    }

    public MySQLDatabaseType(String relocated) {
        this.relocated = relocated;
        registerTransformer(UUID.class, uuid -> {
            return List.of(uuid.toString());
        });
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.database.DatabaseType
    public HikariConfig config(DatabaseConfig databaseConfig) {
        HikariConfig hikariConfig = new HikariConfig();
        hikariConfig.setDriverClassName(this.relocated + ".cj.jdbc.Driver");
        hikariConfig.setMaximumPoolSize(databaseConfig.pool.maximumPoolSize);
        hikariConfig.setMinimumIdle(databaseConfig.pool.minimumIdle);
        hikariConfig.setMaxLifetime(databaseConfig.pool.maximumLifetime);
        hikariConfig.setKeepaliveTime(databaseConfig.pool.keepaliveTime);
        hikariConfig.setConnectionTimeout(databaseConfig.pool.connectionTimeout);
        hikariConfig.addDataSourceProperty("user", databaseConfig.username);
        hikariConfig.addDataSourceProperty("password", databaseConfig.password);
        hikariConfig.addDataSourceProperty("allowMultiQueries", "true");
        hikariConfig.setJdbcUrl(databaseConfig.url == null ? "jdbc:mysql://" + databaseConfig.address + ":" + databaseConfig.port + "/" + databaseConfig.database : databaseConfig.url);
        return hikariConfig;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.database.DatabaseType
    public String name() {
        return "mysql";
    }
}
