package com.artillexstudios.axquestboard.libs.axapi.gui.configuration.actions.implementation;

import com.artillexstudios.axquestboard.libs.axapi.context.HashMapContext;
import com.artillexstudios.axquestboard.libs.axapi.gui.configuration.actions.Action;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.Gui;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.GuiKeys;
import com.artillexstudios.axquestboard.libs.axapi.nms.wrapper.ServerPlayerWrapper;
import com.artillexstudios.axquestboard.libs.axapi.placeholders.PlaceholderHandler;
import com.artillexstudios.axquestboard.libs.axapi.placeholders.PlaceholderParameters;
import com.artillexstudios.axquestboard.libs.axapi.utils.StringUtils;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/gui/configuration/actions/implementation/MessageAction.class */
public final class MessageAction extends Action<String> {
    private static transient /* synthetic */ String yspENyzvXB = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public MessageAction(String data) {
        super(data);
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.artillexstudios.axquestboard.libs.axapi.gui.configuration.actions.Action
    public String transform(String data) {
        return data;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.gui.configuration.actions.Action
    public void run(Player player, HashMapContext context) {
        ServerPlayerWrapper.wrap(player).message(StringUtils.format(PlaceholderHandler.parseWithPlaceholderAPI(value(), new PlaceholderParameters().withParameters(Player.class, player).withParameters(Gui.class, context.get(GuiKeys.GUI))), new TagResolver[0]));
    }
}
