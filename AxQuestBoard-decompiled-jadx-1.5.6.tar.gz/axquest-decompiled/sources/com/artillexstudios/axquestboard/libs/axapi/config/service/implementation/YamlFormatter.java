package com.artillexstudios.axquestboard.libs.axapi.config.service.implementation;

import com.artillexstudios.axquestboard.libs.axapi.config.service.Formatter;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/service/implementation/YamlFormatter.class */
public final class YamlFormatter implements Formatter {
    private static transient /* synthetic */ String PjnTAgFohu = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    @Override // com.artillexstudios.axquestboard.libs.axapi.config.service.Formatter
    public String format(String toFormat) {
        StringBuilder sb = new StringBuilder();
        String[] strArrSplit = toFormat.split("\n");
        int i = 0;
        while (i < strArrSplit.length) {
            String str = strArrSplit[i];
            if (str.strip().startsWith("#")) {
                if (getLeadingWhiteSpace(str) == 0 && i >= 1) {
                    sb.append("\n");
                }
                sb.append(toPrettyComment(str));
                sb.append("\n");
                int i2 = i + 1;
                while (i2 < strArrSplit.length) {
                    String str2 = strArrSplit[i2];
                    if (!str2.strip().startsWith("#")) {
                        break;
                    }
                    sb.append(toPrettyComment(str2));
                    sb.append("\n");
                    i2++;
                    i++;
                }
            } else if (i >= 1 && getLeadingWhiteSpace(str) < getLeadingWhiteSpace(strArrSplit[i - 1]) && getLeadingWhiteSpace(str) == 0) {
                sb.append("\n");
                sb.append(str);
                sb.append("\n");
            } else {
                sb.append(str);
                sb.append("\n");
            }
            i++;
        }
        return sb.toString();
    }

    private int getLeadingWhiteSpace(String string) {
        int i = 0;
        for (int i2 = 0; i2 < string.length(); i2++) {
            char cCharAt = string.charAt(i2);
            if (!Character.isWhitespace(cCharAt) && cCharAt != '-') {
                break;
            }
            i++;
        }
        return i;
    }

    private String toPrettyComment(String string) {
        int iIndexOf = string.indexOf(35);
        if (iIndexOf == -1 || iIndexOf == string.length() - 1) {
            return string;
        }
        if (Character.isWhitespace(string.charAt(iIndexOf + 1))) {
            return string;
        }
        StringBuilder sb = new StringBuilder(string.length());
        for (int i = 0; i < string.length(); i++) {
            if (string.charAt(i) == '#') {
                sb.append('#').append(' ');
            } else {
                sb.append(string.charAt(i));
            }
        }
        return sb.toString();
    }
}
