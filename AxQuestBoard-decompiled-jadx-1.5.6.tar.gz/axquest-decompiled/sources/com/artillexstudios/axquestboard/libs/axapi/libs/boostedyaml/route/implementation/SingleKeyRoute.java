package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.route.implementation;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.route.Route;
import java.util.Objects;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/route/implementation/SingleKeyRoute.class */
public class SingleKeyRoute implements Route {
    private final Object key;
    private static transient /* synthetic */ String DrSDqCfShC = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public SingleKeyRoute(@NotNull Object obj) {
        this.key = Objects.requireNonNull(obj, "Route cannot contain null keys!");
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.route.Route
    @NotNull
    public String join(char c) {
        return this.key.toString();
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.route.Route
    public int length() {
        return 1;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.route.Route
    @NotNull
    public Object get(int i) {
        if (i != 0) {
            throw new ArrayIndexOutOfBoundsException("Index " + i + " for single key route!");
        }
        return this.key;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.route.Route
    @NotNull
    public Route parent() {
        throw new IllegalArgumentException("Empty routes are not allowed!");
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.route.Route
    @NotNull
    public Route add(@NotNull Object obj) {
        return Route.from(this.key, Objects.requireNonNull(obj, "Route cannot contain null keys!"));
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.route.Route
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Route)) {
            return false;
        }
        Route route = (Route) obj;
        if (route.length() != 1) {
            return false;
        }
        return Objects.equals(this.key, route.get(0));
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.route.Route
    public int hashCode() {
        return Objects.hash(this.key);
    }

    public String toString() {
        return "SingleKeyRoute{key=" + this.key + '}';
    }
}
