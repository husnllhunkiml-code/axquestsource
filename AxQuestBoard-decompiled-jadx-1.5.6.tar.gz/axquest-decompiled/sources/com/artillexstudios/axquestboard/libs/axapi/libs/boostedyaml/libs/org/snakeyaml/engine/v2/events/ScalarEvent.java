package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.Anchor;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.CharConstants;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.ScalarStyle;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.Mark;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/events/ScalarEvent.class */
public final class ScalarEvent extends NodeEvent {
    private final Optional<String> tag;
    private final ScalarStyle style;
    private final String value;
    private final ImplicitTuple implicit;
    private static transient /* synthetic */ String laSQwTbVPR = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public ScalarEvent(Optional<Anchor> optional, Optional<String> optional2, ImplicitTuple implicitTuple, String str, ScalarStyle scalarStyle, Optional<Mark> optional3, Optional<Mark> optional4) {
        super(optional, optional3, optional4);
        Objects.requireNonNull(optional2);
        this.tag = optional2;
        this.implicit = implicitTuple;
        Objects.requireNonNull(str);
        this.value = str;
        Objects.requireNonNull(scalarStyle);
        this.style = scalarStyle;
    }

    public ScalarEvent(Optional<Anchor> optional, Optional<String> optional2, ImplicitTuple implicitTuple, String str, ScalarStyle scalarStyle) {
        this(optional, optional2, implicitTuple, str, scalarStyle, Optional.empty(), Optional.empty());
    }

    public Optional<String> getTag() {
        return this.tag;
    }

    public ScalarStyle getScalarStyle() {
        return this.style;
    }

    public String getValue() {
        return this.value;
    }

    public ImplicitTuple getImplicit() {
        return this.implicit;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.Event
    public Event.ID getEventId() {
        return Event.ID.Scalar;
    }

    public boolean isPlain() {
        return this.style == ScalarStyle.PLAIN;
    }

    public boolean isLiteral() {
        return this.style == ScalarStyle.LITERAL;
    }

    public boolean isSQuoted() {
        return this.style == ScalarStyle.SINGLE_QUOTED;
    }

    public boolean isDQuoted() {
        return this.style == ScalarStyle.DOUBLE_QUOTED;
    }

    public boolean isFolded() {
        return this.style == ScalarStyle.FOLDED;
    }

    public boolean isJson() {
        return this.style == ScalarStyle.JSON_SCALAR_STYLE;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("=VAL");
        getAnchor().ifPresent(anchor -> {
            sb.append(" &" + anchor);
        });
        if (this.implicit.bothFalse()) {
            getTag().ifPresent(str -> {
                sb.append(" <" + str + ">");
            });
        }
        sb.append(" ");
        sb.append(getScalarStyle().toString());
        sb.append(escapedValue());
        return sb.toString();
    }

    public String escapedValue() {
        return (String) this.value.codePoints().filter(i -> {
            return i < 65535;
        }).mapToObj(i2 -> {
            return CharConstants.escapeChar(String.valueOf(Character.toChars(i2)));
        }).collect(Collectors.joining(""));
    }
}
