package com.artillexstudios.axquestboard.libs.axapi.gui.inventory;

import com.artillexstudios.axquestboard.libs.axapi.context.HashMapContext;
import com.artillexstudios.axquestboard.libs.axapi.items.WrappedItemStack;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.runtime.ObjectMethods;
import java.util.function.BiConsumer;
import java.util.function.Function;
import org.bukkit.event.inventory.InventoryClickEvent;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/gui/inventory/GuiItem.class */
public final class GuiItem extends Record {
    private final Function<HashMapContext, WrappedItemStack> stack;
    private final BiConsumer<HashMapContext, InventoryClickEvent> eventConsumer;
    private static transient /* synthetic */ String RRNaBdDUWa = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public GuiItem(Function<HashMapContext, WrappedItemStack> stack, BiConsumer<HashMapContext, InventoryClickEvent> eventConsumer) {
        this.stack = stack;
        this.eventConsumer = eventConsumer;
    }

    @Override // java.lang.Record
    public final String toString() {
        return (String) ObjectMethods.bootstrap(MethodHandles.lookup(), "toString", MethodType.methodType(String.class, GuiItem.class), GuiItem.class, "stack;eventConsumer", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/gui/inventory/GuiItem;->stack:Ljava/util/function/Function;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/gui/inventory/GuiItem;->eventConsumer:Ljava/util/function/BiConsumer;").dynamicInvoker().invoke(this) /* invoke-custom */;
    }

    @Override // java.lang.Record
    public final int hashCode() {
        return (int) ObjectMethods.bootstrap(MethodHandles.lookup(), "hashCode", MethodType.methodType(Integer.TYPE, GuiItem.class), GuiItem.class, "stack;eventConsumer", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/gui/inventory/GuiItem;->stack:Ljava/util/function/Function;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/gui/inventory/GuiItem;->eventConsumer:Ljava/util/function/BiConsumer;").dynamicInvoker().invoke(this) /* invoke-custom */;
    }

    @Override // java.lang.Record
    public final boolean equals(Object o) {
        return (boolean) ObjectMethods.bootstrap(MethodHandles.lookup(), "equals", MethodType.methodType(Boolean.TYPE, GuiItem.class, Object.class), GuiItem.class, "stack;eventConsumer", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/gui/inventory/GuiItem;->stack:Ljava/util/function/Function;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/gui/inventory/GuiItem;->eventConsumer:Ljava/util/function/BiConsumer;").dynamicInvoker().invoke(this, o) /* invoke-custom */;
    }

    public Function<HashMapContext, WrappedItemStack> stack() {
        return this.stack;
    }

    public BiConsumer<HashMapContext, InventoryClickEvent> eventConsumer() {
        return this.eventConsumer;
    }

    public GuiItem(Function<HashMapContext, WrappedItemStack> stack) {
        this(stack, (hashMapContext, inventoryClickEvent) -> {
        });
    }
}
