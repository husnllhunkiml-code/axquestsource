package com.artillexstudios.axquestboard.libs.axapi.items;

import com.artillexstudios.axquestboard.libs.axapi.items.component.DataComponent;
import com.artillexstudios.axquestboard.libs.axapi.nms.wrapper.Wrapper;
import com.artillexstudios.axquestboard.libs.axapi.nms.wrapper.WrapperRegistry;
import java.util.function.Function;
import org.bukkit.inventory.ItemStack;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/items/WrappedItemStack.class */
public interface WrappedItemStack extends Wrapper<ItemStack> {

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/items/WrappedItemStack$CodecData.class */
    public enum CodecData {
        OPTIONAL_STREAM_CODEC,
        OPTIONAL_UNTRUSTED_STREAM_CODEC,
        STREAM_CODEC
    }

    <T> void set(DataComponent<T> component, T value);

    <T> T get(DataComponent<T> component);

    void setAmount(int amount);

    int getAmount();

    ItemStack toBukkit();

    HashedStack toHashedStack(HashGenerator generator);

    String toSNBT();

    byte[] serialize();

    void finishEdit();

    WrappedItemStack copy();

    void editFrom(WrappedItemStack stack);

    static WrappedItemStack wrap(Object data) {
        return (WrappedItemStack) WrapperRegistry.ITEM_STACK.map(data);
    }

    static <T> T edit(ItemStack itemStack, Function<WrappedItemStack, T> function) {
        WrappedItemStack wrapped = wrap(itemStack);
        T result = function.apply(wrapped);
        wrapped.finishEdit();
        return result;
    }
}
