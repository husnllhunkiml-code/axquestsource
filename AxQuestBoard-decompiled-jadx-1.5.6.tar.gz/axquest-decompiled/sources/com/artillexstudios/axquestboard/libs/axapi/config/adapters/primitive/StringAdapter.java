package com.artillexstudios.axquestboard.libs.axapi.config.adapters.primitive;

import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapterHolder;
import java.lang.reflect.Type;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/adapters/primitive/StringAdapter.class */
public final class StringAdapter implements TypeAdapter<String, String> {
    private static transient /* synthetic */ String CGmLASIDkR = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public String deserialize(TypeAdapterHolder holder, Object input, Type type) {
        return input instanceof String ? (String) input : input.toString();
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public String serialize(TypeAdapterHolder holder, String value, Type type) {
        return value;
    }
}
