package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml;

import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.inspector.TagInspector;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.inspector.UnTrustedTagInspector;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/LoaderOptions.class */
public class LoaderOptions {
    private boolean allowDuplicateKeys = true;
    private boolean wrappedToRootException = false;
    private int maxAliasesForCollections = 50;
    private boolean allowRecursiveKeys = false;
    private boolean processComments = false;
    private boolean enumCaseSensitive = true;
    private int nestingDepthLimit = 50;
    private int codePointLimit = 3145728;
    private TagInspector tagInspector = new UnTrustedTagInspector();
    private static transient /* synthetic */ String dRBsbTVHIi = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public final boolean isAllowDuplicateKeys() {
        return this.allowDuplicateKeys;
    }

    public void setAllowDuplicateKeys(boolean z) {
        this.allowDuplicateKeys = z;
    }

    public final boolean isWrappedToRootException() {
        return this.wrappedToRootException;
    }

    public void setWrappedToRootException(boolean z) {
        this.wrappedToRootException = z;
    }

    public final int getMaxAliasesForCollections() {
        return this.maxAliasesForCollections;
    }

    public void setMaxAliasesForCollections(int i) {
        this.maxAliasesForCollections = i;
    }

    public final boolean getAllowRecursiveKeys() {
        return this.allowRecursiveKeys;
    }

    public void setAllowRecursiveKeys(boolean z) {
        this.allowRecursiveKeys = z;
    }

    public final boolean isProcessComments() {
        return this.processComments;
    }

    public LoaderOptions setProcessComments(boolean z) {
        this.processComments = z;
        return this;
    }

    public final boolean isEnumCaseSensitive() {
        return this.enumCaseSensitive;
    }

    public void setEnumCaseSensitive(boolean z) {
        this.enumCaseSensitive = z;
    }

    public final int getNestingDepthLimit() {
        return this.nestingDepthLimit;
    }

    public void setNestingDepthLimit(int i) {
        this.nestingDepthLimit = i;
    }

    public final int getCodePointLimit() {
        return this.codePointLimit;
    }

    public void setCodePointLimit(int i) {
        this.codePointLimit = i;
    }

    public TagInspector getTagInspector() {
        return this.tagInspector;
    }

    public void setTagInspector(TagInspector tagInspector) {
        this.tagInspector = tagInspector;
    }
}
