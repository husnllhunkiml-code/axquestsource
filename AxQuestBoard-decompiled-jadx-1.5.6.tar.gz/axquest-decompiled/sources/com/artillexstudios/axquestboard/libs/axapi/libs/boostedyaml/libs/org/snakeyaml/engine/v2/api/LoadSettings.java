package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.SpecVersion;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.env.EnvConfig;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Tag;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.schema.Schema;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.function.IntFunction;
import java.util.function.UnaryOperator;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/api/LoadSettings.class */
public final class LoadSettings {
    private final String label;
    private final Map<Tag, ConstructNode> tagConstructors;
    private final IntFunction<List<Object>> defaultList;
    private final IntFunction<Set<Object>> defaultSet;
    private final IntFunction<Map<Object, Object>> defaultMap;
    private final UnaryOperator<SpecVersion> versionFunction;
    private final Integer bufferSize;
    private final boolean allowDuplicateKeys;
    private final boolean allowRecursiveKeys;
    private final boolean parseComments;
    private final int maxAliasesForCollections;
    private final boolean useMarks;
    private final Optional<EnvConfig> envConfig;
    private final int codePointLimit;
    private final Schema schema;
    private final Map<SettingKey, Object> customProperties;
    private static transient /* synthetic */ String NiEaelzTxG = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    LoadSettings(String str, Map<Tag, ConstructNode> map, IntFunction<List<Object>> intFunction, IntFunction<Set<Object>> intFunction2, IntFunction<Map<Object, Object>> intFunction3, UnaryOperator<SpecVersion> unaryOperator, Integer num, boolean z, boolean z2, int i, boolean z3, Map<SettingKey, Object> map2, Optional<EnvConfig> optional, boolean z4, int i2, Schema schema) {
        this.label = str;
        this.tagConstructors = map;
        this.defaultList = intFunction;
        this.defaultSet = intFunction2;
        this.defaultMap = intFunction3;
        this.versionFunction = unaryOperator;
        this.bufferSize = num;
        this.allowDuplicateKeys = z;
        this.allowRecursiveKeys = z2;
        this.parseComments = z4;
        this.maxAliasesForCollections = i;
        this.useMarks = z3;
        this.customProperties = map2;
        this.envConfig = optional;
        this.codePointLimit = i2;
        this.schema = schema;
    }

    public static LoadSettingsBuilder builder() {
        return new LoadSettingsBuilder();
    }

    public String getLabel() {
        return this.label;
    }

    public Map<Tag, ConstructNode> getTagConstructors() {
        return this.tagConstructors;
    }

    public IntFunction<List<Object>> getDefaultList() {
        return this.defaultList;
    }

    public IntFunction<Set<Object>> getDefaultSet() {
        return this.defaultSet;
    }

    public IntFunction<Map<Object, Object>> getDefaultMap() {
        return this.defaultMap;
    }

    public Integer getBufferSize() {
        return this.bufferSize;
    }

    public boolean getAllowDuplicateKeys() {
        return this.allowDuplicateKeys;
    }

    public boolean getAllowRecursiveKeys() {
        return this.allowRecursiveKeys;
    }

    public boolean getUseMarks() {
        return this.useMarks;
    }

    public Function<SpecVersion, SpecVersion> getVersionFunction() {
        return this.versionFunction;
    }

    public Object getCustomProperty(SettingKey settingKey) {
        return this.customProperties.get(settingKey);
    }

    public int getMaxAliasesForCollections() {
        return this.maxAliasesForCollections;
    }

    public Optional<EnvConfig> getEnvConfig() {
        return this.envConfig;
    }

    public boolean getParseComments() {
        return this.parseComments;
    }

    public int getCodePointLimit() {
        return this.codePointLimit;
    }

    public Schema getSchema() {
        return this.schema;
    }
}
