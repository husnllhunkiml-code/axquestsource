package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.engine;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.LoadSettings;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.constructor.StandardConstructor;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Node;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Tag;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.serialization.YamlSerializer;
import java.util.HashMap;
import java.util.Map;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/engine/ExtendedConstructor.class */
public class ExtendedConstructor extends StandardConstructor {
    private final YamlSerializer serializer;
    private final Map<Node, Object> constructed;
    private static transient /* synthetic */ String HsxQvRUvca = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    /* JADX INFO: renamed from: com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.engine.ExtendedConstructor$1 */
    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/engine/ExtendedConstructor$1.class */
    static /* synthetic */ class C00111 {
        private static transient /* synthetic */ String aCNqTuMgJE = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";
    }

    public ExtendedConstructor(@NotNull LoadSettings loadSettings, @NotNull YamlSerializer yamlSerializer) {
        super(loadSettings);
        this.constructed = new HashMap();
        this.serializer = yamlSerializer;
        this.tagConstructors.put(Tag.MAP, new ConstructMap(this, (StandardConstructor.ConstructYamlMap) this.tagConstructors.get(Tag.MAP), null));
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.constructor.BaseConstructor
    protected Object construct(Node node) {
        Object objConstruct = super.construct(node);
        this.constructed.put(node, objConstruct);
        return objConstruct;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.constructor.BaseConstructor
    protected Object constructObjectNoCheck(Node node) {
        Object objConstructObjectNoCheck = super.constructObjectNoCheck(node);
        this.constructed.put(node, objConstructObjectNoCheck);
        return objConstructObjectNoCheck;
    }

    @NotNull
    public Object getConstructed(@NotNull Node node) {
        return this.constructed.get(node);
    }

    public void clear() {
        this.constructed.clear();
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/engine/ExtendedConstructor$ConstructMap.class */
    private class ConstructMap extends StandardConstructor.ConstructYamlMap {
        private final StandardConstructor.ConstructYamlMap previous;
        private static transient /* synthetic */ String eAnjVDUdoG = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        /* synthetic */ ConstructMap(ExtendedConstructor extendedConstructor, StandardConstructor.ConstructYamlMap constructYamlMap, C00111 c00111) {
            this(constructYamlMap);
        }

        private ConstructMap(StandardConstructor.ConstructYamlMap constructYamlMap) {
            super();
            this.previous = constructYamlMap;
        }

        @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.constructor.StandardConstructor.ConstructYamlMap, com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.ConstructNode
        public Object construct(Node node) {
            Map<Object, Object> map = (Map) this.previous.construct(node);
            Object objDeserialize = ExtendedConstructor.this.serializer.deserialize(map);
            return objDeserialize == null ? map : objDeserialize;
        }
    }
}
