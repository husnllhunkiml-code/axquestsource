package com.artillexstudios.axquestboard.libs.axapi.collections;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/collections/RegistrationFailedException.class */
public class RegistrationFailedException extends Exception {
    private final Object key;
    private final Cause cause;
    private static transient /* synthetic */ String elOpaLRzNy = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/collections/RegistrationFailedException$Cause.class */
    public enum Cause {
        ALREADY_PRESENT,
        NOT_PRESENT
    }

    public RegistrationFailedException(Object key, Cause cause) {
        this.key = key;
        this.cause = cause;
    }

    public RegistrationFailedException(String message, Object key, Cause cause) {
        super(message);
        this.key = key;
        this.cause = cause;
    }

    public RegistrationFailedException(String message, Throwable throwable, Object key, Cause cause) {
        super(message, throwable);
        this.key = key;
        this.cause = cause;
    }

    public RegistrationFailedException(Throwable throwable, Object key, Cause cause) {
        super(throwable);
        this.key = key;
        this.cause = cause;
    }

    public Object key() {
        return this.key;
    }

    public Cause cause() {
        return this.cause;
    }
}
