package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.constructor;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.ConstructNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.LoadSettings;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.ConstructorException;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.YamlEngineException;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.MappingNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Node;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.NodeTuple;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.ScalarNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.SequenceNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Tag;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/constructor/BaseConstructor.class */
public abstract class BaseConstructor {
    protected final Map<Tag, ConstructNode> tagConstructors = new HashMap();
    final Map<Node, Object> constructedObjects = new HashMap();
    private final Set<Node> recursiveObjects = new HashSet();
    private final ArrayList<RecursiveTuple<Map<Object, Object>, RecursiveTuple<Object, Object>>> maps2fill = new ArrayList<>();
    private final ArrayList<RecursiveTuple<Set<Object>, Object>> sets2fill = new ArrayList<>();
    protected LoadSettings settings;

    public BaseConstructor(LoadSettings loadSettings) {
        this.settings = loadSettings;
    }

    public Object constructSingleDocument(Optional<Node> optional) {
        if (!optional.isPresent() || Tag.NULL.equals(optional.get().getTag())) {
            return this.tagConstructors.get(Tag.NULL).construct(optional.orElse(null));
        }
        return construct(optional.get());
    }

    protected Object construct(Node node) {
        try {
            try {
                Object objConstructObject = constructObject(node);
                fillRecursive();
                this.constructedObjects.clear();
                this.recursiveObjects.clear();
                return objConstructObject;
            } catch (YamlEngineException e) {
                throw e;
            } catch (RuntimeException e2) {
                throw new YamlEngineException(e2);
            }
        } catch (Throwable th) {
            this.constructedObjects.clear();
            this.recursiveObjects.clear();
            throw th;
        }
    }

    private void fillRecursive() {
        if (!this.maps2fill.isEmpty()) {
            for (RecursiveTuple<Map<Object, Object>, RecursiveTuple<Object, Object>> recursiveTuple : this.maps2fill) {
                RecursiveTuple<Object, Object> value2 = recursiveTuple.getValue2();
                recursiveTuple.getValue1().put(value2.getValue1(), value2.getValue2());
            }
            this.maps2fill.clear();
        }
        if (!this.sets2fill.isEmpty()) {
            for (RecursiveTuple<Set<Object>, Object> recursiveTuple2 : this.sets2fill) {
                recursiveTuple2.getValue1().add(recursiveTuple2.getValue2());
            }
            this.sets2fill.clear();
        }
    }

    protected Object constructObject(Node node) {
        Objects.requireNonNull(node, "Node cannot be null");
        if (this.constructedObjects.containsKey(node)) {
            return this.constructedObjects.get(node);
        }
        return constructObjectNoCheck(node);
    }

    protected Object constructObjectNoCheck(Node node) throws Throwable {
        if (this.recursiveObjects.contains(node)) {
            throw new ConstructorException(null, Optional.empty(), "found unconstructable recursive node", node.getStartMark());
        }
        this.recursiveObjects.add(node);
        ConstructNode constructNodeOrElseThrow = findConstructorFor(node).orElseThrow(() -> {
            return new ConstructorException(null, Optional.empty(), "could not determine a constructor for the tag " + node.getTag(), node.getStartMark());
        });
        Object objConstruct = this.constructedObjects.containsKey(node) ? this.constructedObjects.get(node) : constructNodeOrElseThrow.construct(node);
        this.constructedObjects.put(node, objConstruct);
        this.recursiveObjects.remove(node);
        if (node.isRecursive()) {
            constructNodeOrElseThrow.constructRecursive(node, objConstruct);
        }
        return objConstruct;
    }

    protected Optional<ConstructNode> findConstructorFor(Node node) {
        Tag tag = node.getTag();
        if (this.settings.getTagConstructors().containsKey(tag)) {
            return Optional.of(this.settings.getTagConstructors().get(tag));
        }
        if (this.tagConstructors.containsKey(tag)) {
            return Optional.of(this.tagConstructors.get(tag));
        }
        return Optional.empty();
    }

    protected String constructScalar(ScalarNode scalarNode) {
        return scalarNode.getValue();
    }

    protected List<Object> createEmptyListForNode(SequenceNode sequenceNode) {
        return this.settings.getDefaultList().apply(sequenceNode.getValue().size());
    }

    protected Set<Object> createEmptySetForNode(MappingNode mappingNode) {
        return this.settings.getDefaultSet().apply(mappingNode.getValue().size());
    }

    protected Map<Object, Object> createEmptyMapFor(MappingNode mappingNode) {
        return this.settings.getDefaultMap().apply(mappingNode.getValue().size());
    }

    protected List<Object> constructSequence(SequenceNode sequenceNode) {
        List<Object> listApply = this.settings.getDefaultList().apply(sequenceNode.getValue().size());
        constructSequenceStep2(sequenceNode, listApply);
        return listApply;
    }

    protected void constructSequenceStep2(SequenceNode sequenceNode, Collection<Object> collection) {
        Iterator<Node> it = sequenceNode.getValue().iterator();
        while (it.hasNext()) {
            collection.add(constructObject(it.next()));
        }
    }

    protected Set<Object> constructSet(MappingNode mappingNode) {
        Set<Object> setApply = this.settings.getDefaultSet().apply(mappingNode.getValue().size());
        constructSet2ndStep(mappingNode, setApply);
        return setApply;
    }

    protected Map<Object, Object> constructMapping(MappingNode mappingNode) {
        Map<Object, Object> mapApply = this.settings.getDefaultMap().apply(mappingNode.getValue().size());
        constructMapping2ndStep(mappingNode, mapApply);
        return mapApply;
    }

    protected void constructMapping2ndStep(MappingNode mappingNode, Map<Object, Object> map) {
        for (NodeTuple nodeTuple : mappingNode.getValue()) {
            Node keyNode = nodeTuple.getKeyNode();
            Node valueNode = nodeTuple.getValueNode();
            Object objConstructObject = constructObject(keyNode);
            if (objConstructObject != null) {
                try {
                    objConstructObject.hashCode();
                } catch (Exception e) {
                    throw new ConstructorException("while constructing a mapping", mappingNode.getStartMark(), "found unacceptable key " + objConstructObject, nodeTuple.getKeyNode().getStartMark(), e);
                }
            }
            Object objConstructObject2 = constructObject(valueNode);
            if (keyNode.isRecursive()) {
                if (this.settings.getAllowRecursiveKeys()) {
                    postponeMapFilling(map, objConstructObject, objConstructObject2);
                } else {
                    throw new YamlEngineException("Recursive key for mapping is detected but it is not configured to be allowed.");
                }
            } else {
                map.put(objConstructObject, objConstructObject2);
            }
        }
    }

    protected void postponeMapFilling(Map<Object, Object> map, Object obj, Object obj2) {
        this.maps2fill.add(0, new RecursiveTuple<>(map, new RecursiveTuple(obj, obj2)));
    }

    protected void constructSet2ndStep(MappingNode mappingNode, Set<Object> set) {
        for (NodeTuple nodeTuple : mappingNode.getValue()) {
            Node keyNode = nodeTuple.getKeyNode();
            Object objConstructObject = constructObject(keyNode);
            if (objConstructObject != null) {
                try {
                    objConstructObject.hashCode();
                } catch (Exception e) {
                    throw new ConstructorException("while constructing a Set", mappingNode.getStartMark(), "found unacceptable key " + objConstructObject, nodeTuple.getKeyNode().getStartMark(), e);
                }
            }
            if (keyNode.isRecursive()) {
                if (this.settings.getAllowRecursiveKeys()) {
                    postponeSetFilling(set, objConstructObject);
                } else {
                    throw new YamlEngineException("Recursive key for mapping is detected but it is not configured to be allowed.");
                }
            } else {
                set.add(objConstructObject);
            }
        }
    }

    protected void postponeSetFilling(Set<Object> set, Object obj) {
        this.sets2fill.add(0, new RecursiveTuple<>(set, obj));
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/constructor/BaseConstructor$RecursiveTuple.class */
    private static class RecursiveTuple<T, K> {
        private final T value1;
        private final K value2;
        private static transient /* synthetic */ String zJuJfiDyDw = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        public RecursiveTuple(T t, K k) {
            this.value1 = t;
            this.value2 = k;
        }

        public K getValue2() {
            return this.value2;
        }

        public T getValue1() {
            return this.value1;
        }
    }
}
