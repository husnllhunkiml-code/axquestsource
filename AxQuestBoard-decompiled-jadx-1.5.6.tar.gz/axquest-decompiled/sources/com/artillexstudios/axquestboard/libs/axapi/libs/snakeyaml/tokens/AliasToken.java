package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.tokens;

import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.error.Mark;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/tokens/AliasToken.class */
public final class AliasToken extends Token {
    private final String value;
    private static transient /* synthetic */ String aqtWEWasIW = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public AliasToken(String str, Mark mark, Mark mark2) {
        super(mark, mark2);
        if (str == null) {
            throw new NullPointerException("alias is expected");
        }
        this.value = str;
    }

    public String getValue() {
        return this.value;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.tokens.Token
    public Token.ID getTokenId() {
        return Token.ID.Alias;
    }
}
