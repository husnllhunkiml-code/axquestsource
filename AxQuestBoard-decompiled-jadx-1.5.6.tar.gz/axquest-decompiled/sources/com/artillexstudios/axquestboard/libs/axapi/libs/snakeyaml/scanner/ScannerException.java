package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.scanner;

import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.error.Mark;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.error.MarkedYAMLException;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/scanner/ScannerException.class */
public class ScannerException extends MarkedYAMLException {
    private static final long serialVersionUID = 4782293188600445954L;
    private static transient /* synthetic */ String QRzKJGZnqz = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public ScannerException(String str, Mark mark, String str2, Mark mark2, String str3) {
        super(str, mark, str2, mark2, str3);
    }

    public ScannerException(String str, Mark mark, String str2, Mark mark2) {
        this(str, mark, str2, mark2, null);
    }
}
