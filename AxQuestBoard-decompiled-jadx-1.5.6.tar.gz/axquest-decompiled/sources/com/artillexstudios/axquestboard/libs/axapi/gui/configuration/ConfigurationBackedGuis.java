package com.artillexstudios.axquestboard.libs.axapi.gui.configuration;

import com.artillexstudios.axquestboard.libs.axapi.config.YamlConfiguration;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.MapConfigurationGetter;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.Gui;
import com.artillexstudios.axquestboard.libs.axapi.utils.logging.LogUtils;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/gui/configuration/ConfigurationBackedGuis.class */
public class ConfigurationBackedGuis {
    private static final Map<String, ConfigurationBackedGui<?>> guis = new HashMap();
    private static final Map<String, ConfigurationBackedGui<?>> guisView = Collections.unmodifiableMap(guis);
    private static transient /* synthetic */ String iImpqCQjbG = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public static <T extends Gui> ConfigurationBackedGui<T> register(ConfigurationBackedGui<T> gui) {
        MapConfigurationGetter mapConfigurationGetterConfiguration = gui.builder().configuration();
        if (mapConfigurationGetterConfiguration instanceof YamlConfiguration) {
            register(((YamlConfiguration) mapConfigurationGetterConfiguration).path().toString(), gui);
        } else {
            LogUtils.warn("Failed to register gui configuration, because the configuration is not backed by a yaml document, and no id was specified!", new Object[0]);
        }
        return gui;
    }

    public static <T extends Gui> ConfigurationBackedGui<T> register(String id, ConfigurationBackedGui<T> gui) {
        guis.put(id, gui);
        return gui;
    }

    public static Map<String, ConfigurationBackedGui<?>> registered() {
        return guisView;
    }
}
