package com.artillexstudios.axquestboard.libs.axapi.gui.inventory;

import com.artillexstudios.axquestboard.libs.axapi.context.HashMapContext;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.Gui;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.GuiBuilder;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.builder.DynamicGuiBuilder;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.builder.PaginatedGuiBuilder;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.builder.StaticGuiBuilder;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.modifier.WrappedItemStackModifier;
import com.google.common.base.Preconditions;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryType;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/gui/inventory/GuiBuilder.class */
public abstract class GuiBuilder<T extends Gui, Z extends GuiBuilder<T, Z>> {
    protected final List<WrappedItemStackModifier> modifiers = new ArrayList();
    protected InventoryType type = InventoryType.CHEST;
    protected HashMapContext context = new HashMapContext();
    protected Function<HashMapContext, Component> titleProvider = hashMapContext -> {
        return Component.empty();
    };
    protected int rows;

    public abstract T build(Player player);

    public static DynamicGuiBuilder createDynamic() {
        return new DynamicGuiBuilder();
    }

    public static StaticGuiBuilder createStatic() {
        return new StaticGuiBuilder();
    }

    public static PaginatedGuiBuilder createPaginated() {
        return new PaginatedGuiBuilder();
    }

    public void context(HashMapContext context) {
        this.context = context;
    }

    public Z title(Function<HashMapContext, Component> titleProvider) {
        this.titleProvider = (Function) Preconditions.checkNotNull(titleProvider);
        return this;
    }

    public Z rows(int rows) {
        this.rows = rows;
        return this;
    }

    public Z inventoryType(InventoryType type) {
        this.type = type;
        return this;
    }

    public Z guiItemModifier(WrappedItemStackModifier modifier) {
        this.modifiers.add(modifier);
        return this;
    }
}
