package com.artillexstudios.axquestboard.libs.axapi.libs.hikari.util;

import java.util.Locale;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/hikari/util/UtilityElf.class */
public final class UtilityElf {
    private static final Pattern PASSWORD_MASKING_PATTERN = Pattern.compile("([?&;][^&#;=]*[pP]assword=)[^&#;]*");
    private static transient /* synthetic */ String jzqcNgTLMv = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    private UtilityElf() {
    }

    public static String maskPasswordInJdbcUrl(String str) {
        return PASSWORD_MASKING_PATTERN.matcher(str).replaceAll("$1<masked>");
    }

    public static String getNullIfEmpty(String str) {
        if (str == null || str.trim().isEmpty()) {
            return null;
        }
        return str.trim();
    }

    public static void quietlySleep(long j) {
        try {
            Thread.sleep(j);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    public static boolean safeIsAssignableFrom(Object obj, String str) {
        try {
            return Class.forName(str).isAssignableFrom(obj.getClass());
        } catch (ClassNotFoundException e) {
            return false;
        }
    }

    public static <T> T createInstance(String str, Class<T> cls, Object... objArr) {
        if (str == null) {
            return null;
        }
        try {
            Class<?> clsLoadClass = UtilityElf.class.getClassLoader().loadClass(str);
            int length = objArr.length;
            if (length == 0) {
                return cls.cast(clsLoadClass.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]));
            }
            Class<?>[] clsArr = new Class[length];
            for (int i = 0; i < length; i++) {
                clsArr[i] = objArr[i].getClass();
            }
            return cls.cast(clsLoadClass.getConstructor(clsArr).newInstance(objArr));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static ThreadPoolExecutor createThreadPoolExecutor(int i, String str, ThreadFactory threadFactory, RejectedExecutionHandler rejectedExecutionHandler) {
        return createThreadPoolExecutor(new LinkedBlockingQueue(i), str, threadFactory, rejectedExecutionHandler);
    }

    public static ThreadPoolExecutor createThreadPoolExecutor(BlockingQueue<Runnable> blockingQueue, String str, ThreadFactory threadFactory, RejectedExecutionHandler rejectedExecutionHandler) {
        if (threadFactory == null) {
            threadFactory = new DefaultThreadFactory(str);
        }
        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(1, 1, 5L, TimeUnit.SECONDS, blockingQueue, threadFactory, rejectedExecutionHandler);
        threadPoolExecutor.allowCoreThreadTimeOut(true);
        return threadPoolExecutor;
    }

    public static int getTransactionIsolation(String str) {
        if (str != null) {
            try {
                return IsolationLevel.valueOf(str.toUpperCase(Locale.ENGLISH)).getLevelId();
            } catch (IllegalArgumentException e) {
                try {
                    int i = Integer.parseInt(str);
                    for (IsolationLevel isolationLevel : IsolationLevel.values()) {
                        if (isolationLevel.getLevelId() == i) {
                            return isolationLevel.getLevelId();
                        }
                    }
                    throw new IllegalArgumentException("Invalid transaction isolation value: " + str);
                } catch (NumberFormatException e2) {
                    throw new IllegalArgumentException("Invalid transaction isolation value: " + str, e2);
                }
            }
        }
        return -1;
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/hikari/util/UtilityElf$CustomDiscardPolicy.class */
    public static class CustomDiscardPolicy implements RejectedExecutionHandler {
        private static transient /* synthetic */ String XhdhWCQkez = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        @Override // java.util.concurrent.RejectedExecutionHandler
        public void rejectedExecution(Runnable runnable, ThreadPoolExecutor threadPoolExecutor) {
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/hikari/util/UtilityElf$DefaultThreadFactory.class */
    public static final class DefaultThreadFactory implements ThreadFactory {
        private final String threadName;
        private final boolean daemon = true;
        private static transient /* synthetic */ String BxrWwMnvJh = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        public DefaultThreadFactory(String str) {
            this.threadName = str;
        }

        @Override // java.util.concurrent.ThreadFactory
        public Thread newThread(Runnable runnable) {
            Thread thread = new Thread(runnable, this.threadName);
            thread.setDaemon(this.daemon);
            return thread;
        }
    }
}
