package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.emitter.Emitter;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Node;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.representer.BaseRepresenter;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.representer.StandardRepresenter;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.serializer.Serializer;
import java.util.Collections;
import java.util.Iterator;
import java.util.Objects;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/api/Dump.class */
public class Dump {
    protected DumpSettings settings;
    protected BaseRepresenter representer;
    private static transient /* synthetic */ String pOOINbaedL = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public Dump(DumpSettings dumpSettings) {
        this(dumpSettings, new StandardRepresenter(dumpSettings));
    }

    public Dump(DumpSettings dumpSettings, BaseRepresenter baseRepresenter) {
        Objects.requireNonNull(dumpSettings, "DumpSettings cannot be null");
        Objects.requireNonNull(baseRepresenter, "Representer cannot be null");
        this.settings = dumpSettings;
        this.representer = baseRepresenter;
    }

    public void dumpAll(Iterator<? extends Object> it, StreamDataWriter streamDataWriter) {
        Objects.requireNonNull(it, "Iterator cannot be null");
        Objects.requireNonNull(streamDataWriter, "StreamDataWriter cannot be null");
        Serializer serializer = new Serializer(this.settings, new Emitter(this.settings, streamDataWriter));
        serializer.emitStreamStart();
        while (it.hasNext()) {
            serializer.serializeDocument(this.representer.represent(it.next()));
        }
        serializer.emitStreamEnd();
    }

    public void dump(Object obj, StreamDataWriter streamDataWriter) {
        dumpAll(Collections.singleton(obj).iterator(), streamDataWriter);
    }

    public String dumpAllToString(Iterator<? extends Object> it) {
        StreamToStringWriter streamToStringWriter = new StreamToStringWriter();
        dumpAll(it, streamToStringWriter);
        return streamToStringWriter.toString();
    }

    public String dumpToString(Object obj) {
        StreamToStringWriter streamToStringWriter = new StreamToStringWriter();
        dump(obj, streamToStringWriter);
        return streamToStringWriter.toString();
    }

    public void dumpNode(Node node, StreamDataWriter streamDataWriter) {
        Objects.requireNonNull(node, "Node cannot be null");
        Objects.requireNonNull(streamDataWriter, "StreamDataWriter cannot be null");
        Serializer serializer = new Serializer(this.settings, new Emitter(this.settings, streamDataWriter));
        serializer.emitStreamStart();
        serializer.serializeDocument(node);
        serializer.emitStreamEnd();
    }
}
