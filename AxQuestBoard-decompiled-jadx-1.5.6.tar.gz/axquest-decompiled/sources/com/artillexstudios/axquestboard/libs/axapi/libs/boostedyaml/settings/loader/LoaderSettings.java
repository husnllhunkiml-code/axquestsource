package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.loader;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.ConstructNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.LoadSettings;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.LoadSettingsBuilder;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.env.EnvConfig;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Tag;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.schema.Schema;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.Settings;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.general.GeneralSettings;
import java.util.Map;
import java.util.Optional;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/settings/loader/LoaderSettings.class */
public class LoaderSettings implements Settings {
    public static final LoaderSettings DEFAULT = builder().build();
    private final LoadSettingsBuilder builder;
    private final boolean createFileIfAbsent;
    private final boolean autoUpdate;
    private static transient /* synthetic */ String nValggYMqN = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    /* JADX INFO: renamed from: com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.loader.LoaderSettings$1 */
    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/settings/loader/LoaderSettings$1.class */
    static /* synthetic */ class C00241 {
        private static transient /* synthetic */ String THPnrNeveF = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";
    }

    /* synthetic */ LoaderSettings(Builder builder, C00241 c00241) {
        this(builder);
    }

    private LoaderSettings(Builder builder) {
        this.builder = builder.builder;
        this.autoUpdate = builder.autoUpdate;
        this.createFileIfAbsent = builder.createFileIfAbsent;
    }

    public boolean isAutoUpdate() {
        return this.autoUpdate;
    }

    public boolean isCreateFileIfAbsent() {
        return this.createFileIfAbsent;
    }

    public LoadSettings buildEngineSettings(GeneralSettings generalSettings) {
        LoadSettingsBuilder parseComments = this.builder.setParseComments(true);
        generalSettings.getClass();
        LoadSettingsBuilder defaultList = parseComments.setDefaultList(generalSettings::getDefaultList);
        generalSettings.getClass();
        LoadSettingsBuilder defaultSet = defaultList.setDefaultSet(generalSettings::getDefaultSet);
        generalSettings.getClass();
        return defaultSet.setDefaultMap(generalSettings::getDefaultMap).build();
    }

    public static Builder builder() {
        return new Builder((C00241) null);
    }

    public static Builder builder(LoadSettingsBuilder loadSettingsBuilder) {
        return new Builder(loadSettingsBuilder, null);
    }

    public static Builder builder(LoaderSettings loaderSettings) {
        return builder(loaderSettings.builder).setAutoUpdate(loaderSettings.autoUpdate).setCreateFileIfAbsent(loaderSettings.createFileIfAbsent);
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/settings/loader/LoaderSettings$Builder.class */
    public static class Builder {
        public static final boolean DEFAULT_CREATE_FILE_IF_ABSENT = true;
        public static final boolean DEFAULT_AUTO_UPDATE = false;
        public static final boolean DEFAULT_DETAILED_ERRORS = true;
        public static final boolean DEFAULT_ALLOW_DUPLICATE_KEYS = true;
        private final LoadSettingsBuilder builder;
        private boolean autoUpdate;
        private boolean createFileIfAbsent;
        private static transient /* synthetic */ String CsCtKEdZoo = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        /* synthetic */ Builder(C00241 c00241) {
            this();
        }

        /* synthetic */ Builder(LoadSettingsBuilder loadSettingsBuilder, C00241 c00241) {
            this(loadSettingsBuilder);
        }

        private Builder(LoadSettingsBuilder loadSettingsBuilder) {
            this.autoUpdate = false;
            this.createFileIfAbsent = true;
            this.builder = loadSettingsBuilder;
        }

        private Builder() {
            this.autoUpdate = false;
            this.createFileIfAbsent = true;
            this.builder = LoadSettings.builder();
            setDetailedErrors(true);
            setAllowDuplicateKeys(true);
        }

        public Builder setCreateFileIfAbsent(boolean z) {
            this.createFileIfAbsent = z;
            return this;
        }

        public Builder setAutoUpdate(boolean z) {
            this.autoUpdate = z;
            return this;
        }

        public Builder setErrorLabel(@NotNull String str) {
            this.builder.setLabel(str);
            return this;
        }

        public Builder setDetailedErrors(boolean z) {
            this.builder.setUseMarks(z);
            return this;
        }

        public Builder setAllowDuplicateKeys(boolean z) {
            this.builder.setAllowDuplicateKeys(z);
            return this;
        }

        public Builder setMaxCollectionAliases(int i) {
            this.builder.setMaxAliasesForCollections(i);
            return this;
        }

        public Builder setTagConstructors(@NotNull Map<Tag, ConstructNode> map) {
            this.builder.setTagConstructors(map);
            return this;
        }

        public Builder setSchema(@NotNull Schema schema) {
            this.builder.setSchema(schema);
            return this;
        }

        public Builder setEnvironmentConfig(@Nullable EnvConfig envConfig) {
            this.builder.setEnvConfig(Optional.ofNullable(envConfig));
            return this;
        }

        public LoaderSettings build() {
            return new LoaderSettings(this, null);
        }
    }
}
