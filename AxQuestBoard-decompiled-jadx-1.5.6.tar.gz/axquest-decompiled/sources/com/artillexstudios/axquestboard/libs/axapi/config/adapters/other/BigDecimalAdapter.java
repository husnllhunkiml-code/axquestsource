package com.artillexstudios.axquestboard.libs.axapi.config.adapters.other;

import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapterHolder;
import java.lang.reflect.Type;
import java.math.BigDecimal;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/adapters/other/BigDecimalAdapter.class */
public final class BigDecimalAdapter implements TypeAdapter<BigDecimal, String> {
    private static transient /* synthetic */ String UsksuvJiDt = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public BigDecimal deserialize(TypeAdapterHolder holder, Object input, Type type) {
        if (input instanceof String) {
            return new BigDecimal((String) input);
        }
        if (input instanceof Number) {
            return BigDecimal.valueOf(((Number) input).doubleValue());
        }
        throw new IllegalArgumentException("Can't convert %s into a BigDecimal!".formatted(input.getClass()));
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public String serialize(TypeAdapterHolder holder, BigDecimal value, Type type) {
        return value.toString();
    }
}
