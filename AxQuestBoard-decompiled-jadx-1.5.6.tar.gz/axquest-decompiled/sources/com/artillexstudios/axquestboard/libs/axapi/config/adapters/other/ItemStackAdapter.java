package com.artillexstudios.axquestboard.libs.axapi.config.adapters.other;

import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapterHolder;
import com.artillexstudios.axquestboard.libs.axapi.items.WrappedItemStack;
import java.lang.reflect.Type;
import java.util.Map;
import org.bukkit.inventory.ItemStack;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/adapters/other/ItemStackAdapter.class */
public final class ItemStackAdapter implements TypeAdapter<ItemStack, Map<String, Object>> {
    private final WrappedItemStackAdapter wrappedItemStackAdapter = new WrappedItemStackAdapter();
    private static transient /* synthetic */ String WLtFEdodqU = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public ItemStack deserialize(TypeAdapterHolder holder, Object input, Type type) {
        return this.wrappedItemStackAdapter.deserialize(holder, input, type).toBukkit();
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public Map<String, Object> serialize(TypeAdapterHolder holder, ItemStack value, Type type) {
        return this.wrappedItemStackAdapter.serialize(holder, WrappedItemStack.wrap(value), type);
    }
}
