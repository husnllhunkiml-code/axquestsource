package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.external.biz.base64Coder;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/external/biz/base64Coder/Base64Coder.class */
public class Base64Coder {
    private static final String systemLineSeparator = System.getProperty("line.separator");
    private static final char[] map1 = new char[64];
    private static final byte[] map2;
    private static transient /* synthetic */ String XrzmDrQABG = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    static {
        int i = 0;
        char c = 'A';
        while (true) {
            char c2 = c;
            if (c2 > 'Z') {
                break;
            }
            int i2 = i;
            i++;
            map1[i2] = c2;
            c = (char) (c2 + 1);
        }
        char c3 = 'a';
        while (true) {
            char c4 = c3;
            if (c4 > 'z') {
                break;
            }
            int i3 = i;
            i++;
            map1[i3] = c4;
            c3 = (char) (c4 + 1);
        }
        char c5 = '0';
        while (true) {
            char c6 = c5;
            if (c6 > '9') {
                break;
            }
            int i4 = i;
            i++;
            map1[i4] = c6;
            c5 = (char) (c6 + 1);
        }
        int i5 = i;
        int i6 = i + 1;
        map1[i5] = '+';
        int i7 = i6 + 1;
        map1[i6] = '/';
        map2 = new byte[128];
        for (int i8 = 0; i8 < map2.length; i8++) {
            map2[i8] = -1;
        }
        for (int i9 = 0; i9 < 64; i9++) {
            map2[map1[i9]] = (byte) i9;
        }
    }

    public static String encodeString(String str) {
        return new String(encode(str.getBytes()));
    }

    public static String encodeLines(byte[] bArr) {
        return encodeLines(bArr, 0, bArr.length, 76, systemLineSeparator);
    }

    public static String encodeLines(byte[] bArr, int i, int i2, int i3, String str) {
        int i4 = (i3 * 3) / 4;
        if (i4 <= 0) {
            throw new IllegalArgumentException();
        }
        StringBuilder sb = new StringBuilder((((i2 + 2) / 3) * 4) + ((((i2 + i4) - 1) / i4) * str.length()));
        int i5 = 0;
        while (true) {
            int i6 = i5;
            if (i6 < i2) {
                int iMin = Math.min(i2 - i6, i4);
                sb.append(encode(bArr, i + i6, iMin));
                sb.append(str);
                i5 = i6 + iMin;
            } else {
                return sb.toString();
            }
        }
    }

    public static char[] encode(byte[] bArr) {
        return encode(bArr, 0, bArr.length);
    }

    public static char[] encode(byte[] bArr, int i) {
        return encode(bArr, 0, i);
    }

    public static char[] encode(byte[] bArr, int i, int i2) {
        int i3;
        int i4;
        int i5 = ((i2 * 4) + 2) / 3;
        char[] cArr = new char[((i2 + 2) / 3) * 4];
        int i6 = i;
        int i7 = i + i2;
        int i8 = 0;
        while (i6 < i7) {
            int i9 = i6;
            i6++;
            int i10 = bArr[i9] & 255;
            if (i6 < i7) {
                i6++;
                i3 = bArr[i6] & 255;
            } else {
                i3 = 0;
            }
            int i11 = i3;
            if (i6 < i7) {
                int i12 = i6;
                i6++;
                i4 = bArr[i12] & 255;
            } else {
                i4 = 0;
            }
            int i13 = i4;
            int i14 = i10 >>> 2;
            int i15 = ((i10 & 3) << 4) | (i11 >>> 4);
            int i16 = ((i11 & 15) << 2) | (i13 >>> 6);
            int i17 = i13 & 63;
            int i18 = i8;
            int i19 = i8 + 1;
            cArr[i18] = map1[i14];
            int i20 = i19 + 1;
            cArr[i19] = map1[i15];
            cArr[i20] = i20 < i5 ? map1[i16] : '=';
            int i21 = i20 + 1;
            cArr[i21] = i21 < i5 ? map1[i17] : '=';
            i8 = i21 + 1;
        }
        return cArr;
    }

    public static String decodeString(String str) {
        return new String(decode(str));
    }

    public static byte[] decodeLines(String str) {
        char[] cArr = new char[str.length()];
        int i = 0;
        for (int i2 = 0; i2 < str.length(); i2++) {
            char cCharAt = str.charAt(i2);
            if (cCharAt != ' ' && cCharAt != '\r' && cCharAt != '\n' && cCharAt != '\t') {
                int i3 = i;
                i++;
                cArr[i3] = cCharAt;
            }
        }
        return decode(cArr, 0, i);
    }

    public static byte[] decode(String str) {
        return decode(str.toCharArray());
    }

    public static byte[] decode(char[] cArr) {
        return decode(cArr, 0, cArr.length);
    }

    public static byte[] decode(char[] cArr, int i, int i2) {
        char c;
        char c2;
        if (i2 % 4 != 0) {
            throw new IllegalArgumentException("Length of Base64 encoded input string is not a multiple of 4.");
        }
        while (i2 > 0 && cArr[(i + i2) - 1] == '=') {
            i2--;
        }
        int i3 = (i2 * 3) / 4;
        byte[] bArr = new byte[i3];
        int i4 = i;
        int i5 = i + i2;
        int i6 = 0;
        while (i4 < i5) {
            int i7 = i4;
            int i8 = i4 + 1;
            char c3 = cArr[i7];
            i4 = i8 + 1;
            char c4 = cArr[i8];
            if (i4 < i5) {
                i4++;
                c = cArr[i4];
            } else {
                c = 'A';
            }
            char c5 = c;
            if (i4 < i5) {
                int i9 = i4;
                i4++;
                c2 = cArr[i9];
            } else {
                c2 = 'A';
            }
            char c6 = c2;
            if (c3 > '\u007f' || c4 > '\u007f' || c5 > '\u007f' || c6 > '\u007f') {
                throw new IllegalArgumentException("Illegal character in Base64 encoded data.");
            }
            byte b = map2[c3];
            byte b2 = map2[c4];
            byte b3 = map2[c5];
            byte b4 = map2[c6];
            if (b < 0 || b2 < 0 || b3 < 0 || b4 < 0) {
                throw new IllegalArgumentException("Illegal character in Base64 encoded data.");
            }
            int i10 = (b << 2) | (b2 >>> 4);
            int i11 = ((b2 & 15) << 4) | (b3 >>> 2);
            int i12 = ((b3 & 3) << 6) | b4;
            int i13 = i6;
            i6++;
            bArr[i13] = (byte) i10;
            if (i6 < i3) {
                i6++;
                bArr[i6] = (byte) i11;
            }
            if (i6 < i3) {
                int i14 = i6;
                i6++;
                bArr[i14] = (byte) i12;
            }
        }
        return bArr;
    }

    private Base64Coder() {
    }
}
