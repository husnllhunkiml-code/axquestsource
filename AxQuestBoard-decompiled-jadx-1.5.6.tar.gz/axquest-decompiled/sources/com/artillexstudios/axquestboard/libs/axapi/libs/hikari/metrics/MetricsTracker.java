package com.artillexstudios.axquestboard.libs.axapi.libs.hikari.metrics;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/hikari/metrics/MetricsTracker.class */
@Deprecated
public class MetricsTracker implements IMetricsTracker {
    private static transient /* synthetic */ String uPGbrrEEzD = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";
}
