package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.updater.operators;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.YamlDocument;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.block.Block;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.block.implementation.Section;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.block.implementation.TerminatedBlock;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.engine.ExtendedConstructor;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.engine.ExtendedRepresenter;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.ScalarStyle;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.MappingNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Node;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.ScalarNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Tag;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.route.Route;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.general.GeneralSettings;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.updater.MergeRule;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.updater.UpdaterSettings;
import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.function.Supplier;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/updater/operators/Merger.class */
public class Merger {
    private static final Merger INSTANCE = new Merger();
    private static transient /* synthetic */ String sNUngBhJuF = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public static void merge(@NotNull Section section, @NotNull Section section2, @NotNull UpdaterSettings updaterSettings) {
        INSTANCE.iterate(section, section2, updaterSettings);
    }

    private void iterate(Section section, Section section2, UpdaterSettings updaterSettings) {
        HashSet hashSet = new HashSet(section.getStoredValue().keySet());
        boolean z = updaterSettings.getOptionSorting() == UpdaterSettings.OptionSorting.SORT_BY_DEFAULTS;
        Map<Object, Block<?>> defaultMap = z ? section.getRoot().getGeneralSettings().getDefaultMap() : null;
        for (Map.Entry<Object, Block<?>> entry : section2.getStoredValue().entrySet()) {
            Object key = entry.getKey();
            Route routeFrom = Route.from(key);
            hashSet.remove(key);
            Block<?> blockOrElse = section.getOptionalBlock(routeFrom).orElse(null);
            Block<?> value = entry.getValue();
            if (blockOrElse != null) {
                if (blockOrElse.isIgnored()) {
                    blockOrElse.setIgnored(false);
                    if (blockOrElse instanceof Section) {
                        resetIgnored((Section) blockOrElse);
                    }
                    if (z) {
                        defaultMap.put(key, blockOrElse);
                    }
                } else {
                    boolean z2 = blockOrElse instanceof Section;
                    boolean z3 = value instanceof Section;
                    if (z3 && z2) {
                        iterate((Section) blockOrElse, (Section) value, updaterSettings);
                        if (z) {
                            defaultMap.put(key, blockOrElse);
                        }
                    } else if (z) {
                        defaultMap.put(key, getPreservedValue(updaterSettings.getMergeRules(), blockOrElse, () -> {
                            return cloneBlock(value, section);
                        }, z2, z3));
                    } else {
                        section.set(routeFrom, getPreservedValue(updaterSettings.getMergeRules(), blockOrElse, () -> {
                            return cloneBlock(value, section);
                        }, z2, z3));
                    }
                }
            } else if (z) {
                defaultMap.put(key, cloneBlock(value, section));
            } else {
                section.set(routeFrom, cloneBlock(value, section));
            }
        }
        if (updaterSettings.isKeepAll()) {
            if (z) {
                hashSet.forEach(obj -> {
                });
                section.repopulate(defaultMap);
                return;
            }
            return;
        }
        for (Object obj2 : hashSet) {
            Route routeFromSingleKey = Route.fromSingleKey(obj2);
            Block<?> blockOrElse2 = section.getOptionalBlock(routeFromSingleKey).orElse(null);
            if (blockOrElse2 != null && blockOrElse2.isIgnored()) {
                blockOrElse2.setIgnored(false);
                if (blockOrElse2 instanceof Section) {
                    resetIgnored((Section) blockOrElse2);
                }
                if (z) {
                    defaultMap.put(obj2, blockOrElse2);
                }
            } else if (!z) {
                section.remove(routeFromSingleKey);
            }
        }
        if (z) {
            section.repopulate(defaultMap);
        }
    }

    private void resetIgnored(@NotNull Section section) {
        section.getStoredValue().values().forEach(block -> {
            block.setIgnored(false);
            if (block instanceof Section) {
                resetIgnored((Section) block);
            }
        });
    }

    @NotNull
    private Block<?> cloneBlock(@NotNull Block<?> block, @NotNull Section section) {
        return block instanceof Section ? cloneSection((Section) block, section) : cloneTerminated((TerminatedBlock) block, section);
    }

    @NotNull
    private Section cloneSection(@NotNull Section section, @NotNull Section section2) {
        if (section.getRoute() == null) {
            throw new IllegalArgumentException("Cannot clone the root!");
        }
        YamlDocument root = section.getRoot();
        GeneralSettings generalSettings = root.getGeneralSettings();
        ExtendedRepresenter extendedRepresenter = new ExtendedRepresenter(generalSettings, root.getDumperSettings());
        ExtendedConstructor extendedConstructor = new ExtendedConstructor(root.getLoaderSettings().buildEngineSettings(generalSettings), generalSettings.getSerializer());
        Node nodeRepresent = extendedRepresenter.represent(section);
        extendedConstructor.constructSingleDocument(Optional.of(nodeRepresent));
        Section section3 = new Section(section2.getRoot(), section2, section.getRoute(), moveComments(nodeRepresent), (MappingNode) nodeRepresent, extendedConstructor);
        extendedConstructor.clear();
        return section3;
    }

    @NotNull
    private TerminatedBlock cloneTerminated(@NotNull TerminatedBlock terminatedBlock, @NotNull Section section) {
        YamlDocument root = section.getRoot();
        GeneralSettings generalSettings = root.getGeneralSettings();
        ExtendedRepresenter extendedRepresenter = new ExtendedRepresenter(generalSettings, root.getDumperSettings());
        ExtendedConstructor extendedConstructor = new ExtendedConstructor(root.getLoaderSettings().buildEngineSettings(generalSettings), generalSettings.getSerializer());
        Node nodeRepresent = extendedRepresenter.represent(terminatedBlock.getStoredValue());
        extendedConstructor.constructSingleDocument(Optional.of(nodeRepresent));
        TerminatedBlock terminatedBlock2 = new TerminatedBlock(terminatedBlock, extendedConstructor.getConstructed(nodeRepresent));
        extendedConstructor.clear();
        return terminatedBlock2;
    }

    private Node moveComments(@NotNull Node node) {
        ScalarNode scalarNode = new ScalarNode(Tag.STR, "", ScalarStyle.PLAIN);
        scalarNode.setBlockComments(node.getBlockComments());
        scalarNode.setInLineComments(node.getInLineComments());
        scalarNode.setEndComments(node.getEndComments());
        node.setBlockComments(Collections.emptyList());
        node.setInLineComments(null);
        node.setEndComments(null);
        return scalarNode;
    }

    @NotNull
    private Block<?> getPreservedValue(@NotNull Map<MergeRule, Boolean> map, @NotNull Block<?> block, @NotNull Supplier<Block<?>> supplier, boolean z, boolean z2) {
        return map.get(MergeRule.getFor(z, z2)).booleanValue() ? block : supplier.get();
    }
}
