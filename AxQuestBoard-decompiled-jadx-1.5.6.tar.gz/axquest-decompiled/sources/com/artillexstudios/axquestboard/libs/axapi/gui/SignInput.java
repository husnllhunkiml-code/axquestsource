package com.artillexstudios.axquestboard.libs.axapi.gui;

import com.artillexstudios.axquestboard.libs.axapi.nms.NMSHandlers;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;
import net.kyori.adventure.text.Component;
import org.bukkit.Location;
import org.bukkit.entity.Player;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/gui/SignInput.class */
public class SignInput {
    private static final List<SignInput> inputs = new ArrayList();
    private final Player player;
    private final Component[] lines;
    private final BiConsumer<Player, String[]> listener;
    private final Location location;
    private static transient /* synthetic */ String ZUQcQfuDVF = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public SignInput(Player player, Component[] lines, BiConsumer<Player, String[]> listener) {
        this.player = player;
        this.lines = lines;
        this.listener = listener;
        this.location = player.getLocation().clone().clone().add(0.0d, 4.0d, 0.0d);
    }

    public void open() {
        NMSHandlers.getNmsHandler().openSignInput(this);
        inputs.add(this);
    }

    public Location getLocation() {
        return this.location;
    }

    public BiConsumer<Player, String[]> getListener() {
        return this.listener;
    }

    public Component[] getLines() {
        return this.lines;
    }

    public Player getPlayer() {
        return this.player;
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/gui/SignInput$Builder.class */
    public static class Builder {
        private Component[] lines = new Component[0];
        private BiConsumer<Player, String[]> response = (player, strArr) -> {
        };
        private static transient /* synthetic */ String oZOEDvaNMO = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        public Builder setLines(Component[] lines) {
            this.lines = lines;
            return this;
        }

        public Builder setLines(List<Component> lines) {
            this.lines = (Component[]) lines.toArray(new Component[0]);
            return this;
        }

        public Builder setHandler(BiConsumer<Player, String[]> response) {
            this.response = response;
            return this;
        }

        public SignInput build(Player player) {
            return new SignInput(player, this.lines, this.response);
        }
    }

    public static SignInput remove(Player player) {
        SignInput signInput = null;
        for (SignInput signInput2 : inputs) {
            if (signInput2.player.equals(player)) {
                signInput = signInput2;
                break;
            }
        }
        if (signInput != null) {
            inputs.remove(signInput);
        }
        return signInput;
    }
}
