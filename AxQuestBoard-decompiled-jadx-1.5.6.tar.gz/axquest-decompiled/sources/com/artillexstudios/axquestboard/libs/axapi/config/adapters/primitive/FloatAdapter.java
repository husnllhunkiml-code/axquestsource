package com.artillexstudios.axquestboard.libs.axapi.config.adapters.primitive;

import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapterHolder;
import java.lang.reflect.Type;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/adapters/primitive/FloatAdapter.class */
public final class FloatAdapter implements TypeAdapter<Float, Float> {
    private static transient /* synthetic */ String kwQThzDymh = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public Float deserialize(TypeAdapterHolder registry, Object input, Type type) {
        if (input instanceof Number) {
            return validate((Number) input);
        }
        if (input instanceof String) {
            return validate(Double.valueOf(Double.parseDouble((String) input)));
        }
        throw new IllegalArgumentException("Can't make a float from a " + String.valueOf(input.getClass()));
    }

    private Float validate(Number number) {
        double dDoubleValue = number.doubleValue();
        if (dDoubleValue > 3.4028234663852886E38d || dDoubleValue < -3.4028234663852886E38d) {
            throw new IllegalArgumentException("Float value is not actually a float! Should be between %s and %s, but was %s".formatted(Float.valueOf(-3.4028235E38f), Float.valueOf(Float.MAX_VALUE), Double.valueOf(dDoubleValue)));
        }
        return Float.valueOf((float) dDoubleValue);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public Float serialize(TypeAdapterHolder registry, Float value, Type type) {
        return value;
    }
}
