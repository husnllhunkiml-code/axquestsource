package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.Mark;
import java.util.Optional;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/tokens/BlockMappingStartToken.class */
public final class BlockMappingStartToken extends Token {
    private static transient /* synthetic */ String vbEesfKkoT = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public BlockMappingStartToken(Optional<Mark> optional, Optional<Mark> optional2) {
        super(optional, optional2);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.Token
    public Token.ID getTokenId() {
        return Token.ID.BlockMappingStart;
    }
}
