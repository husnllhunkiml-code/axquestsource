package com.artillexstudios.axquestboard.libs.axapi.items.component.type;

import com.google.common.collect.LinkedHashMultimap;
import com.google.common.collect.Multimap;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.runtime.ObjectMethods;
import java.util.UUID;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/items/component/type/ProfileProperties.class */
public final class ProfileProperties {
    private final Multimap<String, Property> properties = LinkedHashMultimap.create();
    private final UUID uuid;
    private final String name;
    private static transient /* synthetic */ String HskYZdwbfC = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public ProfileProperties(UUID uuid, String name) {
        this.uuid = uuid;
        this.name = name;
    }

    public UUID uuid() {
        return this.uuid;
    }

    public String name() {
        return this.name;
    }

    public void put(String key, Property property) {
        this.properties.put(key, property);
    }

    public Multimap<String, Property> properties() {
        return this.properties;
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/items/component/type/ProfileProperties$Property.class */
    public static final class Property extends Record {
        private final String name;
        private final String value;
        private final String signature;
        private static transient /* synthetic */ String ChbowRzNrm = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        public Property(String name, String value, String signature) {
            this.name = name;
            this.value = value;
            this.signature = signature;
        }

        @Override // java.lang.Record
        public final String toString() {
            return (String) ObjectMethods.bootstrap(MethodHandles.lookup(), "toString", MethodType.methodType(String.class, Property.class), Property.class, "name;value;signature", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/items/component/type/ProfileProperties$Property;->name:Ljava/lang/String;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/items/component/type/ProfileProperties$Property;->value:Ljava/lang/String;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/items/component/type/ProfileProperties$Property;->signature:Ljava/lang/String;").dynamicInvoker().invoke(this) /* invoke-custom */;
        }

        @Override // java.lang.Record
        public final int hashCode() {
            return (int) ObjectMethods.bootstrap(MethodHandles.lookup(), "hashCode", MethodType.methodType(Integer.TYPE, Property.class), Property.class, "name;value;signature", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/items/component/type/ProfileProperties$Property;->name:Ljava/lang/String;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/items/component/type/ProfileProperties$Property;->value:Ljava/lang/String;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/items/component/type/ProfileProperties$Property;->signature:Ljava/lang/String;").dynamicInvoker().invoke(this) /* invoke-custom */;
        }

        @Override // java.lang.Record
        public final boolean equals(Object o) {
            return (boolean) ObjectMethods.bootstrap(MethodHandles.lookup(), "equals", MethodType.methodType(Boolean.TYPE, Property.class, Object.class), Property.class, "name;value;signature", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/items/component/type/ProfileProperties$Property;->name:Ljava/lang/String;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/items/component/type/ProfileProperties$Property;->value:Ljava/lang/String;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/items/component/type/ProfileProperties$Property;->signature:Ljava/lang/String;").dynamicInvoker().invoke(this, o) /* invoke-custom */;
        }

        public String name() {
            return this.name;
        }

        public String value() {
            return this.value;
        }

        public String signature() {
            return this.signature;
        }
    }
}
