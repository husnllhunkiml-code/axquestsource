package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.introspector;

import java.lang.annotation.Annotation;
import java.util.Collections;
import java.util.List;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/introspector/MissingProperty.class */
public class MissingProperty extends Property {
    private static transient /* synthetic */ String ZURtMgawiW = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public MissingProperty(String str) {
        super(str, Object.class);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.introspector.Property
    public Class<?>[] getActualTypeArguments() {
        return new Class[0];
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.introspector.Property
    public void set(Object obj, Object obj2) {
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.introspector.Property
    public Object get(Object obj) {
        return obj;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.introspector.Property
    public List<Annotation> getAnnotations() {
        return Collections.emptyList();
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.introspector.Property
    public <A extends Annotation> A getAnnotation(Class<A> cls) {
        return null;
    }
}
