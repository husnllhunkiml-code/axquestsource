package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.serializer;

import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.error.YAMLException;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/serializer/SerializerException.class */
public class SerializerException extends YAMLException {
    private static final long serialVersionUID = 2632638197498912433L;
    private static transient /* synthetic */ String MemTLmaLZj = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public SerializerException(String str) {
        super(str);
    }
}
