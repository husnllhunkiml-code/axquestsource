package com.artillexstudios.axquestboard.libs.axapi.config.adapters;

import com.artillexstudios.axquestboard.libs.axapi.utils.UncheckedUtils;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Function;
import java.util.regex.Pattern;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/adapters/ConfigurationGetter.class */
public interface ConfigurationGetter {
    <T> T get(String path, Class<T> clazz);

    Set<String> getKeys();

    default <T> T anyOf(Function<String, T> function, String... paths) {
        for (String path : paths) {
            T value = function.apply(path);
            if (value != null) {
                return value;
            }
        }
        return null;
    }

    default Object getObject(String path) {
        return get(path, Object.class);
    }

    default Boolean getBoolean(String path) {
        return (Boolean) get(path, Boolean.class);
    }

    default String getString(String path) {
        return (String) get(path, String.class);
    }

    default Double getDouble(String path) {
        return (Double) get(path, Double.class);
    }

    default Integer getInteger(String path) {
        return (Integer) get(path, Integer.class);
    }

    default Float getFloat(String path) {
        return (Float) get(path, Float.class);
    }

    default Short getShort(String path) {
        return (Short) get(path, Short.class);
    }

    default Byte getByte(String path) {
        return (Byte) get(path, Byte.class);
    }

    default <T> List<T> getList(String path) {
        return (List) UncheckedUtils.unsafeCast(get(path, List.class));
    }

    default <T, Z> List<T> getList(String path, Function<Z, T> converter) {
        List<Z> list = (List) UncheckedUtils.unsafeCast(get(path, List.class));
        if (list == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList(list.size());
        for (Z object : list) {
            arrayList.add(converter.apply(object));
        }
        return arrayList;
    }

    default List<String> getStringList(String path) {
        return getList(path, (v0) -> {
            return v0.toString();
        });
    }

    default <T, Z> Map<T, Z> getMap(String path) {
        return (Map) UncheckedUtils.unsafeCast(get(path, Map.class));
    }

    default <T, Z> List<Map<T, Z>> getMapList(String path) {
        return getList(path);
    }

    default MapConfigurationGetter getConfiguration(String path) {
        return new MapConfigurationGetter((Map) UncheckedUtils.unsafeCast(get(path, Map.class)));
    }

    default MapConfigurationGetter getConfigurationSection(String path) {
        return new MapConfigurationGetter((Map) UncheckedUtils.unsafeCast(get(path, LinkedHashMap.class)));
    }

    default <T, Z> Map<T, Z> getSection(String path) {
        return (Map) UncheckedUtils.unsafeCast(get(path, LinkedHashMap.class));
    }

    default UUID getUUID(String path) {
        return (UUID) get(path, UUID.class);
    }

    default Long getLong(String path) {
        return (Long) get(path, Long.class);
    }

    default BigDecimal getBigDecimal(String path) {
        return (BigDecimal) get(path, BigDecimal.class);
    }

    default BigInteger getBigInteger(String path) {
        return (BigInteger) get(path, BigInteger.class);
    }

    default Pattern getPattern(String path) {
        return (Pattern) get(path, Pattern.class);
    }

    default <T extends Enum<T>> T getEnum(String path, Class<T> clazz) {
        return (T) get(path, clazz);
    }
}
