package com.artillexstudios.axquestboard.libs.axapi.dialog;

import com.artillexstudios.axquestboard.libs.axapi.dialog.action.Action;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.runtime.ObjectMethods;
import javax.annotation.Nullable;
import net.kyori.adventure.text.Component;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/dialog/ActionButton.class */
public final class ActionButton extends Record {
    private final Component label;

    @Nullable
    private final Component tooltip;
    private final int width;

    @Nullable
    private final Action action;
    private static transient /* synthetic */ String chkCjARNHd = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public ActionButton(Component label, @Nullable Component tooltip, int width, @Nullable Action action) {
        this.label = label;
        this.tooltip = tooltip;
        this.width = width;
        this.action = action;
    }

    @Override // java.lang.Record
    public final String toString() {
        return (String) ObjectMethods.bootstrap(MethodHandles.lookup(), "toString", MethodType.methodType(String.class, ActionButton.class), ActionButton.class, "label;tooltip;width;action", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/dialog/ActionButton;->label:Lnet/kyori/adventure/text/Component;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/dialog/ActionButton;->tooltip:Lnet/kyori/adventure/text/Component;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/dialog/ActionButton;->width:I", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/dialog/ActionButton;->action:Lcom/artillexstudios/axquestboard/libs/axapi/dialog/action/Action;").dynamicInvoker().invoke(this) /* invoke-custom */;
    }

    @Override // java.lang.Record
    public final int hashCode() {
        return (int) ObjectMethods.bootstrap(MethodHandles.lookup(), "hashCode", MethodType.methodType(Integer.TYPE, ActionButton.class), ActionButton.class, "label;tooltip;width;action", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/dialog/ActionButton;->label:Lnet/kyori/adventure/text/Component;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/dialog/ActionButton;->tooltip:Lnet/kyori/adventure/text/Component;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/dialog/ActionButton;->width:I", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/dialog/ActionButton;->action:Lcom/artillexstudios/axquestboard/libs/axapi/dialog/action/Action;").dynamicInvoker().invoke(this) /* invoke-custom */;
    }

    @Override // java.lang.Record
    public final boolean equals(Object o) {
        return (boolean) ObjectMethods.bootstrap(MethodHandles.lookup(), "equals", MethodType.methodType(Boolean.TYPE, ActionButton.class, Object.class), ActionButton.class, "label;tooltip;width;action", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/dialog/ActionButton;->label:Lnet/kyori/adventure/text/Component;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/dialog/ActionButton;->tooltip:Lnet/kyori/adventure/text/Component;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/dialog/ActionButton;->width:I", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/dialog/ActionButton;->action:Lcom/artillexstudios/axquestboard/libs/axapi/dialog/action/Action;").dynamicInvoker().invoke(this, o) /* invoke-custom */;
    }

    public Component label() {
        return this.label;
    }

    @Nullable
    public Component tooltip() {
        return this.tooltip;
    }

    public int width() {
        return this.width;
    }

    @Nullable
    public Action action() {
        return this.action;
    }
}
