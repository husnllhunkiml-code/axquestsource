package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.FlowStyle;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.Mark;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/nodes/SequenceNode.class */
public class SequenceNode extends CollectionNode<Node> {
    private final List<Node> value;
    private static transient /* synthetic */ String mnSUFDzqjV = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public SequenceNode(Tag tag, boolean z, List<Node> list, FlowStyle flowStyle, Optional<Mark> optional, Optional<Mark> optional2) {
        super(tag, flowStyle, optional, optional2);
        Objects.requireNonNull(list, "value in a Node is required.");
        this.value = list;
        this.resolved = z;
    }

    public SequenceNode(Tag tag, List<Node> list, FlowStyle flowStyle) {
        this(tag, true, list, flowStyle, Optional.empty(), Optional.empty());
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Node
    public NodeType getNodeType() {
        return NodeType.SEQUENCE;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.CollectionNode
    public List<Node> getValue() {
        return this.value;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Node node : getValue()) {
            if (node instanceof CollectionNode) {
                sb.append(System.identityHashCode(node));
            } else {
                sb.append(node.toString());
            }
            sb.append(",");
        }
        if (sb.length() > 0) {
            sb.deleteCharAt(sb.length() - 1);
        }
        return "<" + getClass().getName() + " (tag=" + getTag() + ", value=[" + ((Object) sb) + "])>";
    }
}
