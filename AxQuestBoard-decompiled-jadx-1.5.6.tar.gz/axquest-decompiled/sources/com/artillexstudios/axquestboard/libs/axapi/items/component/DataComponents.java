package com.artillexstudios.axquestboard.libs.axapi.items.component;

import com.artillexstudios.axquestboard.libs.axapi.items.component.type.CustomModelData;
import com.artillexstudios.axquestboard.libs.axapi.items.component.type.DyedColor;
import com.artillexstudios.axquestboard.libs.axapi.items.component.type.ItemEnchantments;
import com.artillexstudios.axquestboard.libs.axapi.items.component.type.ItemLore;
import com.artillexstudios.axquestboard.libs.axapi.items.component.type.ProfileProperties;
import com.artillexstudios.axquestboard.libs.axapi.items.component.type.Rarity;
import com.artillexstudios.axquestboard.libs.axapi.items.component.type.Unbreakable;
import com.artillexstudios.axquestboard.libs.axapi.items.component.type.Unit;
import com.artillexstudios.axquestboard.libs.axapi.items.nbt.CompoundTag;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.potion.PotionType;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/items/component/DataComponents.class */
public class DataComponents {
    private static DataComponentImpl dataComponentImpl;
    private static transient /* synthetic */ String fLmAQpMBAt = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public static DataComponent<CompoundTag> customData() {
        return dataComponentImpl.customData();
    }

    public static DataComponent<Integer> maxStackSize() {
        return dataComponentImpl.maxStackSize();
    }

    public static DataComponent<Integer> maxDamage() {
        return dataComponentImpl.maxDamage();
    }

    public static DataComponent<Integer> damage() {
        return dataComponentImpl.damage();
    }

    public static DataComponent<Unbreakable> unbreakable() {
        return dataComponentImpl.unbreakable();
    }

    public static DataComponent<Component> customName() {
        return dataComponentImpl.customName();
    }

    public static DataComponent<Component> itemName() {
        return dataComponentImpl.itemName();
    }

    public static DataComponent<Key> itemModel() {
        return dataComponentImpl.itemModel();
    }

    public static DataComponent<ItemLore> lore() {
        return dataComponentImpl.lore();
    }

    public static DataComponent<Rarity> rarity() {
        return dataComponentImpl.rarity();
    }

    public static DataComponent<ItemEnchantments> enchantments() {
        return dataComponentImpl.enchantments();
    }

    public static DataComponent<CustomModelData> customModelData() {
        return dataComponentImpl.customModelData();
    }

    public static DataComponent<Unit> hideAdditionalTooltip() {
        return dataComponentImpl.hideAdditionalTooltip();
    }

    public static DataComponent<Unit> hideTooltip() {
        return dataComponentImpl.hideTooltip();
    }

    public static DataComponent<Integer> repairCost() {
        return dataComponentImpl.repairCost();
    }

    public static DataComponent<Unit> creativeSlotLock() {
        return dataComponentImpl.creativeSlotLock();
    }

    public static DataComponent<Boolean> enchantmentGlintOverride() {
        return dataComponentImpl.enchantmentGlintOverride();
    }

    public static DataComponent<Unit> intangibleProjectile() {
        return dataComponentImpl.intangibleProjectile();
    }

    public static DataComponent<ItemEnchantments> storedEnchantments() {
        return dataComponentImpl.storedEnchantments();
    }

    public static DataComponent<ProfileProperties> profile() {
        return dataComponentImpl.profile();
    }

    public static DataComponent<Material> material() {
        return dataComponentImpl.material();
    }

    public static DataComponent<DyedColor> dyedColor() {
        return dataComponentImpl.dyedColor();
    }

    public static DataComponent<PotionType> potionType() {
        return dataComponentImpl.potionType();
    }

    public static DataComponent<Key> tooltipStyle() {
        return dataComponentImpl.tooltipStyle();
    }

    public static void setDataComponentImpl(DataComponentImpl dataComponentImpl2) {
        if (dataComponentImpl != null) {
            return;
        }
        dataComponentImpl = dataComponentImpl2;
    }
}
