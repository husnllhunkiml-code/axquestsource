package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions;

import java.util.Objects;
import java.util.Optional;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/exceptions/ComposerException.class */
public class ComposerException extends MarkedYamlEngineException {
    private static transient /* synthetic */ String OWUqaobFzv = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public ComposerException(String str, Optional<Mark> optional, String str2, Optional<Mark> optional2) {
        super(str, optional, str2, optional2);
        Objects.requireNonNull(str);
    }

    public ComposerException(String str, Optional<Mark> optional) {
        super("", Optional.empty(), str, optional);
    }
}
