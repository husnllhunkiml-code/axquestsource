package com.artillexstudios.axquestboard.libs.axapi.gui.inventory.renderer.strategy;

import com.artillexstudios.axquestboard.libs.axapi.context.HashMapContext;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.BakedGuiItem;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.Gui;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import java.util.concurrent.Semaphore;
import org.bukkit.inventory.Inventory;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/gui/inventory/renderer/strategy/RenderStrategy.class */
public interface RenderStrategy {
    void render(Gui gui, HashMapContext context, boolean newInventory, Int2ObjectMap<BakedGuiItem> items, Inventory inventory, Semaphore lock);
}
