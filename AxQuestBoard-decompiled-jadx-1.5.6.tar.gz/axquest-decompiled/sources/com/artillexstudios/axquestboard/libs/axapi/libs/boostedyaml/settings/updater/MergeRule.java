package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.updater;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/settings/updater/MergeRule.class */
public enum MergeRule {
    SECTION_AT_MAPPING,
    MAPPING_AT_SECTION,
    MAPPINGS;

    public static MergeRule getFor(boolean z, boolean z2) {
        if (!z) {
            return z2 ? MAPPING_AT_SECTION : MAPPINGS;
        }
        if (z2) {
            return null;
        }
        return SECTION_AT_MAPPING;
    }
}
