package com.artillexstudios.axquestboard.libs.axapi.items.component.type;

import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.runtime.ObjectMethods;
import org.bukkit.Color;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/items/component/type/DyedColor.class */
public final class DyedColor extends Record {
    private final Color color;
    private final boolean showInTooltip;
    private static transient /* synthetic */ String QnPRdxbVRT = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public DyedColor(Color color, boolean showInTooltip) {
        this.color = color;
        this.showInTooltip = showInTooltip;
    }

    @Override // java.lang.Record
    public final String toString() {
        return (String) ObjectMethods.bootstrap(MethodHandles.lookup(), "toString", MethodType.methodType(String.class, DyedColor.class), DyedColor.class, "color;showInTooltip", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/items/component/type/DyedColor;->color:Lorg/bukkit/Color;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/items/component/type/DyedColor;->showInTooltip:Z").dynamicInvoker().invoke(this) /* invoke-custom */;
    }

    @Override // java.lang.Record
    public final int hashCode() {
        return (int) ObjectMethods.bootstrap(MethodHandles.lookup(), "hashCode", MethodType.methodType(Integer.TYPE, DyedColor.class), DyedColor.class, "color;showInTooltip", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/items/component/type/DyedColor;->color:Lorg/bukkit/Color;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/items/component/type/DyedColor;->showInTooltip:Z").dynamicInvoker().invoke(this) /* invoke-custom */;
    }

    @Override // java.lang.Record
    public final boolean equals(Object o) {
        return (boolean) ObjectMethods.bootstrap(MethodHandles.lookup(), "equals", MethodType.methodType(Boolean.TYPE, DyedColor.class, Object.class), DyedColor.class, "color;showInTooltip", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/items/component/type/DyedColor;->color:Lorg/bukkit/Color;", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/items/component/type/DyedColor;->showInTooltip:Z").dynamicInvoker().invoke(this, o) /* invoke-custom */;
    }

    public Color color() {
        return this.color;
    }

    public boolean showInTooltip() {
        return this.showInTooltip;
    }

    public int rgb() {
        return this.color.asRGB();
    }
}
