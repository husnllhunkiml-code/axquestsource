package com.artillexstudios.axquestboard.libs.axapi.database;

import java.sql.ResultSet;
import java.sql.SQLException;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/database/ResultHandler.class */
public interface ResultHandler<T> {
    T handle(ResultSet resultSet, boolean checkNext) throws SQLException;

    default T handle(ResultSet resultSet) throws SQLException {
        return handle(resultSet, true);
    }
}
