package com.artillexstudios.axquestboard.libs.axapi.libs.hikari;

import java.sql.SQLException;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/hikari/SQLExceptionOverride.class */
public interface SQLExceptionOverride {

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/hikari/SQLExceptionOverride$Override.class */
    public enum Override {
        CONTINUE_EVICT,
        DO_NOT_EVICT,
        MUST_EVICT
    }

    default Override adjudicate(SQLException sqlException) {
        return Override.CONTINUE_EVICT;
    }
}
