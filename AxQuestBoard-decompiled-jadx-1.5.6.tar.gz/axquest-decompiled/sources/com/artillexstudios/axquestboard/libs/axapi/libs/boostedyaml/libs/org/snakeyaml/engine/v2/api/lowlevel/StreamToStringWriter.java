package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.lowlevel;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.StreamDataWriter;
import java.io.StringWriter;

/* JADX INFO: compiled from: Present.java */
/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/api/lowlevel/StreamToStringWriter.class */
class StreamToStringWriter extends StringWriter implements StreamDataWriter {
    private static transient /* synthetic */ String xBLymdfafT = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    StreamToStringWriter() {
    }
}
