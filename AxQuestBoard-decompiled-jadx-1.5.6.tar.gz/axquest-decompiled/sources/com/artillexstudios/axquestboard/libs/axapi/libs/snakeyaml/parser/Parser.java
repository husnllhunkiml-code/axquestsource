package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.parser;

import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.events.Event;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/parser/Parser.class */
public interface Parser {
    boolean checkEvent(Event.ID id);

    Event peekEvent();

    Event getEvent();
}
