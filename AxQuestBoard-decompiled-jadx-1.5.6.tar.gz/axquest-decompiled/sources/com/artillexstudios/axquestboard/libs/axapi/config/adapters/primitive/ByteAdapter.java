package com.artillexstudios.axquestboard.libs.axapi.config.adapters.primitive;

import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapterHolder;
import java.lang.reflect.Type;
import java.math.BigInteger;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/adapters/primitive/ByteAdapter.class */
public final class ByteAdapter implements TypeAdapter<Byte, Byte> {
    private static transient /* synthetic */ String TaOITxDMLL = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public Byte deserialize(TypeAdapterHolder registry, Object input, Type type) {
        if (input instanceof Number) {
            return validate((Number) input);
        }
        if (input instanceof String) {
            return validate(Double.valueOf(Double.parseDouble((String) input)));
        }
        throw new IllegalArgumentException("Can't make a byte from a " + String.valueOf(input.getClass()));
    }

    private Byte validate(Number number) {
        long jLongValueExact = number instanceof BigInteger ? ((BigInteger) number).longValueExact() : number.longValue();
        if (jLongValueExact > 127 || jLongValueExact < -128) {
            throw new IllegalArgumentException("Byte value is not actually a byte! Should be between %s and %s, but was %s".formatted((byte) -128, (byte) 127, Long.valueOf(jLongValueExact)));
        }
        return Byte.valueOf((byte) jLongValueExact);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public Byte serialize(TypeAdapterHolder registry, Byte value, Type type) {
        return value;
    }
}
