package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions;

import java.util.Optional;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/exceptions/ParserException.class */
public class ParserException extends MarkedYamlEngineException {
    private static transient /* synthetic */ String wwXncWOWeE = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public ParserException(String str, Optional<Mark> optional, String str2, Optional<Mark> optional2) {
        super(str, optional, str2, optional2, null);
    }

    public ParserException(String str, Optional<Mark> optional) {
        super(null, Optional.empty(), str, optional, null);
    }
}
