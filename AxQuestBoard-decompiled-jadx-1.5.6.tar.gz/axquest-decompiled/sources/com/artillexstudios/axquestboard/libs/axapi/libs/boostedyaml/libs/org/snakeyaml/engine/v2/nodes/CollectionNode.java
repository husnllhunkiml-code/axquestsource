package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.FlowStyle;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.Mark;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/nodes/CollectionNode.class */
public abstract class CollectionNode<T> extends Node {
    private FlowStyle flowStyle;

    public abstract List<T> getValue();

    public CollectionNode(Tag tag, FlowStyle flowStyle, Optional<Mark> optional, Optional<Mark> optional2) {
        super(tag, optional, optional2);
        setFlowStyle(flowStyle);
    }

    public FlowStyle getFlowStyle() {
        return this.flowStyle;
    }

    public void setFlowStyle(FlowStyle flowStyle) {
        Objects.requireNonNull(flowStyle, "Flow style must be provided.");
        this.flowStyle = flowStyle;
    }

    public void setEndMark(Optional<Mark> optional) {
        this.endMark = optional;
    }
}
