package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.route.implementation;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.route.Route;
import java.util.Arrays;
import java.util.Objects;
import org.jetbrains.annotations.NotNull;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/route/implementation/MultiKeyRoute.class */
public class MultiKeyRoute implements Route {
    private final Object[] route;
    private static transient /* synthetic */ String FilwHnwMoA = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public MultiKeyRoute(@NotNull Object... objArr) {
        if (((Object[]) Objects.requireNonNull(objArr, "Route array cannot be null!")).length == 0) {
            throw new IllegalArgumentException("Empty routes are not allowed!");
        }
        for (Object obj : objArr) {
            Objects.requireNonNull(obj, "Route cannot contain null keys!");
        }
        this.route = objArr;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.route.Route
    @NotNull
    public String join(char c) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length(); i++) {
            sb.append(get(i)).append(i + 1 < length() ? Character.valueOf(c) : "");
        }
        return sb.toString();
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.route.Route
    public int length() {
        return this.route.length;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.route.Route
    @NotNull
    public Object get(int i) {
        return this.route[i];
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.route.Route
    @NotNull
    public Route add(@NotNull Object obj) {
        Object[] objArrCopyOf = Arrays.copyOf(this.route, this.route.length + 1);
        objArrCopyOf[objArrCopyOf.length - 1] = Objects.requireNonNull(obj, "Route cannot contain null keys!");
        return new MultiKeyRoute(objArrCopyOf);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.route.Route
    @NotNull
    public Route parent() {
        return this.route.length == 2 ? Route.from(this.route[0]) : Route.from(Arrays.copyOf(this.route, this.route.length - 1));
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.route.Route
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Route)) {
            return false;
        }
        Route route = (Route) obj;
        if (length() != route.length()) {
            return false;
        }
        if (length() == 1 && route.length() == 1) {
            return Objects.equals(get(0), route.get(0));
        }
        if (route instanceof MultiKeyRoute) {
            return Arrays.equals(this.route, ((MultiKeyRoute) route).route);
        }
        return false;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.route.Route
    public int hashCode() {
        return length() > 1 ? Arrays.hashCode(this.route) : Objects.hashCode(this.route[0]);
    }

    public String toString() {
        return "MultiKeyRoute{route=" + Arrays.toString(this.route) + '}';
    }
}
