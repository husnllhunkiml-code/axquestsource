package com.artillexstudios.axquestboard.libs.axapi.libs.hikari.metrics.dropwizard;

import com.artillexstudios.axquestboard.libs.axapi.libs.hikari.metrics.IMetricsTracker;
import com.artillexstudios.axquestboard.libs.axapi.libs.hikari.metrics.MetricsTrackerFactory;
import com.artillexstudios.axquestboard.libs.axapi.libs.hikari.metrics.PoolStats;
import com.codahale.metrics.MetricRegistry;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/hikari/metrics/dropwizard/CodahaleMetricsTrackerFactory.class */
public final class CodahaleMetricsTrackerFactory implements MetricsTrackerFactory {
    private final MetricRegistry registry;
    private static transient /* synthetic */ String oiLTBZqNTZ = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public CodahaleMetricsTrackerFactory(MetricRegistry metricRegistry) {
        this.registry = metricRegistry;
    }

    public MetricRegistry getRegistry() {
        return this.registry;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.hikari.metrics.MetricsTrackerFactory
    public IMetricsTracker create(String str, PoolStats poolStats) {
        return new CodaHaleMetricsTracker(str, poolStats, this.registry);
    }
}
