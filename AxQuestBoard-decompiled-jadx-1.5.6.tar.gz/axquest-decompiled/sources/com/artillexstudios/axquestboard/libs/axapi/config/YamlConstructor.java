package com.artillexstudios.axquestboard.libs.axapi.config;

import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.LoaderOptions;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.constructor.SafeConstructor;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.nodes.MappingNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.nodes.Node;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/YamlConstructor.class */
public class YamlConstructor extends SafeConstructor {
    private static transient /* synthetic */ String ivKFasBKvq = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public YamlConstructor(LoaderOptions loaderOptions) {
        super(loaderOptions);
    }

    public void flatten(MappingNode node) {
        flattenMapping(node);
    }

    public Object construct(Node node) {
        return constructObject(node);
    }
}
