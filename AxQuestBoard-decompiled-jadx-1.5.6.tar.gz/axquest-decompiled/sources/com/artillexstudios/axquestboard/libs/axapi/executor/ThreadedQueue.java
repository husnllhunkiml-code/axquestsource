package com.artillexstudios.axquestboard.libs.axapi.executor;

import com.google.common.collect.Queues;
import java.lang.Runnable;
import java.util.Queue;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/executor/ThreadedQueue.class */
public class ThreadedQueue<T extends Runnable> implements Runnable {
    private static final Logger log = LoggerFactory.getLogger(ThreadedQueue.class);
    private final Thread thread;
    private static transient /* synthetic */ String VUioCfZeFh = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";
    private final Queue<T> jobs = Queues.newArrayDeque();
    private final ReentrantLock lock = new ReentrantLock();
    private final Condition condition = this.lock.newCondition();
    private volatile boolean killed = false;

    public ThreadedQueue(String threadName) {
        this.thread = new Thread(this, threadName);
        this.thread.start();
    }

    public void stop() {
        this.killed = true;
        this.lock.lock();
        try {
            this.condition.signalAll();
        } finally {
            this.lock.unlock();
        }
    }

    public void submit(T task) {
        this.lock.lock();
        try {
            this.jobs.offer(task);
            this.condition.signalAll();
        } finally {
            this.lock.unlock();
        }
    }

    @Override // java.lang.Runnable
    public void run() {
        while (!this.killed) {
            try {
                Runnable next = next();
                if (next != null) {
                    next.run();
                }
            } catch (Exception e) {
                log.error("An unexpected error occurred while running ThreadedQueue {}!", this.thread.getName(), e);
            }
        }
    }

    public T next() {
        this.lock.lock();
        while (this.jobs.isEmpty() && !this.killed) {
            try {
                this.condition.await();
            } catch (Throwable th) {
                this.lock.unlock();
                throw th;
            }
        }
        if (!this.jobs.isEmpty()) {
            T tRemove = this.jobs.remove();
            this.lock.unlock();
            return tRemove;
        }
        this.lock.unlock();
        return null;
    }
}
