package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.dvs;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.dvs.segment.Segment;
import java.util.Arrays;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/dvs/Pattern.class */
public class Pattern {
    private final Segment[] segments;
    private static transient /* synthetic */ String jQXrVJacch = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public Pattern(@NotNull Segment... segmentArr) {
        this.segments = segmentArr;
    }

    @Deprecated
    @NotNull
    public Segment getPart(int i) {
        return this.segments[i];
    }

    @NotNull
    public Segment getSegment(int i) {
        return this.segments[i];
    }

    @Nullable
    public Version getVersion(@NotNull String str) {
        int[] iArr = new int[this.segments.length];
        int elementLength = 0;
        for (int i = 0; i < this.segments.length; i++) {
            int i2 = this.segments[i].parse(str, elementLength);
            if (i2 == -1) {
                return null;
            }
            iArr[i] = i2;
            elementLength += this.segments[i].getElementLength(i2);
        }
        return new Version(str, this, iArr);
    }

    public Version getFirstVersion() {
        return new Version(null, this, new int[this.segments.length]);
    }

    public String toString() {
        return "Pattern{segments=" + Arrays.toString(this.segments) + '}';
    }
}
