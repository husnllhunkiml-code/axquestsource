package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.composer;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.LoadSettings;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.comments.CommentEventsCollector;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.comments.CommentLine;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.comments.CommentType;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.Anchor;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.FlowStyle;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.AliasEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.Event;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.MappingStartEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.NodeEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.ScalarEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.SequenceStartEvent;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.ComposerException;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.Mark;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.YamlEngineException;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.MappingNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Node;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.NodeTuple;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.NodeType;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.ScalarNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.SequenceNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Tag;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.parser.Parser;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.resolver.ScalarResolver;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import net.kyori.adventure.text.minimessage.tag.standard.DecorationTag;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/composer/Composer.class */
public class Composer implements Iterator<Node> {
    protected final Parser parser;
    private final ScalarResolver scalarResolver;
    private final Map<Anchor, Node> anchors;
    private final Set<Node> recursiveNodes;
    private final LoadSettings settings;
    private final CommentEventsCollector blockCommentsCollector;
    private final CommentEventsCollector inlineCommentsCollector;
    private int nonScalarAliasesCount;
    private static transient /* synthetic */ String iaMrMtdcfU = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    @Deprecated
    public Composer(Parser parser, LoadSettings loadSettings) {
        this(loadSettings, parser);
    }

    public Composer(LoadSettings loadSettings, Parser parser) {
        this.nonScalarAliasesCount = 0;
        this.parser = parser;
        this.scalarResolver = loadSettings.getSchema().getScalarResolver();
        this.settings = loadSettings;
        this.anchors = new HashMap();
        this.recursiveNodes = new HashSet();
        this.blockCommentsCollector = new CommentEventsCollector(parser, CommentType.BLANK_LINE, CommentType.BLOCK);
        this.inlineCommentsCollector = new CommentEventsCollector(parser, CommentType.IN_LINE);
    }

    @Override // java.util.Iterator
    public boolean hasNext() {
        if (this.parser.checkEvent(Event.ID.StreamStart)) {
            this.parser.next();
        }
        return !this.parser.checkEvent(Event.ID.StreamEnd);
    }

    public Optional<Node> getSingleNode() {
        this.parser.next();
        Optional<Node> optionalEmpty = Optional.empty();
        if (!this.parser.checkEvent(Event.ID.StreamEnd)) {
            optionalEmpty = Optional.of(next());
        }
        if (!this.parser.checkEvent(Event.ID.StreamEnd)) {
            throw new ComposerException("expected a single document in the stream", optionalEmpty.flatMap((v0) -> {
                return v0.getStartMark();
            }), "but found another document", this.parser.next().getStartMark());
        }
        this.parser.next();
        return optionalEmpty;
    }

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // java.util.Iterator
    public Node next() {
        this.blockCommentsCollector.collectEvents();
        if (this.parser.checkEvent(Event.ID.StreamEnd)) {
            List<CommentLine> listConsume = this.blockCommentsCollector.consume();
            Optional<Mark> startMark = listConsume.get(0).getStartMark();
            MappingNode mappingNode = new MappingNode(Tag.COMMENT, false, Collections.emptyList(), FlowStyle.BLOCK, startMark, Optional.empty());
            mappingNode.setBlockComments(listConsume);
            return mappingNode;
        }
        this.parser.next();
        Node nodeComposeNode = composeNode(Optional.empty());
        this.blockCommentsCollector.collectEvents();
        if (!this.blockCommentsCollector.isEmpty()) {
            nodeComposeNode.setEndComments(this.blockCommentsCollector.consume());
        }
        this.parser.next();
        this.anchors.clear();
        this.recursiveNodes.clear();
        this.nonScalarAliasesCount = 0;
        return nodeComposeNode;
    }

    private Node composeNode(Optional<Node> optional) {
        Node nodeComposeMappingNode;
        this.blockCommentsCollector.collectEvents();
        Set<Node> set = this.recursiveNodes;
        Objects.requireNonNull(set);
        optional.ifPresent((v1) -> {
            r1.add(v1);
        });
        if (this.parser.checkEvent(Event.ID.Alias)) {
            AliasEvent aliasEvent = (AliasEvent) this.parser.next();
            Anchor alias = aliasEvent.getAlias();
            if (!this.anchors.containsKey(alias)) {
                throw new ComposerException("found undefined alias " + alias, aliasEvent.getStartMark());
            }
            nodeComposeMappingNode = this.anchors.get(alias);
            if (nodeComposeMappingNode.getNodeType() != NodeType.SCALAR) {
                this.nonScalarAliasesCount++;
                if (this.nonScalarAliasesCount > this.settings.getMaxAliasesForCollections()) {
                    throw new YamlEngineException("Number of aliases for non-scalar nodes exceeds the specified max=" + this.settings.getMaxAliasesForCollections());
                }
            }
            if (this.recursiveNodes.remove(nodeComposeMappingNode)) {
                nodeComposeMappingNode.setRecursive(true);
            }
            this.blockCommentsCollector.consume();
            this.inlineCommentsCollector.collectEvents().consume();
        } else {
            Optional<Anchor> anchor = ((NodeEvent) this.parser.peekEvent()).getAnchor();
            if (this.parser.checkEvent(Event.ID.Scalar)) {
                nodeComposeMappingNode = composeScalarNode(anchor, this.blockCommentsCollector.consume());
            } else if (this.parser.checkEvent(Event.ID.SequenceStart)) {
                nodeComposeMappingNode = composeSequenceNode(anchor);
            } else {
                nodeComposeMappingNode = composeMappingNode(anchor);
            }
        }
        Set<Node> set2 = this.recursiveNodes;
        Objects.requireNonNull(set2);
        optional.ifPresent((v1) -> {
            r1.remove(v1);
        });
        return nodeComposeMappingNode;
    }

    private void registerAnchor(Anchor anchor, Node node) {
        this.anchors.put(anchor, node);
        node.setAnchor(Optional.of(anchor));
    }

    protected Node composeScalarNode(Optional<Anchor> optional, List<CommentLine> list) {
        Tag tagResolve;
        ScalarEvent scalarEvent = (ScalarEvent) this.parser.next();
        Optional<String> tag = scalarEvent.getTag();
        boolean z = false;
        if (!tag.isPresent() || tag.get().equals(DecorationTag.REVERT)) {
            tagResolve = this.scalarResolver.resolve(scalarEvent.getValue(), Boolean.valueOf(scalarEvent.getImplicit().canOmitTagInPlainScalar()));
            z = true;
        } else {
            tagResolve = new Tag(tag.get());
        }
        ScalarNode scalarNode = new ScalarNode(tagResolve, z, scalarEvent.getValue(), scalarEvent.getScalarStyle(), scalarEvent.getStartMark(), scalarEvent.getEndMark());
        optional.ifPresent(anchor -> {
            registerAnchor(anchor, scalarNode);
        });
        scalarNode.setBlockComments(list);
        scalarNode.setInLineComments(this.inlineCommentsCollector.collectEvents().consume());
        return scalarNode;
    }

    protected SequenceNode composeSequenceNode(Optional<Anchor> optional) {
        Tag tag;
        SequenceStartEvent sequenceStartEvent = (SequenceStartEvent) this.parser.next();
        Optional<String> tag2 = sequenceStartEvent.getTag();
        boolean z = false;
        if (!tag2.isPresent() || tag2.get().equals(DecorationTag.REVERT)) {
            tag = Tag.SEQ;
            z = true;
        } else {
            tag = new Tag(tag2.get());
        }
        ArrayList arrayList = new ArrayList();
        SequenceNode sequenceNode = new SequenceNode(tag, z, arrayList, sequenceStartEvent.getFlowStyle(), sequenceStartEvent.getStartMark(), Optional.empty());
        if (sequenceStartEvent.isFlow()) {
            sequenceNode.setBlockComments(this.blockCommentsCollector.consume());
        }
        optional.ifPresent(anchor -> {
            registerAnchor(anchor, sequenceNode);
        });
        while (!this.parser.checkEvent(Event.ID.SequenceEnd)) {
            this.blockCommentsCollector.collectEvents();
            if (this.parser.checkEvent(Event.ID.SequenceEnd)) {
                break;
            }
            arrayList.add(composeNode(Optional.of(sequenceNode)));
        }
        if (sequenceStartEvent.isFlow()) {
            sequenceNode.setInLineComments(this.inlineCommentsCollector.collectEvents().consume());
        }
        sequenceNode.setEndMark(this.parser.next().getEndMark());
        this.inlineCommentsCollector.collectEvents();
        if (!this.inlineCommentsCollector.isEmpty()) {
            sequenceNode.setInLineComments(this.inlineCommentsCollector.consume());
        }
        return sequenceNode;
    }

    protected Node composeMappingNode(Optional<Anchor> optional) {
        Tag tag;
        MappingStartEvent mappingStartEvent = (MappingStartEvent) this.parser.next();
        Optional<String> tag2 = mappingStartEvent.getTag();
        boolean z = false;
        if (!tag2.isPresent() || tag2.get().equals(DecorationTag.REVERT)) {
            tag = Tag.MAP;
            z = true;
        } else {
            tag = new Tag(tag2.get());
        }
        ArrayList arrayList = new ArrayList();
        MappingNode mappingNode = new MappingNode(tag, z, arrayList, mappingStartEvent.getFlowStyle(), mappingStartEvent.getStartMark(), Optional.empty());
        if (mappingStartEvent.isFlow()) {
            mappingNode.setBlockComments(this.blockCommentsCollector.consume());
        }
        optional.ifPresent(anchor -> {
            registerAnchor(anchor, mappingNode);
        });
        while (!this.parser.checkEvent(Event.ID.MappingEnd)) {
            this.blockCommentsCollector.collectEvents();
            if (this.parser.checkEvent(Event.ID.MappingEnd)) {
                break;
            }
            composeMappingChildren(arrayList, mappingNode);
        }
        if (mappingStartEvent.isFlow()) {
            mappingNode.setInLineComments(this.inlineCommentsCollector.collectEvents().consume());
        }
        mappingNode.setEndMark(this.parser.next().getEndMark());
        this.inlineCommentsCollector.collectEvents();
        if (!this.inlineCommentsCollector.isEmpty()) {
            mappingNode.setInLineComments(this.inlineCommentsCollector.consume());
        }
        return mappingNode;
    }

    protected void composeMappingChildren(List<NodeTuple> list, MappingNode mappingNode) {
        list.add(new NodeTuple(composeKeyNode(mappingNode), composeValueNode(mappingNode)));
    }

    protected Node composeKeyNode(MappingNode mappingNode) {
        return composeNode(Optional.of(mappingNode));
    }

    protected Node composeValueNode(MappingNode mappingNode) {
        return composeNode(Optional.of(mappingNode));
    }
}
