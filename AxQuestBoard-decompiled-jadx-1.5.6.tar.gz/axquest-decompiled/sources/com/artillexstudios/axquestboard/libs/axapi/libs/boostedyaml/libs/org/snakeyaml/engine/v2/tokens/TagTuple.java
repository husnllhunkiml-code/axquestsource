package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens;

import java.util.Objects;
import java.util.Optional;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/tokens/TagTuple.class */
public final class TagTuple {
    private final Optional<String> handle;
    private final String suffix;
    private static transient /* synthetic */ String PdZaHScbif = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public TagTuple(Optional<String> optional, String str) {
        Objects.requireNonNull(optional);
        this.handle = optional;
        Objects.requireNonNull(str);
        this.suffix = str;
    }

    public Optional<String> getHandle() {
        return this.handle;
    }

    public String getSuffix() {
        return this.suffix;
    }
}
