package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.events;

import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.DumperOptions;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.error.Mark;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/events/SequenceStartEvent.class */
public final class SequenceStartEvent extends CollectionStartEvent {
    private static transient /* synthetic */ String JAbZNZcsIA = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public SequenceStartEvent(String str, String str2, boolean z, Mark mark, Mark mark2, DumperOptions.FlowStyle flowStyle) {
        super(str, str2, z, mark, mark2, flowStyle);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.events.Event
    public Event.ID getEventId() {
        return Event.ID.SequenceStart;
    }
}
