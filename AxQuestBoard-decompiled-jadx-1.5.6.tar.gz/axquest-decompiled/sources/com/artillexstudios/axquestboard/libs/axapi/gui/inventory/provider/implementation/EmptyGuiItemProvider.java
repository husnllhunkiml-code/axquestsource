package com.artillexstudios.axquestboard.libs.axapi.gui.inventory.provider.implementation;

import com.artillexstudios.axquestboard.libs.axapi.context.HashMapContext;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.BakedGuiItem;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.modifier.WrappedItemStackModifier;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.provider.GuiItemProvider;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/gui/inventory/provider/implementation/EmptyGuiItemProvider.class */
public class EmptyGuiItemProvider implements GuiItemProvider {
    public static final EmptyGuiItemProvider INSTANCE = new EmptyGuiItemProvider();
    private static final BakedGuiItem EMPTY_ITEM = new BakedGuiItem(new ItemStack(Material.AIR), inventoryClickEvent -> {
    });
    private static final CompletableFuture<BakedGuiItem> FUTURE = CompletableFuture.completedFuture(EMPTY_ITEM);
    private static transient /* synthetic */ String BnWLzWaeJa = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    @Override // com.artillexstudios.axquestboard.libs.axapi.gui.inventory.provider.GuiItemProvider
    public CompletableFuture<BakedGuiItem> provide(HashMapContext context, List<WrappedItemStackModifier> modifiers) {
        return FUTURE;
    }
}
