package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.Mark;
import java.util.Optional;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/tokens/FlowSequenceEndToken.class */
public final class FlowSequenceEndToken extends Token {
    private static transient /* synthetic */ String lLUCuuxBlH = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public FlowSequenceEndToken(Optional<Mark> optional, Optional<Mark> optional2) {
        super(optional, optional2);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.Token
    public Token.ID getTokenId() {
        return Token.ID.FlowSequenceEnd;
    }
}
