package com.artillexstudios.axquestboard.libs.axapi.gui.inventory.implementation;

import com.artillexstudios.axquestboard.libs.axapi.context.HashMapContext;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.Gui;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.GuiItem;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.modifier.WrappedItemStackModifier;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.provider.GuiItemProvider;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.provider.implementation.EmptyGuiItemProvider;
import com.artillexstudios.axquestboard.libs.axapi.reflection.ClassUtils;
import com.artillexstudios.axquestboard.libs.axapi.utils.logging.LogUtils;
import com.artillexstudios.axquestboard.libs.axapi.utils.mutable.MutableInteger;
import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Supplier;
import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryType;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/gui/inventory/implementation/PaginatedGui.class */
public class PaginatedGui extends Gui {
    private final HashMap<Class<?>, Function<?, GuiItemProvider>> customProviders;
    private final List<GuiItemProvider> otherProviders;
    private int page;
    private int pageSize;
    private Supplier<List<?>> itemsProvider;
    private static transient /* synthetic */ String zLwIViCnAR = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public PaginatedGui(Player player, Function<HashMapContext, Component> titleProvider, InventoryType type, int rows, HashMap<Class<?>, Function<?, GuiItemProvider>> providers, HashMapContext context, List<WrappedItemStackModifier> modifiers) {
        super(player, titleProvider, type, rows, context, modifiers);
        this.otherProviders = new ArrayList();
        this.page = 0;
        this.pageSize = this.size;
        this.customProviders = providers;
    }

    public <T> void addItem(T item) {
        this.otherProviders.add(provide(item).apply(item));
    }

    public <T> void setItems(List<T> items, boolean same) {
        this.otherProviders.clear();
        if (!same) {
            Iterator<T> it = items.iterator();
            while (it.hasNext()) {
                addItem(it.next());
            }
            return;
        }
        Function<Object, GuiItemProvider> functionProvide = null;
        for (T t : items) {
            if (functionProvide == null) {
                functionProvide = provide(t);
            }
            this.otherProviders.add(functionProvide.apply(t));
        }
    }

    public <T> void setItems(List<T> items) {
        setItems(items, false);
    }

    public void setItemsProvider(Supplier<List<?>> itemsProvider) {
        this.itemsProvider = itemsProvider;
    }

    private Function<Object, GuiItemProvider> provide(Object item) {
        Class<?> cls = item.getClass();
        Function<?, GuiItemProvider> function = this.customProviders.get(cls);
        if (function != null) {
            return function;
        }
        Iterator<Class<?>> it = ClassUtils.INSTANCE.superClasses(cls).iterator();
        while (it.hasNext()) {
            Function<?, GuiItemProvider> function2 = this.customProviders.get(it.next());
            if (function2 != null) {
                return function2;
            }
        }
        for (Class<?> cls2 : ClassUtils.INSTANCE.interfaces(cls)) {
            Function<?, GuiItemProvider> function3 = this.customProviders.get(cls2);
            if (function3 != null) {
                return function3;
            }
        }
        throw new IllegalStateException("No custom provider for class " + String.valueOf(item.getClass()) + "!");
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.gui.inventory.Gui
    public void setItem(int slot, GuiItemProvider provider) {
        super.setItem(slot, provider);
        recalculatePageSize();
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.gui.inventory.Gui
    public void setItem(int slot, GuiItem item, Function<GuiItem, GuiItemProvider> provider) {
        super.setItem(slot, item, provider);
        recalculatePageSize();
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.gui.inventory.Gui
    public void setItem(int slot, GuiItem item) {
        super.setItem(slot, item);
        recalculatePageSize();
    }

    private void recalculatePageSize() {
        MutableInteger mutableInteger = new MutableInteger();
        this.providers.forEach((num, guiItemProvider) -> {
            if (guiItemProvider instanceof EmptyGuiItemProvider) {
                mutableInteger.increment();
            }
        });
        this.pageSize = mutableInteger.get().intValue();
    }

    public int page() {
        return this.page;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.gui.inventory.Gui
    public void open() {
        if (this.itemsProvider != null) {
            setItems(this.itemsProvider.get(), true);
        }
        if (this.page >= maxPages()) {
            this.page = maxPages() - 1;
        }
        super.open();
    }

    public void page(int page) {
        if (page >= maxPages()) {
            throw new IllegalStateException("Max pages: " + maxPages());
        }
        if (page < 0) {
            throw new IllegalStateException("Min page is 0!");
        }
        this.page = page;
    }

    public int maxPages() {
        int size = this.otherProviders.size();
        if (size == 0) {
            return 1;
        }
        return Math.ceilDiv(size, this.pageSize);
    }

    public boolean hasNextPage() {
        return this.page + 1 < maxPages();
    }

    public boolean hasPreviousPage() {
        return this.page > 0;
    }

    public boolean hasPage(int page) {
        return page < maxPages() && page >= 0;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.gui.inventory.Gui
    public Int2ObjectArrayMap<GuiItemProvider> getProviders() {
        if (this.pageSize == 0 && !this.otherProviders.isEmpty()) {
            LogUtils.warn("This paginated gui has no empty slots for the provided items!", new Object[0]);
            LogUtils.warn("Please create some empty slots for them!", new Object[0]);
            return super.getProviders();
        }
        int i = this.page * this.pageSize;
        Int2ObjectArrayMap<GuiItemProvider> int2ObjectArrayMapClone = super.getProviders().clone();
        ObjectIterator it = int2ObjectArrayMapClone.int2ObjectEntrySet().iterator();
        while (it.hasNext()) {
            Int2ObjectMap.Entry entry = (Int2ObjectMap.Entry) it.next();
            if (entry.getValue() instanceof EmptyGuiItemProvider) {
                if (i >= this.otherProviders.size()) {
                    break;
                }
                entry.setValue(this.otherProviders.get(i));
                i++;
            }
        }
        return int2ObjectArrayMapClone;
    }
}
