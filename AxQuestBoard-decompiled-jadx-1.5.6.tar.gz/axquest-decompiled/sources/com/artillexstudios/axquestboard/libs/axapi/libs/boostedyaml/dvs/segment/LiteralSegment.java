package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.dvs.segment;

import java.util.Arrays;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/dvs/segment/LiteralSegment.class */
public class LiteralSegment implements Segment {
    private final String[] elements;
    private static transient /* synthetic */ String XuClEHqQMo = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public LiteralSegment(String... strArr) {
        this.elements = strArr;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.dvs.segment.Segment
    public int parse(String str, int i) {
        for (int i2 = 0; i2 < this.elements.length; i2++) {
            if (str.startsWith(this.elements[i2], i)) {
                return i2;
            }
        }
        return -1;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.dvs.segment.Segment
    public String getElement(int i) {
        return this.elements[i];
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.dvs.segment.Segment
    public int getElementLength(int i) {
        return this.elements[i].length();
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.dvs.segment.Segment
    public int length() {
        return this.elements.length;
    }

    public String toString() {
        return "LiteralSegment{elements=" + Arrays.toString(this.elements) + '}';
    }
}
