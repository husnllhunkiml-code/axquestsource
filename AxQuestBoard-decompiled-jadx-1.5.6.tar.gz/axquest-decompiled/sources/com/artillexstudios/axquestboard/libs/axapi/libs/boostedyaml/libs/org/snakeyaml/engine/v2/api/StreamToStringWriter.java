package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api;

import java.io.StringWriter;

/* JADX INFO: compiled from: Dump.java */
/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/api/StreamToStringWriter.class */
class StreamToStringWriter extends StringWriter implements StreamDataWriter {
    private static transient /* synthetic */ String QBOOnIRIxA = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    StreamToStringWriter() {
    }
}
