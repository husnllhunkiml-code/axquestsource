package com.artillexstudios.axquestboard.libs.axapi.config.adapters.primitive;

import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapterHolder;
import java.lang.reflect.Type;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/adapters/primitive/BooleanAdapter.class */
public final class BooleanAdapter implements TypeAdapter<Boolean, Boolean> {
    private static transient /* synthetic */ String pGNPAXQpqa = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public Boolean deserialize(TypeAdapterHolder registry, Object input, Type type) {
        if (input instanceof Boolean) {
            return (Boolean) input;
        }
        if (input instanceof String) {
            String str = (String) input;
            if (str.equalsIgnoreCase("true") || str.equalsIgnoreCase("on") || str.equalsIgnoreCase("enabled")) {
                return Boolean.TRUE;
            }
            if (str.equalsIgnoreCase("false") || str.equalsIgnoreCase("off") || str.equalsIgnoreCase("disabled")) {
                return Boolean.FALSE;
            }
            throw new IllegalArgumentException("Not a boolean type: " + str);
        }
        throw new IllegalArgumentException("Not a boolean type: " + String.valueOf(input.getClass()));
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public Boolean serialize(TypeAdapterHolder registry, Boolean value, Type type) {
        return value;
    }
}
