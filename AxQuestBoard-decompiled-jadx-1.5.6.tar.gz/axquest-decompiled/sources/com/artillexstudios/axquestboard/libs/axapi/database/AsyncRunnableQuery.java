package com.artillexstudios.axquestboard.libs.axapi.database;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.function.Supplier;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/database/AsyncRunnableQuery.class */
public class AsyncRunnableQuery<T> {
    private final Supplier<Executor> executorSupplier;
    private final RunnableQuery<T> query;
    private static transient /* synthetic */ String fiMOMrgNrw = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public AsyncRunnableQuery(Supplier<Executor> executorSupplier, RunnableQuery<T> query) {
        this.executorSupplier = executorSupplier;
        this.query = query;
    }

    public CompletableFuture<Integer> update(Object... parameters) {
        return CompletableFuture.supplyAsync(() -> {
            return Integer.valueOf(this.query.update(parameters));
        }, this.executorSupplier.get());
    }

    public CompletableFuture<T> execute(Object... parameters) {
        return CompletableFuture.supplyAsync(() -> {
            return this.query.execute(parameters);
        }, this.executorSupplier.get());
    }

    public CompletableFuture<T> query(Object... parameters) {
        return CompletableFuture.supplyAsync(() -> {
            return this.query.query(parameters);
        }, this.executorSupplier.get());
    }

    public CompletableFuture<int[]> batch(List<Object[]> batch) {
        return CompletableFuture.supplyAsync(() -> {
            return this.query.batch(batch);
        }, this.executorSupplier.get());
    }
}
