package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions;

import java.util.Objects;
import java.util.Optional;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/exceptions/MarkedYamlEngineException.class */
public class MarkedYamlEngineException extends YamlEngineException {
    private final String context;
    private final Optional<Mark> contextMark;
    private final String problem;
    private final Optional<Mark> problemMark;
    private static transient /* synthetic */ String KiKXNbpbJp = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    protected MarkedYamlEngineException(String str, Optional<Mark> optional, String str2, Optional<Mark> optional2, Throwable th) {
        super(str + "; " + str2 + "; " + optional2, th);
        Objects.requireNonNull(optional, "contextMark must be provided");
        Objects.requireNonNull(optional2, "problemMark must be provided");
        this.context = str;
        this.contextMark = optional;
        this.problem = str2;
        this.problemMark = optional2;
    }

    protected MarkedYamlEngineException(String str, Optional<Mark> optional, String str2, Optional<Mark> optional2) {
        this(str, optional, str2, optional2, null);
    }

    @Override // java.lang.Throwable
    public String getMessage() {
        return toString();
    }

    @Override // java.lang.Throwable
    public String toString() {
        StringBuilder sb = new StringBuilder();
        if (this.context != null) {
            sb.append(this.context);
            sb.append("\n");
        }
        if (this.contextMark.isPresent() && (this.problem == null || !this.problemMark.isPresent() || this.contextMark.get().getName().equals(this.problemMark.get().getName()) || this.contextMark.get().getLine() != this.problemMark.get().getLine() || this.contextMark.get().getColumn() != this.problemMark.get().getColumn())) {
            sb.append(this.contextMark.get());
            sb.append("\n");
        }
        if (this.problem != null) {
            sb.append(this.problem);
            sb.append("\n");
        }
        if (this.problemMark.isPresent()) {
            sb.append(this.problemMark.get());
            sb.append("\n");
        }
        return sb.toString();
    }

    public String getContext() {
        return this.context;
    }

    public Optional<Mark> getContextMark() {
        return this.contextMark;
    }

    public String getProblem() {
        return this.problem;
    }

    public Optional<Mark> getProblemMark() {
        return this.problemMark;
    }
}
