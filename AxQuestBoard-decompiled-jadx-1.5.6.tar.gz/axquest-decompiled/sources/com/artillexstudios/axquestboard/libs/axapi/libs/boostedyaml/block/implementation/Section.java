package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.block.implementation;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.YamlDocument;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.block.Block;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.engine.ExtendedConstructor;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.MappingNode;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Node;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.NodeTuple;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.route.Route;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.general.GeneralSettings;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.utils.conversion.ListConversions;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.utils.conversion.PrimitiveConversions;
import java.math.BigInteger;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.BiConsumer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/block/implementation/Section.class */
public class Section extends Block<Map<Object, Block<?>>> {
    private YamlDocument root;
    private Section defaults;
    private Section parent;
    private Object name;
    private Route route;
    private static transient /* synthetic */ String pqZAVWSpwk = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    /* JADX INFO: renamed from: com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.block.implementation.Section$1 */
    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/block/implementation/Section$1.class */
    static /* synthetic */ class C00101 {
        private static transient /* synthetic */ String hPOXBSgxyF = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";
    }

    public Section(@NotNull YamlDocument yamlDocument, @Nullable Section section, @NotNull Route route, @Nullable Node node, @NotNull MappingNode mappingNode, @NotNull ExtendedConstructor extendedConstructor) {
        super(node, mappingNode, yamlDocument.getGeneralSettings().getDefaultMap());
        this.defaults = null;
        this.root = yamlDocument;
        this.parent = section;
        this.name = adaptKey(route.get(route.length() - 1));
        this.route = route;
        resetDefaults();
        init(yamlDocument, node, mappingNode, extendedConstructor);
    }

    public Section(@NotNull YamlDocument yamlDocument, @Nullable Section section, @NotNull Route route, @Nullable Block<?> block, @NotNull Map<?, ?> map) {
        super(block, yamlDocument.getGeneralSettings().getDefaultMap());
        this.defaults = null;
        this.root = yamlDocument;
        this.parent = section;
        this.name = adaptKey(route.get(route.length() - 1));
        this.route = route;
        resetDefaults();
        for (Map.Entry<?, ?> entry : map.entrySet()) {
            Object objAdaptKey = adaptKey(entry.getKey());
            Object value = entry.getValue();
            getStoredValue().put(objAdaptKey, value instanceof Map ? new Section(yamlDocument, this, route.add(objAdaptKey), null, (Map) value) : new TerminatedBlock(null, value));
        }
    }

    protected Section(@NotNull Map<Object, Block<?>> map) {
        super(map);
        this.defaults = null;
        this.root = null;
        this.parent = null;
        this.name = null;
        this.route = null;
        this.defaults = null;
    }

    protected void initEmpty(@NotNull YamlDocument yamlDocument) {
        if (!yamlDocument.isRoot()) {
            throw new IllegalStateException("Cannot init non-root section!");
        }
        super.init(null, null);
        this.root = yamlDocument;
        resetDefaults();
    }

    protected void init(@NotNull YamlDocument yamlDocument, @Nullable Node node, @NotNull MappingNode mappingNode, @NotNull ExtendedConstructor extendedConstructor) {
        Block<?> terminatedBlock;
        if (yamlDocument == this && node != null) {
            throw new IllegalArgumentException("Root sections cannot have a key node!");
        }
        super.init(node, mappingNode);
        this.root = yamlDocument;
        resetDefaults();
        for (NodeTuple nodeTuple : mappingNode.getValue()) {
            Object objAdaptKey = adaptKey(extendedConstructor.getConstructed(nodeTuple.getKeyNode()));
            Object constructed = extendedConstructor.getConstructed(nodeTuple.getValueNode());
            Map<Object, Block<?>> storedValue = getStoredValue();
            if (constructed instanceof Map) {
                terminatedBlock = new Section(yamlDocument, this, getSubRoute(objAdaptKey), nodeTuple.getKeyNode(), (MappingNode) nodeTuple.getValueNode(), extendedConstructor);
            } else {
                terminatedBlock = new TerminatedBlock(nodeTuple.getKeyNode(), nodeTuple.getValueNode(), constructed);
            }
            storedValue.put(objAdaptKey, terminatedBlock);
        }
    }

    public boolean isEmpty(boolean z) {
        if (getStoredValue().isEmpty()) {
            return true;
        }
        if (!z) {
            return false;
        }
        for (Block<?> block : getStoredValue().values()) {
            if (block instanceof TerminatedBlock) {
                return false;
            }
            if ((block instanceof Section) && !((Section) block).isEmpty(true)) {
                return false;
            }
        }
        return true;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.block.Block
    public boolean isSection() {
        return true;
    }

    public boolean isRoot() {
        return false;
    }

    @NotNull
    public YamlDocument getRoot() {
        return this.root;
    }

    public Section getParent() {
        return this.parent;
    }

    @Nullable
    public Object getName() {
        return this.name;
    }

    @Nullable
    public String getNameAsString() {
        if (this.name == null) {
            return null;
        }
        return this.name.toString();
    }

    @NotNull
    public Route getNameAsRoute() {
        return Route.from(this.name);
    }

    @Nullable
    public Route getRoute() {
        return this.route;
    }

    @Nullable
    public String getRouteAsString() {
        if (this.route == null) {
            return null;
        }
        return this.route.join(this.root.getGeneralSettings().getRouteSeparator());
    }

    @NotNull
    public Route getSubRoute(@NotNull Object obj) {
        return Route.addTo(this.route, obj);
    }

    @Nullable
    public Section getDefaults() {
        return this.defaults;
    }

    public boolean hasDefaults() {
        return this.defaults != null;
    }

    private void adapt(@NotNull YamlDocument yamlDocument, @Nullable Section section, @NotNull Route route) {
        if (this.parent != null && this.parent != section && this.parent.getStoredValue().get(this.name) == this) {
            this.parent.removeInternal(this.parent, this.name);
        }
        this.name = route.get(route.length() - 1);
        this.parent = section;
        adapt(yamlDocument, route);
    }

    private void adapt(@NotNull YamlDocument yamlDocument, @NotNull Route route) {
        this.root = yamlDocument;
        this.route = route;
        resetDefaults();
        for (Map.Entry<Object, Block<?>> entry : getStoredValue().entrySet()) {
            if (entry.getValue() instanceof Section) {
                ((Section) entry.getValue()).adapt(yamlDocument, route.add(entry.getKey()));
            }
        }
    }

    @NotNull
    public Object adaptKey(@NotNull Object obj) {
        Objects.requireNonNull(obj, "Sections cannot contain null keys!");
        return this.root.getGeneralSettings().getKeyFormat() == GeneralSettings.KeyFormat.OBJECT ? obj : obj.toString();
    }

    private void resetDefaults() {
        Section section;
        if (isRoot()) {
            section = this.root.getDefaults();
        } else {
            section = (this.parent == null || this.parent.defaults == null) ? null : this.parent.defaults.getSection(Route.fromSingleKey(this.name), (Section) null);
        }
        this.defaults = section;
    }

    private boolean canUseDefaults() {
        return hasDefaults() && this.root.getGeneralSettings().isUseDefaults();
    }

    @NotNull
    public Set<Route> getRoutes(boolean z) {
        Set<Route> defaultSet = this.root.getGeneralSettings().getDefaultSet();
        if (canUseDefaults()) {
            defaultSet.addAll(this.defaults.getRoutes(z));
        }
        addData((route, entry) -> {
            defaultSet.add(route);
        }, null, z);
        return defaultSet;
    }

    @NotNull
    public Set<String> getRoutesAsStrings(boolean z) {
        Set<String> defaultSet = this.root.getGeneralSettings().getDefaultSet();
        if (canUseDefaults()) {
            defaultSet.addAll(this.defaults.getRoutesAsStrings(z));
        }
        addData((str, entry) -> {
            defaultSet.add(str);
        }, new StringBuilder(), this.root.getGeneralSettings().getRouteSeparator(), z);
        return defaultSet;
    }

    @NotNull
    public Set<Object> getKeys() {
        Set<Object> defaultSet = this.root.getGeneralSettings().getDefaultSet(getStoredValue().size());
        if (canUseDefaults()) {
            defaultSet.addAll(this.defaults.getKeys());
        }
        defaultSet.addAll(getStoredValue().keySet());
        return defaultSet;
    }

    @NotNull
    public Map<Route, Object> getRouteMappedValues(boolean z) {
        Map<Route, Object> defaultMap = this.root.getGeneralSettings().getDefaultMap();
        if (canUseDefaults()) {
            defaultMap.putAll(this.defaults.getRouteMappedValues(z));
        }
        addData((route, entry) -> {
            defaultMap.put(route, entry.getValue() instanceof Section ? entry.getValue() : ((Block) entry.getValue()).getStoredValue());
        }, null, z);
        return defaultMap;
    }

    @NotNull
    public Map<String, Object> getStringRouteMappedValues(boolean z) {
        Map<String, Object> defaultMap = this.root.getGeneralSettings().getDefaultMap();
        if (canUseDefaults()) {
            defaultMap.putAll(this.defaults.getStringRouteMappedValues(z));
        }
        addData((str, entry) -> {
            defaultMap.put(str, entry.getValue() instanceof Section ? entry.getValue() : ((Block) entry.getValue()).getStoredValue());
        }, new StringBuilder(), this.root.getGeneralSettings().getRouteSeparator(), z);
        return defaultMap;
    }

    @NotNull
    public Map<Route, Block<?>> getRouteMappedBlocks(boolean z) {
        Map<Route, Block<?>> defaultMap = this.root.getGeneralSettings().getDefaultMap();
        if (canUseDefaults()) {
            defaultMap.putAll(this.defaults.getRouteMappedBlocks(z));
        }
        addData((route, entry) -> {
        }, null, z);
        return defaultMap;
    }

    @NotNull
    public Map<String, Block<?>> getStringRouteMappedBlocks(boolean z) {
        Map<String, Block<?>> defaultMap = this.root.getGeneralSettings().getDefaultMap();
        if (canUseDefaults()) {
            defaultMap.putAll(this.defaults.getStringRouteMappedBlocks(z));
        }
        addData((str, entry) -> {
        }, new StringBuilder(), this.root.getGeneralSettings().getRouteSeparator(), z);
        return defaultMap;
    }

    private void addData(@NotNull BiConsumer<Route, Map.Entry<?, Block<?>>> biConsumer, @Nullable Route route, boolean z) {
        Iterator<Map.Entry<Object, Block<?>>> it = getStoredValue().entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<?, Block<?>> entry = (Map.Entry) it.next();
            Route routeAddTo = Route.addTo(route, entry.getKey());
            biConsumer.accept(routeAddTo, entry);
            if (z && (entry.getValue() instanceof Section)) {
                ((Section) entry.getValue()).addData(biConsumer, routeAddTo, true);
            }
        }
    }

    private void addData(@NotNull BiConsumer<String, Map.Entry<?, Block<?>>> biConsumer, @NotNull StringBuilder sb, char c, boolean z) {
        Iterator<Map.Entry<Object, Block<?>>> it = getStoredValue().entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<?, Block<?>> entry = (Map.Entry) it.next();
            int length = sb.length();
            if (length > 0) {
                sb.append(c);
            }
            biConsumer.accept(sb.append(entry.getKey().toString()).toString(), entry);
            if (z && (entry.getValue() instanceof Section)) {
                ((Section) entry.getValue()).addData(biConsumer, sb, c, true);
            }
            sb.setLength(length);
        }
    }

    public boolean contains(@NotNull Route route) {
        return getBlock(route) != null;
    }

    public boolean contains(@NotNull String str) {
        return getBlock(str) != null;
    }

    public Section createSection(@NotNull Route route) {
        Section sectionCreateSectionInternal = this;
        for (int i = 0; i < route.length(); i++) {
            sectionCreateSectionInternal = sectionCreateSectionInternal.createSectionInternal(route.get(i), null);
        }
        return sectionCreateSectionInternal;
    }

    public Section createSection(@NotNull String str) {
        int i = 0;
        Section sectionCreateSectionInternal = this;
        while (true) {
            int iIndexOf = str.indexOf(this.root.getGeneralSettings().getRouteSeparator(), i);
            if (iIndexOf != -1) {
                sectionCreateSectionInternal = sectionCreateSectionInternal.createSectionInternal(str.substring(i, iIndexOf), null);
                i = iIndexOf + 1;
            } else {
                return sectionCreateSectionInternal.createSectionInternal(str.substring(i), null);
            }
        }
    }

    private Section createSectionInternal(@NotNull Object obj, @Nullable Block<?> block) {
        Object objAdaptKey = adaptKey(obj);
        return getOptionalSection(Route.from(objAdaptKey)).orElseGet(() -> {
            Section section = new Section(this.root, this, getSubRoute(objAdaptKey), block, this.root.getGeneralSettings().getDefaultMap());
            getStoredValue().put(objAdaptKey, section);
            return section;
        });
    }

    public void repopulate(@NotNull Map<Object, Block<?>> map) {
        clear();
        map.forEach((v1, v2) -> {
            setInternal(v1, v2);
        });
    }

    public void setAll(@NotNull Map<Route, Object> map) {
        map.forEach(this::set);
    }

    public void set(@NotNull Route route, @Nullable Object obj) {
        traverse(route, true).ifPresent(blockReference -> {
            blockReference.parent.setInternal(blockReference.key, obj);
        });
    }

    public void set(@NotNull String str, @Nullable Object obj) {
        traverse(str, true).ifPresent(blockReference -> {
            blockReference.parent.setInternal(blockReference.key, obj);
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setInternal(@NotNull Object obj, @Nullable Object obj2) {
        if (obj2 instanceof Section) {
            Section section = (Section) obj2;
            if (section.isRoot()) {
                throw new IllegalArgumentException("Cannot set root section as the value!");
            }
            if (section.getRoot().getGeneralSettings().getKeyFormat() != getRoot().getGeneralSettings().getKeyFormat()) {
                throw new IllegalArgumentException("Cannot move sections between files with different key formats!");
            }
            getStoredValue().put(obj, section);
            section.adapt(this.root, this, getSubRoute(obj));
            return;
        }
        if (obj2 instanceof TerminatedBlock) {
            getStoredValue().put(obj, (TerminatedBlock) obj2);
            return;
        }
        if (obj2 instanceof Map) {
            getStoredValue().put(obj, new Section(this.root, this, getSubRoute(obj), getStoredValue().getOrDefault(obj, null), (Map) obj2));
            return;
        }
        Block<?> block = getStoredValue().get(obj);
        if (block == null) {
            getStoredValue().put(obj, new TerminatedBlock(null, null, obj2));
        } else {
            getStoredValue().put(obj, new TerminatedBlock(block, obj2));
        }
    }

    @Nullable
    public Block<?> move(@NotNull Route route, @NotNull Route route2) {
        return (Block) traverse(route, false).map(blockReference -> {
            return blockReference.parent.getStoredValue().remove(blockReference.key);
        }).map(block -> {
            set(route2, block);
            return block;
        }).orElse(null);
    }

    @Nullable
    public Block<?> move(@NotNull String str, @NotNull String str2) {
        return (Block) traverse(str, false).map(blockReference -> {
            return blockReference.parent.getStoredValue().remove(blockReference.key);
        }).map(block -> {
            set(str2, block);
            return block;
        }).orElse(null);
    }

    private Optional<BlockReference> traverse(@NotNull Route route, boolean z) {
        int i = -1;
        Section sectionCreateSectionInternal = this;
        while (true) {
            Section section = sectionCreateSectionInternal;
            i++;
            Object objAdaptKey = adaptKey(route.get(i));
            if (i + 1 == route.length()) {
                return Optional.of(new BlockReference(section, objAdaptKey, null));
            }
            Block<?> orDefault = section.getStoredValue().getOrDefault(objAdaptKey, null);
            if (orDefault instanceof Section) {
                sectionCreateSectionInternal = (Section) orDefault;
            } else {
                if (!z) {
                    return Optional.empty();
                }
                sectionCreateSectionInternal = section.createSectionInternal(objAdaptKey, orDefault);
            }
        }
    }

    private Optional<BlockReference> traverse(@NotNull String str, boolean z) {
        int i = 0;
        Section sectionCreateSectionInternal = this;
        while (true) {
            Section section = sectionCreateSectionInternal;
            int iIndexOf = str.indexOf(this.root.getGeneralSettings().getRouteSeparator(), i);
            if (iIndexOf == -1) {
                return Optional.of(new BlockReference(section, str.substring(i), null));
            }
            String strSubstring = str.substring(i, iIndexOf);
            Block<?> orDefault = section.getStoredValue().getOrDefault(strSubstring, null);
            i = iIndexOf + 1;
            if (orDefault instanceof Section) {
                sectionCreateSectionInternal = (Section) orDefault;
            } else {
                if (!z) {
                    return Optional.empty();
                }
                sectionCreateSectionInternal = section.createSectionInternal(strSubstring, orDefault);
            }
        }
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/block/implementation/Section$BlockReference.class */
    private static class BlockReference {

        @NotNull
        private final Section parent;

        @NotNull
        private final Object key;
        private static transient /* synthetic */ String mnqqvVnoSL = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

        /* synthetic */ BlockReference(Section section, Object obj, C00101 c00101) {
            this(section, obj);
        }

        private BlockReference(@NotNull Section section, @NotNull Object obj) {
            this.parent = section;
            this.key = obj;
        }
    }

    public boolean remove(@NotNull Route route) {
        return removeInternal(getParent(route).orElse(null), adaptKey(route.get(route.length() - 1)));
    }

    public boolean remove(@NotNull String str) {
        return removeInternal(getParent(str).orElse(null), str.substring(str.lastIndexOf(this.root.getGeneralSettings().getRouteSeparator()) + 1));
    }

    private boolean removeInternal(@Nullable Section section, @Nullable Object obj) {
        return (section == null || section.getStoredValue().remove(obj) == null) ? false : true;
    }

    public void clear() {
        getStoredValue().clear();
    }

    public Optional<Block<?>> getOptionalBlock(@NotNull Route route) {
        return getBlockInternal(route, false);
    }

    private Optional<Block<?>> getDirectOptionalBlock(@NotNull Object obj) {
        return Optional.ofNullable(getStoredValue().get(adaptKey(obj)));
    }

    public Optional<Block<?>> getOptionalBlock(@NotNull String str) {
        return str.indexOf(this.root.getGeneralSettings().getRouteSeparator()) != -1 ? getBlockInternalString(str, false) : getDirectOptionalBlock(str);
    }

    public Block<?> getBlock(@NotNull Route route) {
        return getOptionalBlock(route).orElseGet(() -> {
            if (canUseDefaults()) {
                return this.defaults.getBlock(route);
            }
            return null;
        });
    }

    public Block<?> getBlock(@NotNull String str) {
        return getOptionalBlock(str).orElseGet(() -> {
            if (canUseDefaults()) {
                return this.defaults.getBlock(str);
            }
            return null;
        });
    }

    private Optional<Block<?>> getBlockInternalString(@NotNull String str, boolean z) {
        int i = 0;
        Section section = this;
        while (true) {
            int iIndexOf = str.indexOf(this.root.getGeneralSettings().getRouteSeparator(), i);
            if (iIndexOf == -1) {
                return Optional.ofNullable(z ? section : section.getStoredValue().get(str.substring(i)));
            }
            Block<?> orDefault = section.getStoredValue().getOrDefault(str.substring(i, iIndexOf), null);
            if (!(orDefault instanceof Section)) {
                return Optional.empty();
            }
            section = (Section) orDefault;
            i = iIndexOf + 1;
        }
    }

    private Optional<Block<?>> getBlockInternal(@NotNull Route route, boolean z) {
        int i = -1;
        Section section = this;
        while (true) {
            Section section2 = section;
            i++;
            if (i >= route.length() - 1) {
                return Optional.ofNullable(z ? section2 : section2.getStoredValue().get(adaptKey(route.get(i))));
            }
            Block<?> orDefault = section2.getStoredValue().getOrDefault(adaptKey(route.get(i)), null);
            if (!(orDefault instanceof Section)) {
                return Optional.empty();
            }
            section = (Section) orDefault;
        }
    }

    public Optional<Section> getParent(@NotNull Route route) {
        return getBlockInternal(route, true).map(block -> {
            if (block instanceof Section) {
                return (Section) block;
            }
            return null;
        });
    }

    public Optional<Section> getParent(@NotNull String str) {
        return getBlockInternalString(str, true).map(block -> {
            if (block instanceof Section) {
                return (Section) block;
            }
            return null;
        });
    }

    public Optional<Object> getOptional(@NotNull Route route) {
        return getOptionalBlock(route).map(block -> {
            return block instanceof Section ? block : block.getStoredValue();
        });
    }

    public Optional<Object> getOptional(@NotNull String str) {
        return getOptionalBlock(str).map(block -> {
            return block instanceof Section ? block : block.getStoredValue();
        });
    }

    public Object get(@NotNull Route route) {
        return getOptional(route).orElseGet(() -> {
            return canUseDefaults() ? this.defaults.get(route) : this.root.getGeneralSettings().getDefaultObject();
        });
    }

    public Object get(@NotNull String str) {
        return getOptional(str).orElseGet(() -> {
            return canUseDefaults() ? this.defaults.get(str) : this.root.getGeneralSettings().getDefaultObject();
        });
    }

    public Object get(@NotNull Route route, @Nullable Object obj) {
        return getOptional(route).orElse(obj);
    }

    public Object get(@NotNull String str, @Nullable Object obj) {
        return getOptional(str).orElse(obj);
    }

    public <T> Optional<T> getAsOptional(@NotNull Route route, @NotNull Class<T> cls) {
        return (Optional<T>) getOptional(route).map(obj -> {
            if (cls.isInstance(obj)) {
                return obj;
            }
            if (PrimitiveConversions.isNumber(obj.getClass()) && PrimitiveConversions.isNumber(cls)) {
                return PrimitiveConversions.convertNumber(obj, cls);
            }
            if (PrimitiveConversions.NON_NUMERIC_CONVERSIONS.containsKey(obj.getClass()) && PrimitiveConversions.NON_NUMERIC_CONVERSIONS.containsKey(cls)) {
                return obj;
            }
            return null;
        });
    }

    public <T> Optional<T> getAsOptional(@NotNull String str, @NotNull Class<T> cls) {
        return (Optional<T>) getOptional(str).map(obj -> {
            if (cls.isInstance(obj)) {
                return obj;
            }
            if (PrimitiveConversions.isNumber(obj.getClass()) && PrimitiveConversions.isNumber(cls)) {
                return PrimitiveConversions.convertNumber(obj, cls);
            }
            if (PrimitiveConversions.NON_NUMERIC_CONVERSIONS.containsKey(obj.getClass()) && PrimitiveConversions.NON_NUMERIC_CONVERSIONS.containsKey(cls)) {
                return obj;
            }
            return null;
        });
    }

    public <T> T getAs(@NotNull Route route, @NotNull Class<T> cls) {
        return getAsOptional(route, cls).orElseGet(() -> {
            if (canUseDefaults()) {
                return this.defaults.getAs(route, cls);
            }
            return null;
        });
    }

    public <T> T getAs(@NotNull String str, @NotNull Class<T> cls) {
        return getAsOptional(str, cls).orElseGet(() -> {
            if (canUseDefaults()) {
                return this.defaults.getAs(str, cls);
            }
            return null;
        });
    }

    public <T> T getAs(@NotNull Route route, @NotNull Class<T> cls, @Nullable T t) {
        return getAsOptional(route, cls).orElse(t);
    }

    public <T> T getAs(@NotNull String str, @NotNull Class<T> cls, @Nullable T t) {
        return getAsOptional(str, cls).orElse(t);
    }

    public <T> boolean is(@NotNull Route route, @NotNull Class<T> cls) {
        Object obj = get(route);
        return PrimitiveConversions.PRIMITIVES_TO_OBJECTS.containsKey(cls) ? PrimitiveConversions.PRIMITIVES_TO_OBJECTS.get(cls).isInstance(obj) : cls.isInstance(obj);
    }

    public <T> boolean is(@NotNull String str, @NotNull Class<T> cls) {
        Object obj = get(str);
        return PrimitiveConversions.PRIMITIVES_TO_OBJECTS.containsKey(cls) ? PrimitiveConversions.PRIMITIVES_TO_OBJECTS.get(cls).isInstance(obj) : cls.isInstance(obj);
    }

    public Optional<Section> getOptionalSection(@NotNull Route route) {
        return getAsOptional(route, Section.class);
    }

    public Optional<Section> getOptionalSection(@NotNull String str) {
        return getAsOptional(str, Section.class);
    }

    public Section getSection(@NotNull Route route) {
        return getOptionalSection(route).orElseGet(() -> {
            if (canUseDefaults()) {
                return this.defaults.getSection(route);
            }
            return null;
        });
    }

    public Section getSection(@NotNull String str) {
        return getOptionalSection(str).orElseGet(() -> {
            if (canUseDefaults()) {
                return this.defaults.getSection(str);
            }
            return null;
        });
    }

    public Section getSection(@NotNull Route route, @Nullable Section section) {
        return getOptionalSection(route).orElse(section);
    }

    public Section getSection(@NotNull String str, @Nullable Section section) {
        return getOptionalSection(str).orElse(section);
    }

    public boolean isSection(@NotNull Route route) {
        return get(route) instanceof Section;
    }

    public boolean isSection(@NotNull String str) {
        return get(str) instanceof Section;
    }

    public Optional<String> getOptionalString(@NotNull Route route) {
        return getOptional(route).map((v0) -> {
            return v0.toString();
        });
    }

    public Optional<String> getOptionalString(@NotNull String str) {
        return getOptional(str).map((v0) -> {
            return v0.toString();
        });
    }

    public String getString(@NotNull Route route) {
        return getOptionalString(route).orElseGet(() -> {
            return canUseDefaults() ? this.defaults.getString(route) : this.root.getGeneralSettings().getDefaultString();
        });
    }

    public String getString(@NotNull String str) {
        return getOptionalString(str).orElseGet(() -> {
            return canUseDefaults() ? this.defaults.getString(str) : this.root.getGeneralSettings().getDefaultString();
        });
    }

    public String getString(@NotNull Route route, @Nullable String str) {
        return getOptionalString(route).orElse(str);
    }

    public String getString(@NotNull String str, @Nullable String str2) {
        return getOptionalString(str).orElse(str2);
    }

    public boolean isString(@NotNull Route route) {
        return get(route) instanceof String;
    }

    public boolean isString(@NotNull String str) {
        return get(str) instanceof String;
    }

    public <T extends Enum<T>> Optional<T> getOptionalEnum(@NotNull Route route, @NotNull Class<T> cls) {
        return (Optional<T>) getOptional(route).map(obj -> {
            return toEnum(obj, cls);
        });
    }

    public <T extends Enum<T>> Optional<T> getOptionalEnum(@NotNull String str, @NotNull Class<T> cls) {
        return (Optional<T>) getOptionalString(str).map(str2 -> {
            return toEnum(str2, cls);
        });
    }

    public <T extends Enum<T>> T getEnum(@NotNull Route route, @NotNull Class<T> cls) {
        return getOptionalEnum(route, cls).orElseGet(() -> {
            if (canUseDefaults()) {
                return this.defaults.getEnum(route, cls);
            }
            return null;
        });
    }

    public <T extends Enum<T>> T getEnum(@NotNull String str, @NotNull Class<T> cls) {
        return getOptionalEnum(str, cls).orElseGet(() -> {
            if (canUseDefaults()) {
                return this.defaults.getEnum(str, cls);
            }
            return null;
        });
    }

    public <T extends Enum<T>> T getEnum(@NotNull Route route, @NotNull Class<T> cls, @Nullable T t) {
        return getOptionalEnum(route, cls).orElse(t);
    }

    public <T extends Enum<T>> T getEnum(@NotNull String str, @NotNull Class<T> cls, @Nullable T t) {
        return getOptionalEnum(str, cls).orElse(t);
    }

    public <T extends Enum<T>> boolean isEnum(@NotNull Route route, @NotNull Class<T> cls) {
        return toEnum(get(route), cls) != null;
    }

    public <T extends Enum<T>> boolean isEnum(@NotNull String str, @NotNull Class<T> cls) {
        return toEnum(get(str), cls) != null;
    }

    private <T extends Enum<T>> T toEnum(@Nullable Object obj, @NotNull Class<T> cls) {
        if (obj == null) {
            return null;
        }
        if (cls.isInstance(obj)) {
            return (T) obj;
        }
        if (obj instanceof Enum) {
            return null;
        }
        try {
            return (T) Enum.valueOf(cls, obj.toString());
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    public Optional<Character> getOptionalChar(@NotNull Route route) {
        return getOptional(route).map(this::toChar);
    }

    public Optional<Character> getOptionalChar(@NotNull String str) {
        return getOptional(str).map(this::toChar);
    }

    public Character getChar(@NotNull Route route) {
        return getOptionalChar(route).orElseGet(() -> {
            return canUseDefaults() ? this.defaults.getChar(route) : this.root.getGeneralSettings().getDefaultChar();
        });
    }

    public Character getChar(@NotNull String str) {
        return getOptionalChar(str).orElseGet(() -> {
            return canUseDefaults() ? this.defaults.getChar(str) : this.root.getGeneralSettings().getDefaultChar();
        });
    }

    public Character getChar(@NotNull Route route, @Nullable Character ch) {
        return getOptionalChar(route).orElse(ch);
    }

    public Character getChar(@NotNull String str, @Nullable Character ch) {
        return getOptionalChar(str).orElse(ch);
    }

    public boolean isChar(@NotNull Route route) {
        return toChar(get(route)) != null;
    }

    public boolean isChar(@NotNull String str) {
        return toChar(get(str)) != null;
    }

    private Character toChar(@Nullable Object obj) {
        if (obj == null) {
            return null;
        }
        if (obj instanceof Character) {
            return (Character) obj;
        }
        if (obj instanceof Integer) {
            return Character.valueOf((char) ((Integer) obj).intValue());
        }
        if ((obj instanceof String) && obj.toString().length() == 1) {
            return Character.valueOf(obj.toString().charAt(0));
        }
        return null;
    }

    public Optional<Number> getOptionalNumber(@NotNull Route route) {
        return getAsOptional(route, Number.class);
    }

    public Optional<Number> getOptionalNumber(@NotNull String str) {
        return getAsOptional(str, Number.class);
    }

    public Number getNumber(@NotNull Route route) {
        return getOptionalNumber(route).orElseGet(() -> {
            return canUseDefaults() ? this.defaults.getNumber(route) : this.root.getGeneralSettings().getDefaultNumber();
        });
    }

    public Number getNumber(@NotNull String str) {
        return getOptionalNumber(str).orElseGet(() -> {
            return canUseDefaults() ? this.defaults.getNumber(str) : this.root.getGeneralSettings().getDefaultNumber();
        });
    }

    public Number getNumber(@NotNull Route route, @Nullable Number number) {
        return getOptionalNumber(route).orElse(number);
    }

    public Number getNumber(@NotNull String str, @Nullable Number number) {
        return getOptionalNumber(str).orElse(number);
    }

    public boolean isNumber(@NotNull Route route) {
        return get(route) instanceof Number;
    }

    public boolean isNumber(@NotNull String str) {
        return get(str) instanceof Number;
    }

    public Optional<Integer> getOptionalInt(@NotNull Route route) {
        return PrimitiveConversions.toInt(getAs(route, Number.class));
    }

    public Optional<Integer> getOptionalInt(@NotNull String str) {
        return PrimitiveConversions.toInt(getAs(str, Number.class));
    }

    public Integer getInt(@NotNull Route route) {
        return getOptionalInt(route).orElseGet(() -> {
            return Integer.valueOf(canUseDefaults() ? this.defaults.getInt(route).intValue() : this.root.getGeneralSettings().getDefaultNumber().intValue());
        });
    }

    public Integer getInt(@NotNull String str) {
        return getOptionalInt(str).orElseGet(() -> {
            return Integer.valueOf(canUseDefaults() ? this.defaults.getInt(str).intValue() : this.root.getGeneralSettings().getDefaultNumber().intValue());
        });
    }

    public Integer getInt(@NotNull Route route, @Nullable Integer num) {
        return getOptionalInt(route).orElse(num);
    }

    public Integer getInt(@NotNull String str, @Nullable Integer num) {
        return getOptionalInt(str).orElse(num);
    }

    public boolean isInt(@NotNull Route route) {
        return get(route) instanceof Integer;
    }

    public boolean isInt(@NotNull String str) {
        return get(str) instanceof Integer;
    }

    public Optional<BigInteger> getOptionalBigInt(@NotNull Route route) {
        return PrimitiveConversions.toBigInt(getAs(route, Number.class));
    }

    public Optional<BigInteger> getOptionalBigInt(@NotNull String str) {
        return PrimitiveConversions.toBigInt(getAs(str, Number.class));
    }

    public BigInteger getBigInt(@NotNull Route route) {
        return getOptionalBigInt(route).orElseGet(() -> {
            return canUseDefaults() ? this.defaults.getBigInt(route) : BigInteger.valueOf(this.root.getGeneralSettings().getDefaultNumber().longValue());
        });
    }

    public BigInteger getBigInt(@NotNull String str) {
        return getOptionalBigInt(str).orElseGet(() -> {
            return canUseDefaults() ? this.defaults.getBigInt(str) : BigInteger.valueOf(this.root.getGeneralSettings().getDefaultNumber().longValue());
        });
    }

    public BigInteger getBigInt(@NotNull Route route, @Nullable BigInteger bigInteger) {
        return getOptionalBigInt(route).orElse(bigInteger);
    }

    public BigInteger getBigInt(@NotNull String str, @Nullable BigInteger bigInteger) {
        return getOptionalBigInt(str).orElse(bigInteger);
    }

    public boolean isBigInt(@NotNull Route route) {
        return get(route) instanceof BigInteger;
    }

    public boolean isBigInt(@NotNull String str) {
        return get(str) instanceof BigInteger;
    }

    public Optional<Boolean> getOptionalBoolean(@NotNull Route route) {
        return getAsOptional(route, Boolean.class);
    }

    public Optional<Boolean> getOptionalBoolean(@NotNull String str) {
        return getAsOptional(str, Boolean.class);
    }

    public Boolean getBoolean(@NotNull Route route) {
        return getOptionalBoolean(route).orElseGet(() -> {
            return canUseDefaults() ? this.defaults.getBoolean(route) : this.root.getGeneralSettings().getDefaultBoolean();
        });
    }

    public Boolean getBoolean(@NotNull String str) {
        return getOptionalBoolean(str).orElseGet(() -> {
            return canUseDefaults() ? this.defaults.getBoolean(str) : this.root.getGeneralSettings().getDefaultBoolean();
        });
    }

    public Boolean getBoolean(@NotNull Route route, @Nullable Boolean bool) {
        return getOptionalBoolean(route).orElse(bool);
    }

    public Boolean getBoolean(@NotNull String str, @Nullable Boolean bool) {
        return getOptionalBoolean(str).orElse(bool);
    }

    public boolean isBoolean(@NotNull Route route) {
        return get(route) instanceof Boolean;
    }

    public boolean isBoolean(@NotNull String str) {
        return get(str) instanceof Boolean;
    }

    public Optional<Double> getOptionalDouble(@NotNull Route route) {
        return PrimitiveConversions.toDouble(getAs(route, Number.class));
    }

    public Optional<Double> getOptionalDouble(@NotNull String str) {
        return PrimitiveConversions.toDouble(getAs(str, Number.class));
    }

    public Double getDouble(@NotNull Route route) {
        return getOptionalDouble(route).orElseGet(() -> {
            return Double.valueOf(canUseDefaults() ? this.defaults.getDouble(route).doubleValue() : this.root.getGeneralSettings().getDefaultNumber().doubleValue());
        });
    }

    public Double getDouble(@NotNull String str) {
        return getOptionalDouble(str).orElseGet(() -> {
            return Double.valueOf(canUseDefaults() ? this.defaults.getDouble(str).doubleValue() : this.root.getGeneralSettings().getDefaultNumber().doubleValue());
        });
    }

    public Double getDouble(@NotNull Route route, @Nullable Double d) {
        return getOptionalDouble(route).orElse(d);
    }

    public Double getDouble(@NotNull String str, @Nullable Double d) {
        return getOptionalDouble(str).orElse(d);
    }

    public boolean isDouble(@NotNull Route route) {
        return get(route) instanceof Double;
    }

    public boolean isDouble(@NotNull String str) {
        return get(str) instanceof Double;
    }

    public Optional<Float> getOptionalFloat(@NotNull Route route) {
        return PrimitiveConversions.toFloat(getAs(route, Number.class));
    }

    public Optional<Float> getOptionalFloat(@NotNull String str) {
        return PrimitiveConversions.toFloat(getAs(str, Number.class));
    }

    public Float getFloat(@NotNull Route route) {
        return getOptionalFloat(route).orElseGet(() -> {
            return Float.valueOf(canUseDefaults() ? this.defaults.getFloat(route).floatValue() : this.root.getGeneralSettings().getDefaultNumber().floatValue());
        });
    }

    public Float getFloat(@NotNull String str) {
        return getOptionalFloat(str).orElseGet(() -> {
            return Float.valueOf(canUseDefaults() ? this.defaults.getFloat(str).floatValue() : this.root.getGeneralSettings().getDefaultNumber().floatValue());
        });
    }

    public Float getFloat(@NotNull Route route, @Nullable Float f) {
        return getOptionalFloat(route).orElse(f);
    }

    public Float getFloat(@NotNull String str, @Nullable Float f) {
        return getOptionalFloat(str).orElse(f);
    }

    public boolean isFloat(@NotNull Route route) {
        return get(route) instanceof Float;
    }

    public boolean isFloat(@NotNull String str) {
        return get(str) instanceof Float;
    }

    public Optional<Byte> getOptionalByte(@NotNull Route route) {
        return PrimitiveConversions.toByte(getAs(route, Number.class));
    }

    public Optional<Byte> getOptionalByte(@NotNull String str) {
        return PrimitiveConversions.toByte(getAs(str, Number.class));
    }

    public Byte getByte(@NotNull Route route) {
        return getOptionalByte(route).orElseGet(() -> {
            return Byte.valueOf(canUseDefaults() ? this.defaults.getByte(route).byteValue() : this.root.getGeneralSettings().getDefaultNumber().byteValue());
        });
    }

    public Byte getByte(@NotNull String str) {
        return getOptionalByte(str).orElseGet(() -> {
            return Byte.valueOf(canUseDefaults() ? this.defaults.getByte(str).byteValue() : this.root.getGeneralSettings().getDefaultNumber().byteValue());
        });
    }

    public Byte getByte(@NotNull Route route, @Nullable Byte b) {
        return getOptionalByte(route).orElse(b);
    }

    public Byte getByte(@NotNull String str, @Nullable Byte b) {
        return getOptionalByte(str).orElse(b);
    }

    public boolean isByte(@NotNull Route route) {
        return get(route) instanceof Byte;
    }

    public boolean isByte(@NotNull String str) {
        return get(str) instanceof Byte;
    }

    public Optional<Long> getOptionalLong(@NotNull Route route) {
        return PrimitiveConversions.toLong(getAs(route, Number.class));
    }

    public Optional<Long> getOptionalLong(String str) {
        return PrimitiveConversions.toLong(getAs(str, Number.class));
    }

    public Long getLong(@NotNull Route route) {
        return getOptionalLong(route).orElseGet(() -> {
            return Long.valueOf(canUseDefaults() ? this.defaults.getLong(route).longValue() : this.root.getGeneralSettings().getDefaultNumber().longValue());
        });
    }

    public Long getLong(@NotNull String str) {
        return getOptionalLong(str).orElseGet(() -> {
            return Long.valueOf(canUseDefaults() ? this.defaults.getLong(str).longValue() : this.root.getGeneralSettings().getDefaultNumber().longValue());
        });
    }

    public Long getLong(@NotNull Route route, @Nullable Long l) {
        return getOptionalLong(route).orElse(l);
    }

    public Long getLong(@NotNull String str, @Nullable Long l) {
        return getOptionalLong(str).orElse(l);
    }

    public boolean isLong(@NotNull Route route) {
        return get(route) instanceof Long;
    }

    public boolean isLong(@NotNull String str) {
        return get(str) instanceof Long;
    }

    public Optional<Short> getOptionalShort(@NotNull Route route) {
        return PrimitiveConversions.toShort(getAs(route, Number.class));
    }

    public Optional<Short> getOptionalShort(@NotNull String str) {
        return PrimitiveConversions.toShort(getAs(str, Number.class));
    }

    public Short getShort(@NotNull Route route) {
        return getOptionalShort(route).orElseGet(() -> {
            return Short.valueOf(canUseDefaults() ? this.defaults.getShort(route).shortValue() : this.root.getGeneralSettings().getDefaultNumber().shortValue());
        });
    }

    public Short getShort(@NotNull String str) {
        return getOptionalShort(str).orElseGet(() -> {
            return Short.valueOf(canUseDefaults() ? this.defaults.getShort(str).shortValue() : this.root.getGeneralSettings().getDefaultNumber().shortValue());
        });
    }

    public Short getShort(@NotNull Route route, @Nullable Short sh) {
        return getOptionalShort(route).orElse(sh);
    }

    public Short getShort(@NotNull String str, @Nullable Short sh) {
        return getOptionalShort(str).orElse(sh);
    }

    public boolean isShort(@NotNull Route route) {
        return get(route) instanceof Short;
    }

    public boolean isShort(@NotNull String str) {
        return get(str) instanceof Short;
    }

    public boolean isDecimal(@NotNull Route route) {
        Object obj = get(route);
        return (obj instanceof Double) || (obj instanceof Float);
    }

    public boolean isDecimal(@NotNull String str) {
        Object obj = get(str);
        return (obj instanceof Double) || (obj instanceof Float);
    }

    public Optional<List<?>> getOptionalList(@NotNull Route route) {
        return getAsOptional(route, List.class).map(list -> {
            return list;
        });
    }

    public Optional<List<?>> getOptionalList(@NotNull String str) {
        return getAsOptional(str, List.class).map(list -> {
            return list;
        });
    }

    public List<?> getList(@NotNull Route route) {
        return getOptionalList(route).orElseGet(() -> {
            return canUseDefaults() ? this.defaults.getList(route) : this.root.getGeneralSettings().getDefaultList();
        });
    }

    public List<?> getList(@NotNull String str) {
        return getOptionalList(str).orElseGet(() -> {
            return canUseDefaults() ? this.defaults.getList(str) : this.root.getGeneralSettings().getDefaultList();
        });
    }

    public List<?> getList(@NotNull Route route, @Nullable List<?> list) {
        return getOptionalList(route).orElse(list);
    }

    public List<?> getList(@NotNull String str, @Nullable List<?> list) {
        return getOptionalList(str).orElse(list);
    }

    public boolean isList(@NotNull Route route) {
        return get(route) instanceof List;
    }

    public boolean isList(@NotNull String str) {
        return get(str) instanceof List;
    }

    public Optional<List<String>> getOptionalStringList(@NotNull Route route) {
        return ListConversions.toStringList(getList(route, (List<?>) null));
    }

    public Optional<List<String>> getOptionalStringList(@NotNull String str) {
        return ListConversions.toStringList(getList(str, (List<?>) null));
    }

    public List<String> getStringList(@NotNull Route route, @Nullable List<String> list) {
        return getOptionalStringList(route).orElse(list);
    }

    public List<String> getStringList(@NotNull String str, @Nullable List<String> list) {
        return getOptionalStringList(str).orElse(list);
    }

    public List<String> getStringList(@NotNull Route route) {
        return getOptionalStringList(route).orElseGet(() -> {
            return canUseDefaults() ? this.defaults.getStringList(route) : this.root.getGeneralSettings().getDefaultList();
        });
    }

    public List<String> getStringList(@NotNull String str) {
        return getOptionalStringList(str).orElseGet(() -> {
            return canUseDefaults() ? this.defaults.getStringList(str) : this.root.getGeneralSettings().getDefaultList();
        });
    }

    public Optional<List<Integer>> getOptionalIntList(@NotNull Route route) {
        return ListConversions.toIntList(getList(route, (List<?>) null));
    }

    public Optional<List<Integer>> getOptionalIntList(@NotNull String str) {
        return ListConversions.toIntList(getList(str, (List<?>) null));
    }

    public List<Integer> getIntList(@NotNull Route route, @Nullable List<Integer> list) {
        return getOptionalIntList(route).orElse(list);
    }

    public List<Integer> getIntList(@NotNull String str, @Nullable List<Integer> list) {
        return getOptionalIntList(str).orElse(list);
    }

    public List<Integer> getIntList(@NotNull Route route) {
        return getOptionalIntList(route).orElseGet(() -> {
            return canUseDefaults() ? this.defaults.getIntList(route) : this.root.getGeneralSettings().getDefaultList();
        });
    }

    public List<Integer> getIntList(@NotNull String str) {
        return getOptionalIntList(str).orElseGet(() -> {
            return canUseDefaults() ? this.defaults.getIntList(str) : this.root.getGeneralSettings().getDefaultList();
        });
    }

    public Optional<List<BigInteger>> getOptionalBigIntList(@NotNull Route route) {
        return ListConversions.toBigIntList(getList(route, (List<?>) null));
    }

    public Optional<List<BigInteger>> getOptionalBigIntList(@NotNull String str) {
        return ListConversions.toBigIntList(getList(str, (List<?>) null));
    }

    public List<BigInteger> getBigIntList(@NotNull Route route, @Nullable List<BigInteger> list) {
        return getOptionalBigIntList(route).orElse(list);
    }

    public List<BigInteger> getBigIntList(@NotNull String str, @Nullable List<BigInteger> list) {
        return getOptionalBigIntList(str).orElse(list);
    }

    public List<BigInteger> getBigIntList(@NotNull Route route) {
        return getOptionalBigIntList(route).orElseGet(() -> {
            return canUseDefaults() ? this.defaults.getBigIntList(route) : this.root.getGeneralSettings().getDefaultList();
        });
    }

    public List<BigInteger> getBigIntList(@NotNull String str) {
        return getOptionalBigIntList(str).orElseGet(() -> {
            return canUseDefaults() ? this.defaults.getBigIntList(str) : this.root.getGeneralSettings().getDefaultList();
        });
    }

    public Optional<List<Byte>> getOptionalByteList(@NotNull Route route) {
        return ListConversions.toByteList(getList(route, (List<?>) null));
    }

    public Optional<List<Byte>> getOptionalByteList(@NotNull String str) {
        return ListConversions.toByteList(getList(str, (List<?>) null));
    }

    public List<Byte> getByteList(@NotNull Route route, @Nullable List<Byte> list) {
        return getOptionalByteList(route).orElse(list);
    }

    public List<Byte> getByteList(@NotNull String str, @Nullable List<Byte> list) {
        return getOptionalByteList(str).orElse(list);
    }

    public List<Byte> getByteList(@NotNull Route route) {
        return getOptionalByteList(route).orElseGet(() -> {
            return canUseDefaults() ? this.defaults.getByteList(route) : this.root.getGeneralSettings().getDefaultList();
        });
    }

    public List<Byte> getByteList(@NotNull String str) {
        return getOptionalByteList(str).orElseGet(() -> {
            return canUseDefaults() ? this.defaults.getByteList(str) : this.root.getGeneralSettings().getDefaultList();
        });
    }

    public Optional<List<Long>> getOptionalLongList(@NotNull Route route) {
        return ListConversions.toLongList(getList(route, (List<?>) null));
    }

    public Optional<List<Long>> getOptionalLongList(@NotNull String str) {
        return ListConversions.toLongList(getList(str, (List<?>) null));
    }

    public List<Long> getLongList(@NotNull Route route, @Nullable List<Long> list) {
        return getOptionalLongList(route).orElse(list);
    }

    public List<Long> getLongList(@NotNull String str, @Nullable List<Long> list) {
        return getOptionalLongList(str).orElse(list);
    }

    public List<Long> getLongList(@NotNull Route route) {
        return getOptionalLongList(route).orElseGet(() -> {
            return canUseDefaults() ? this.defaults.getLongList(route) : this.root.getGeneralSettings().getDefaultList();
        });
    }

    public List<Long> getLongList(@NotNull String str) {
        return getOptionalLongList(str).orElseGet(() -> {
            return canUseDefaults() ? this.defaults.getLongList(str) : this.root.getGeneralSettings().getDefaultList();
        });
    }

    public Optional<List<Double>> getOptionalDoubleList(@NotNull Route route) {
        return ListConversions.toDoubleList(getList(route, (List<?>) null));
    }

    public Optional<List<Double>> getOptionalDoubleList(@NotNull String str) {
        return ListConversions.toDoubleList(getList(str, (List<?>) null));
    }

    public List<Double> getDoubleList(@NotNull Route route, @Nullable List<Double> list) {
        return getOptionalDoubleList(route).orElse(list);
    }

    public List<Double> getDoubleList(@NotNull String str, @Nullable List<Double> list) {
        return getOptionalDoubleList(str).orElse(list);
    }

    public List<Double> getDoubleList(@NotNull Route route) {
        return getOptionalDoubleList(route).orElseGet(() -> {
            return canUseDefaults() ? this.defaults.getDoubleList(route) : this.root.getGeneralSettings().getDefaultList();
        });
    }

    public List<Double> getDoubleList(@NotNull String str) {
        return getOptionalDoubleList(str).orElseGet(() -> {
            return canUseDefaults() ? this.defaults.getDoubleList(str) : this.root.getGeneralSettings().getDefaultList();
        });
    }

    public Optional<List<Float>> getOptionalFloatList(@NotNull Route route) {
        return ListConversions.toFloatList(getList(route, (List<?>) null));
    }

    public Optional<List<Float>> getOptionalFloatList(@NotNull String str) {
        return ListConversions.toFloatList(getList(str, (List<?>) null));
    }

    public List<Float> getFloatList(@NotNull Route route, @Nullable List<Float> list) {
        return getOptionalFloatList(route).orElse(list);
    }

    public List<Float> getFloatList(@NotNull String str, @Nullable List<Float> list) {
        return getOptionalFloatList(str).orElse(list);
    }

    public List<Float> getFloatList(@NotNull Route route) {
        return getOptionalFloatList(route).orElseGet(() -> {
            return canUseDefaults() ? this.defaults.getFloatList(route) : this.root.getGeneralSettings().getDefaultList();
        });
    }

    public List<Float> getFloatList(@NotNull String str) {
        return getOptionalFloatList(str).orElseGet(() -> {
            return canUseDefaults() ? this.defaults.getFloatList(str) : this.root.getGeneralSettings().getDefaultList();
        });
    }

    public Optional<List<Short>> getOptionalShortList(@NotNull Route route) {
        return ListConversions.toShortList(getList(route, (List<?>) null));
    }

    public Optional<List<Short>> getOptionalShortList(@NotNull String str) {
        return ListConversions.toShortList(getList(str, (List<?>) null));
    }

    public List<Short> getShortList(@NotNull Route route, @Nullable List<Short> list) {
        return getOptionalShortList(route).orElse(list);
    }

    public List<Short> getShortList(@NotNull String str, @Nullable List<Short> list) {
        return getOptionalShortList(str).orElse(list);
    }

    public List<Short> getShortList(@NotNull Route route) {
        return getOptionalShortList(route).orElseGet(() -> {
            return canUseDefaults() ? this.defaults.getShortList(route) : this.root.getGeneralSettings().getDefaultList();
        });
    }

    public List<Short> getShortList(@NotNull String str) {
        return getOptionalShortList(str).orElseGet(() -> {
            return canUseDefaults() ? this.defaults.getShortList(str) : this.root.getGeneralSettings().getDefaultList();
        });
    }

    public Optional<List<Map<?, ?>>> getOptionalMapList(@NotNull Route route) {
        return ListConversions.toMapList(getList(route, (List<?>) null));
    }

    public Optional<List<Map<?, ?>>> getOptionalMapList(@NotNull String str) {
        return ListConversions.toMapList(getList(str, (List<?>) null));
    }

    public List<Map<?, ?>> getMapList(@NotNull Route route, @Nullable List<Map<?, ?>> list) {
        return getOptionalMapList(route).orElse(list);
    }

    public List<Map<?, ?>> getMapList(@NotNull String str, @Nullable List<Map<?, ?>> list) {
        return getOptionalMapList(str).orElse(list);
    }

    public List<Map<?, ?>> getMapList(@NotNull Route route) {
        return getOptionalMapList(route).orElseGet(() -> {
            return canUseDefaults() ? this.defaults.getMapList(route) : this.root.getGeneralSettings().getDefaultList();
        });
    }

    public List<Map<?, ?>> getMapList(@NotNull String str) {
        return getOptionalMapList(str).orElseGet(() -> {
            return canUseDefaults() ? this.defaults.getMapList(str) : this.root.getGeneralSettings().getDefaultList();
        });
    }
}
