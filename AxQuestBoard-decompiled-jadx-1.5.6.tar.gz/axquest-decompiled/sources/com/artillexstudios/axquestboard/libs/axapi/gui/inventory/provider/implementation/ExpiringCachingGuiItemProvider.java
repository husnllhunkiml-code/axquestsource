package com.artillexstudios.axquestboard.libs.axapi.gui.inventory.provider.implementation;

import com.artillexstudios.axquestboard.libs.axapi.context.HashMapContext;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.BakedGuiItem;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.GuiItem;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.modifier.WrappedItemStackModifier;
import com.artillexstudios.axquestboard.libs.axapi.gui.inventory.provider.GuiItemProvider;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/gui/inventory/provider/implementation/ExpiringCachingGuiItemProvider.class */
public class ExpiringCachingGuiItemProvider implements GuiItemProvider {
    private final SimpleGuiItemProvider simpleProvider;
    private final long durationMillis;
    private CompletableFuture<BakedGuiItem> provided;
    private HashMapContext lastContext;
    private long lastCheck = 0;
    private static transient /* synthetic */ String KZrlOHiRZV = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public ExpiringCachingGuiItemProvider(GuiItem item, Duration duration) {
        this.simpleProvider = new SimpleGuiItemProvider(item);
        this.durationMillis = duration.toMillis();
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.gui.inventory.provider.GuiItemProvider
    public CompletableFuture<BakedGuiItem> provide(HashMapContext context, List<WrappedItemStackModifier> modifiers) {
        long jCurrentTimeMillis = System.currentTimeMillis();
        if (this.provided != null && this.lastContext.equals(context) && jCurrentTimeMillis - this.lastCheck < this.durationMillis) {
            return this.provided;
        }
        this.lastCheck = jCurrentTimeMillis;
        this.lastContext = context;
        this.provided = this.simpleProvider.provide(context, modifiers);
        return this.provided;
    }
}
