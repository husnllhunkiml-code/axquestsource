package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.constructor;

import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.error.Mark;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/constructor/DuplicateKeyException.class */
public class DuplicateKeyException extends ConstructorException {
    private static transient /* synthetic */ String HXsjaVymXW = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    protected DuplicateKeyException(Mark mark, Object obj, Mark mark2) {
        super("while constructing a mapping", mark, "found duplicate key " + obj, mark2);
    }
}
