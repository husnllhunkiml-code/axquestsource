package com.artillexstudios.axquestboard.libs.axapi.items.component;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/items/component/DataComponent.class */
public interface DataComponent<T> {
    void apply(Object item, T t);

    T get(Object item);
}
