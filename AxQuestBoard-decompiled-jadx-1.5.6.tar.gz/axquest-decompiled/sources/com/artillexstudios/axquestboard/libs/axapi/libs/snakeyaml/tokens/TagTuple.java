package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.tokens;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/tokens/TagTuple.class */
public final class TagTuple {
    private final String handle;
    private final String suffix;
    private static transient /* synthetic */ String nItQRIiASL = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public TagTuple(String str, String str2) {
        if (str2 == null) {
            throw new NullPointerException("Suffix must be provided.");
        }
        this.handle = str;
        this.suffix = str2;
    }

    public String getHandle() {
        return this.handle;
    }

    public String getSuffix() {
        return this.suffix;
    }
}
