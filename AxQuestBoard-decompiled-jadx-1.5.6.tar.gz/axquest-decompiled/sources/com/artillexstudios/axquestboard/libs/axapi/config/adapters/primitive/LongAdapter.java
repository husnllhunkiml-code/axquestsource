package com.artillexstudios.axquestboard.libs.axapi.config.adapters.primitive;

import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter;
import com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapterHolder;
import java.lang.reflect.Type;
import java.math.BigInteger;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/adapters/primitive/LongAdapter.class */
public final class LongAdapter implements TypeAdapter<Long, Long> {
    private static transient /* synthetic */ String hrINylhRRz = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    /* JADX WARN: Can't rename method to resolve collision */
    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public Long deserialize(TypeAdapterHolder registry, Object input, Type type) {
        if (input instanceof Number) {
            return getValue((Number) input);
        }
        if (input instanceof String) {
            return getValue(Double.valueOf(Double.parseDouble((String) input)));
        }
        throw new IllegalArgumentException("Can't make a long from a " + String.valueOf(input.getClass()));
    }

    private Long getValue(Number number) {
        return number instanceof BigInteger ? Long.valueOf(((BigInteger) number).longValueExact()) : Long.valueOf(number.longValue());
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.config.adapters.TypeAdapter
    public Long serialize(TypeAdapterHolder registry, Long value, Type type) {
        return value;
    }
}
