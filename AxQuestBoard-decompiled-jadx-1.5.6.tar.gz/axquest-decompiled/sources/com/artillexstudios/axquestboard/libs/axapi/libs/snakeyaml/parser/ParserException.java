package com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.parser;

import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.error.Mark;
import com.artillexstudios.axquestboard.libs.axapi.libs.snakeyaml.error.MarkedYAMLException;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/snakeyaml/parser/ParserException.class */
public class ParserException extends MarkedYAMLException {
    private static final long serialVersionUID = -2349253802798398038L;
    private static transient /* synthetic */ String BOoaYdIuih = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public ParserException(String str, Mark mark, String str2, Mark mark2) {
        super(str, mark, str2, mark2, null, null);
    }
}
