package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.comments.CommentType;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.Mark;
import java.util.Objects;
import java.util.Optional;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/events/CommentEvent.class */
public final class CommentEvent extends Event {
    private final CommentType type;
    private final String value;
    private static transient /* synthetic */ String LwDflMTebP = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public CommentEvent(CommentType commentType, String str, Optional<Mark> optional, Optional<Mark> optional2) {
        super(optional, optional2);
        Objects.requireNonNull(commentType);
        this.type = commentType;
        Objects.requireNonNull(str);
        this.value = str;
    }

    public String getValue() {
        return this.value;
    }

    public CommentType getCommentType() {
        return this.type;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.events.Event
    public Event.ID getEventId() {
        return Event.ID.Comment;
    }

    public String toString() {
        return "=COM " + this.type + " " + this.value;
    }
}
