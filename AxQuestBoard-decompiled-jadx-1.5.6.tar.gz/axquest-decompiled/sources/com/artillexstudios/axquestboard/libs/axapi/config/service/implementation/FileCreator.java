package com.artillexstudios.axquestboard.libs.axapi.config.service.implementation;

import com.artillexstudios.axquestboard.libs.axapi.config.service.Writer;
import com.artillexstudios.axquestboard.libs.axapi.utils.logging.LogUtils;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/config/service/implementation/FileCreator.class */
public final class FileCreator {
    private final Writer writer;
    private static transient /* synthetic */ String bdgKNYnWxP = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public FileCreator(Writer writer) {
        this.writer = writer;
    }

    public boolean create(Path path, InputStream defaults) {
        if (Files.exists(path, new LinkOption[0])) {
            if (Files.isDirectory(path, new LinkOption[0])) {
                LogUtils.error("Failed to load file at {}! File is a directory!", path);
                try {
                    Files.delete(path);
                    return true;
                } catch (IOException e) {
                    LogUtils.error("An unexpected error occurred while deleting directory which should have been a file!", e);
                    return false;
                }
            }
            return true;
        }
        try {
            if (defaults != null) {
                this.writer.write(path, new String(defaults.readAllBytes(), StandardCharsets.UTF_8));
            } else {
                this.writer.write(path, null);
            }
            return true;
        } catch (IOException e2) {
            LogUtils.error("Failed to read bytes from defaults stream!", new Object[0]);
            return false;
        }
    }
}
