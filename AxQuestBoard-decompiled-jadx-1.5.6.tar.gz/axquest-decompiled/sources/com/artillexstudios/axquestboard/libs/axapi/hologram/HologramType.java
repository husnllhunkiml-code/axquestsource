package com.artillexstudios.axquestboard.libs.axapi.hologram;

import com.artillexstudios.axquestboard.libs.axapi.hologram.page.HologramPage;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.runtime.ObjectMethods;
import org.apache.commons.lang3.function.TriFunction;
import org.bukkit.Location;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/hologram/HologramType.class */
public final class HologramType<T> extends Record {
    private final TriFunction<Hologram, Boolean, Location, HologramPage<T, ?>> function;
    private static transient /* synthetic */ String DeFhpJkUjt = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public HologramType(TriFunction<Hologram, Boolean, Location, HologramPage<T, ?>> function) {
        this.function = function;
    }

    @Override // java.lang.Record
    public final String toString() {
        return (String) ObjectMethods.bootstrap(MethodHandles.lookup(), "toString", MethodType.methodType(String.class, HologramType.class), HologramType.class, "function", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/hologram/HologramType;->function:Lorg/apache/commons/lang3/function/TriFunction;").dynamicInvoker().invoke(this) /* invoke-custom */;
    }

    @Override // java.lang.Record
    public final int hashCode() {
        return (int) ObjectMethods.bootstrap(MethodHandles.lookup(), "hashCode", MethodType.methodType(Integer.TYPE, HologramType.class), HologramType.class, "function", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/hologram/HologramType;->function:Lorg/apache/commons/lang3/function/TriFunction;").dynamicInvoker().invoke(this) /* invoke-custom */;
    }

    @Override // java.lang.Record
    public final boolean equals(Object o) {
        return (boolean) ObjectMethods.bootstrap(MethodHandles.lookup(), "equals", MethodType.methodType(Boolean.TYPE, HologramType.class, Object.class), HologramType.class, "function", "FIELD:Lcom/artillexstudios/axquestboard/libs/axapi/hologram/HologramType;->function:Lorg/apache/commons/lang3/function/TriFunction;").dynamicInvoker().invoke(this, o) /* invoke-custom */;
    }

    public TriFunction<Hologram, Boolean, Location, HologramPage<T, ?>> function() {
        return this.function;
    }

    public HologramPage<T, ?> create(Hologram hologram, boolean isFirstPage, Location location) {
        return (HologramPage) this.function.apply(hologram, Boolean.valueOf(isFirstPage), location);
    }
}
