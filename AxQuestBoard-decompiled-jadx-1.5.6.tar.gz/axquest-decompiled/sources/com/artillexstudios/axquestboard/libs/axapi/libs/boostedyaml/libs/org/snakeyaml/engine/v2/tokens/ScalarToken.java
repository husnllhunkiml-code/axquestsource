package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.ScalarStyle;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.exceptions.Mark;
import java.util.Objects;
import java.util.Optional;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/libs/org/snakeyaml/engine/v2/tokens/ScalarToken.class */
public final class ScalarToken extends Token {
    private final String value;
    private final boolean plain;
    private final ScalarStyle style;
    private static transient /* synthetic */ String exMSDjJGdW = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public ScalarToken(String str, boolean z, Optional<Mark> optional, Optional<Mark> optional2) {
        this(str, z, ScalarStyle.PLAIN, optional, optional2);
    }

    public ScalarToken(String str, boolean z, ScalarStyle scalarStyle, Optional<Mark> optional, Optional<Mark> optional2) {
        super(optional, optional2);
        Objects.requireNonNull(str);
        this.value = str;
        this.plain = z;
        Objects.requireNonNull(scalarStyle);
        this.style = scalarStyle;
    }

    public boolean isPlain() {
        return this.plain;
    }

    public String getValue() {
        return this.value;
    }

    public ScalarStyle getStyle() {
        return this.style;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.Token
    public Token.ID getTokenId() {
        return Token.ID.Scalar;
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.tokens.Token
    public String toString() {
        return getTokenId().toString() + " plain=" + this.plain + " style=" + this.style + " value=" + this.value;
    }
}
