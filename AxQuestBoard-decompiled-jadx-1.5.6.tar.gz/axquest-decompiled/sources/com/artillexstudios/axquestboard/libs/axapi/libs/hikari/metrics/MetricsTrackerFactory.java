package com.artillexstudios.axquestboard.libs.axapi.libs.hikari.metrics;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/hikari/metrics/MetricsTrackerFactory.class */
public interface MetricsTrackerFactory {
    IMetricsTracker create(String str, PoolStats poolStats);
}
