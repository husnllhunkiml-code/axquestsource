package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.updater;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.block.Block;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.block.implementation.Section;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.route.Route;
import java.util.function.BiFunction;
import java.util.function.Function;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/settings/updater/ValueMapper.class */
public interface ValueMapper {
    @Nullable
    default Object map(@NotNull Section section, @NotNull Route key) {
        return map(section.getBlock(key));
    }

    @Nullable
    default Object map(@NotNull Block<?> block) {
        return map(block.getStoredValue());
    }

    @Nullable
    default Object map(@Nullable Object value) {
        return value;
    }

    static ValueMapper section(final BiFunction<Section, Route, Object> mapper) {
        return new ValueMapper() { // from class: com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.updater.ValueMapper.1
            private static transient /* synthetic */ String FHFmtvYMxD = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

            @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.updater.ValueMapper
            public Object map(@NotNull Section section, @NotNull Route route) {
                return mapper.apply(section, route);
            }
        };
    }

    static ValueMapper block(final Function<Block<?>, Object> mapper) {
        return new ValueMapper() { // from class: com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.updater.ValueMapper.2
            private static transient /* synthetic */ String NCgIibgRNb = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

            @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.updater.ValueMapper
            public Object map(@NotNull Block<?> block) {
                return mapper.apply(block);
            }
        };
    }

    static ValueMapper value(final Function<Object, Object> mapper) {
        return new ValueMapper() { // from class: com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.updater.ValueMapper.3
            private static transient /* synthetic */ String XUSgnfRfsN = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

            @Override // com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.updater.ValueMapper
            public Object map(@Nullable Object obj) {
                return mapper.apply(obj);
            }
        };
    }
}
