package com.artillexstudios.axquestboard.libs.axapi.gui.configuration.actions.implementation;

import com.artillexstudios.axquestboard.libs.axapi.context.HashMapContext;
import com.artillexstudios.axquestboard.libs.axapi.gui.configuration.actions.Action;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryCloseEvent;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/gui/configuration/actions/implementation/CloseAction.class */
public final class CloseAction extends Action<Object> {
    private static transient /* synthetic */ String KmjIdJCNWB = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    public CloseAction(String data) {
        super(data);
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.gui.configuration.actions.Action
    public Object transform(String data) {
        return "";
    }

    @Override // com.artillexstudios.axquestboard.libs.axapi.gui.configuration.actions.Action
    public void run(Player player, HashMapContext context) {
        player.closeInventory(InventoryCloseEvent.Reason.PLUGIN);
    }
}
