package com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.dumper;

import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.DumpSettings;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.api.DumpSettingsBuilder;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.FlowStyle;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.NonPrintableStyle;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.ScalarStyle;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.common.SpecVersion;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.nodes.Tag;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.schema.Schema;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.serializer.AnchorGenerator;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.libs.org.snakeyaml.engine.v2.serializer.NumberAnchorGenerator;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.Settings;
import com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.utils.format.Formatter;
import java.util.Map;
import java.util.Optional;
import java.util.function.Supplier;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/settings/dumper/DumperSettings.class */
public class DumperSettings implements Settings {
    public static final DumperSettings DEFAULT = builder().build();
    private final DumpSettingsBuilder builder;
    private final Supplier<AnchorGenerator> generatorSupplier;
    private final ScalarStyle stringStyle;
    private final Formatter<ScalarStyle, String> scalarFormatter;
    private final Formatter<FlowStyle, Iterable<?>> sequenceFormatter;
    private final Formatter<FlowStyle, Map<?, ?>> mappingFormatter;
    private static transient /* synthetic */ String fiWAsQOWbV = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";

    /* JADX INFO: renamed from: com.artillexstudios.axquestboard.libs.axapi.libs.boostedyaml.settings.dumper.DumperSettings$1 */
    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/settings/dumper/DumperSettings$1.class */
    static /* synthetic */ class C00221 {
        private static transient /* synthetic */ String DjmWaEUWoE = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";
    }

    /* synthetic */ DumperSettings(Builder builder, C00221 c00221) {
        this(builder);
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/settings/dumper/DumperSettings$Encoding.class */
    public enum Encoding {
        UNICODE,
        ASCII;

        boolean isUnicode() {
            return this == UNICODE;
        }
    }

    private DumperSettings(Builder builder) {
        this.builder = builder.builder;
        this.generatorSupplier = builder.anchorGeneratorSupplier;
        this.scalarFormatter = builder.scalarFormatter;
        this.sequenceFormatter = builder.sequenceFormatter;
        this.mappingFormatter = builder.mappingFormatter;
        this.stringStyle = builder.stringStyle;
    }

    public DumpSettings buildEngineSettings() {
        return this.builder.setAnchorGenerator(this.generatorSupplier.get()).setDumpComments(true).build();
    }

    public ScalarStyle getStringStyle() {
        return this.stringStyle;
    }

    public Formatter<ScalarStyle, String> getScalarFormatter() {
        return this.scalarFormatter;
    }

    public Formatter<FlowStyle, Iterable<?>> getSequenceFormatter() {
        return this.sequenceFormatter;
    }

    public Formatter<FlowStyle, Map<?, ?>> getMappingFormatter() {
        return this.mappingFormatter;
    }

    public static Builder builder() {
        return new Builder((C00221) null);
    }

    public static Builder builder(DumpSettingsBuilder dumpSettingsBuilder) {
        return new Builder(dumpSettingsBuilder, null);
    }

    public static Builder builder(DumperSettings dumperSettings) {
        return builder(dumperSettings.builder).setAnchorGenerator(dumperSettings.generatorSupplier);
    }

    /* JADX INFO: loaded from: questPluginSpacyBoyDecompileNowUPDATENOW.jar:com/artillexstudios/axquestboard/libs/axapi/libs/boostedyaml/settings/dumper/DumperSettings$Builder.class */
    public static class Builder {
        public static final boolean DEFAULT_START_MARKER = false;
        public static final boolean DEFAULT_END_MARKER = false;
        public static final boolean DEFAULT_CANONICAL = false;
        public static final boolean DEFAULT_MULTILINE_FORMAT = false;
        public static final int DEFAULT_INDENTATION = 2;
        public static final int DEFAULT_INDICATOR_INDENTATION = 0;
        public static final int DEFAULT_MAX_LINE_WIDTH = 0;
        public static final int DEFAULT_MAX_SIMPLE_KEY_LENGTH = 0;
        public static final boolean DEFAULT_ESCAPE_UNPRINTABLE = true;
        private final DumpSettingsBuilder builder;
        private Supplier<AnchorGenerator> anchorGeneratorSupplier;
        private Formatter<ScalarStyle, String> scalarFormatter;
        private Formatter<FlowStyle, Iterable<?>> sequenceFormatter;
        private Formatter<FlowStyle, Map<?, ?>> mappingFormatter;
        private ScalarStyle stringStyle;
        private static transient /* synthetic */ String fnUobVdErd = "jejLp5oqX1aVJBRWaiJCV5MFiBc3gyeJo7/AqXBycJU=";
        public static final Supplier<AnchorGenerator> DEFAULT_ANCHOR_GENERATOR = () -> {
            return new NumberAnchorGenerator(0);
        };
        public static final FlowStyle DEFAULT_FLOW_STYLE = FlowStyle.BLOCK;
        public static final ScalarStyle DEFAULT_SCALAR_STYLE = ScalarStyle.PLAIN;
        public static final Formatter<ScalarStyle, String> DEFAULT_SCALAR_FORMATTER = Formatter.identity();
        public static final Formatter<FlowStyle, Iterable<?>> DEFAULT_SEQUENCE_FORMATTER = Formatter.identity();
        public static final Formatter<FlowStyle, Map<?, ?>> DEFAULT_MAPPING_FORMATTER = Formatter.identity();
        public static final ScalarStyle DEFAULT_STRING_STYLE = ScalarStyle.PLAIN;
        public static final Tag DEFAULT_ROOT_TAG = null;
        public static final Encoding DEFAULT_ENCODING = Encoding.UNICODE;

        /* synthetic */ Builder(C00221 c00221) {
            this();
        }

        /* synthetic */ Builder(DumpSettingsBuilder dumpSettingsBuilder, C00221 c00221) {
            this(dumpSettingsBuilder);
        }

        private Builder(DumpSettingsBuilder dumpSettingsBuilder) {
            this.anchorGeneratorSupplier = DEFAULT_ANCHOR_GENERATOR;
            this.scalarFormatter = DEFAULT_SCALAR_FORMATTER;
            this.sequenceFormatter = DEFAULT_SEQUENCE_FORMATTER;
            this.mappingFormatter = DEFAULT_MAPPING_FORMATTER;
            this.stringStyle = DEFAULT_STRING_STYLE;
            this.builder = dumpSettingsBuilder;
        }

        private Builder() {
            this.anchorGeneratorSupplier = DEFAULT_ANCHOR_GENERATOR;
            this.scalarFormatter = DEFAULT_SCALAR_FORMATTER;
            this.sequenceFormatter = DEFAULT_SEQUENCE_FORMATTER;
            this.mappingFormatter = DEFAULT_MAPPING_FORMATTER;
            this.stringStyle = DEFAULT_STRING_STYLE;
            this.builder = DumpSettings.builder();
            setFlowStyle(DEFAULT_FLOW_STYLE);
            setScalarStyle(DEFAULT_SCALAR_STYLE);
            setStringStyle(DEFAULT_STRING_STYLE);
            setStartMarker(false);
            setEndMarker(false);
            setRootTag(DEFAULT_ROOT_TAG);
            setCanonicalForm(false);
            setMultilineStyle(false);
            setEncoding(DEFAULT_ENCODING);
            setIndentation(2);
            setIndicatorIndentation(0);
            setLineWidth(0);
            setMaxSimpleKeyLength(0);
            setEscapeUnprintable(true);
        }

        public Builder setAnchorGenerator(@NotNull Supplier<AnchorGenerator> supplier) {
            this.anchorGeneratorSupplier = supplier;
            return this;
        }

        public Builder setFlowStyle(@NotNull FlowStyle flowStyle) {
            this.builder.setDefaultFlowStyle(flowStyle);
            return this;
        }

        public Builder setScalarStyle(@NotNull ScalarStyle scalarStyle) {
            this.builder.setDefaultScalarStyle(scalarStyle);
            return this;
        }

        public Builder setScalarFormatter(@NotNull Formatter<ScalarStyle, String> formatter) {
            this.scalarFormatter = formatter;
            return this;
        }

        public Builder setSequenceFormatter(@NotNull Formatter<FlowStyle, Iterable<?>> formatter) {
            this.sequenceFormatter = formatter;
            return this;
        }

        public Builder setMappingFormatter(@NotNull Formatter<FlowStyle, Map<?, ?>> formatter) {
            this.mappingFormatter = formatter;
            return this;
        }

        @Deprecated
        public Builder setStringStyle(@NotNull ScalarStyle scalarStyle) {
            this.stringStyle = scalarStyle;
            return this;
        }

        public Builder setStartMarker(boolean z) {
            this.builder.setExplicitStart(z);
            return this;
        }

        public Builder setEndMarker(boolean z) {
            this.builder.setExplicitEnd(z);
            return this;
        }

        public Builder setSchema(@NotNull Schema schema) {
            this.builder.setSchema(schema);
            return this;
        }

        public Builder setRootTag(@Nullable Tag tag) {
            this.builder.setExplicitRootTag(Optional.ofNullable(tag));
            return this;
        }

        public Builder setYamlDirective(@Nullable SpecVersion specVersion) {
            this.builder.setYamlDirective(Optional.ofNullable(specVersion));
            return this;
        }

        public Builder setTagDirectives(@NotNull Map<String, String> map) {
            this.builder.setTagDirective(map);
            return this;
        }

        public Builder setCanonicalForm(boolean z) {
            this.builder.setCanonical(z);
            return this;
        }

        public Builder setMultilineStyle(boolean z) {
            this.builder.setMultiLineFlow(z);
            return this;
        }

        public Builder setEncoding(@NotNull Encoding encoding) {
            this.builder.setUseUnicodeEncoding(encoding.isUnicode());
            return this;
        }

        public Builder setIndentation(int i) {
            this.builder.setIndent(i);
            return this;
        }

        public Builder setIndicatorIndentation(int i) {
            this.builder.setIndentWithIndicator(i > 0);
            this.builder.setIndicatorIndent(Math.max(i, 0));
            return this;
        }

        public Builder setLineWidth(int i) {
            this.builder.setWidth(i <= 0 ? Integer.MAX_VALUE : i);
            return this;
        }

        public Builder setLineBreak(@NotNull String str) {
            this.builder.setBestLineBreak(str);
            return this;
        }

        public Builder setMaxSimpleKeyLength(int i) {
            if (i > 1018) {
                throw new IllegalArgumentException("Maximum simple key length is limited to 1018!");
            }
            this.builder.setMaxSimpleKeyLength(i <= 0 ? 1024 : i + 6);
            return this;
        }

        public Builder setEscapeUnprintable(boolean z) {
            return setUnprintableStyle(z ? NonPrintableStyle.ESCAPE : NonPrintableStyle.BINARY);
        }

        public Builder setUnprintableStyle(@NotNull NonPrintableStyle nonPrintableStyle) {
            this.builder.setNonPrintableStyle(nonPrintableStyle);
            return this;
        }

        public DumperSettings build() {
            return new DumperSettings(this, null);
        }
    }
}
